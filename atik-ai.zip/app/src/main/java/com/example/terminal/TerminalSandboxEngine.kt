package com.example.terminal

import android.os.Build
import com.example.python.PythonSandboxEngine
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class TerminalLine(
    val type: TerminalLineType,
    val text: String
)

enum class TerminalLineType {
    INPUT,
    OUTPUT,
    ERROR,
    SYSTEM,
    SUCCESS
}

class TerminalSandboxEngine(
    private val pythonEngine: PythonSandboxEngine = PythonSandboxEngine()
) {
    private var currentDir: String = "/home/atik"
    val history = mutableListOf<String>()

    // In-memory safe virtual file system
    private val fileSystem = mutableMapOf<String, String>(
        "/home/atik/welcome.txt" to "Welcome to Atik AI Mobile Linux & Termux Sandbox!\nSafe, isolated execution environment for Atikur Rahman.",
        "/home/atik/hello.py" to "name = 'Atik Bhai'\nprint(f'Hello, {name}! Atik AI is ready.')\nfor i in range(3):\n    print('Run iteration:', i + 1)",
        "/home/atik/notes.txt" to "1. Complete AI Assistant platform\n2. Integrate Python Sandbox\n3. Test Live Voice & Vision Assistant",
        "/etc/os-release" to "NAME=\"Atik AI Termux OS\"\nVERSION=\"2.5.0-LTS\"\nID=atik-linux\nPRETTY_NAME=\"Atik AI Mobile Linux Sandbox (aarch64)\"",
        "/etc/hostname" to "atik-ai"
    )

    private val directories = mutableSetOf(
        "/",
        "/bin",
        "/etc",
        "/home",
        "/home/atik",
        "/home/atik/scripts",
        "/storage",
        "/tmp"
    )

    fun getCurrentDir(): String = currentDir

    suspend fun executeCommand(
        commandLine: String,
        onGeminiQuery: (suspend (String) -> String)? = null,
        onMemoryAction: (suspend (action: String, arg: String) -> String)? = null,
        onHardwareAction: (suspend (action: String, arg: String) -> String)? = null,
        remoteBackendUrl: String? = null
    ): List<TerminalLine> = withContext(Dispatchers.Default) {
        val trimmed = commandLine.trim()
        if (trimmed.isEmpty()) return@withContext emptyList()

        history.add(trimmed)
        val result = mutableListOf<TerminalLine>()

        // Check if remote backend is requested
        if (!remoteBackendUrl.isNullOrBlank()) {
            return@withContext executeRemoteCommand(trimmed, remoteBackendUrl)
        }

        val parts = trimmed.split(Regex("\\s+"))
        val cmd = parts[0].lowercase()
        val args = if (parts.size > 1) parts.subList(1, parts.size) else emptyList()

        when (cmd) {
            "help" -> {
                result.add(TerminalLine(TerminalLineType.SYSTEM, "=== Atik AI Termux & Kali Linux Sandbox Help ==="))
                result.add(TerminalLine(TerminalLineType.OUTPUT, "Core System Commands:"))
                result.add(TerminalLine(TerminalLineType.OUTPUT, "  help                  - Show this help manual"))
                result.add(TerminalLine(TerminalLineType.OUTPUT, "  whoami                - Display current user"))
                result.add(TerminalLine(TerminalLineType.OUTPUT, "  uname [-a]           - Print kernel & system architecture"))
                result.add(TerminalLine(TerminalLineType.OUTPUT, "  pwd                   - Print current working directory"))
                result.add(TerminalLine(TerminalLineType.OUTPUT, "  ls [-la] [dir]        - List directory contents"))
                result.add(TerminalLine(TerminalLineType.OUTPUT, "  cd [dir]              - Change directory"))
                result.add(TerminalLine(TerminalLineType.OUTPUT, "  cat [file]            - View content of a file"))
                result.add(TerminalLine(TerminalLineType.OUTPUT, "  echo [text] [> file]  - Output string or write to file"))
                result.add(TerminalLine(TerminalLineType.OUTPUT, "  touch [file]          - Create a new empty file"))
                result.add(TerminalLine(TerminalLineType.OUTPUT, "  mkdir [dir]           - Create directory"))
                result.add(TerminalLine(TerminalLineType.OUTPUT, "  rm [-rf] [file]       - Remove file or directory"))
                result.add(TerminalLine(TerminalLineType.OUTPUT, "  python [file / -c]    - Execute Python in secure sandbox"))
                result.add(TerminalLine(TerminalLineType.OUTPUT, "  date                  - Display current date and time"))
                result.add(TerminalLine(TerminalLineType.OUTPUT, "  uptime                - Device & assistant uptime"))
                result.add(TerminalLine(TerminalLineType.OUTPUT, "  history               - Show command history"))
                result.add(TerminalLine(TerminalLineType.OUTPUT, "  top / ps              - Active virtual processes"))
                result.add(TerminalLine(TerminalLineType.OUTPUT, "  env                   - Show environment variables"))
                result.add(TerminalLine(TerminalLineType.OUTPUT, "  ping [host]           - Network latency check"))
                result.add(TerminalLine(TerminalLineType.OUTPUT, "  ifconfig / ip addr    - Display network interface IPs"))
                result.add(TerminalLine(TerminalLineType.OUTPUT, "  sysinfo               - Live device & hardware telemetry"))
                result.add(TerminalLine(TerminalLineType.OUTPUT, ""))
                result.add(TerminalLine(TerminalLineType.SYSTEM, "Kali Linux & Developer Tools:"))
                result.add(TerminalLine(TerminalLineType.OUTPUT, "  kali                  - Launch Kali Linux ethical environment"))
                result.add(TerminalLine(TerminalLineType.OUTPUT, "  neofetch              - Display system specs & ASCII logo"))
                result.add(TerminalLine(TerminalLineType.OUTPUT, "  nmap [target]         - Network security port scanner"))
                result.add(TerminalLine(TerminalLineType.OUTPUT, "  msfconsole            - Metasploit penetration framework"))
                result.add(TerminalLine(TerminalLineType.OUTPUT, "  cmatrix               - Matrix green digital rain"))
                result.add(TerminalLine(TerminalLineType.OUTPUT, "  whois [domain]        - Domain registration lookup"))
                result.add(TerminalLine(TerminalLineType.OUTPUT, "  snake                 - Play Developer Arcade Snake Game 🐍"))
                result.add(TerminalLine(TerminalLineType.OUTPUT, "  termux-torch [on/off] - Toggle hardware flashlight"))
                result.add(TerminalLine(TerminalLineType.OUTPUT, "  termux-battery-status - Hardware battery telemetry"))
                result.add(TerminalLine(TerminalLineType.OUTPUT, "  gemini [prompt]       - Ask Atik AI directly from terminal"))
                result.add(TerminalLine(TerminalLineType.OUTPUT, "  clear                 - Clear terminal screen"))
                result.add(TerminalLine(TerminalLineType.SYSTEM, "Security Note: Isolated sandbox mode active."))
            }

            "whoami" -> {
                result.add(TerminalLine(TerminalLineType.OUTPUT, "atik (Atikur Rahman)"))
            }

            "uname" -> {
                result.add(TerminalLine(TerminalLineType.OUTPUT, "Linux atik-ai 6.1.0-android-aarch64 #1 SMP PREEMPT Termux-Sandbox GNU/Linux"))
            }

            "pwd" -> {
                result.add(TerminalLine(TerminalLineType.OUTPUT, currentDir))
            }

            "ls" -> {
                val targetDir = if (args.isNotEmpty() && !args.last().startsWith("-")) {
                    resolvePath(args.last())
                } else currentDir

                val isDetailed = args.any { it.contains("l") }

                val subDirs = directories.filter {
                    it != targetDir && (if (targetDir == "/") it.count { c -> c == '/' } == 1 else it.startsWith("$targetDir/") && it.substring(targetDir.length + 1).none { c -> c == '/' })
                }.map { it.substringAfterLast('/') }

                val files = fileSystem.keys.filter {
                    val parent = it.substringBeforeLast('/', "/")
                    val normParent = if (parent.isEmpty()) "/" else parent
                    normParent == targetDir
                }.map { it.substringAfterLast('/') }

                if (isDetailed) {
                    result.add(TerminalLine(TerminalLineType.SYSTEM, "total ${subDirs.size + files.size}"))
                    for (d in subDirs.sorted()) {
                        result.add(TerminalLine(TerminalLineType.OUTPUT, "drwxr-xr-x 2 atik atik 4096 Sep 24 12:00 $d/"))
                    }
                    for (f in files.sorted()) {
                        val path = if (targetDir == "/") "/$f" else "$targetDir/$f"
                        val size = fileSystem[path]?.length ?: 0
                        result.add(TerminalLine(TerminalLineType.OUTPUT, "-rw-r--r-- 1 atik atik $size Sep 24 12:00 $f"))
                    }
                } else {
                    val all = (subDirs.map { "$it/" } + files).sorted()
                    if (all.isEmpty()) {
                        result.add(TerminalLine(TerminalLineType.OUTPUT, "[empty directory]"))
                    } else {
                        result.add(TerminalLine(TerminalLineType.OUTPUT, all.joinToString("   ")))
                    }
                }
            }

            "cd" -> {
                val target = if (args.isEmpty()) "/home/atik" else args[0]
                val newPath = resolvePath(target)
                if (directories.contains(newPath)) {
                    currentDir = newPath
                } else {
                    result.add(TerminalLine(TerminalLineType.ERROR, "cd: no such file or directory: $target"))
                }
            }

            "cat" -> {
                if (args.isEmpty()) {
                    result.add(TerminalLine(TerminalLineType.ERROR, "cat: missing file operand"))
                } else {
                    val path = resolvePath(args[0])
                    val content = fileSystem[path]
                    if (content != null) {
                        content.lines().forEach { result.add(TerminalLine(TerminalLineType.OUTPUT, it)) }
                    } else {
                        result.add(TerminalLine(TerminalLineType.ERROR, "cat: ${args[0]}: No such file or directory"))
                    }
                }
            }

            "echo" -> {
                val redirectIdx = args.indexOf(">")
                if (redirectIdx != -1 && redirectIdx < args.size - 1) {
                    val textToSave = args.subList(0, redirectIdx).joinToString(" ").replace("\"", "")
                    val targetFile = resolvePath(args[redirectIdx + 1])
                    fileSystem[targetFile] = textToSave
                    result.add(TerminalLine(TerminalLineType.SUCCESS, "Wrote to $targetFile"))
                } else {
                    val echoText = args.joinToString(" ").replace("\"", "")
                    result.add(TerminalLine(TerminalLineType.OUTPUT, echoText))
                }
            }

            "touch" -> {
                if (args.isEmpty()) {
                    result.add(TerminalLine(TerminalLineType.ERROR, "touch: missing file operand"))
                } else {
                    val path = resolvePath(args[0])
                    if (!fileSystem.containsKey(path)) {
                        fileSystem[path] = ""
                        result.add(TerminalLine(TerminalLineType.SUCCESS, "Created file: $path"))
                    }
                }
            }

            "mkdir" -> {
                if (args.isEmpty()) {
                    result.add(TerminalLine(TerminalLineType.ERROR, "mkdir: missing operand"))
                } else {
                    val path = resolvePath(args[0])
                    directories.add(path)
                    result.add(TerminalLine(TerminalLineType.SUCCESS, "Created directory: $path"))
                }
            }

            "rm" -> {
                if (args.isEmpty()) {
                    result.add(TerminalLine(TerminalLineType.ERROR, "rm: missing operand"))
                } else {
                    val target = args.filter { !it.startsWith("-") }.lastOrNull()
                    if (target != null) {
                        val path = resolvePath(target)
                        if (fileSystem.remove(path) != null) {
                            result.add(TerminalLine(TerminalLineType.SUCCESS, "Removed file $target"))
                        } else if (directories.remove(path)) {
                            result.add(TerminalLine(TerminalLineType.SUCCESS, "Removed directory $target"))
                        } else {
                            result.add(TerminalLine(TerminalLineType.ERROR, "rm: cannot remove '$target': No such file or directory"))
                        }
                    }
                }
            }

            "python", "python3" -> {
                if (args.isEmpty()) {
                    result.add(TerminalLine(TerminalLineType.OUTPUT, "Python 3.12.0 (Atik AI Sandbox Engine)"))
                    result.add(TerminalLine(TerminalLineType.OUTPUT, "Use: python <script.py> or python -c \"code\""))
                } else if (args[0] == "-c" && args.size > 1) {
                    val code = args.subList(1, args.size).joinToString(" ").replace("\"", "")
                    val exec = pythonEngine.execute(code)
                    if (exec.success) {
                        exec.output.lines().forEach { result.add(TerminalLine(TerminalLineType.OUTPUT, it)) }
                    } else {
                        result.add(TerminalLine(TerminalLineType.ERROR, exec.error ?: "Execution error"))
                    }
                } else {
                    val path = resolvePath(args[0])
                    val script = fileSystem[path]
                    if (script != null) {
                        val exec = pythonEngine.execute(script)
                        if (exec.success) {
                            exec.output.lines().forEach { result.add(TerminalLine(TerminalLineType.OUTPUT, it)) }
                        } else {
                            result.add(TerminalLine(TerminalLineType.ERROR, exec.error ?: "Execution error"))
                        }
                    } else {
                        result.add(TerminalLine(TerminalLineType.ERROR, "python: can't open file '${args[0]}': [Errno 2] No such file or directory"))
                    }
                }
            }

            "date" -> {
                val now = SimpleDateFormat("EEE MMM dd HH:mm:ss z yyyy", Locale.US).format(Date())
                result.add(TerminalLine(TerminalLineType.OUTPUT, now))
            }

            "uptime" -> {
                result.add(TerminalLine(TerminalLineType.OUTPUT, " 12:00:00 up 14 days, 3 users,  load average: 0.12, 0.08, 0.05"))
            }

            "history" -> {
                history.forEachIndexed { idx, item ->
                    result.add(TerminalLine(TerminalLineType.OUTPUT, "  ${idx + 1}  $item"))
                }
            }

            "clear" -> {
                // handled by UI to wipe screen
                result.add(TerminalLine(TerminalLineType.SYSTEM, "__CLEAR__"))
            }

            "env" -> {
                result.add(TerminalLine(TerminalLineType.OUTPUT, "USER=atik"))
                result.add(TerminalLine(TerminalLineType.OUTPUT, "HOME=/home/atik"))
                result.add(TerminalLine(TerminalLineType.OUTPUT, "SHELL=/bin/bash"))
                result.add(TerminalLine(TerminalLineType.OUTPUT, "TERM=xterm-256color"))
                result.add(TerminalLine(TerminalLineType.OUTPUT, "ASSISTANT=Atik AI v2.5"))
                result.add(TerminalLine(TerminalLineType.OUTPUT, "LANG=en_US.UTF-8"))
                result.add(TerminalLine(TerminalLineType.OUTPUT, "ARCH=aarch64"))
            }

            "top", "ps" -> {
                result.add(TerminalLine(TerminalLineType.SYSTEM, "PID  USER      PR  NI  VIRT   RES   SHR S  %CPU  %MEM     TIME+ COMMAND"))
                result.add(TerminalLine(TerminalLineType.OUTPUT, "  1  root      20   0  102M   12M    4M S   0.0   0.4   0:01.20 init"))
                result.add(TerminalLine(TerminalLineType.OUTPUT, " 42  atik      20   0  512M   96M   48M S   1.5   2.8   0:04.82 atik-ai-core"))
                result.add(TerminalLine(TerminalLineType.OUTPUT, " 98  atik      20   0  128M   24M   12M S   0.2   0.8   0:00.64 bash"))
                result.add(TerminalLine(TerminalLineType.OUTPUT, "104  atik      20   0  256M   48M   20M R   0.8   1.5   0:00.18 python3"))
            }

            "ping" -> {
                val host = if (args.isNotEmpty()) args[0] else "8.8.8.8"
                result.add(TerminalLine(TerminalLineType.SYSTEM, "PING $host ($host) 56(84) bytes of data."))
                result.add(TerminalLine(TerminalLineType.OUTPUT, "64 bytes from $host: icmp_seq=1 ttl=118 time=14.2 ms"))
                result.add(TerminalLine(TerminalLineType.OUTPUT, "64 bytes from $host: icmp_seq=2 ttl=118 time=13.8 ms"))
                result.add(TerminalLine(TerminalLineType.OUTPUT, "64 bytes from $host: icmp_seq=3 ttl=118 time=15.1 ms"))
                result.add(TerminalLine(TerminalLineType.SYSTEM, "--- $host ping statistics ---"))
                result.add(TerminalLine(TerminalLineType.OUTPUT, "3 packets transmitted, 3 received, 0% packet loss, time 2003ms"))
            }

            "sysinfo" -> {
                result.add(TerminalLine(TerminalLineType.SYSTEM, "=== System & Hardware Telemetry ==="))
                result.add(TerminalLine(TerminalLineType.OUTPUT, "Device Model: ${Build.MANUFACTURER} ${Build.MODEL}"))
                result.add(TerminalLine(TerminalLineType.OUTPUT, "Android Version: ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})"))
                result.add(TerminalLine(TerminalLineType.OUTPUT, "CPU Architecture: ${Build.SUPPORTED_ABIS.joinToString(", ")}"))
                result.add(TerminalLine(TerminalLineType.OUTPUT, "Sandbox Status: Secure Container Active (Isolated)"))
                result.add(TerminalLine(TerminalLineType.OUTPUT, "Atik AI Core: Version 2.5 (Personal Assistant)"))
            }

            "kali" -> {
                result.add(TerminalLine(TerminalLineType.SYSTEM, ".............."))
                result.add(TerminalLine(TerminalLineType.SYSTEM, "            ...,-:;//+>+++///:;:-..."))
                result.add(TerminalLine(TerminalLineType.SYSTEM, "        :++++++++++++++//:::://+++++++:::."))
                result.add(TerminalLine(TerminalLineType.SYSTEM, "       /+++++++/:-````````````` -:/++++++/:."))
                result.add(TerminalLine(TerminalLineType.SYSTEM, "      .+++++/`                      `-/+++++."))
                result.add(TerminalLine(TerminalLineType.SUCCESS, "  🐉 KALI LINUX ETHICAL AUDIT SIMULATOR (v2026.2)"))
                result.add(TerminalLine(TerminalLineType.OUTPUT, "  Personal Security Suite for Atikur Rahman"))
                result.add(TerminalLine(TerminalLineType.OUTPUT, "  Available Security Simulators:"))
                result.add(TerminalLine(TerminalLineType.OUTPUT, "   • nmap [host]       - Port scan report simulation"))
                result.add(TerminalLine(TerminalLineType.OUTPUT, "   • msfconsole        - Metasploit penetration framework"))
                result.add(TerminalLine(TerminalLineType.OUTPUT, "   • whois [domain]    - WHOIS registrar reconnaissance"))
                result.add(TerminalLine(TerminalLineType.OUTPUT, "   • ifconfig          - Network interface parameters"))
                result.add(TerminalLine(TerminalLineType.OUTPUT, "   • cmatrix           - Digital cipher matrix stream"))
                result.add(TerminalLine(TerminalLineType.OUTPUT, "   • snake             - Developer arcade mini-game"))
                result.add(TerminalLine(TerminalLineType.SYSTEM, "  Status: Defense Lab Active • Strict Ethical Sandbox"))
            }

            "neofetch" -> {
                result.add(TerminalLine(TerminalLineType.SYSTEM, "       _,met\$\$\$\$gg.          atik@atik-ai"))
                result.add(TerminalLine(TerminalLineType.SYSTEM, "    ,g\$\$\$\$\$\$\$\$\$\$\$\$\$\$P.       ------------"))
                result.add(TerminalLine(TerminalLineType.SYSTEM, "  ,g\$\$P\"\"       \"\"\"Y\$\$.     OS: Atik AI Termux OS (aarch64)"))
                result.add(TerminalLine(TerminalLineType.SYSTEM, " ,\$\$P'              `\$\$\$b.   Host: ${Build.MANUFACTURER} ${Build.MODEL}"))
                result.add(TerminalLine(TerminalLineType.SYSTEM, ",\$\$P                 \$\$\$b   Kernel: Linux 6.1.0-android-arm64"))
                result.add(TerminalLine(TerminalLineType.SYSTEM, "\$\$\$P       ,ggs.     `\$\$b:  Uptime: 4 days, 12 hours"))
                result.add(TerminalLine(TerminalLineType.SYSTEM, "\$\$\$b       \$\$\$\$.      \$\$\$   Packages: 42 (termux-pkg)"))
                result.add(TerminalLine(TerminalLineType.SYSTEM, "\$\$\$\$.      `'\"'      ,\$\$P   Shell: bash 5.2.21"))
                result.add(TerminalLine(TerminalLineType.SYSTEM, " \$\$\$b.             ,g\$\$P    Terminal: Atik Console v2.5"))
                result.add(TerminalLine(TerminalLineType.SYSTEM, "  `Y\$\$\$.         ,g\$\$P'     CPU: ${Runtime.getRuntime().availableProcessors()} Cores (${Build.SUPPORTED_ABIS.firstOrNull() ?: "arm64"})"))
                result.add(TerminalLine(TerminalLineType.SYSTEM, "    `Y\$\$\$\$\$\$\$\$\$\$\$\$\$P'       Memory: 4120MiB / 8192MiB (50%)"))
                result.add(TerminalLine(TerminalLineType.OUTPUT, "       `\"\"\"\"\"\"\"\"`           UI Theme: Atik Cyberpunk OLED"))
            }

            "nmap" -> {
                val target = if (args.isNotEmpty()) args[0] else "127.0.0.1"
                result.add(TerminalLine(TerminalLineType.SYSTEM, "Starting Nmap 7.94 ( https://nmap.org ) at ${SimpleDateFormat("HH:mm:ss", Locale.US).format(Date())} UTC"))
                result.add(TerminalLine(TerminalLineType.OUTPUT, "Nmap scan report for $target"))
                result.add(TerminalLine(TerminalLineType.OUTPUT, "Host is up (0.0014s latency)."))
                result.add(TerminalLine(TerminalLineType.OUTPUT, "Not shown: 996 closed tcp ports (reset)"))
                result.add(TerminalLine(TerminalLineType.SYSTEM, "PORT     STATE SERVICE       VERSION"))
                result.add(TerminalLine(TerminalLineType.OUTPUT, "22/tcp   open  ssh           OpenSSH 9.3p1 (Debian)"))
                result.add(TerminalLine(TerminalLineType.OUTPUT, "80/tcp   open  http          nginx/1.24.0 (Ubuntu)"))
                result.add(TerminalLine(TerminalLineType.OUTPUT, "443/tcp  open  ssl/https     nginx/1.24.0 (TLSv1.3)"))
                result.add(TerminalLine(TerminalLineType.OUTPUT, "8080/tcp open  http-proxy    Atik AI Python Bridge"))
                result.add(TerminalLine(TerminalLineType.SUCCESS, "Nmap done: 1 IP address (1 host up) scanned in 1.42 seconds"))
            }

            "msfconsole", "metasploit" -> {
                result.add(TerminalLine(TerminalLineType.SYSTEM, "      .:okOOOkdc:             c0NNNNNNNNKOdl:."))
                result.add(TerminalLine(TerminalLineType.SYSTEM, "    .kMMMMMMMMMMW0d:         .xMMMMMMMMMMMMMMWKc"))
                result.add(TerminalLine(TerminalLineType.SYSTEM, "    oMMMMMMMMMMMMMMW0l.       kMMMMMMMMMMMMMMMMWd"))
                result.add(TerminalLine(TerminalLineType.SUCCESS, "=[ metasploit v6.3.38-dev                          ]"))
                result.add(TerminalLine(TerminalLineType.OUTPUT, "+ -- --=[ 2382 exploits - 1230 auxiliary - 413 post       ]"))
                result.add(TerminalLine(TerminalLineType.OUTPUT, "+ -- --=[ 1385 payloads - 46 encoders - 11 nops           ]"))
                result.add(TerminalLine(TerminalLineType.OUTPUT, "msf6 > type 'help' or explore safe cybersecurity blueprints."))
            }

            "cmatrix" -> {
                result.add(TerminalLine(TerminalLineType.SUCCESS, "0 1 0 1 1 0 1 0 0 1 0 1 1 0 1 0 1 1 0 1"))
                result.add(TerminalLine(TerminalLineType.SUCCESS, "A T I K   A I   M A T R I X   K E R N E L"))
                result.add(TerminalLine(TerminalLineType.SUCCESS, "1 0 1 1 0 0 1 0 1 1 0 1 0 0 1 1 0 1 0 1"))
                result.add(TerminalLine(TerminalLineType.SUCCESS, "S Y S T E M   C O N N E C T E D   2 0 2 6"))
                result.add(TerminalLine(TerminalLineType.SUCCESS, "0 1 0 0 1 1 0 1 0 1 1 0 0 1 0 1 1 0 1 0"))
            }

            "ifconfig", "ip" -> {
                result.add(TerminalLine(TerminalLineType.SYSTEM, "wlan0: flags=4163<UP,BROADCAST,RUNNING,MULTICAST>  mtu 1500"))
                result.add(TerminalLine(TerminalLineType.OUTPUT, "        inet 192.168.1.105  netmask 255.255.255.0  broadcast 192.168.1.255"))
                result.add(TerminalLine(TerminalLineType.OUTPUT, "        inet6 fe80::20c:29ff:fe4a:3780  prefixlen 64  scopeid 0x20<link>"))
                result.add(TerminalLine(TerminalLineType.OUTPUT, "        ether 00:0c:29:4a:37:80  txqueuelen 1000  (Ethernet)"))
                result.add(TerminalLine(TerminalLineType.OUTPUT, "        RX packets 28419  bytes 18942018 (18.0 MB)"))
                result.add(TerminalLine(TerminalLineType.OUTPUT, "        TX packets 14022  bytes 1948291 (1.8 MB)"))
                result.add(TerminalLine(TerminalLineType.OUTPUT, ""))
                result.add(TerminalLine(TerminalLineType.SYSTEM, "lo: flags=73<UP,LOOPBACK,RUNNING>  mtu 65536"))
                result.add(TerminalLine(TerminalLineType.OUTPUT, "        inet 127.0.0.1  netmask 255.0.0.0"))
            }

            "whois" -> {
                val domain = if (args.isNotEmpty()) args[0] else "google.com"
                result.add(TerminalLine(TerminalLineType.SYSTEM, "Domain Name: ${domain.uppercase()}"))
                result.add(TerminalLine(TerminalLineType.OUTPUT, "Registry Domain ID: 2138514_DOMAIN_COM-VRSN"))
                result.add(TerminalLine(TerminalLineType.OUTPUT, "Registrar WHOIS Server: whois.markmonitor.com"))
                result.add(TerminalLine(TerminalLineType.OUTPUT, "Registrar: MarkMonitor Inc."))
                result.add(TerminalLine(TerminalLineType.OUTPUT, "Creation Date: 1997-09-15T04:00:00Z"))
                result.add(TerminalLine(TerminalLineType.OUTPUT, "Name Server: ns1.google.com, ns2.google.com"))
                result.add(TerminalLine(TerminalLineType.SUCCESS, "DNSSEC: signedDelegation"))
            }

            "snake" -> {
                result.add(TerminalLine(TerminalLineType.SUCCESS, "🐍 Launching Interactive Arcade Snake Game..."))
                result.add(TerminalLine(TerminalLineType.OUTPUT, "Switch to the 'Snake Game 🐍' tab at the top of the console to play!"))
            }

            "termux-torch" -> {
                val state = if (args.isNotEmpty()) args[0].lowercase() else "toggle"
                val feedback = onHardwareAction?.invoke("flashlight", state) ?: "Flashlight toggled."
                result.add(TerminalLine(TerminalLineType.SUCCESS, feedback))
            }

            "termux-wifi-enable" -> {
                val feedback = onHardwareAction?.invoke("wifi", "") ?: "Opening Wi-Fi controls..."
                result.add(TerminalLine(TerminalLineType.SUCCESS, feedback))
            }

            "termux-battery-status" -> {
                val feedback = onHardwareAction?.invoke("battery", "") ?: "Battery Status: 85%, Good"
                result.add(TerminalLine(TerminalLineType.OUTPUT, feedback))
            }

            "memory" -> {
                if (args.isEmpty() || args[0] == "list") {
                    val reply = onMemoryAction?.invoke("list", "") ?: "No memories stored."
                    reply.lines().forEach { result.add(TerminalLine(TerminalLineType.OUTPUT, it)) }
                } else if (args[0] == "add" && args.size > 1) {
                    val entry = args.subList(1, args.size).joinToString(" ")
                    val reply = onMemoryAction?.invoke("add", entry) ?: "Memory saved."
                    result.add(TerminalLine(TerminalLineType.SUCCESS, reply))
                } else {
                    result.add(TerminalLine(TerminalLineType.OUTPUT, "Usage: memory list | memory add <key: value>"))
                }
            }

            else -> {
                result.add(TerminalLine(TerminalLineType.ERROR, "bash: $cmd: command not found. Type 'help' for available commands."))
            }
        }

        result
    }

    private fun resolvePath(input: String): String {
        return when {
            input == "~" || input == "" -> "/home/atik"
            input.startsWith("~/") -> "/home/atik/" + input.removePrefix("~/")
            input.startsWith("/") -> normalizePath(input)
            input == ".." -> {
                val parent = currentDir.substringBeforeLast('/', "")
                if (parent.isEmpty()) "/" else parent
            }
            input == "." -> currentDir
            else -> {
                val combined = if (currentDir == "/") "/$input" else "$currentDir/$input"
                normalizePath(combined)
            }
        }
    }

    private fun normalizePath(path: String): String {
        val parts = path.split('/').filter { it.isNotEmpty() && it != "." }
        val stack = mutableListOf<String>()
        for (p in parts) {
            if (p == "..") {
                if (stack.isNotEmpty()) stack.removeAt(stack.size - 1)
            } else {
                stack.add(p)
            }
        }
        return "/" + stack.joinToString("/")
    }

    private suspend fun executeRemoteCommand(
        command: String,
        backendUrl: String
    ): List<TerminalLine> = withContext(Dispatchers.IO) {
        val lines = mutableListOf<TerminalLine>()
        try {
            val client = OkHttpClient()
            val json = org.json.JSONObject().apply {
                put("command", command)
                put("workingDir", currentDir)
            }
            val mediaType = "application/json; charset=utf-8".toMediaTypeOrNull()
            val body = json.toString().toRequestBody(mediaType)
            val request = Request.Builder()
                .url(backendUrl)
                .post(body)
                .build()

            val response = client.newCall(request).execute()
            val respStr = response.body?.string().orEmpty()
            val respJson = org.json.JSONObject(respStr)

            val stdout = respJson.optString("stdout")
            val stderr = respJson.optString("stderr")

            if (stdout.isNotBlank()) {
                stdout.lines().forEach { lines.add(TerminalLine(TerminalLineType.OUTPUT, it)) }
            }
            if (stderr.isNotBlank()) {
                stderr.lines().forEach { lines.add(TerminalLine(TerminalLineType.ERROR, it)) }
            }
        } catch (e: Exception) {
            lines.add(TerminalLine(TerminalLineType.ERROR, "Backend Connection Failed: ${e.message}"))
            lines.add(TerminalLine(TerminalLineType.SYSTEM, "Reverting to local sandboxed terminal."))
        }
        lines
    }
}
