package com.example.ide

import java.io.File

/**
 * Supported programming languages in Atik IDE Workspace.
 */
enum class SupportedLanguage(
    val displayName: String,
    val fileExtension: String,
    val emoji: String,
    val identifier: String,
    val isWebVisual: Boolean = false
) {
    PYTHON("Python", ".py", "🐍", "python", false),
    JAVASCRIPT("JavaScript", ".js", "⚡", "javascript", true),
    HTML_CSS("HTML / CSS", ".html", "🌐", "html", true),
    KOTLIN("Kotlin", ".kt", "🟣", "kotlin", false),
    CPP("C++", ".cpp", "⚙️", "cpp", false);

    companion object {
        fun fromIdentifier(id: String): SupportedLanguage {
            return values().firstOrNull { it.identifier.equals(id, ignoreCase = true) } ?: PYTHON
        }
    }
}

/**
 * Execution result for code run in the IDE.
 */
data class IdeExecutionResult(
    val success: Boolean,
    val output: String,
    val error: String? = null,
    val executionTimeMs: Long = 0,
    val language: SupportedLanguage = SupportedLanguage.PYTHON,
    val isWebPreview: Boolean = false,
    val htmlPayload: String? = null,
    val exitCode: Int = 0
)

/**
 * Code starter template for quick onboarding.
 */
data class CodeTemplate(
    val id: String,
    val name: String,
    val language: SupportedLanguage,
    val description: String,
    val code: String
)

/**
 * AI Coding Assistant action types.
 */
enum class AiCodeAction(val title: String, val description: String) {
    GENERATE("Generate Code", "Create new code from a natural language prompt"),
    DEBUG_FIX("Debug & Fix", "Analyze, diagnose, and fix syntax or runtime errors"),
    REFACTOR("Refactor & Optimize", "Improve performance, clean architecture, and readability"),
    EXPLAIN("Explain Logic", "Detailed step-by-step breakdown of how the code works"),
    UNIT_TESTS("Generate Tests", "Create unit tests and edge-case verification routines")
}

/**
 * Diagnostic log item produced during execution or analysis.
 */
data class DiagnosticLog(
    val timestamp: Long = System.currentTimeMillis(),
    val severity: DiagnosticSeverity,
    val message: String,
    val line: Int? = null,
    val suggestion: String? = null
)

enum class DiagnosticSeverity {
    INFO,
    WARNING,
    ERROR,
    SUCCESS
}

/**
 * Exported code file descriptor.
 */
data class ExportedFileResult(
    val file: File,
    val fileName: String,
    val absolutePath: String,
    val byteCount: Long,
    val language: SupportedLanguage
)
