package com.example.ide

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import com.example.ui.theme.AtikElectricBlue
import com.example.ui.theme.AtikNeonAzure
import com.example.ui.theme.AtikNeonCyan
import com.example.ui.theme.AtikTextMuted
import com.example.ui.theme.AtikTextPrimary
import java.util.regex.Pattern

/**
 * Real-time syntax highlighter for Python, JavaScript, HTML/CSS, Kotlin, and C++.
 */
object SyntaxHighlighter {

    private val KEYWORD_COLOR = AtikNeonCyan
    private val STRING_COLOR = Color(0xFF81C784) // Soft green
    private val COMMENT_COLOR = AtikTextMuted // Muted grey
    private val NUMBER_COLOR = Color(0xFFFFB74D) // Soft amber/orange
    private val TYPE_COLOR = Color(0xFFBA68C8) // Purple
    private val FUNCTION_COLOR = AtikNeonAzure // Blue
    private val TAG_COLOR = Color(0xFFFF8A80) // Coral red for HTML tags

    private val PYTHON_KEYWORDS = setOf(
        "def", "class", "import", "from", "as", "return", "if", "elif", "else",
        "while", "for", "in", "try", "except", "finally", "with", "lambda",
        "pass", "break", "continue", "global", "nonlocal", "assert", "yield",
        "True", "False", "None", "async", "await", "raise", "print"
    )

    private val JS_KEYWORDS = setOf(
        "function", "const", "let", "var", "return", "if", "else", "switch",
        "case", "break", "continue", "while", "for", "of", "in", "try", "catch",
        "finally", "throw", "new", "class", "extends", "import", "export", "default",
        "async", "await", "null", "undefined", "true", "false", "this", "typeof"
    )

    private val KOTLIN_KEYWORDS = setOf(
        "fun", "val", "var", "class", "object", "interface", "data", "sealed",
        "package", "import", "return", "if", "else", "when", "while", "for",
        "in", "is", "as", "try", "catch", "finally", "throw", "null", "true",
        "false", "this", "super", "override", "private", "public", "protected",
        "internal", "suspend", "companion", "by", "lazy", "init"
    )

    private val CPP_KEYWORDS = setOf(
        "int", "float", "double", "char", "void", "bool", "auto", "class",
        "struct", "namespace", "using", "public", "private", "protected",
        "return", "if", "else", "while", "for", "do", "switch", "case",
        "break", "continue", "new", "delete", "const", "constexpr", "static",
        "virtual", "template", "typename", "include", "true", "false", "nullptr"
    )

    fun highlight(code: String, language: SupportedLanguage): AnnotatedString {
        if (code.isEmpty()) return AnnotatedString("")

        return buildAnnotatedString {
            append(code)

            when (language) {
                SupportedLanguage.PYTHON -> highlightPython(code, this)
                SupportedLanguage.JAVASCRIPT -> highlightJavaScript(code, this)
                SupportedLanguage.HTML_CSS -> highlightHtmlCss(code, this)
                SupportedLanguage.KOTLIN -> highlightKotlin(code, this)
                SupportedLanguage.CPP -> highlightCpp(code, this)
            }
        }
    }

    private fun highlightPython(code: String, builder: AnnotatedString.Builder) {
        // Comments: # ...
        applyRegex(code, "#[^\n]*", COMMENT_COLOR, builder, italic = true)
        // Strings: "..." or '...'
        applyRegex(code, "\"\"\"[\\s\\S]*?\"\"\"|\"([^\"\\\\]|\\\\.)*\"|'([^'\\\\]|\\\\.)*'", STRING_COLOR, builder)
        // Numbers
        applyRegex(code, "\\b\\d+(\\.\\d+)?\\b", NUMBER_COLOR, builder)
        // Keywords
        highlightKeywords(code, PYTHON_KEYWORDS, KEYWORD_COLOR, builder)
        // Function definitions: def name(
        applyRegex(code, "(?<=def\\s+)[a-zA-Z_][a-zA-Z0-9_]*", FUNCTION_COLOR, builder, bold = true)
    }

    private fun highlightJavaScript(code: String, builder: AnnotatedString.Builder) {
        // Comments: // ... or /* ... */
        applyRegex(code, "//[^\n]*|/\\*[\\s\\S]*?\\*/", COMMENT_COLOR, builder, italic = true)
        // Strings: "...", '...', `...`
        applyRegex(code, "`[\\s\\S]*?`|\"([^\"\\\\]|\\\\.)*\"|'([^'\\\\]|\\\\.)*'", STRING_COLOR, builder)
        // Numbers
        applyRegex(code, "\\b\\d+(\\.\\d+)?\\b", NUMBER_COLOR, builder)
        // Keywords
        highlightKeywords(code, JS_KEYWORDS, KEYWORD_COLOR, builder)
        // Functions: function name(
        applyRegex(code, "(?<=function\\s+)[a-zA-Z_][a-zA-Z0-9_]*", FUNCTION_COLOR, builder, bold = true)
    }

    private fun highlightKotlin(code: String, builder: AnnotatedString.Builder) {
        // Comments
        applyRegex(code, "//[^\n]*|/\\*[\\s\\S]*?\\*/", COMMENT_COLOR, builder, italic = true)
        // Strings
        applyRegex(code, "\"\"\"[\\s\\S]*?\"\"\"|\"([^\"\\\\]|\\\\.)*\"", STRING_COLOR, builder)
        // Numbers
        applyRegex(code, "\\b\\d+(\\.\\d+)?([fFL])?\\b", NUMBER_COLOR, builder)
        // Keywords
        highlightKeywords(code, KOTLIN_KEYWORDS, KEYWORD_COLOR, builder)
        // Types
        applyRegex(code, "\\b[A-Z][a-zA-Z0-9_]*\\b", TYPE_COLOR, builder)
        // Functions
        applyRegex(code, "(?<=fun\\s+)[a-zA-Z_][a-zA-Z0-9_]*", FUNCTION_COLOR, builder, bold = true)
    }

    private fun highlightCpp(code: String, builder: AnnotatedString.Builder) {
        // Comments
        applyRegex(code, "//[^\n]*|/\\*[\\s\\S]*?\\*/", COMMENT_COLOR, builder, italic = true)
        // Preprocessor: #include, #define
        applyRegex(code, "#[a-zA-Z]+", AtikElectricBlue, builder, bold = true)
        // Strings
        applyRegex(code, "\"([^\"\\\\]|\\\\.)*\"|<[a-zA-Z0-9_\\.]+>", STRING_COLOR, builder)
        // Numbers
        applyRegex(code, "\\b\\d+(\\.\\d+)?\\b", NUMBER_COLOR, builder)
        // Keywords
        highlightKeywords(code, CPP_KEYWORDS, KEYWORD_COLOR, builder)
        // Functions
        applyRegex(code, "\\b[a-zA-Z_][a-zA-Z0-9_]*(?=\\s*\\()", FUNCTION_COLOR, builder)
    }

    private fun highlightHtmlCss(code: String, builder: AnnotatedString.Builder) {
        // Comments: <!-- ... --> or /* ... */
        applyRegex(code, "<!--[\\s\\S]*?-->|/\\*[\\s\\S]*?\\*/", COMMENT_COLOR, builder, italic = true)
        // Tags: <tag> or </tag>
        applyRegex(code, "</?[a-zA-Z0-9\\-]+", TAG_COLOR, builder, bold = true)
        // Tag brackets
        applyRegex(code, ">|/>", TAG_COLOR, builder, bold = true)
        // Attributes: class=, id=, style=
        applyRegex(code, "\\b[a-zA-Z\\-]+(?=\\=)", KEYWORD_COLOR, builder)
        // Attribute values / strings
        applyRegex(code, "\"([^\"\\\\]|\\\\.)*\"|'([^'\\\\]|\\\\.)*'", STRING_COLOR, builder)
        // CSS properties: color:, margin:, padding:
        applyRegex(code, "\\b[a-zA-Z\\-]+(?=\\s*:)", FUNCTION_COLOR, builder)
        // Numbers with units: 10px, 2rem, 100%
        applyRegex(code, "\\b\\d+(\\.\\d+)?(px|rem|em|%|vh|vw|s|ms)?\\b", NUMBER_COLOR, builder)
    }

    private fun highlightKeywords(
        code: String,
        keywords: Set<String>,
        color: Color,
        builder: AnnotatedString.Builder
    ) {
        val pattern = Pattern.compile("\\b(" + keywords.joinToString("|") + ")\\b")
        val matcher = pattern.matcher(code)
        while (matcher.find()) {
            builder.addStyle(
                SpanStyle(color = color, fontWeight = FontWeight.SemiBold),
                matcher.start(),
                matcher.end()
            )
        }
    }

    private fun applyRegex(
        code: String,
        regex: String,
        color: Color,
        builder: AnnotatedString.Builder,
        bold: Boolean = false,
        italic: Boolean = false
    ) {
        try {
            val pattern = Pattern.compile(regex)
            val matcher = pattern.matcher(code)
            while (matcher.find()) {
                builder.addStyle(
                    SpanStyle(
                        color = color,
                        fontWeight = if (bold) FontWeight.Bold else FontWeight.Normal,
                        fontStyle = if (italic) FontStyle.Italic else FontStyle.Normal
                    ),
                    matcher.start(),
                    matcher.end()
                )
            }
        } catch (_: Exception) {}
    }
}
