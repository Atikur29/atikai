package com.example.python

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.StringWriter
import java.lang.StringBuilder
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * Result of Python script execution.
 */
data class PythonExecutionResult(
    val success: Boolean,
    val output: String,
    val error: String? = null,
    val executionTimeMs: Long = 0,
    val isSandboxed: Boolean = true
)

/**
 * Secure sandboxed Python execution engine.
 * Safely evaluates Python code in-memory without unrestricted access to the host OS.
 * Strictly enforces timeout, iteration bounds, and disallows dangerous system calls.
 */
class PythonSandboxEngine {

    // Disallowed keywords and modules for strict sandbox security
    private val blockedKeywords = listOf(
        "import os", "import sys", "import subprocess", "import socket",
        "import shutil", "__import__", "eval(", "exec(", "open(", "compile(",
        "os.system", "os.popen", "subprocess.Popen", "subprocess.run"
    )

    suspend fun execute(
        code: String,
        remoteBackendUrl: String? = null
    ): PythonExecutionResult = withContext(Dispatchers.Default) {
        val startTime = System.currentTimeMillis()

        // If remote backend URL is provided, optionally execute via remote server
        if (!remoteBackendUrl.isNullOrBlank()) {
            return@withContext executeViaRemoteBackend(code, remoteBackendUrl, startTime)
        }

        // Security check
        for (blocked in blockedKeywords) {
            if (code.contains(blocked, ignoreCase = true)) {
                return@withContext PythonExecutionResult(
                    success = false,
                    output = "",
                    error = "Security Policy Error: '$blocked' is blocked in the secure sandbox. Host system calls are prohibited.",
                    executionTimeMs = System.currentTimeMillis() - startTime,
                    isSandboxed = true
                )
            }
        }

        try {
            val output = StringBuilder()
            val variables = mutableMapOf<String, Any?>()

            // Pre-populate standard safe built-ins and math
            variables["pi"] = Math.PI
            variables["e"] = Math.E
            variables["True"] = true
            variables["False"] = false
            variables["None"] = null

            val lines = code.lines()
            var stepCount = 0
            val maxSteps = 20000

            var i = 0
            while (i < lines.size) {
                stepCount++
                if (stepCount > maxSteps) {
                    return@withContext PythonExecutionResult(
                        success = false,
                        output = output.toString(),
                        error = "Runtime Error: Execution limit exceeded ($maxSteps steps). Infinite loop prevented.",
                        executionTimeMs = System.currentTimeMillis() - startTime,
                        isSandboxed = true
                    )
                }

                val rawLine = lines[i]
                val trimmed = rawLine.trim()

                // Skip comments and blanks
                if (trimmed.isEmpty() || trimmed.startsWith("#")) {
                    i++
                    continue
                }

                // Handle print(...)
                if (trimmed.startsWith("print(") && trimmed.endsWith(")")) {
                    val inner = trimmed.substring(6, trimmed.length - 1)
                    val result = evaluatePrintArguments(inner, variables)
                    output.append(result).append("\n")
                    i++
                    continue
                }

                // Handle for loop: for x in range(n): or for item in list:
                if (trimmed.startsWith("for ") && trimmed.endsWith(":")) {
                    val loopHeader = trimmed.substring(4, trimmed.length - 1)
                    val parts = loopHeader.split(" in ", limit = 2)
                    if (parts.size == 2) {
                        val varName = parts[0].trim()
                        val iterableExpr = parts[1].trim()

                        // Extract loop body (indented subsequent lines)
                        val bodyLines = mutableListOf<String>()
                        val currentIndent = getIndentLevel(rawLine)
                        var j = i + 1
                        while (j < lines.size) {
                            val nextRaw = lines[j]
                            if (nextRaw.trim().isEmpty()) {
                                bodyLines.add("")
                                j++
                                continue
                            }
                            if (getIndentLevel(nextRaw) > currentIndent) {
                                bodyLines.add(nextRaw.trim())
                                j++
                            } else {
                                break
                            }
                        }

                        // Evaluate iterable (range, list, string)
                        val items = evaluateIterable(iterableExpr, variables)
                        for (item in items) {
                            variables[varName] = item
                            for (bLine in bodyLines) {
                                if (bLine.startsWith("print(") && bLine.endsWith(")")) {
                                    val inner = bLine.substring(6, bLine.length - 1)
                                    output.append(evaluatePrintArguments(inner, variables)).append("\n")
                                } else if (bLine.contains("=")) {
                                    executeAssignment(bLine, variables)
                                }
                            }
                        }
                        i = j
                        continue
                    }
                }

                // Handle if / else
                if (trimmed.startsWith("if ") && trimmed.endsWith(":")) {
                    val condition = trimmed.substring(3, trimmed.length - 1).trim()
                    val condResult = evaluateBoolean(condition, variables)

                    // Gather if body
                    val ifBody = mutableListOf<String>()
                    val currentIndent = getIndentLevel(rawLine)
                    var j = i + 1
                    while (j < lines.size) {
                        val nextRaw = lines[j]
                        if (nextRaw.trim().isEmpty()) { j++; continue }
                        if (getIndentLevel(nextRaw) > currentIndent) {
                            ifBody.add(nextRaw.trim())
                            j++
                        } else {
                            break
                        }
                    }

                    // Check if followed by else:
                    var elseBody = mutableListOf<String>()
                    if (j < lines.size && lines[j].trim() == "else:") {
                        j++
                        while (j < lines.size) {
                            val nextRaw = lines[j]
                            if (nextRaw.trim().isEmpty()) { j++; continue }
                            if (getIndentLevel(nextRaw) > currentIndent) {
                                elseBody.add(nextRaw.trim())
                                j++
                            } else {
                                break
                            }
                        }
                    }

                    val activeBody = if (condResult) ifBody else elseBody
                    for (bLine in activeBody) {
                        if (bLine.startsWith("print(") && bLine.endsWith(")")) {
                            val inner = bLine.substring(6, bLine.length - 1)
                            output.append(evaluatePrintArguments(inner, variables)).append("\n")
                        } else if (bLine.contains("=")) {
                            executeAssignment(bLine, variables)
                        }
                    }

                    i = j
                    continue
                }

                // Handle assignments: a = 10, list.append(...), etc.
                if (trimmed.contains("=")) {
                    executeAssignment(trimmed, variables)
                    i++
                    continue
                }

                // Method call on object: list.append(x)
                if (trimmed.contains(".")) {
                    executeMethodCall(trimmed, variables)
                    i++
                    continue
                }

                i++
            }

            PythonExecutionResult(
                success = true,
                output = output.toString().ifEmpty { "[Program finished with no output]" },
                error = null,
                executionTimeMs = System.currentTimeMillis() - startTime,
                isSandboxed = true
            )
        } catch (e: Exception) {
            PythonExecutionResult(
                success = false,
                output = "",
                error = "Python Error: ${e.message ?: "Syntax or Evaluation error"}",
                executionTimeMs = System.currentTimeMillis() - startTime,
                isSandboxed = true
            )
        }
    }

    private fun getIndentLevel(line: String): Int {
        var count = 0
        for (ch in line) {
            if (ch == ' ') count++
            else if (ch == '\t') count += 4
            else break
        }
        return count
    }

    private fun executeAssignment(line: String, variables: MutableMap<String, Any?>) {
        val eqIndex = line.indexOf('=')
        if (eqIndex <= 0) return
        val left = line.substring(0, eqIndex).trim()
        val right = line.substring(eqIndex + 1).trim()

        // e.g. a += 1
        if (left.endsWith("+") || left.endsWith("-") || left.endsWith("*") || left.endsWith("/")) {
            val op = left.last()
            val varName = left.substring(0, left.length - 1).trim()
            val currentVal = (variables[varName] as? Number)?.toDouble() ?: 0.0
            val rightVal = (evaluateExpression(right, variables) as? Number)?.toDouble() ?: 0.0
            val newVal = when (op) {
                '+' -> currentVal + rightVal
                '-' -> currentVal - rightVal
                '*' -> currentVal * rightVal
                '/' -> if (rightVal != 0.0) currentVal / rightVal else 0.0
                else -> rightVal
            }
            variables[varName] = if (newVal % 1.0 == 0.0) newVal.toLong() else newVal
            return
        }

        val evalResult = evaluateExpression(right, variables)
        variables[left] = evalResult
    }

    private fun executeMethodCall(line: String, variables: MutableMap<String, Any?>) {
        if (line.contains(".append(") && line.endsWith(")")) {
            val dot = line.indexOf(".append(")
            val varName = line.substring(0, dot).trim()
            val arg = line.substring(dot + 8, line.length - 1).trim()
            val list = variables[varName] as? MutableList<Any?>
            if (list != null) {
                val value = evaluateExpression(arg, variables)
                list.add(value)
            }
        }
    }

    private fun evaluatePrintArguments(expr: String, variables: Map<String, Any?>): String {
        if (expr.isBlank()) return ""
        // Handle comma-separated print arguments
        val args = splitArguments(expr)
        return args.joinToString(" ") { arg ->
            val eval = evaluateExpression(arg.trim(), variables)
            eval?.toString() ?: "None"
        }
    }

    private fun splitArguments(expr: String): List<String> {
        val result = mutableListOf<String>()
        var current = StringBuilder()
        var inQuotes = false
        var quoteChar = ' '
        var parenDepth = 0

        for (ch in expr) {
            if ((ch == '"' || ch == '\'') && (parenDepth == 0 || inQuotes)) {
                if (!inQuotes) {
                    inQuotes = true
                    quoteChar = ch
                } else if (quoteChar == ch) {
                    inQuotes = false
                }
            }
            if (!inQuotes) {
                if (ch == '(' || ch == '[') parenDepth++
                if (ch == ')' || ch == ']') parenDepth--
                if (ch == ',' && parenDepth == 0) {
                    result.add(current.toString().trim())
                    current = StringBuilder()
                    continue
                }
            }
            current.append(ch)
        }
        if (current.isNotBlank()) {
            result.add(current.toString().trim())
        }
        return result
    }

    private fun evaluateExpression(expr: String, variables: Map<String, Any?>): Any? {
        val trimmed = expr.trim()

        // String literals
        if ((trimmed.startsWith("\"") && trimmed.endsWith("\"")) ||
            (trimmed.startsWith("'") && trimmed.endsWith("'"))) {
            return trimmed.substring(1, trimmed.length - 1)
        }

        // f-strings
        if (trimmed.startsWith("f\"") || trimmed.startsWith("f'")) {
            val content = trimmed.substring(2, trimmed.length - 1)
            var formatted = content
            val regex = Regex("\\{([^}]+)\\}")
            return regex.replace(formatted) { matchResult ->
                val innerVar = matchResult.groupValues[1].trim()
                evaluateExpression(innerVar, variables)?.toString() ?: ""
            }
        }

        // Numbers
        trimmed.toLongOrNull()?.let { return it }
        trimmed.toDoubleOrNull()?.let { return it }

        // Booleans
        if (trimmed == "True" || trimmed == "true") return true
        if (trimmed == "False" || trimmed == "false") return false
        if (trimmed == "None" || trimmed == "null") return null

        // Lists: [1, 2, 3]
        if (trimmed.startsWith("[") && trimmed.endsWith("]")) {
            val inner = trimmed.substring(1, trimmed.length - 1).trim()
            if (inner.isEmpty()) return mutableListOf<Any?>()
            val items = splitArguments(inner).map { evaluateExpression(it, variables) }
            return items.toMutableList()
        }

        // len(...)
        if (trimmed.startsWith("len(") && trimmed.endsWith(")")) {
            val inner = trimmed.substring(4, trimmed.length - 1).trim()
            val target = evaluateExpression(inner, variables)
            return when (target) {
                is Collection<*> -> target.size
                is String -> target.length
                else -> 0
            }
        }

        // sum(...)
        if (trimmed.startsWith("sum(") && trimmed.endsWith(")")) {
            val inner = trimmed.substring(4, trimmed.length - 1).trim()
            val target = evaluateExpression(inner, variables) as? Collection<*>
            return target?.filterIsInstance<Number>()?.sumOf { it.toDouble() } ?: 0.0
        }

        // math.sqrt(...)
        if (trimmed.startsWith("math.sqrt(") && trimmed.endsWith(")")) {
            val inner = trimmed.substring(10, trimmed.length - 1).trim()
            val num = (evaluateExpression(inner, variables) as? Number)?.toDouble() ?: 0.0
            return sqrt(num)
        }

        // Variables
        if (variables.containsKey(trimmed)) {
            return variables[trimmed]
        }

        // Simple arithmetic: a + b, a * b, a - b, a / b
        for (op in listOf("+", "-", "*", "/", "%")) {
            if (trimmed.contains(op)) {
                val parts = trimmed.split(op, limit = 2)
                if (parts.size == 2) {
                    val leftVal = evaluateExpression(parts[0].trim(), variables)
                    val rightVal = evaluateExpression(parts[1].trim(), variables)

                    if (leftVal is String && op == "+") {
                        return leftVal + (rightVal?.toString() ?: "")
                    }
                    if (leftVal is Number && rightVal is Number) {
                        val d1 = leftVal.toDouble()
                        val d2 = rightVal.toDouble()
                        val res = when (op) {
                            "+" -> d1 + d2
                            "-" -> d1 - d2
                            "*" -> d1 * d2
                            "/" -> if (d2 != 0.0) d1 / d2 else 0.0
                            "%" -> if (d2 != 0.0) d1 % d2 else 0.0
                            else -> 0.0
                        }
                        return if (res % 1.0 == 0.0) res.toLong() else res
                    }
                }
            }
        }

        return trimmed
    }

    private fun evaluateIterable(expr: String, variables: Map<String, Any?>): List<Any?> {
        val trimmed = expr.trim()
        if (trimmed.startsWith("range(") && trimmed.endsWith(")")) {
            val inner = trimmed.substring(6, trimmed.length - 1).trim()
            val parts = splitArguments(inner)
            val start: Int
            val end: Int
            if (parts.size == 1) {
                start = 0
                end = (evaluateExpression(parts[0], variables) as? Number)?.toInt() ?: 0
            } else {
                start = (evaluateExpression(parts[0], variables) as? Number)?.toInt() ?: 0
                end = (evaluateExpression(parts[1], variables) as? Number)?.toInt() ?: 0
            }
            return (start until end).map { it }
        }

        val target = evaluateExpression(trimmed, variables)
        if (target is Collection<*>) {
            return target.toList()
        }
        if (target is String) {
            return target.map { it.toString() }
        }
        return emptyList()
    }

    private fun evaluateBoolean(condition: String, variables: Map<String, Any?>): Boolean {
        for (op in listOf("==", "!=", "<=", ">=", "<", ">")) {
            if (condition.contains(op)) {
                val parts = condition.split(op, limit = 2)
                val left = evaluateExpression(parts[0].trim(), variables)
                val right = evaluateExpression(parts[1].trim(), variables)

                val n1 = (left as? Number)?.toDouble()
                val n2 = (right as? Number)?.toDouble()

                if (n1 != null && n2 != null) {
                    return when (op) {
                        "==" -> n1 == n2
                        "!=" -> n1 != n2
                        "<" -> n1 < n2
                        ">" -> n1 > n2
                        "<=" -> n1 <= n2
                        ">=" -> n1 >= n2
                        else -> false
                    }
                }
                return when (op) {
                    "==" -> left == right
                    "!=" -> left != right
                    else -> false
                }
            }
        }
        val value = evaluateExpression(condition, variables)
        return when (value) {
            is Boolean -> value
            is Number -> value.toDouble() != 0.0
            is String -> value.isNotEmpty()
            is Collection<*> -> value.isNotEmpty()
            null -> false
            else -> true
        }
    }

    private suspend fun executeViaRemoteBackend(
        code: String,
        backendUrl: String,
        startTime: Long
    ): PythonExecutionResult = withContext(Dispatchers.IO) {
        try {
            // Standard JSON POST to remote runner endpoint
            val client = OkHttpClient()
            val json = org.json.JSONObject().apply {
                put("language", "python")
                put("code", code)
            }
            val mediaType = "application/json; charset=utf-8".toMediaTypeOrNull()
            val body = json.toString().toRequestBody(mediaType)
            val request = Request.Builder()
                .url(backendUrl)
                .post(body)
                .build()

            val response = client.newCall(request).execute()
            val respStr = response.body?.string().orEmpty()
            val respJson = org.json.JSONObject(respStr)

            PythonExecutionResult(
                success = response.isSuccessful,
                output = respJson.optString("output", respStr),
                error = respJson.optString("error").ifEmpty { null },
                executionTimeMs = System.currentTimeMillis() - startTime,
                isSandboxed = false
            )
        } catch (e: Exception) {
            PythonExecutionResult(
                success = false,
                output = "",
                error = "Remote Runner Error: ${e.message}. Ensure backend is active and reachable.",
                executionTimeMs = System.currentTimeMillis() - startTime,
                isSandboxed = false
            )
        }
    }
}
