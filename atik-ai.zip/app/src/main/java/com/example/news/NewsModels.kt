package com.example.news

enum class NewsCategory(val displayName: String, val emoji: String) {
    ALL("All Feeds", "🌐"),
    TECH("Tech & AI", "💻"),
    BUSINESS("Business & Markets", "📈"),
    ENTERTAINMENT("Entertainment", "🎬"),
    WORLD("World & Politics", "🌍"),
    SCIENCE("Science & Space", "🚀"),
    LOCAL("Local & Regional", "📍")
}

data class NewsArticle(
    val id: String,
    val title: String,
    val summary: String,
    val category: NewsCategory,
    val source: String,
    val sourceUrl: String,
    val publishedTime: String,
    val readTimeMinutes: Int = 3,
    val tags: List<String> = emptyList(),
    val isBookmarked: Boolean = false,
    val fullContent: String? = null
)

data class WebSearchResult(
    val query: String,
    val title: String,
    val snippet: String,
    val url: String,
    val source: String,
    val timestamp: Long = System.currentTimeMillis()
)

data class WebSearchAnswer(
    val query: String,
    val directAnswer: String,
    val sources: List<WebSearchResult>,
    val relatedQueries: List<String>,
    val latencyMs: Long,
    val isOffline: Boolean = false
)

data class ArticleSummaryResult(
    val url: String,
    val title: String,
    val executiveSummary: String,
    val keyTakeaways: List<String>,
    val readingTime: String,
    val sentiment: String,
    val domain: String,
    val latencyMs: Long = 0,
    val timestamp: Long = System.currentTimeMillis()
)
