package com.example.device

import android.app.NotificationManager
import android.bluetooth.BluetoothAdapter
import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.net.Uri
import android.net.wifi.WifiManager
import android.os.Build
import android.provider.Settings
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

enum class SoundProfile(val displayName: String, val emoji: String, val ringerMode: Int) {
    NORMAL("Normal", "🔔", AudioManager.RINGER_MODE_NORMAL),
    VIBRATE("Vibrate", "📳", AudioManager.RINGER_MODE_VIBRATE),
    SILENT("Silent", "🔕", AudioManager.RINGER_MODE_SILENT)
}

data class SystemStatusSummary(
    val isAirplaneModeOn: Boolean,
    val isWifiOn: Boolean,
    val isBluetoothOn: Boolean,
    val isFlashlightOn: Boolean,
    val soundProfile: SoundProfile,
    val ringerVolumePct: Int,
    val mediaVolumePct: Int
)

/**
 * Deep System Automation & Settings Engine (Step 20).
 * Dynamic controls for Airplane Mode, Mobile Data, Wi-Fi, Bluetooth, Flashlight,
 * and Audio Sound Profiles with system settings deep-linking.
 */
class SystemAutomationEngine(
    private val context: Context,
    private val hardwareManager: DeviceHardwareManager
) {

    private val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager
    private val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager

    private val _currentSoundProfile = MutableStateFlow(detectCurrentSoundProfile())
    val currentSoundProfile: StateFlow<SoundProfile> = _currentSoundProfile.asStateFlow()

    private val _isAirplaneModeOn = MutableStateFlow(isAirplaneModeActive())
    val isAirplaneModeOn: StateFlow<Boolean> = _isAirplaneModeOn.asStateFlow()

    fun refreshStatus() {
        _isAirplaneModeOn.value = isAirplaneModeActive()
        _currentSoundProfile.value = detectCurrentSoundProfile()
    }

    /**
     * Checks if Airplane Mode is currently active in Android settings.
     */
    fun isAirplaneModeActive(): Boolean {
        return try {
            Settings.Global.getInt(context.contentResolver, Settings.Global.AIRPLANE_MODE_ON, 0) == 1
        } catch (_: Exception) {
            false
        }
    }

    /**
     * Navigates directly to the system Airplane Mode settings panel.
     */
    fun openAirplaneModeSettings(): String {
        return try {
            val intent = Intent(Settings.ACTION_AIRPLANE_MODE_SETTINGS).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            _isAirplaneModeOn.value = isAirplaneModeActive()
            "Navigating to Airplane Mode settings."
        } catch (e: Exception) {
            try {
                val fallback = Intent(Settings.ACTION_WIRELESS_SETTINGS).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(fallback)
                "Navigating to Network & Wireless settings."
            } catch (err: Exception) {
                "Unable to open Airplane Mode settings: ${err.localizedMessage}"
            }
        }
    }

    /**
     * Opens Cellular Data / Mobile Network settings.
     */
    fun openMobileDataSettings(): String {
        return try {
            val intent = Intent(Settings.ACTION_DATA_ROAMING_SETTINGS).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            "Opened Mobile Data & Roaming settings."
        } catch (_: Exception) {
            try {
                val fallback = Intent(Settings.ACTION_NETWORK_OPERATOR_SETTINGS).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(fallback)
                "Opened Mobile Network settings."
            } catch (err: Exception) {
                "Unable to open Mobile Data settings: ${err.localizedMessage}"
            }
        }
    }

    /**
     * Opens Wi-Fi Quick Panel or Settings.
     */
    fun openWifiControls(): String {
        return hardwareManager.openWifiControls()
    }

    /**
     * Opens Bluetooth Settings.
     */
    fun openBluetoothControls(): String {
        return hardwareManager.openBluetoothControls()
    }

    /**
     * Toggles hardware flashlight.
     */
    fun toggleFlashlight(enable: Boolean? = null): Boolean {
        val res = hardwareManager.toggleFlashlight(enable)
        return res.getOrDefault(false)
    }

    /**
     * Detects current device ringer mode.
     */
    fun detectCurrentSoundProfile(): SoundProfile {
        val am = audioManager ?: return SoundProfile.NORMAL
        return when (am.ringerMode) {
            AudioManager.RINGER_MODE_SILENT -> SoundProfile.SILENT
            AudioManager.RINGER_MODE_VIBRATE -> SoundProfile.VIBRATE
            else -> SoundProfile.NORMAL
        }
    }

    /**
     * Changes sound profile dynamically (Normal, Vibrate, Silent).
     */
    fun setSoundProfile(profile: SoundProfile): String {
        val am = audioManager ?: return "Audio system unavailable"
        try {
            if (profile == SoundProfile.SILENT && Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                val hasDndPermission = notificationManager?.isNotificationPolicyAccessGranted == true
                if (!hasDndPermission) {
                    val intent = Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS).apply {
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                    context.startActivity(intent)
                    return "Please grant Do Not Disturb access to enable Silent mode."
                }
            }

            am.ringerMode = profile.ringerMode
            _currentSoundProfile.value = profile
            return "Sound Profile changed to ${profile.displayName} ${profile.emoji}"
        } catch (e: Exception) {
            // Fallback: Open sound settings if restricted
            try {
                val intent = Intent(Settings.ACTION_SOUND_SETTINGS).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(intent)
                return "Opened System Sound settings."
            } catch (err: Exception) {
                return "Failed to set sound profile: ${e.localizedMessage}"
            }
        }
    }

    fun getSystemStatusSummary(): SystemStatusSummary {
        val am = audioManager
        val maxRinger = am?.getStreamMaxVolume(AudioManager.STREAM_RING) ?: 100
        val currentRinger = am?.getStreamVolume(AudioManager.STREAM_RING) ?: 70
        val ringerPct = if (maxRinger > 0) (currentRinger * 100) / maxRinger else 70

        val maxMedia = am?.getStreamMaxVolume(AudioManager.STREAM_MUSIC) ?: 100
        val currentMedia = am?.getStreamVolume(AudioManager.STREAM_MUSIC) ?: 50
        val mediaPct = if (maxMedia > 0) (currentMedia * 100) / maxMedia else 50

        return SystemStatusSummary(
            isAirplaneModeOn = isAirplaneModeActive(),
            isWifiOn = hardwareManager.isWifiEnabled(),
            isBluetoothOn = hardwareManager.isBluetoothEnabled(),
            isFlashlightOn = hardwareManager.isFlashlightOn.value,
            soundProfile = detectCurrentSoundProfile(),
            ringerVolumePct = ringerPct,
            mediaVolumePct = mediaPct
        )
    }
}
