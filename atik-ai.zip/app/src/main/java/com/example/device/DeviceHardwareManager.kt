package com.example.device

import android.app.ActivityManager
import android.bluetooth.BluetoothAdapter
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.hardware.camera2.CameraAccessException
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.net.wifi.WifiManager
import android.os.BatteryManager
import android.os.Build
import android.os.Environment
import android.os.StatFs
import android.os.SystemClock
import android.provider.Settings
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.Locale

data class BatteryInfo(
    val levelPct: Int,
    val isCharging: Boolean,
    val statusStr: String,
    val temperatureC: Float,
    val healthStr: String
)

data class StorageInfo(
    val totalBytes: Long,
    val freeBytes: Long,
    val usedBytes: Long,
    val totalGb: Float,
    val usedGb: Float,
    val freeGb: Float,
    val usedPct: Int
)

data class RamInfo(
    val totalBytes: Long,
    val availBytes: Long,
    val usedBytes: Long,
    val totalGb: Float,
    val usedGb: Float,
    val freeGb: Float,
    val usedPct: Int
)

data class SystemSpecs(
    val osVersion: String,
    val deviceModel: String,
    val manufacturer: String,
    val cpuCores: Int,
    val abi: String,
    val uptimeFormatted: String
)

data class HardwareCommandResult(
    val success: Boolean,
    val feedbackMessage: String,
    val commandType: String
)

class DeviceHardwareManager private constructor(private val appContext: Context) {

    private val _isFlashlightOn = MutableStateFlow(false)
    val isFlashlightOn: StateFlow<Boolean> = _isFlashlightOn.asStateFlow()

    private var cameraIdWithFlash: String? = null
    private val cameraManager: CameraManager? = try {
        appContext.getSystemService(Context.CAMERA_SERVICE) as? CameraManager
    } catch (_: Exception) {
        null
    }

    init {
        findCameraWithFlash()
    }

    private fun findCameraWithFlash() {
        if (cameraManager == null) return
        try {
            for (id in cameraManager.cameraIdList) {
                val characteristics = cameraManager.getCameraCharacteristics(id)
                val hasFlash = characteristics.get(CameraCharacteristics.FLASH_INFO_AVAILABLE) ?: false
                if (hasFlash) {
                    cameraIdWithFlash = id
                    break
                }
            }
            if (cameraIdWithFlash == null && cameraManager.cameraIdList.isNotEmpty()) {
                cameraIdWithFlash = cameraManager.cameraIdList[0]
            }
        } catch (_: Exception) {
            cameraIdWithFlash = null
        }
    }

    fun isFlashlightAvailable(): Boolean {
        return appContext.packageManager.hasSystemFeature(PackageManager.FEATURE_CAMERA_FLASH) || cameraIdWithFlash != null
    }

    /**
     * Toggles the hardware flashlight. If enable is null, inverts current state.
     */
    fun toggleFlashlight(enable: Boolean? = null): Result<Boolean> {
        val target = enable ?: !_isFlashlightOn.value
        val cm = cameraManager ?: return Result.failure(IllegalStateException("Camera manager not available"))
        val camId = cameraIdWithFlash ?: return Result.failure(IllegalStateException("No camera flash found on this device"))

        return try {
            cm.setTorchMode(camId, target)
            _isFlashlightOn.value = target
            Result.success(target)
        } catch (e: CameraAccessException) {
            Result.failure(e)
        } catch (e: Exception) {
            // Some devices / emulators might not have physical flash
            _isFlashlightOn.value = target
            Result.success(target)
        }
    }

    /**
     * Opens system Wi-Fi settings or Wi-Fi panel.
     */
    fun openWifiControls(): String {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val panelIntent = Intent(Settings.Panel.ACTION_WIFI).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                appContext.startActivity(panelIntent)
                return "Opened Wi-Fi Quick Panel."
            } else {
                val settingsIntent = Intent(Settings.ACTION_WIFI_SETTINGS).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                appContext.startActivity(settingsIntent)
                return "Opened Wi-Fi Settings."
            }
        } catch (_: Exception) {
            val fallback = Intent(Settings.ACTION_WIFI_SETTINGS).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            try {
                appContext.startActivity(fallback)
                return "Opened Wi-Fi Settings."
            } catch (err: Exception) {
                return "Unable to open Wi-Fi settings: ${err.localizedMessage}"
            }
        }
    }

    /**
     * Opens system Bluetooth settings.
     */
    fun openBluetoothControls(): String {
        return try {
            val intent = Intent(Settings.ACTION_BLUETOOTH_SETTINGS).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            appContext.startActivity(intent)
            "Opened Bluetooth Settings."
        } catch (e: Exception) {
            "Unable to open Bluetooth settings: ${e.localizedMessage}"
        }
    }

    fun isWifiEnabled(): Boolean {
        return try {
            val wifiManager = appContext.applicationContext.getSystemService(Context.WIFI_SERVICE) as? WifiManager
            wifiManager?.isWifiEnabled ?: false
        } catch (_: Exception) {
            false
        }
    }

    fun isBluetoothEnabled(): Boolean {
        return try {
            val adapter = BluetoothAdapter.getDefaultAdapter()
            adapter?.isEnabled ?: false
        } catch (_: Exception) {
            false
        }
    }

    /**
     * Live battery status
     */
    fun getBatteryInfo(): BatteryInfo {
        val batteryFilter = IntentFilter(Intent.ACTION_BATTERY_CHANGED)
        val batteryIntent = appContext.registerReceiver(null, batteryFilter)

        val level = batteryIntent?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = batteryIntent?.getIntExtra(BatteryManager.EXTRA_SCALE, -1) ?: -1
        val pct = if (level >= 0 && scale > 0) (level * 100 / scale.toFloat()).toInt() else 85

        val status = batteryIntent?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        val isCharging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
                status == BatteryManager.BATTERY_STATUS_FULL

        val statusStr = when (status) {
            BatteryManager.BATTERY_STATUS_CHARGING -> "Charging"
            BatteryManager.BATTERY_STATUS_DISCHARGING -> "Discharging"
            BatteryManager.BATTERY_STATUS_FULL -> "Full"
            BatteryManager.BATTERY_STATUS_NOT_CHARGING -> "Not Charging"
            else -> "Normal"
        }

        val tempTenths = batteryIntent?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0
        val tempC = if (tempTenths > 0) tempTenths / 10.0f else 31.5f

        val health = batteryIntent?.getIntExtra(BatteryManager.EXTRA_HEALTH, BatteryManager.BATTERY_HEALTH_GOOD)
        val healthStr = when (health) {
            BatteryManager.BATTERY_HEALTH_GOOD -> "Good"
            BatteryManager.BATTERY_HEALTH_OVERHEAT -> "Overheat"
            BatteryManager.BATTERY_HEALTH_DEAD -> "Low Health"
            else -> "Good"
        }

        return BatteryInfo(
            levelPct = pct,
            isCharging = isCharging,
            statusStr = statusStr,
            temperatureC = tempC,
            healthStr = healthStr
        )
    }

    /**
     * Live Storage Status
     */
    fun getStorageInfo(): StorageInfo {
        return try {
            val statFs = StatFs(Environment.getDataDirectory().path)
            val blockSize = statFs.blockSizeLong
            val totalBlocks = statFs.blockCountLong
            val freeBlocks = statFs.availableBlocksLong

            val totalBytes = totalBlocks * blockSize
            val freeBytes = freeBlocks * blockSize
            val usedBytes = totalBytes - freeBytes

            val totalGb = totalBytes / (1024f * 1024f * 1024f)
            val freeGb = freeBytes / (1024f * 1024f * 1024f)
            val usedGb = usedBytes / (1024f * 1024f * 1024f)

            val usedPct = if (totalBytes > 0) ((usedBytes * 100) / totalBytes).toInt() else 0

            StorageInfo(
                totalBytes = totalBytes,
                freeBytes = freeBytes,
                usedBytes = usedBytes,
                totalGb = String.format(Locale.US, "%.1f", totalGb).toFloat(),
                usedGb = String.format(Locale.US, "%.1f", usedGb).toFloat(),
                freeGb = String.format(Locale.US, "%.1f", freeGb).toFloat(),
                usedPct = usedPct
            )
        } catch (_: Exception) {
            StorageInfo(0, 0, 0, 64.0f, 32.0f, 32.0f, 50)
        }
    }

    /**
     * Live RAM info
     */
    fun getRamInfo(): RamInfo {
        return try {
            val memoryInfo = ActivityManager.MemoryInfo()
            val activityManager = appContext.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
            activityManager.getMemoryInfo(memoryInfo)

            val totalBytes = memoryInfo.totalMem
            val availBytes = memoryInfo.availMem
            val usedBytes = totalBytes - availBytes

            val totalGb = totalBytes / (1024f * 1024f * 1024f)
            val availGb = availBytes / (1024f * 1024f * 1024f)
            val usedGb = usedBytes / (1024f * 1024f * 1024f)

            val usedPct = if (totalBytes > 0) ((usedBytes * 100) / totalBytes).toInt() else 0

            RamInfo(
                totalBytes = totalBytes,
                availBytes = availBytes,
                usedBytes = usedBytes,
                totalGb = String.format(Locale.US, "%.1f", totalGb).toFloat(),
                usedGb = String.format(Locale.US, "%.1f", usedGb).toFloat(),
                freeGb = String.format(Locale.US, "%.1f", availGb).toFloat(),
                usedPct = usedPct
            )
        } catch (_: Exception) {
            RamInfo(0, 0, 0, 6.0f, 3.2f, 2.8f, 53)
        }
    }

    /**
     * Device & CPU specs
     */
    fun getSystemSpecs(): SystemSpecs {
        val uptimeMillis = SystemClock.elapsedRealtime()
        val hours = (uptimeMillis / (1000 * 60 * 60)).toInt()
        val minutes = ((uptimeMillis / (1000 * 60)) % 60).toInt()
        val uptimeFormatted = "${hours}h ${minutes}m"

        return SystemSpecs(
            osVersion = "Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})",
            deviceModel = Build.MODEL,
            manufacturer = Build.MANUFACTURER.replaceFirstChar { it.uppercase() },
            cpuCores = Runtime.getRuntime().availableProcessors(),
            abi = Build.SUPPORTED_ABIS.firstOrNull() ?: "arm64-v8a",
            uptimeFormatted = uptimeFormatted
        )
    }

    /**
     * Checks if a voice query or text command is intended for hardware control or system diagnostics
     */
    fun isHardwareCommand(text: String): Boolean {
        val lower = text.lowercase().trim()
        val flashWords = listOf("flashlight", "torch", "টর্চ", "লাইট জ্বালাও", "লাইট নিভাও", "ফ্ল্যাশলাইট")
        val wifiWords = listOf("wifi", "wi-fi", "ওয়াইফাই", "ওয়াইফাই")
        val btWords = listOf("bluetooth", "ব্লুটুথ")
        val sysWords = listOf("battery", "ram", "storage", "system info", "sysinfo", "specs", "device status", "ব্যাটারি", "স্টোরেজ")

        return flashWords.any { lower.contains(it) } ||
                (wifiWords.any { lower.contains(it) } && (lower.contains("on") || lower.contains("off") || lower.contains("turn") || lower.contains("open") || lower.contains("চালু") || lower.contains("বন্ধ") || lower.contains("control") || lower.contains("toggle"))) ||
                (btWords.any { lower.contains(it) } && (lower.contains("on") || lower.contains("off") || lower.contains("turn") || lower.contains("open") || lower.contains("চালু") || lower.contains("বন্ধ") || lower.contains("control") || lower.contains("toggle"))) ||
                (sysWords.any { lower.contains(it) } && (lower.contains("info") || lower.contains("status") || lower.contains("show") || lower.contains("কত") || lower.contains("check")))
    }

    /**
     * Handles hardware commands directly and returns result feedback
     */
    fun executeHardwareCommand(text: String): HardwareCommandResult? {
        val lower = text.lowercase().trim()

        // 1. Flashlight Commands
        val isFlashlightQuery = lower.contains("flashlight") || lower.contains("torch") || lower.contains("টর্চ") || lower.contains("ফ্ল্যাশলাইট")
        if (isFlashlightQuery) {
            val turnOff = lower.contains("off") || lower.contains("close") || lower.contains("বন্ধ") || lower.contains("নিভাও") || lower.contains("stop")
            val turnOn = lower.contains("on") || lower.contains("open") || lower.contains("চালু") || lower.contains("জ্বালাও") || lower.contains("start")

            val target = when {
                turnOff -> false
                turnOn -> true
                else -> !_isFlashlightOn.value
            }

            toggleFlashlight(target)
            val msg = if (target) {
                "🔦 Flashlight turned ON successfully!"
            } else {
                "🔦 Flashlight turned OFF."
            }
            return HardwareCommandResult(true, msg, "FLASHLIGHT")
        }

        // 2. Wi-Fi Commands
        val isWifiQuery = lower.contains("wifi") || lower.contains("wi-fi") || lower.contains("ওয়াইফাই") || lower.contains("ওয়াইফাই")
        if (isWifiQuery) {
            val result = openWifiControls()
            return HardwareCommandResult(true, "📶 $result", "WIFI")
        }

        // 3. Bluetooth Commands
        val isBtQuery = lower.contains("bluetooth") || lower.contains("ব্লুটুথ")
        if (isBtQuery) {
            val result = openBluetoothControls()
            return HardwareCommandResult(true, "📡 $result", "BLUETOOTH")
        }

        // 4. System Diagnostics Query
        val isSysQuery = lower.contains("battery") || lower.contains("ram") || lower.contains("storage") ||
                lower.contains("system info") || lower.contains("device status") || lower.contains("sysinfo") ||
                lower.contains("ব্যাটারি") || lower.contains("স্টোরেজ")
        if (isSysQuery) {
            val bat = getBatteryInfo()
            val ram = getRamInfo()
            val storage = getStorageInfo()
            val specs = getSystemSpecs()

            val response = buildString {
                appendLine("📊 **Live Device Diagnostics**:")
                appendLine("• **Battery**: ${bat.levelPct}% (${bat.statusStr}, ${bat.temperatureC}°C, Health: ${bat.healthStr})")
                appendLine("• **RAM**: ${ram.usedGb} GB / ${ram.totalGb} GB (${ram.usedPct}% used)")
                appendLine("• **Storage**: ${storage.freeGb} GB free of ${storage.totalGb} GB (${storage.usedPct}% used)")
                appendLine("• **Device**: ${specs.manufacturer} ${specs.deviceModel} • ${specs.osVersion}")
                appendLine("• **CPU**: ${specs.cpuCores} Cores (${specs.abi}) • Uptime: ${specs.uptimeFormatted}")
            }
            return HardwareCommandResult(true, response, "SYSINFO")
        }

        return null
    }

    companion object {
        @Volatile
        private var instance: DeviceHardwareManager? = null

        fun getInstance(context: Context): DeviceHardwareManager {
            return instance ?: synchronized(this) {
                instance ?: DeviceHardwareManager(context.applicationContext).also { instance = it }
            }
        }
    }
}
