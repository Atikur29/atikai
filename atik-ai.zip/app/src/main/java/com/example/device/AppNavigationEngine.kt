package com.example.device

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.AlarmClock
import android.provider.MediaStore
import android.provider.Settings

data class AppShortcutItem(
    val name: String,
    val packageName: String,
    val category: String,
    val iconEmoji: String,
    val isInstalled: Boolean = true
)

data class SystemSubMenuShortcut(
    val title: String,
    val description: String,
    val actionIntent: String,
    val iconEmoji: String,
    val category: String
)

/**
 * Universal App Launcher & System Deep-Link Engine (Step 20).
 * Handles direct deep-linking to system setting sub-menus and launching installed applications.
 */
class AppNavigationEngine(private val context: Context) {

    private val packageManager: PackageManager = context.packageManager

    /**
     * Standard list of popular app launcher presets.
     */
    val popularAppShortcuts = listOf(
        AppShortcutItem("YouTube", "com.google.android.youtube", "Media", "▶️"),
        AppShortcutItem("Google Chrome", "com.android.chrome", "Browser", "🌐"),
        AppShortcutItem("WhatsApp", "com.whatsapp", "Communication", "💬"),
        AppShortcutItem("Google Maps", "com.google.android.apps.maps", "Navigation", "🗺️"),
        AppShortcutItem("Camera", "com.android.camera", "System", "📷"),
        AppShortcutItem("Calculator", "com.google.android.calculator", "Utility", "🧮"),
        AppShortcutItem("Clock / Alarms", "com.google.android.deskclock", "Utility", "⏰"),
        AppShortcutItem("Google Photos", "com.google.android.apps.photos", "Media", "🖼️"),
        AppShortcutItem("Spotify", "com.spotify.music", "Media", "🎵"),
        AppShortcutItem("Telegram", "org.telegram.messenger", "Communication", "✈️"),
        AppShortcutItem("System Settings", "com.android.settings", "System", "⚙️")
    )

    /**
     * System settings sub-menu targets.
     */
    val systemSubMenus = listOf(
        SystemSubMenuShortcut("Airplane Mode", "Radio signals and offline status", Settings.ACTION_AIRPLANE_MODE_SETTINGS, "✈️", "Network"),
        SystemSubMenuShortcut("Wi-Fi & Networks", "Wireless network connections", Settings.ACTION_WIFI_SETTINGS, "📶", "Network"),
        SystemSubMenuShortcut("Bluetooth", "Connected wireless accessories", Settings.ACTION_BLUETOOTH_SETTINGS, "📡", "Connectivity"),
        SystemSubMenuShortcut("Mobile Cellular", "Data roaming and SIM options", Settings.ACTION_DATA_ROAMING_SETTINGS, "📱", "Network"),
        SystemSubMenuShortcut("Battery & Power", "Usage analytics and saver mode", Settings.ACTION_BATTERY_SAVER_SETTINGS, "🔋", "Hardware"),
        SystemSubMenuShortcut("Display & Theme", "Brightness, dark mode, screen timeout", Settings.ACTION_DISPLAY_SETTINGS, "🔆", "Display"),
        SystemSubMenuShortcut("Sound & Vibration", "Ringtone, alarms, and volume levels", Settings.ACTION_SOUND_SETTINGS, "🔊", "Audio"),
        SystemSubMenuShortcut("Internal Storage", "Device memory breakdown and cleanup", Settings.ACTION_INTERNAL_STORAGE_SETTINGS, "💾", "Hardware"),
        SystemSubMenuShortcut("Installed Apps", "App permissions and notification controls", Settings.ACTION_APPLICATION_SETTINGS, "📦", "System"),
        SystemSubMenuShortcut("Location Access", "GPS satellites and location accuracy", Settings.ACTION_LOCATION_SOURCE_SETTINGS, "📍", "Privacy"),
        SystemSubMenuShortcut("Accessibility", "Screen readers, magnification, dexterity", Settings.ACTION_ACCESSIBILITY_SETTINGS, "♿", "System"),
        SystemSubMenuShortcut("Date & Time", "Automatic time zones and NTP sync", Settings.ACTION_DATE_SETTINGS, "🕒", "System")
    )

    /**
     * Launches an application by package name or falls back to browser/play store.
     */
    fun launchAppByPackage(packageName: String): Boolean {
        return try {
            val intent = packageManager.getLaunchIntentForPackage(packageName)
            if (intent != null) {
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(intent)
                true
            } else {
                // Fallback for special system apps like camera or calculator
                when {
                    packageName.contains("camera") -> {
                        val camIntent = Intent(MediaStore.ACTION_IMAGE_CAPTURE).apply {
                            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        }
                        context.startActivity(camIntent)
                        true
                    }
                    packageName.contains("calculator") -> {
                        val calcIntent = Intent(Intent.ACTION_MAIN).apply {
                            addCategory(Intent.CATEGORY_APP_CALCULATOR)
                            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        }
                        context.startActivity(calcIntent)
                        true
                    }
                    packageName.contains("settings") -> {
                        val setIntent = Intent(Settings.ACTION_SETTINGS).apply {
                            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        }
                        context.startActivity(setIntent)
                        true
                    }
                    packageName.contains("deskclock") -> {
                        val clockIntent = Intent(AlarmClock.ACTION_SHOW_ALARMS).apply {
                            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        }
                        context.startActivity(clockIntent)
                        true
                    }
                    else -> false
                }
            }
        } catch (_: Exception) {
            false
        }
    }

    /**
     * Navigates directly to any system setting sub-menu.
     */
    fun openSystemSetting(actionIntent: String): Boolean {
        return try {
            val intent = Intent(actionIntent).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            true
        } catch (_: Exception) {
            try {
                val fallback = Intent(Settings.ACTION_SETTINGS).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(fallback)
                true
            } catch (_: Exception) {
                false
            }
        }
    }

    /**
     * Natural Language Command Router for App Launches & System Navigation.
     * Checks if a voice command or text query is an instruction to open an app or settings menu.
     */
    fun processNavigationCommand(text: String): String? {
        val lower = text.lowercase().trim()

        // 1. Check for specific settings requests
        if (lower.contains("airplane mode") || lower.contains("flight mode") || lower.contains("এয়ারপ্লেন মোড")) {
            openSystemSetting(Settings.ACTION_AIRPLANE_MODE_SETTINGS)
            return "Opening Airplane Mode settings."
        }
        if (lower.contains("battery settings") || lower.contains("battery saver") || lower.contains("power usage") || lower.contains("ব্যাটারি সেটিংস")) {
            openSystemSetting(Settings.ACTION_BATTERY_SAVER_SETTINGS)
            return "Opening Battery & Power settings."
        }
        if (lower.contains("wifi settings") || lower.contains("wi-fi settings") || lower.contains("ওয়াইফাই সেটিংস")) {
            openSystemSetting(Settings.ACTION_WIFI_SETTINGS)
            return "Opening Wi-Fi settings."
        }
        if (lower.contains("bluetooth settings") || lower.contains("ব্লুটুথ সেটিংস")) {
            openSystemSetting(Settings.ACTION_BLUETOOTH_SETTINGS)
            return "Opening Bluetooth settings."
        }
        if (lower.contains("display settings") || lower.contains("brightness settings") || lower.contains("স্ক্রিন সেটিংস")) {
            openSystemSetting(Settings.ACTION_DISPLAY_SETTINGS)
            return "Opening Display & Brightness settings."
        }
        if (lower.contains("sound settings") || lower.contains("volume settings") || lower.contains("শব্দ সেটিংস")) {
            openSystemSetting(Settings.ACTION_SOUND_SETTINGS)
            return "Opening Sound & Vibration settings."
        }
        if (lower.contains("storage settings") || lower.contains("স্টোরেজ সেটিংস")) {
            openSystemSetting(Settings.ACTION_INTERNAL_STORAGE_SETTINGS)
            return "Opening Storage settings."
        }

        // 2. Check for App Launch commands ("open ...", "launch ...", "চালু করো ...")
        val isLaunchCommand = lower.startsWith("open ") || lower.startsWith("launch ") ||
                lower.startsWith("start ") || lower.contains("খুলো") || lower.contains("চালু করো")

        if (isLaunchCommand) {
            val appQuery = lower
                .removePrefix("open ")
                .removePrefix("launch ")
                .removePrefix("start ")
                .replace("app", "")
                .trim()

            when {
                appQuery.contains("youtube") -> {
                    launchAppByPackage("com.google.android.youtube")
                    return "Launching YouTube."
                }
                appQuery.contains("chrome") || appQuery.contains("browser") -> {
                    launchAppByPackage("com.android.chrome")
                    return "Launching Google Chrome."
                }
                appQuery.contains("whatsapp") -> {
                    launchAppByPackage("com.whatsapp")
                    return "Launching WhatsApp."
                }
                appQuery.contains("map") -> {
                    launchAppByPackage("com.google.android.apps.maps")
                    return "Launching Google Maps."
                }
                appQuery.contains("camera") -> {
                    launchAppByPackage("com.android.camera")
                    return "Launching Camera."
                }
                appQuery.contains("calculator") -> {
                    launchAppByPackage("com.google.android.calculator")
                    return "Launching Calculator."
                }
                appQuery.contains("photo") || appQuery.contains("gallery") -> {
                    launchAppByPackage("com.google.android.apps.photos")
                    return "Launching Photos Gallery."
                }
                appQuery.contains("spotify") || appQuery.contains("music") -> {
                    launchAppByPackage("com.spotify.music")
                    return "Launching Spotify."
                }
                appQuery.contains("setting") -> {
                    openSystemSetting(Settings.ACTION_SETTINGS)
                    return "Opening Android Settings."
                }
            }
        }

        return null
    }
}
