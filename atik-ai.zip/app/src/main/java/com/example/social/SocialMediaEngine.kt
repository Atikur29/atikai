package com.example.social

import android.content.Context
import android.content.Intent
import android.net.Uri
import com.example.ai.GeminiService
import com.example.data.SocialPlatform
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

data class GeneratedSocialContent(
    val platform: SocialPlatform,
    val hook: String,
    val caption: String,
    val callToAction: String,
    val hashtags: List<String>,
    val fullFormattedPost: String,
    val estimatedEngagementScore: Int,
    val bestTimeRecommendation: String,
    val growthTips: List<String>
)

data class HashtagTrendItem(
    val tag: String,
    val category: String,
    val postVolume: String,
    val velocityScore: Int
)

data class PerformanceEstimation(
    val overallScore: Int, // 0 - 100
    val readabilityRating: String, // "High", "Optimal", "Dense"
    val hookStrength: String, // "Viral", "Strong", "Moderate", "Weak"
    val hashtagScore: Int, // 0 - 100
    val optimalTimeMatch: String,
    val recommendations: List<String>
)

data class PlatformGrowthStrategy(
    val platform: SocialPlatform,
    val algorithmSecret: String,
    val optimalPostingFrequency: String,
    val bestContentTypes: List<String>,
    val actionableHacks: List<String>
)

class SocialMediaEngine(private val geminiService: GeminiService) {

    /**
     * Generate customized captions, viral hashtags, and multi-platform content using Gemini
     */
    suspend fun generateSocialContent(
        topic: String,
        platform: SocialPlatform,
        tone: String,
        targetAudience: String,
        customPromptAddition: String? = null,
        apiKey: String? = null
    ): Result<GeneratedSocialContent> = withContext(Dispatchers.IO) {
        try {
            val systemInstruction = """
                You are Atik AI's elite Social Media Marketing & Viral Content Strategist.
                Your task is to craft high-converting, viral social media posts tailored strictly to platform algorithms.
                Target Platform: ${platform.displayName}
                Tone of Voice: $tone
                Target Audience: $targetAudience
                
                Rules per Platform:
                - TIKTOK: 3-second killer hook, fast conversational pace, punchy body, viral audio suggestions, 6-8 trending FYP hashtags.
                - INSTAGRAM: Aesthetic first line (above the fold), engaging storytelling or value tips, line breaks, strong CTA, 12-18 targeted hashtags.
                - FACEBOOK: Relatable conversational opener, questions to trigger comment debates, clean formatting, 3-5 focused hashtags.
                - TELEGRAM: Eye-catching headline with emojis, bullet points for readability, direct CTA with links placeholder, broadcast channel styling.
                - ALL: Versatile master copy adaptable to any platform.
                
                Respond in valid JSON format:
                {
                    "hook": "Compelling first line or video text overlay",
                    "caption": "The complete post body with formatted paragraphs and emojis",
                    "callToAction": "Clear directive (e.g., Save this, Drop a comment, Share with a friend)",
                    "hashtags": ["#tag1", "#tag2", "#tag3"],
                    "estimatedEngagementScore": 92,
                    "bestTimeRecommendation": "Recommended time window",
                    "growthTips": ["Tip 1 to maximize reach", "Tip 2"]
                }
            """.trimIndent()

            val combinedPrompt = buildString {
                append(systemInstruction)
                append("\n\n---\n\n")
                append("Create a viral social post about: $topic\n")
                if (!customPromptAddition.isNullOrBlank()) {
                    append("Extra Instructions: $customPromptAddition\n")
                }
            }

            val replyResult = geminiService.generateReply(
                prompt = combinedPrompt,
                history = emptyList(),
                languageMode = com.example.ai.LanguageMode.ENGLISH,
                memories = emptyList(),
                model = "gemini-3.5-flash",
                customApiKey = apiKey
            )

            val rawResponse = replyResult.getOrNull().orEmpty()

            // Parse response
            val parsedContent = parseSocialResponse(rawResponse, platform, topic)
            Result.success(parsedContent)
        } catch (e: Exception) {
            // Fallback content in case of network issue
            val fallback = createFallbackContent(topic, platform, tone)
            Result.success(fallback)
        }
    }

    private fun parseSocialResponse(
        raw: String,
        platform: SocialPlatform,
        topic: String
    ): GeneratedSocialContent {
        return try {
            val jsonStart = raw.indexOf('{')
            val jsonEnd = raw.lastIndexOf('}')
            if (jsonStart != -1 && jsonEnd != -1 && jsonEnd > jsonStart) {
                val jsonString = raw.substring(jsonStart, jsonEnd + 1)
                val json = JSONObject(jsonString)

                val hook = json.optString("hook", "🚀 Big News in Tech & AI!")
                val caption = json.optString("caption", raw)
                val cta = json.optString("callToAction", "Share your thoughts below! 👇")

                val tagsList = mutableListOf<String>()
                val tagsArray = json.optJSONArray("hashtags")
                if (tagsArray != null) {
                    for (i in 0 until tagsArray.length()) {
                        val tag = tagsArray.optString(i)
                        if (tag.isNotBlank()) tagsList.add(if (tag.startsWith("#")) tag else "#$tag")
                    }
                }
                if (tagsList.isEmpty()) {
                    tagsList.addAll(getDefaultHashtags(platform))
                }

                val score = json.optInt("estimatedEngagementScore", (80..96).random())
                val timeRec = json.optString("bestTimeRecommendation", platform.optimalTimeDescription)

                val tipsList = mutableListOf<String>()
                val tipsArray = json.optJSONArray("growthTips")
                if (tipsArray != null) {
                    for (i in 0 until tipsArray.length()) {
                        tipsList.add(tipsArray.optString(i))
                    }
                }
                if (tipsList.isEmpty()) {
                    tipsList.add("Post during peak activity: ${platform.optimalTimeDescription}")
                    tipsList.add("Respond to comments within the first 30 minutes to boost algorithmic distribution.")
                }

                val fullPost = buildString {
                    append(hook)
                    append("\n\n")
                    append(caption)
                    append("\n\n")
                    append(cta)
                    append("\n\n")
                    append(tagsList.joinToString(" "))
                }

                GeneratedSocialContent(
                    platform = platform,
                    hook = hook,
                    caption = caption,
                    callToAction = cta,
                    hashtags = tagsList,
                    fullFormattedPost = fullPost,
                    estimatedEngagementScore = score,
                    bestTimeRecommendation = timeRec,
                    growthTips = tipsList
                )
            } else {
                createFormattedFromRawText(raw, platform, topic)
            }
        } catch (e: Exception) {
            createFormattedFromRawText(raw, platform, topic)
        }
    }

    private fun createFormattedFromRawText(
        raw: String,
        platform: SocialPlatform,
        topic: String
    ): GeneratedSocialContent {
        val defaultTags = getDefaultHashtags(platform)
        val hook = "🔥 " + (raw.lines().firstOrNull { it.isNotBlank() } ?: topic)
        val body = raw.replace(hook, "").trim()
        val cta = "👉 Save this post and tag a friend who needs to see this!"

        val full = "$hook\n\n$body\n\n$cta\n\n${defaultTags.joinToString(" ")}"
        return GeneratedSocialContent(
            platform = platform,
            hook = hook,
            caption = body.ifBlank { raw },
            callToAction = cta,
            hashtags = defaultTags,
            fullFormattedPost = full,
            estimatedEngagementScore = 88,
            bestTimeRecommendation = platform.optimalTimeDescription,
            growthTips = listOf(
                "Pin top comments to stimulate community engagement.",
                "Cross-share to your stories within 15 minutes of posting."
            )
        )
    }

    private fun createFallbackContent(
        topic: String,
        platform: SocialPlatform,
        tone: String
    ): GeneratedSocialContent {
        val tags = getDefaultHashtags(platform)
        val hook = "⚡ Unlock the next level with $topic!"
        val body = "Consistency and leveraging smart AI tools is the #1 shortcut to success in 2026. Here is why $topic is changing the game right now:\n\n• Faster execution\n• High-velocity output\n• Scalable growth without burnout"
        val cta = "Double tap if you agree & share with your team! 🚀"
        val full = "$hook\n\n$body\n\n$cta\n\n${tags.joinToString(" ")}"

        return GeneratedSocialContent(
            platform = platform,
            hook = hook,
            caption = body,
            callToAction = cta,
            hashtags = tags,
            fullFormattedPost = full,
            estimatedEngagementScore = 86,
            bestTimeRecommendation = platform.optimalTimeDescription,
            growthTips = listOf(
                "Keep caption under 150 words for peak mobile retention.",
                "Add a carousel image or engaging thumbnail."
            )
        )
    }

    /**
     * Calculate 3 smart optimal posting time slots based on platform algorithms
     */
    fun calculateOptimalPostTimes(platform: SocialPlatform): List<Pair<String, Long>> {
        val calendar = Calendar.getInstance()
        val slots = mutableListOf<Pair<String, Long>>()
        val sdf = SimpleDateFormat("EEE, MMM d • h:mm a", Locale.getDefault())

        when (platform) {
            SocialPlatform.TIKTOK -> {
                // Peak evening: 7:30 PM & 9:00 PM
                slots.add(getSlot(calendar, hour = 19, minute = 30, sdf, "Tonight's FYP Prime Time"))
                slots.add(getSlot(calendar, hour = 21, minute = 0, sdf, "Late Night Viral Surge"))
                slots.add(getSlot(calendar, hour = 12, minute = 30, sdf, "Tomorrow Lunch Break Feed", dayOffset = 1))
            }
            SocialPlatform.INSTAGRAM -> {
                slots.add(getSlot(calendar, hour = 12, minute = 0, sdf, "Lunch Discovery Peak"))
                slots.add(getSlot(calendar, hour = 20, minute = 0, sdf, "Evening Reels Horizon"))
                slots.add(getSlot(calendar, hour = 18, minute = 30, sdf, "Tomorrow Commute Window", dayOffset = 1))
            }
            SocialPlatform.FACEBOOK -> {
                slots.add(getSlot(calendar, hour = 13, minute = 30, sdf, "Early Afternoon Peak"))
                slots.add(getSlot(calendar, hour = 16, minute = 0, sdf, "End-of-Workday Scroll"))
                slots.add(getSlot(calendar, hour = 11, minute = 0, sdf, "Tomorrow Mid-Morning", dayOffset = 1))
            }
            SocialPlatform.TELEGRAM, SocialPlatform.ALL -> {
                slots.add(getSlot(calendar, hour = 10, minute = 30, sdf, "Morning Digest Slot"))
                slots.add(getSlot(calendar, hour = 19, minute = 0, sdf, "Prime Evening Broadcast"))
                slots.add(getSlot(calendar, hour = 15, minute = 0, sdf, "Tomorrow Midday Blast", dayOffset = 1))
            }
        }
        return slots
    }

    private fun getSlot(
        base: Calendar,
        hour: Int,
        minute: Int,
        sdf: SimpleDateFormat,
        label: String,
        dayOffset: Int = 0
    ): Pair<String, Long> {
        val cal = base.clone() as Calendar
        cal.add(Calendar.DAY_OF_YEAR, dayOffset)
        cal.set(Calendar.HOUR_OF_DAY, hour)
        cal.set(Calendar.MINUTE, minute)
        cal.set(Calendar.SECOND, 0)
        cal.set(Calendar.MILLISECOND, 0)

        // If time already passed today without day offset, push to tomorrow
        if (cal.timeInMillis <= System.currentTimeMillis() && dayOffset == 0) {
            cal.add(Calendar.DAY_OF_YEAR, 1)
        }

        return Pair("$label (${sdf.format(Date(cal.timeInMillis))})", cal.timeInMillis)
    }

    /**
     * Estimate post performance and generate actionable recommendations
     */
    fun estimatePerformance(
        caption: String,
        hashtags: String,
        platform: SocialPlatform,
        scheduledTimeMillis: Long
    ): PerformanceEstimation {
        val charCount = caption.length
        val tagsCount = hashtags.split("\\s+".toRegex()).count { it.startsWith("#") }
        val hasEmoji = caption.any { Character.isSurrogate(it) }
        val hasQuestion = caption.contains("?")
        val hasCta = listOf("comment", "share", "save", "link", "follow", "dm", "tap").any {
            caption.contains(it, ignoreCase = true)
        }

        var score = 70
        val recommendations = mutableListOf<String>()

        // Hook analysis
        val firstLine = caption.lines().firstOrNull { it.isNotBlank() } ?: ""
        val hookStrength = when {
            firstLine.length in 10..60 && (firstLine.contains("!") || firstLine.contains("🔥") || firstLine.contains("🚀")) -> {
                score += 10
                "Viral"
            }
            firstLine.length in 5..90 -> {
                score += 5
                "Strong"
            }
            else -> "Moderate"
        }

        // Hashtag optimization
        val hashtagScore = when (platform) {
            SocialPlatform.FACEBOOK -> if (tagsCount in 3..6) 95 else 75
            SocialPlatform.TIKTOK -> if (tagsCount in 4..8) 95 else 70
            SocialPlatform.INSTAGRAM -> if (tagsCount in 8..18) 95 else 75
            SocialPlatform.TELEGRAM -> if (tagsCount in 2..5) 90 else 80
            SocialPlatform.ALL -> if (tagsCount in 5..10) 90 else 75
        }
        score += (hashtagScore - 70) / 4

        // Formatting & Elements
        if (hasEmoji) score += 5 else recommendations.add("Add 2–3 relevant emojis to visually break up the copy.")
        if (hasQuestion) score += 5 else recommendations.add("End with a specific question to encourage viewer discussions.")
        if (hasCta) score += 5 else recommendations.add("Include a direct Call-To-Action (e.g. 'Save for later' or 'Tap the link').")

        // Readability
        val readabilityRating = when {
            charCount < 300 -> "Optimal (High Scanability)"
            charCount < 900 -> "Balanced"
            else -> "Long-Form (Detailed)"
        }

        if (platform == SocialPlatform.TIKTOK && charCount > 500) {
            recommendations.add("TikTok descriptions perform best when concise (under 250 characters).")
        }

        val finalScore = score.coerceIn(55, 99)

        return PerformanceEstimation(
            overallScore = finalScore,
            readabilityRating = readabilityRating,
            hookStrength = hookStrength,
            hashtagScore = hashtagScore,
            optimalTimeMatch = platform.optimalTimeDescription,
            recommendations = recommendations.ifEmpty {
                listOf("Post structure meets peak algorithmic standards. Ready to publish!")
            }
        )
    }

    /**
     * Share content directly to target platform or via Android System Chooser
     */
    fun sharePost(context: Context, platform: SocialPlatform, content: String, mediaUri: Uri? = null) {
        val sendIntent = Intent(Intent.ACTION_SEND).apply {
            type = if (mediaUri != null) "image/*" else "text/plain"
            putExtra(Intent.EXTRA_TEXT, content)
            if (mediaUri != null) {
                putExtra(Intent.EXTRA_STREAM, mediaUri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
        }

        // Specific package targets
        val targetPackage = when (platform) {
            SocialPlatform.FACEBOOK -> "com.facebook.katana"
            SocialPlatform.INSTAGRAM -> "com.instagram.android"
            SocialPlatform.TIKTOK -> "com.zhiliaoapp.musically"
            SocialPlatform.TELEGRAM -> "org.telegram.messenger"
            SocialPlatform.ALL -> null
        }

        if (targetPackage != null) {
            val pm = context.packageManager
            val intentForPackage = Intent(sendIntent).apply { `package` = targetPackage }
            val canHandle = intentForPackage.resolveActivity(pm) != null
            if (canHandle) {
                context.startActivity(intentForPackage)
                return
            }
        }

        // Fallback to chooser
        val chooser = Intent.createChooser(sendIntent, "Share to ${platform.displayName}")
        chooser.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(chooser)
    }

    /**
     * High-velocity trending hashtags categorized by domain
     */
    fun getTrendingHashtags(): List<HashtagTrendItem> {
        return listOf(
            HashtagTrendItem("#AIInnovation", "Tech & AI", "4.8M posts", 98),
            HashtagTrendItem("#FutureOfTech", "Tech & AI", "12.3M posts", 95),
            HashtagTrendItem("#SmartAutomation", "Tech & AI", "3.1M posts", 92),
            HashtagTrendItem("#TechTrends2026", "Tech & AI", "8.9M posts", 96),
            HashtagTrendItem("#ViralReels", "Reels & Video", "88.4M posts", 99),
            HashtagTrendItem("#FYP", "TikTok / FYP", "150M+ posts", 100),
            HashtagTrendItem("#CreatorEconomy", "Earning & Career", "6.2M posts", 94),
            HashtagTrendItem("#DigitalMarketingTips", "Marketing", "9.7M posts", 91),
            HashtagTrendItem("#WorkSmarter", "Productivity", "5.4M posts", 89),
            HashtagTrendItem("#CodingLife", "Developers", "7.1M posts", 93)
        )
    }

    /**
     * Growth strategies and algorithm hacks per platform
     */
    fun getGrowthStrategies(): List<PlatformGrowthStrategy> {
        return listOf(
            PlatformGrowthStrategy(
                platform = SocialPlatform.INSTAGRAM,
                algorithmSecret = "Instagram currently rewards 'Sends/Shares' and 'Saves' 3x higher than simple likes. Carousel posts and Reels maximize dwell time.",
                optimalPostingFrequency = "1 Reel daily + 3 Stories daily + 1 Carousel weekly",
                bestContentTypes = listOf("Educational Carousels", "Behind the Scenes Reels", "Trending Audio Overlays"),
                actionableHacks = listOf(
                    "Include a compelling reason to share in the first 3 seconds.",
                    "Use 3–5 niche hashtags and 5–8 broad hashtags.",
                    "Reply to every comment with a question within 60 minutes."
                )
            ),
            PlatformGrowthStrategy(
                platform = SocialPlatform.TIKTOK,
                algorithmSecret = "The 3-second completion rate dictates 80% of video distribution into the For You Page (FYP). Loopable videos explode in reach.",
                optimalPostingFrequency = "1 to 2 videos daily during local peak hours",
                bestContentTypes = listOf("Problem-Solve Hooks", "Fast Screen Demonstrations", "Hot Takes / Controversies"),
                actionableHacks = listOf(
                    "Display text overlay on the screen within the first second.",
                    "Keep video pacing fast with dynamic visual cuts every 2.5 seconds.",
                    "Add trending sounds even at low background volume (5–10%)."
                )
            ),
            PlatformGrowthStrategy(
                platform = SocialPlatform.FACEBOOK,
                algorithmSecret = "Facebook actively suppresses posts with outbound links in the caption. Place your website or promo link in the first comment.",
                optimalPostingFrequency = "1 high-quality discussion post daily",
                bestContentTypes = listOf("Personal Storytelling", "Discussion Prompts", "Native Short Video Reels"),
                actionableHacks = listOf(
                    "Write 'Link in the first comment 👇' to keep native organic reach high.",
                    "Ask open-ended questions that provoke debate.",
                    "Tag relevant collaborators to trigger dual-audience feeds."
                )
            ),
            PlatformGrowthStrategy(
                platform = SocialPlatform.TELEGRAM,
                algorithmSecret = "Telegram values high forward velocity and instant notification click-throughs. Formatting with bold headers and clear buttons is critical.",
                optimalPostingFrequency = "2 to 3 concise, high-value broadcasts daily",
                bestContentTypes = listOf("Exclusive Resource Drops", "Executive Summaries", "Interactive Polls"),
                actionableHacks = listOf(
                    "Use bold headings and monospace code blocks for clean aesthetics.",
                    "Add an inline reaction emoji poll to measure channel sentiment.",
                    "Schedule broadcasts right before morning and evening commute hours."
                )
            )
        )
    }

    private fun getDefaultHashtags(platform: SocialPlatform): List<String> {
        return when (platform) {
            SocialPlatform.TIKTOK -> listOf("#FYP", "#Viral", "#TechTok", "#AI", "#Trending", "#Innovation")
            SocialPlatform.INSTAGRAM -> listOf("#TechReels", "#AIInnovation", "#CreatorEconomy", "#DigitalCreator", "#FutureTech", "#TrendingNow", "#ProductivityHacks")
            SocialPlatform.FACEBOOK -> listOf("#Technology", "#AI", "#DigitalTransformation", "#Productivity", "#TechNews")
            SocialPlatform.TELEGRAM -> listOf("#TechUpdate", "#AI", "#Exclusive", "#SmartTools")
            SocialPlatform.ALL -> listOf("#AI", "#TechTrends", "#Innovation", "#Productivity", "#Viral")
        }
    }
}
