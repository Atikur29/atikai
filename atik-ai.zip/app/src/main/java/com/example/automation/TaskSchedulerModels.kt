package com.example.automation

import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/**
 * Atomic action steps that can be composed into combined Macro Workflows (Step 22 Requirement 2).
 */
enum class WorkflowActionType(
    val id: String,
    val displayName: String,
    val description: String,
    val iconEmoji: String
) {
    READ_LIVE_NEWS(
        id = "read_news",
        displayName = "Read Live News",
        description = "Fetches top global news and provides audio summary",
        iconEmoji = "📰"
    ),
    CHECK_SYSTEM_STATUS(
        id = "check_system",
        displayName = "Check Device Telemetry",
        description = "Inspects battery level, RAM utilization, and storage",
        iconEmoji = "📊"
    ),
    TURN_ON_WIFI(
        id = "turn_on_wifi",
        displayName = "Engage Wi-Fi Network",
        description = "Opens and verifies wireless connectivity",
        iconEmoji = "📶"
    ),
    TURN_ON_BLUETOOTH(
        id = "turn_on_bluetooth",
        displayName = "Engage Bluetooth Radio",
        description = "Activates Bluetooth adapter for connected gear",
        iconEmoji = "🔷"
    ),
    OPTIMIZE_MEMORY(
        id = "optimize_memory",
        displayName = "Boost Memory (RAM)",
        description = "Cleans application cache and runs garbage collection",
        iconEmoji = "🚀"
    ),
    DISPATCH_EXECUTIVE_BRIEFING(
        id = "briefing",
        displayName = "Executive Voice Briefing",
        description = "Speaks dynamic warrior briefing and daily agenda",
        iconEmoji = "🥋"
    ),
    TOGGLE_FLASHLIGHT(
        id = "toggle_flashlight",
        displayName = "Toggle LED Flashlight",
        description = "Toggles hardware torch for visibility",
        iconEmoji = "🔦"
    ),
    SILENT_SOUND_PROFILE(
        id = "silent_profile",
        displayName = "Engage Mute Profile",
        description = "Silences ringtones and notification speakers",
        iconEmoji = "🔕"
    ),
    NORMAL_SOUND_PROFILE(
        id = "normal_profile",
        displayName = "Normal Sound Profile",
        description = "Restores sound profile to standard ringtone volume",
        iconEmoji = "🔔"
    ),
    SEND_PUSH_ALERT(
        id = "push_alert",
        displayName = "Dispatch Priority Banner",
        description = "Sends high-importance system banner alert",
        iconEmoji = "📣"
    );

    companion object {
        fun fromId(id: String): WorkflowActionType? = values().firstOrNull { it.id.equals(id.trim(), ignoreCase = true) }
    }
}

/**
 * Configuration model for scheduled Quiet Hours and Do Not Disturb (DND) modes (Step 22 Requirement 3).
 */
data class QuietHoursConfig(
    val isEnabled: Boolean = false,
    val startHour: Int = 22,   // 10:00 PM default
    val startMinute: Int = 0,
    val endHour: Int = 7,      // 07:00 AM default
    val endMinute: Int = 0,
    val allowUrgentTasks: Boolean = true,
    val vibrateOnly: Boolean = false,
    val notificationSoundEnabled: Boolean = true
) {
    val formattedStartTime: String
        get() = formatTime(startHour, startMinute)

    val formattedEndTime: String
        get() = formatTime(endHour, endMinute)

    private fun formatTime(h: Int, m: Int): String {
        val amPm = if (h >= 12) "PM" else "AM"
        val hour12 = when {
            h == 0 -> 12
            h > 12 -> h - 12
            else -> h
        }
        return String.format(Locale.US, "%02d:%02d %s", hour12, m, amPm)
    }

    /**
     * Determines whether Quiet Hours / DND is currently active based on system clock.
     */
    fun isCurrentlyActive(): Boolean {
        if (!isEnabled) return false

        val now = Calendar.getInstance()
        val currentMinutes = now.get(Calendar.HOUR_OF_DAY) * 60 + now.get(Calendar.MINUTE)
        val startMinutes = startHour * 60 + startMinute
        val endMinutes = endHour * 60 + endMinute

        return if (startMinutes < endMinutes) {
            // Same-day window (e.g., 01:00 PM to 05:00 PM)
            currentMinutes in startMinutes..endMinutes
        } else {
            // Overnight window (e.g., 10:00 PM to 07:00 AM)
            currentMinutes >= startMinutes || currentMinutes <= endMinutes
        }
    }
}

/**
 * Execution report summarizing steps performed during a macro workflow run.
 */
data class WorkflowExecutionReport(
    val workflowId: String,
    val workflowName: String,
    val isSuccess: Boolean,
    val executedSteps: List<String>,
    val timestamp: Long = System.currentTimeMillis(),
    val summaryMessage: String
)
