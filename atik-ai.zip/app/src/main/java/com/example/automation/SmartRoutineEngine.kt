package com.example.automation

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build
import androidx.core.app.NotificationCompat
import com.example.R
import com.example.data.ChatRepository
import com.example.data.ReminderEntity
import com.example.data.RoutineEntity
import com.example.data.TaskItemEntity
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

sealed class ParsedAutomationCommand {
    data class AddTask(val title: String, val priority: String, val category: String) : ParsedAutomationCommand()
    data class SetReminder(val title: String, val timeFormatted: String, val timeMillis: Long, val isAlarm: Boolean) : ParsedAutomationCommand()
    data class TriggerRoutine(val routineType: String) : ParsedAutomationCommand()
    object ListTasks : ParsedAutomationCommand()
}

/**
 * Smart Automation & Routine Task Engine for Atik AI (Step 13 Requirement 1 & 2).
 * Handles daily morning/evening executive briefings, scheduled alarms, localized push reminders,
 * and text/voice task command parsing.
 */
class SmartRoutineEngine(
    private val context: Context,
    private val repository: ChatRepository
) {
    private val notificationManager =
        context.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager

    companion object {
        const val CHANNEL_ROUTINES = "atik_routines_channel"
        const val CHANNEL_REMINDERS = "atik_reminders_channel"
    }

    init {
        createNotificationChannels()
    }

    private fun createNotificationChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val routineChannel = NotificationChannel(
                CHANNEL_ROUTINES,
                "Atik AI Daily Briefings & Routines",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Automated Morning & Evening executive briefings and focus summaries"
            }

            val reminderChannel = NotificationChannel(
                CHANNEL_REMINDERS,
                "Atik AI Reminders & Alarms",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Scheduled task reminders and priority alert notifications"
                enableVibration(true)
            }

            notificationManager?.createNotificationChannel(routineChannel)
            notificationManager?.createNotificationChannel(reminderChannel)
        }
    }

    /**
     * Dispatches a localized system notification for reminders or briefings.
     */
    fun postNotification(
        id: Int,
        title: String,
        content: String,
        channelId: String = CHANNEL_REMINDERS
    ) {
        try {
            val builder = NotificationCompat.Builder(context, channelId)
                .setSmallIcon(R.drawable.ic_launcher_foreground)
                .setContentTitle(title)
                .setContentText(content)
                .setStyle(NotificationCompat.BigTextStyle().bigText(content))
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setAutoCancel(true)

            notificationManager?.notify(id, builder.build())
        } catch (_: Exception) {
        }
    }

    /**
     * Generates dynamic executive briefings for Morning, Evening, Work Focus, or Night Meditation.
     */
    suspend fun generateBriefingContent(
        routineType: String,
        userName: String = "Atikur Rahman",
        preferredTitle: String = "Atik Bhai"
    ): String {
        val pendingTasks = repository.getPendingTasksList()
        val highPriorityCount = pendingTasks.count { it.priority == "HIGH" || it.priority == "URGENT" }
        val dateFormatted = SimpleDateFormat("EEEE, MMMM d, yyyy", Locale.US).format(Date())
        val timeFormatted = SimpleDateFormat("h:mm a", Locale.US).format(Date())

        return when (routineType.uppercase(Locale.ROOT)) {
            "MORNING_BRIEFING" -> {
                val sb = StringBuilder()
                sb.append("🌅 **[Morning Executive Briefing]**\n")
                sb.append("Assalamu Alaikum **$preferredTitle**! Here is your daily operational roadmap for **$dateFormatted**:\n\n")
                sb.append("🌤️ **Atmosphere:** 27°C • Optimal clarity for peak cognitive performance.\n")
                sb.append("🕒 **Briefing Time:** $timeFormatted\n")
                sb.append("📌 **Pending Action Items:** ${pendingTasks.size} tasks in queue")
                if (highPriorityCount > 0) {
                    sb.append(" (**$highPriorityCount High Priority**)")
                }
                sb.append("\n\n")

                if (pendingTasks.isNotEmpty()) {
                    sb.append("🎯 **Top Priorities for Today:**\n")
                    pendingTasks.take(4).forEachIndexed { i, t ->
                        val badge = when (t.priority) {
                            "URGENT" -> "🚨 [URGENT]"
                            "HIGH" -> "🔴 [HIGH]"
                            "MEDIUM" -> "🟡 [MED]"
                            else -> "⚪"
                        }
                        sb.append("${i + 1}. $badge **${t.title}** (${t.category})\n")
                    }
                    sb.append("\n")
                } else {
                    sb.append("🎉 **Clean Slate:** No pending tasks in your queue! You are fully prepared to start fresh.\n\n")
                }

                sb.append("🥋 **Kung-Fu Warrior Creed:** *\"Discipline is not a constraint—it is the ultimate weapon that turns ambitious objectives into triumphant realities.\"*\n\n")
                sb.append("Ready to conquer today, Boss! What shall we tackle first?")
                sb.toString()
            }

            "EVENING_SUMMARY" -> {
                val sb = StringBuilder()
                sb.append("🌇 **[Evening Accomplishment Summary]**\n")
                sb.append("Good evening, **$preferredTitle**! Reflecting on your accomplishments today ($timeFormatted):\n\n")
                sb.append("📊 **Operational Status:**\n")
                sb.append("• **Remaining Open Tasks:** ${pendingTasks.size}\n")
                if (pendingTasks.isNotEmpty()) {
                    sb.append("• **Key Items for Tomorrow:**\n")
                    pendingTasks.take(3).forEach { t ->
                        sb.append("  - ${t.title} (${t.priority})\n")
                    }
                } else {
                    sb.append("• **Outstanding Execution:** All tasks resolved for the day!\n")
                }
                sb.append("\n🧘 **Kung-Fu Warrior Recovery:** Take time to disconnect, nourish your energy, and rest. Tomorrow holds new victories!")
                sb.toString()
            }

            "WORK_FOCUS" -> {
                val sb = StringBuilder()
                sb.append("⚡ **[Deep Work Sprint Briefing]**\n")
                sb.append("Focus protocol engaged for **$preferredTitle** at $timeFormatted!\n\n")
                sb.append("⏱️ **Session Format:** 25-Minute High-Impact Pomodoro Sprint\n")
                sb.append("🎯 **Target Objective:** Eliminate distractions, silence unnecessary tabs, and achieve deep flow.\n\n")
                if (pendingTasks.isNotEmpty()) {
                    val topTask = pendingTasks.first()
                    sb.append("🥊 **Primary Target:** **${topTask.title}** (${topTask.category} • ${topTask.priority})\n\n")
                }
                sb.append("Let's crush this sprint, Boss!")
                sb.toString()
            }

            "NIGHT_MEDITATION" -> {
                """
                    🌙 **[Night Reflection & Rest]**
                    
                    Assalamu Alaikum **$preferredTitle**. As the day concludes:
                    
                    • **Mindful Reset:** Acknowledge your hard work and let go of unresolved stress.
                    • **System Health:** Device battery and background services checked.
                    • **Restorative Slumber:** Deep sleep sharpens the mind and restores physical strength.
                    
                    Have a restful night, Boss Atik. I remain standing guard. 🥋
                """.trimIndent()
            }

            else -> {
                "📋 **[Daily Automation Briefing]**\nAssalamu Alaikum Boss $preferredTitle! All systems operational at $timeFormatted."
            }
        }
    }

    /**
     * Parses natural language input to detect task, reminder, alarm, or routine instructions.
     */
    fun parseAutomationCommand(input: String): ParsedAutomationCommand? {
        val lower = input.trim().lowercase(Locale.ROOT)

        // 1. Routine triggering
        if (lower.contains("morning briefing") || lower.contains("সকালের ব্রিফিং") || lower.contains("morning routine")) {
            return ParsedAutomationCommand.TriggerRoutine("MORNING_BRIEFING")
        }
        if (lower.contains("evening summary") || lower.contains("সন্ধ্যার ব্রিফিং") || lower.contains("evening routine")) {
            return ParsedAutomationCommand.TriggerRoutine("EVENING_SUMMARY")
        }
        if (lower.contains("work focus") || lower.contains("deep work") || lower.contains("focus sprint")) {
            return ParsedAutomationCommand.TriggerRoutine("WORK_FOCUS")
        }

        // 2. Alarm setting: "set alarm for 7:30 AM" or "৭:৩০ এ অ্যালার্ম দাও"
        val alarmRegex = """(set\s+)?alarm(\s+for)?\s+(\d{1,2}(:\d{2})?\s*(am|pm)?)""".toRegex()
        val alarmMatch = alarmRegex.find(lower)
        if (alarmMatch != null) {
            val timeStr = alarmMatch.groupValues[3].trim()
            val cal = parseTimeStringToCalendar(timeStr)
            return ParsedAutomationCommand.SetReminder(
                title = "Wake Up & Executive Alarm",
                timeFormatted = SimpleDateFormat("h:mm a", Locale.US).format(cal.time),
                timeMillis = cal.timeInMillis,
                isAlarm = true
            )
        }

        // 3. Reminder setting: "remind me to [title] at [time]"
        val remindRegex = """remind\s+(me\s+)?(to\s+)?(.+?)\s+(at|in)\s+(\d{1,2}(:\d{2})?\s*(am|pm)?)""".toRegex()
        val remindMatch = remindRegex.find(lower)
        if (remindMatch != null) {
            val taskTitle = remindMatch.groupValues[3].trim()
            val timeStr = remindMatch.groupValues[5].trim()
            val cal = parseTimeStringToCalendar(timeStr)
            return ParsedAutomationCommand.SetReminder(
                title = taskTitle.replaceFirstChar { if (it.isLowerCase()) it.titlecase(Locale.US) else it.toString() },
                timeFormatted = SimpleDateFormat("h:mm a", Locale.US).format(cal.time),
                timeMillis = cal.timeInMillis,
                isAlarm = false
            )
        }

        // 4. Task creation: "add task: [title]" or "task: [title]" or "টাস্ক যুক্ত করো [title]"
        val isTask = lower.startsWith("add task") ||
                lower.startsWith("task:") ||
                lower.startsWith("new task") ||
                lower.startsWith("create task") ||
                lower.startsWith("টাস্ক:") ||
                lower.startsWith("নতুন টাস্ক")

        if (isTask) {
            val title = input.trim()
                .replace("add task:", "", ignoreCase = true)
                .replace("add task", "", ignoreCase = true)
                .replace("task:", "", ignoreCase = true)
                .replace("new task:", "", ignoreCase = true)
                .replace("new task", "", ignoreCase = true)
                .replace("create task", "", ignoreCase = true)
                .replace("টাস্ক:", "")
                .replace("নতুন টাস্ক", "")
                .trim()

            if (title.isNotBlank()) {
                val priority = when {
                    lower.contains("urgent") || lower.contains("জরুরি") -> "URGENT"
                    lower.contains("high") || lower.contains("হাই") -> "HIGH"
                    lower.contains("low") || lower.contains("কম") -> "LOW"
                    else -> "MEDIUM"
                }
                val category = when {
                    lower.contains("ai") || lower.contains("model") || lower.contains("coding") -> "AI Development"
                    lower.contains("learn") || lower.contains("study") || lower.contains("পড়াশোনা") -> "Learning"
                    lower.contains("gym") || lower.contains("health") || lower.contains("স্বাস্থ্য") -> "Health"
                    lower.contains("personal") || lower.contains("ব্যক্তিগত") -> "Personal"
                    else -> "Work"
                }
                return ParsedAutomationCommand.AddTask(
                    title = title.replaceFirstChar { if (it.isLowerCase()) it.titlecase(Locale.US) else it.toString() },
                    priority = priority,
                    category = category
                )
            }
        }

        // 5. List Tasks: "show tasks", "list tasks", "আমার কাজগুলো দেখাও"
        if (lower.contains("show tasks") || lower.contains("list tasks") || lower.contains("my tasks") ||
            lower.contains("আমার টাস্ক") || lower.contains("টাস্কগুলো দেখাও")
        ) {
            return ParsedAutomationCommand.ListTasks
        }

        return null
    }

    private fun parseTimeStringToCalendar(timeStr: String): Calendar {
        val cal = Calendar.getInstance()
        try {
            val formats = listOf("h:mm a", "h:mma", "h a", "ha", "HH:mm")
            for (fmt in formats) {
                try {
                    val sdf = SimpleDateFormat(fmt, Locale.US)
                    val parsed = sdf.parse(timeStr)
                    if (parsed != null) {
                        val parsedCal = Calendar.getInstance().apply { time = parsed }
                        cal.set(Calendar.HOUR_OF_DAY, parsedCal.get(Calendar.HOUR_OF_DAY))
                        cal.set(Calendar.MINUTE, parsedCal.get(Calendar.MINUTE))
                        cal.set(Calendar.SECOND, 0)
                        if (cal.timeInMillis < System.currentTimeMillis()) {
                            // If time has passed today, schedule for tomorrow
                            cal.add(Calendar.DAY_OF_YEAR, 1)
                        }
                        return cal
                    }
                } catch (_: Exception) {
                }
            }
        } catch (_: Exception) {
        }
        // Fallback: 1 hour from now
        cal.add(Calendar.HOUR_OF_DAY, 1)
        return cal
    }
}
