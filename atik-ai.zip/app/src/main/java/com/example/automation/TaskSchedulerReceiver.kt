package com.example.automation

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.util.Log
import androidx.core.app.NotificationCompat
import com.example.MainActivity
import com.example.R

/**
 * BroadcastReceiver triggered by AlarmManager for automated task triggers,
 * scheduled alarms, reminders, and macro workflow routines (Step 22 Requirement 1).
 */
class TaskSchedulerReceiver : BroadcastReceiver() {

    companion object {
        const val ACTION_TRIGGER_TASK = "com.example.atik.ACTION_TRIGGER_TASK"
        const val ACTION_TRIGGER_REMINDER = "com.example.atik.ACTION_TRIGGER_REMINDER"
        const val ACTION_TRIGGER_WORKFLOW = "com.example.atik.ACTION_TRIGGER_WORKFLOW"

        const val EXTRA_ITEM_ID = "extra_item_id"
        const val EXTRA_TITLE = "extra_title"
        const val EXTRA_CONTENT = "extra_content"
        const val EXTRA_IS_ALARM = "extra_is_alarm"
        const val EXTRA_IS_URGENT = "extra_is_urgent"

        private const val CHANNEL_TASK_ALERTS = "atik_task_scheduler_channel"
    }

    override fun onReceive(context: Context, intent: Intent) {
        val title = intent.getStringExtra(EXTRA_TITLE) ?: "Atik AI Scheduled Event"
        val content = intent.getStringExtra(EXTRA_CONTENT) ?: "Scheduled task action is ready."
        val isAlarm = intent.getBooleanExtra(EXTRA_IS_ALARM, false)
        val isUrgent = intent.getBooleanExtra(EXTRA_IS_URGENT, false)
        val itemId = intent.getStringExtra(EXTRA_ITEM_ID) ?: System.currentTimeMillis().toString()

        Log.d("TaskSchedulerReceiver", "Received scheduled trigger: $title")

        // 1. Inspect Quiet Hours / Do Not Disturb
        val prefs = context.getSharedPreferences("atik_quiet_hours_prefs", Context.MODE_PRIVATE)
        val isDndEnabled = prefs.getBoolean("dnd_enabled", false)
        val startHour = prefs.getInt("dnd_start_hour", 22)
        val startMinute = prefs.getInt("dnd_start_minute", 0)
        val endHour = prefs.getInt("dnd_end_hour", 7)
        val endMinute = prefs.getInt("dnd_end_minute", 0)
        val allowUrgent = prefs.getBoolean("dnd_allow_urgent", true)

        val quietConfig = QuietHoursConfig(
            isEnabled = isDndEnabled,
            startHour = startHour,
            startMinute = startMinute,
            endHour = endHour,
            endMinute = endMinute,
            allowUrgentTasks = allowUrgent
        )

        val isQuietNow = quietConfig.isCurrentlyActive()
        if (isQuietNow && !isUrgent && !isAlarm) {
            Log.d("TaskSchedulerReceiver", "Suppressed audible notification due to active Quiet Hours.")
            // Still deliver silent/low-priority visual notification without sound
            postNotification(context, title, content, isSilent = true, itemId = itemId.hashCode())
            return
        }

        // 2. Play Discrete Tone & Vibration
        triggerAlertFeedback(context, isAlarm)

        // 3. Post System Notification Banner
        postNotification(context, title, content, isSilent = false, itemId = itemId.hashCode())
    }

    private fun postNotification(context: Context, title: String, content: String, isSilent: Boolean, itemId: Int) {
        val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager
            ?: return

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_TASK_ALERTS,
                "Atik AI Task & Workflow Alerts",
                if (isSilent) NotificationManager.IMPORTANCE_LOW else NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Automated reminders, macro workflow runs, and priority task alerts"
                if (!isSilent) enableVibration(true)
            }
            notificationManager.createNotificationChannel(channel)
        }

        val tapIntent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val pendingTapIntent = PendingIntent.getActivity(
            context,
            itemId,
            tapIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val builder = NotificationCompat.Builder(context, CHANNEL_TASK_ALERTS)
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setContentTitle(title)
            .setContentText(content)
            .setStyle(NotificationCompat.BigTextStyle().bigText(content))
            .setPriority(if (isSilent) NotificationCompat.PRIORITY_LOW else NotificationCompat.PRIORITY_HIGH)
            .setContentIntent(pendingTapIntent)
            .setAutoCancel(true)

        try {
            notificationManager.notify(itemId, builder.build())
        } catch (_: Exception) {}
    }

    private fun triggerAlertFeedback(context: Context, isAlarm: Boolean) {
        try {
            val toneGen = ToneGenerator(AudioManager.STREAM_NOTIFICATION, 85)
            if (isAlarm) {
                toneGen.startTone(ToneGenerator.TONE_PROP_ACK, 250)
            } else {
                toneGen.startTone(ToneGenerator.TONE_PROP_BEEP, 120)
            }
        } catch (_: Exception) {}

        try {
            val vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val vm = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
                vm?.defaultVibrator
            } else {
                @Suppress("DEPRECATION")
                context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
            }

            if (vibrator != null && vibrator.hasVibrator()) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    val timings = if (isAlarm) longArrayOf(0, 100, 80, 150) else longArrayOf(0, 60, 50, 60)
                    val amplitudes = if (isAlarm) intArrayOf(0, 200, 0, 255) else intArrayOf(0, 150, 0, 180)
                    vibrator.vibrate(VibrationEffect.createWaveform(timings, amplitudes, -1))
                } else {
                    @Suppress("DEPRECATION")
                    vibrator.vibrate(100)
                }
            }
        } catch (_: Exception) {}
    }
}
