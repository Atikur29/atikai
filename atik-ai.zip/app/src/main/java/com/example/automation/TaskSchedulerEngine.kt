package com.example.automation

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import android.provider.Settings
import android.util.Log
import com.example.data.ChatRepository
import com.example.data.ReminderEntity
import com.example.data.WorkflowEntity
import com.example.device.DeviceHardwareManager
import com.example.device.SoundProfile
import com.example.device.SystemAutomationEngine
import com.example.news.SmartWebSearchEngine
import com.example.voice.AudioCueType
import com.example.voice.VoiceManager
import com.example.ai.LanguageMode
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

/**
 * Smart Automation Workflows & Task Scheduler Engine for Atik AI (Step 22).
 * Integrates AlarmManager background scheduling, macro workflow multi-step execution,
 * and scheduled Quiet Hours / Do Not Disturb (DND) management.
 */
class TaskSchedulerEngine(
    private val context: Context,
    private val repository: ChatRepository,
    private val routineEngine: SmartRoutineEngine,
    private val systemAutomationEngine: SystemAutomationEngine,
    private val hardwareManager: DeviceHardwareManager,
    private val webSearchEngine: SmartWebSearchEngine,
    private val voiceManager: VoiceManager
) {
    private val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager
    private val prefs = context.getSharedPreferences("atik_quiet_hours_prefs", Context.MODE_PRIVATE)
    private val scope = CoroutineScope(Dispatchers.Main)

    // Quiet Hours StateFlow
    private val _quietHoursConfig = MutableStateFlow(loadQuietHoursConfig())
    val quietHoursConfig: StateFlow<QuietHoursConfig> = _quietHoursConfig.asStateFlow()

    private val _isExecutingWorkflow = MutableStateFlow(false)
    val isExecutingWorkflow: StateFlow<Boolean> = _isExecutingWorkflow.asStateFlow()

    private val _lastWorkflowReport = MutableStateFlow<WorkflowExecutionReport?>(null)
    val lastWorkflowReport: StateFlow<WorkflowExecutionReport?> = _lastWorkflowReport.asStateFlow()

    private fun loadQuietHoursConfig(): QuietHoursConfig {
        return QuietHoursConfig(
            isEnabled = prefs.getBoolean("dnd_enabled", false),
            startHour = prefs.getInt("dnd_start_hour", 22),
            startMinute = prefs.getInt("dnd_start_minute", 0),
            endHour = prefs.getInt("dnd_end_hour", 7),
            endMinute = prefs.getInt("dnd_end_minute", 0),
            allowUrgentTasks = prefs.getBoolean("dnd_allow_urgent", true),
            vibrateOnly = prefs.getBoolean("dnd_vibrate_only", false),
            notificationSoundEnabled = prefs.getBoolean("dnd_sound_enabled", true)
        )
    }

    // =========================================================================
    // 1. ALARM MANAGER TASK SCHEDULING (Requirement 1)
    // =========================================================================

    /**
     * Schedules an exact alarm/reminder trigger using Android AlarmManager.
     */
    fun scheduleExactReminder(reminder: ReminderEntity) {
        if (alarmManager == null) return
        val targetMillis = reminder.timeMillis
        if (targetMillis <= System.currentTimeMillis()) return

        val intent = Intent(context, TaskSchedulerReceiver::class.java).apply {
            action = TaskSchedulerReceiver.ACTION_TRIGGER_REMINDER
            putExtra(TaskSchedulerReceiver.EXTRA_ITEM_ID, reminder.id)
            putExtra(TaskSchedulerReceiver.EXTRA_TITLE, "⏰ Reminder: ${reminder.title}")
            putExtra(TaskSchedulerReceiver.EXTRA_CONTENT, "Scheduled for ${reminder.timeFormatted}")
            putExtra(TaskSchedulerReceiver.EXTRA_IS_ALARM, reminder.isAlarm)
            putExtra(TaskSchedulerReceiver.EXTRA_IS_URGENT, false)
        }

        val pendingIntent = PendingIntent.getBroadcast(
            context,
            reminder.id.hashCode(),
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                alarmManager.setExactAndAllowWhileIdle(
                    AlarmManager.RTC_WAKEUP,
                    targetMillis,
                    pendingIntent
                )
            } else {
                alarmManager.setExact(
                    AlarmManager.RTC_WAKEUP,
                    targetMillis,
                    pendingIntent
                )
            }
            Log.d("TaskSchedulerEngine", "Successfully scheduled reminder ${reminder.id} for $targetMillis")
        } catch (e: Exception) {
            Log.e("TaskSchedulerEngine", "Failed to schedule exact alarm: ${e.message}")
        }
    }

    /**
     * Cancels a scheduled reminder alarm.
     */
    fun cancelReminder(reminderId: String) {
        if (alarmManager == null) return
        val intent = Intent(context, TaskSchedulerReceiver::class.java).apply {
            action = TaskSchedulerReceiver.ACTION_TRIGGER_REMINDER
        }
        val pendingIntent = PendingIntent.getBroadcast(
            context,
            reminderId.hashCode(),
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        try {
            alarmManager.cancel(pendingIntent)
        } catch (_: Exception) {}
    }

    /**
     * Schedules daily recurring execution time for a Workflow.
     */
    fun scheduleWorkflowAlarm(workflow: WorkflowEntity) {
        if (alarmManager == null || !workflow.isEnabled) return
        val cal = parseTimeToCalendar(workflow.scheduledTime)

        val intent = Intent(context, TaskSchedulerReceiver::class.java).apply {
            action = TaskSchedulerReceiver.ACTION_TRIGGER_WORKFLOW
            putExtra(TaskSchedulerReceiver.EXTRA_ITEM_ID, workflow.id)
            putExtra(TaskSchedulerReceiver.EXTRA_TITLE, "${workflow.iconEmoji} Workflow: ${workflow.name}")
            putExtra(TaskSchedulerReceiver.EXTRA_CONTENT, workflow.description.ifBlank { "Automated macro routine trigger." })
            putExtra(TaskSchedulerReceiver.EXTRA_IS_ALARM, false)
            putExtra(TaskSchedulerReceiver.EXTRA_IS_URGENT, false)
        }

        val pendingIntent = PendingIntent.getBroadcast(
            context,
            workflow.id.hashCode(),
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        try {
            alarmManager.setRepeating(
                AlarmManager.RTC_WAKEUP,
                cal.timeInMillis,
                AlarmManager.INTERVAL_DAY,
                pendingIntent
            )
            Log.d("TaskSchedulerEngine", "Scheduled repeating workflow ${workflow.name} at ${cal.time}")
        } catch (e: Exception) {
            Log.e("TaskSchedulerEngine", "Failed to schedule workflow alarm: ${e.message}")
        }
    }

    fun cancelWorkflowAlarm(workflowId: String) {
        if (alarmManager == null) return
        val intent = Intent(context, TaskSchedulerReceiver::class.java).apply {
            action = TaskSchedulerReceiver.ACTION_TRIGGER_WORKFLOW
        }
        val pendingIntent = PendingIntent.getBroadcast(
            context,
            workflowId.hashCode(),
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        try {
            alarmManager.cancel(pendingIntent)
        } catch (_: Exception) {}
    }

    // =========================================================================
    // 2. CUSTOM ROUTINE WORKFLOW EXECUTION ENGINE (Requirement 2)
    // =========================================================================

    /**
     * Executes all action steps composed within a macro workflow.
     */
    suspend fun executeWorkflow(
        workflow: WorkflowEntity,
        onStepProgress: ((stepDesc: String) -> Unit)? = null
    ): WorkflowExecutionReport {
        _isExecutingWorkflow.value = true
        val executedSteps = mutableListOf<String>()
        val actionIds = workflow.actionsCsv.split(",").map { it.trim() }.filter { it.isNotBlank() }

        var success = true
        val summaryBuilder = StringBuilder()

        try {
            withContext(Dispatchers.Default) {
                for (actionId in actionIds) {
                    val action = WorkflowActionType.fromId(actionId) ?: continue
                    val stepDesc = "${action.iconEmoji} ${action.displayName}"
                    onStepProgress?.invoke(stepDesc)

                    when (action) {
                        WorkflowActionType.READ_LIVE_NEWS -> {
                            val articles = webSearchEngine.newsArticles.value
                            val headline = articles.firstOrNull()?.title ?: "Technology and AI updates remain active worldwide."
                            executedSteps.add("Read Live News: $headline")
                            if (!_quietHoursConfig.value.isCurrentlyActive()) {
                                withContext(Dispatchers.Main) {
                                    voiceManager.speak("Here is your morning news update: $headline", LanguageMode.ENGLISH)
                                }
                            }
                        }

                        WorkflowActionType.CHECK_SYSTEM_STATUS -> {
                            val battery = hardwareManager.getBatteryInfo().levelPct
                            val wifi = hardwareManager.isWifiEnabled()
                            val ramFreeGb = hardwareManager.getRamInfo().freeGb
                            executedSteps.add("Device Telemetry: Battery $battery% • RAM ${ramFreeGb}GB free • Wi-Fi ${if (wifi) "Connected" else "Offline"}")
                        }

                        WorkflowActionType.TURN_ON_WIFI -> {
                            systemAutomationEngine.openWifiControls()
                            executedSteps.add("Wi-Fi network controls engaged")
                        }

                        WorkflowActionType.TURN_ON_BLUETOOTH -> {
                            systemAutomationEngine.openBluetoothControls()
                            executedSteps.add("Bluetooth radio initialized")
                        }

                        WorkflowActionType.OPTIMIZE_MEMORY -> {
                            System.gc()
                            executedSteps.add("Boost Memory: RAM garbage collection sweep finished")
                        }

                        WorkflowActionType.DISPATCH_EXECUTIVE_BRIEFING -> {
                            val briefing = routineEngine.generateBriefingContent("MORNING_BRIEFING")
                            executedSteps.add("Executive Briefing delivered")
                            if (!_quietHoursConfig.value.isCurrentlyActive()) {
                                withContext(Dispatchers.Main) {
                                    voiceManager.speak("Assalamu Alaikum Boss Atik! Your morning operational roadmap is active.", LanguageMode.ENGLISH)
                                }
                            }
                        }

                        WorkflowActionType.TOGGLE_FLASHLIGHT -> {
                            systemAutomationEngine.toggleFlashlight()
                            executedSteps.add("LED Torch toggled")
                        }

                        WorkflowActionType.SILENT_SOUND_PROFILE -> {
                            systemAutomationEngine.setSoundProfile(SoundProfile.SILENT)
                            executedSteps.add("Sound Profile: Mute engaged")
                        }

                        WorkflowActionType.NORMAL_SOUND_PROFILE -> {
                            systemAutomationEngine.setSoundProfile(SoundProfile.NORMAL)
                            executedSteps.add("Sound Profile: Normal restored")
                        }

                        WorkflowActionType.SEND_PUSH_ALERT -> {
                            routineEngine.postNotification(
                                id = workflow.id.hashCode(),
                                title = "${workflow.iconEmoji} ${workflow.name} Executed",
                                content = "All ${actionIds.size} automated macro actions finished successfully."
                            )
                            executedSteps.add("Push banner dispatched")
                        }
                    }

                    delay(200) // Brief stagger between macro actions
                }
            }
        } catch (e: Exception) {
            success = false
            summaryBuilder.append("Execution halted with error: ${e.message}")
        } finally {
            _isExecutingWorkflow.value = false
        }

        val resultSummary = if (success) {
            "Executed ${executedSteps.size} macro steps successfully."
        } else {
            summaryBuilder.toString().ifBlank { "Completed with partial warnings." }
        }

        // Record last run timestamp & status in Room
        scope.launch(Dispatchers.IO) {
            repository.setWorkflowLastRun(workflow.id, System.currentTimeMillis(), resultSummary)
        }

        val report = WorkflowExecutionReport(
            workflowId = workflow.id,
            workflowName = workflow.name,
            isSuccess = success,
            executedSteps = executedSteps,
            summaryMessage = resultSummary
        )

        _lastWorkflowReport.value = report
        return report
    }

    // =========================================================================
    // 3. NOTIFICATION & QUIET HOURS (DND) MANAGER (Requirement 3)
    // =========================================================================

    fun setQuietHoursEnabled(enabled: Boolean) {
        prefs.edit().putBoolean("dnd_enabled", enabled).apply()
        _quietHoursConfig.value = _quietHoursConfig.value.copy(isEnabled = enabled)
    }

    fun setQuietHoursSchedule(startHour: Int, startMinute: Int, endHour: Int, endMinute: Int) {
        prefs.edit()
            .putInt("dnd_start_hour", startHour)
            .putInt("dnd_start_minute", startMinute)
            .putInt("dnd_end_hour", endHour)
            .putInt("dnd_end_minute", endMinute)
            .apply()

        _quietHoursConfig.value = _quietHoursConfig.value.copy(
            startHour = startHour,
            startMinute = startMinute,
            endHour = endHour,
            endMinute = endMinute
        )
    }

    fun setAllowUrgentTasks(allow: Boolean) {
        prefs.edit().putBoolean("dnd_allow_urgent", allow).apply()
        _quietHoursConfig.value = _quietHoursConfig.value.copy(allowUrgentTasks = allow)
    }

    fun setVibrateOnly(vibrateOnly: Boolean) {
        prefs.edit().putBoolean("dnd_vibrate_only", vibrateOnly).apply()
        _quietHoursConfig.value = _quietHoursConfig.value.copy(vibrateOnly = vibrateOnly)
    }

    fun setNotificationSoundEnabled(enabled: Boolean) {
        prefs.edit().putBoolean("dnd_sound_enabled", enabled).apply()
        _quietHoursConfig.value = _quietHoursConfig.value.copy(notificationSoundEnabled = enabled)
    }

    fun isQuietHoursActive(): Boolean {
        return _quietHoursConfig.value.isCurrentlyActive()
    }

    fun openSystemDndSettings() {
        try {
            val intent = Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(intent)
        } catch (_: Exception) {
            try {
                val fallbackIntent = Intent(Settings.ACTION_SOUND_SETTINGS).apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
                context.startActivity(fallbackIntent)
            } catch (_: Exception) {}
        }
    }

    fun openAppNotificationSettings() {
        try {
            val intent = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).apply {
                    putExtra(Settings.EXTRA_APP_PACKAGE, context.packageName)
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
            } else {
                Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                    data = android.net.Uri.parse("package:${context.packageName}")
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
            }
            context.startActivity(intent)
        } catch (_: Exception) {}
    }

    private fun parseTimeToCalendar(timeStr: String): Calendar {
        val cal = Calendar.getInstance()
        try {
            val formats = listOf("h:mm a", "h:mma", "HH:mm")
            for (fmt in formats) {
                try {
                    val sdf = SimpleDateFormat(fmt, Locale.US)
                    val parsed = sdf.parse(timeStr)
                    if (parsed != null) {
                        val parsedCal = Calendar.getInstance().apply { time = parsed }
                        cal.set(Calendar.HOUR_OF_DAY, parsedCal.get(Calendar.HOUR_OF_DAY))
                        cal.set(Calendar.MINUTE, parsedCal.get(Calendar.MINUTE))
                        cal.set(Calendar.SECOND, 0)
                        if (cal.timeInMillis < System.currentTimeMillis()) {
                            cal.add(Calendar.DAY_OF_YEAR, 1)
                        }
                        return cal
                    }
                } catch (_: Exception) {}
            }
        } catch (_: Exception) {}
        cal.add(Calendar.HOUR_OF_DAY, 1)
        return cal
    }
}
