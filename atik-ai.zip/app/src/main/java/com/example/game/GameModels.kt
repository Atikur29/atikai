package com.example.game

/**
 * Genre categories for AI-generated 2D games (Step 26 Requirement 2).
 */
enum class GameGenre(val displayName: String, val iconEmoji: String) {
    ARCADE("Arcade & Retro", "🕹️"),
    RACING("Highway Racing", "🏎️"),
    BOARD("Board & Dice", "🎲"),
    ACTION("Action & Shooter", "🚀"),
    PUZZLE("Brain & Puzzle", "🧩"),
    SPORTS("Sports & Skill", "⚽")
}

/**
 * Built-in Game Archetypes with instant 60 FPS HTML5/Canvas templates (Step 26 Requirement 2).
 */
enum class GameTemplateType(
    val id: String,
    val title: String,
    val genre: GameGenre,
    val emoji: String,
    val description: String,
    val keywords: List<String>
) {
    LUDO_MINI(
        id = "ludo_mini",
        title = "Retro Ludo Mini",
        genre = GameGenre.BOARD,
        emoji = "🎲",
        description = "Quick 2-Player or Player vs AI colorful token board game with animated 3D-styled dice roll!",
        keywords = listOf("ludo", "লুডু", "board", "dice", "ছক্কা", "tokens", "ludo game")
    ),
    TURBO_RACER(
        id = "turbo_racer",
        title = "Turbo Cyber Racer",
        genre = GameGenre.RACING,
        emoji = "🏎️",
        description = "High-speed neon highway dodge racer with swipe/touch steering, nitro boost & traffic obstacles!",
        keywords = listOf("car", "racing", "race", "গাড়ি", "রেসিং", "highway", "traffic", "dodge", "racer")
    ),
    CYBER_FLAP(
        id = "cyber_flap",
        title = "Cyber Drone Flap",
        genre = GameGenre.ARCADE,
        emoji = "🛸",
        description = "Physics-based one-tap flight dodging laser pillars with particle propulsion and high-voltage score multipliers!",
        keywords = listOf("flappy", "bird", "পাখি", "flap", "drone", "flying", "jump", "pipes")
    ),
    COSMIC_INVADERS(
        id = "cosmic_invaders",
        title = "Cosmic Defender 2D",
        genre = GameGenre.ACTION,
        emoji = "🚀",
        description = "Classic arcade starship shoot'em up with smooth touch movement, laser blasters & alien waves!",
        keywords = listOf("space", "invader", "invaders", "shooter", "galaxy", "alien", "মহাকাশ", "ship", "laser")
    ),
    NEON_ARKANOID(
        id = "neon_arkanoid",
        title = "Neon Brick Breaker",
        genre = GameGenre.ARCADE,
        emoji = "🧱",
        description = "High-energy paddle ball bouncer smashing vibrant glowing matrix bricks with power-up drops!",
        keywords = listOf("brick", "breaker", "arkanoid", "paddle", "ball", "ইট", "ভাঙা", "bounce")
    ),
    MATRIX_SNAKE(
        id = "matrix_snake",
        title = "Cyber Matrix Snake",
        genre = GameGenre.ARCADE,
        emoji = "🐍",
        description = "Ultra-smooth neon snake arcade game with swipe gestures, glowing tail trail & energizing data orbs!",
        keywords = listOf("snake", "সাপ", "স্নেক", "matrix snake", "worm", "food", "tail")
    );

    companion object {
        fun fromPrompt(prompt: String): GameTemplateType? {
            val lower = prompt.lowercase()
            return values().firstOrNull { template ->
                template.keywords.any { kw -> lower.contains(kw) }
            }
        }
    }
}

/**
 * Game session state model for live HUD and runtime callbacks.
 */
data class ActiveGameSession(
    val gameId: String,
    val title: String,
    val genre: String,
    val currentScore: Int = 0,
    val highScore: Int = 0,
    val isGameOver: Boolean = false,
    val isPaused: Boolean = false,
    val isSoundMuted: Boolean = false,
    val sessionDurationSeconds: Int = 0,
    val lastSavedStateJson: String? = null
)
