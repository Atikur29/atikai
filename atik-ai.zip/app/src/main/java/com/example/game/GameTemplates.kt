package com.example.game

/**
 * High-performance, self-contained HTML5 Canvas & JavaScript 2D Game Templates (Step 26 Requirement 1 & 2).
 * Engineered for smooth 60 FPS mobile WebView rendering with touch controls, Web Audio synth, and Room DB score bridge.
 */
object GameTemplates {

    fun getTemplateHtml(templateType: GameTemplateType): String {
        return when (templateType) {
            GameTemplateType.LUDO_MINI -> getLudoMiniHtml()
            GameTemplateType.TURBO_RACER -> getTurboRacerHtml()
            GameTemplateType.CYBER_FLAP -> getCyberFlapHtml()
            GameTemplateType.COSMIC_INVADERS -> getCosmicInvadersHtml()
            GameTemplateType.NEON_ARKANOID -> getNeonArkanoidHtml()
            GameTemplateType.MATRIX_SNAKE -> getMatrixSnakeHtml()
        }
    }

    /**
     * Common CSS and JS Bridge boilerplate for responsive mobile games.
     */
    private fun getHeaderBoilerplate(title: String): String {
        return """
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<title>$title</title>
<style>
  * { box-sizing: border-box; margin: 0; padding: 0; -webkit-touch-callout: none; -webkit-user-select: none; user-select: none; }
  body, html { width: 100%; height: 100%; overflow: hidden; background: #070B14; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; }
  #canvas-container { position: relative; width: 100%; height: 100%; display: flex; justify-content: center; align-items: center; }
  canvas { display: block; touch-action: none; background: #070B14; }
  #overlay-ui { position: absolute; top: 12px; left: 12px; right: 12px; display: flex; justify-content: space-between; pointer-events: none; }
  .hud-badge { background: rgba(15, 23, 42, 0.85); border: 1px solid #00E5FF; color: #FFFFFF; padding: 6px 14px; border-radius: 99px; font-size: 13px; font-weight: 700; backdrop-filter: blur(8px); box-shadow: 0 0 10px rgba(0, 229, 255, 0.3); }
</style>
<script>
  // Safe Audio Synth using Web Audio API
  let audioCtx = null;
  function getAudioContext() {
    if (!audioCtx) {
      const AudioContext = window.AudioContext || window.webkitAudioContext;
      if (AudioContext) audioCtx = new AudioContext();
    }
    if (audioCtx && audioCtx.state === 'suspended') {
      audioCtx.resume();
    }
    return audioCtx;
  }
  function playBeep(freq, type, duration) {
    try {
      const ctx = getAudioContext();
      if (!ctx) return;
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = type || 'sine';
      osc.frequency.setValueAtTime(freq || 440, ctx.currentTime);
      gain.gain.setValueAtTime(0.15, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + (duration || 0.1));
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start();
      osc.stop(ctx.currentTime + (duration || 0.1));
    } catch(e) {}
  }
  function playScoreSound() { playBeep(880, 'sine', 0.15); }
  function playJumpSound() { playBeep(520, 'triangle', 0.12); }
  function playCrashSound() { playBeep(120, 'sawtooth', 0.35); }
  function playLaserSound() { playBeep(990, 'square', 0.08); }
  function playDiceSound() { playBeep(600, 'triangle', 0.2); }

  // Android Native JS Bridge dispatcher
  function notifyScore(score) {
    if (window.AndroidBridge && window.AndroidBridge.postScore) {
      window.AndroidBridge.postScore(score);
    }
  }
  function notifyGameOver(score, stateObj) {
    if (window.AndroidBridge && window.AndroidBridge.postGameOver) {
      window.AndroidBridge.postGameOver(score, JSON.stringify(stateObj || { score }));
    }
  }
  function notifySaveState(stateObj) {
    if (window.AndroidBridge && window.AndroidBridge.postSaveState) {
      window.AndroidBridge.postSaveState(JSON.stringify(stateObj || {}));
    }
  }
</script>
</head>
<body>
<div id="canvas-container">
  <canvas id="gameCanvas"></canvas>
  <div id="overlay-ui">
    <div id="hud-score" class="hud-badge">SCORE: 0</div>
    <div id="hud-title" class="hud-badge">$title</div>
  </div>
</div>
        """.trimIndent()
    }

    private fun getFooterBoilerplate(): String {
        return "</body></html>"
    }

    /**
     * 1. RETRO LUDO MINI (Board & Dice Game).
     */
    private fun getLudoMiniHtml(): String {
        return getHeaderBoilerplate("🎲 Retro Ludo Mini") + """
<script>
const canvas = document.getElementById('gameCanvas');
const ctx = canvas.getContext('2d');
let W, H, boardSize, cellSize, offsetX, offsetY;

function resize() {
  W = window.innerWidth;
  H = window.innerHeight;
  canvas.width = W;
  canvas.height = H;
  boardSize = Math.min(W * 0.92, H * 0.72);
  cellSize = boardSize / 8;
  offsetX = (W - boardSize) / 2;
  offsetY = (H - boardSize) / 2 + 20;
}
window.addEventListener('resize', resize);
resize();

// Ludo Game State
let turn = 'PLAYER'; // 'PLAYER' (Cyan) or 'BOT' (Orange)
let diceValue = 1;
let isRolling = false;
let rollAnimTimer = 0;
let playerScore = 0;
let playerPos = 0; // 0 to 24 steps
let botPos = 0;
const MAX_STEPS = 24;
let message = "Tap DICE to Roll!";

const diceBtn = { x: 0, y: 0, size: 70 };

function drawBoard() {
  ctx.fillStyle = '#070B14';
  ctx.fillRect(0, 0, W, H);

  // Outer board glow
  ctx.save();
  ctx.shadowColor = '#00E5FF';
  ctx.shadowBlur = 15;
  ctx.strokeStyle = '#1E3A8A';
  ctx.lineWidth = 3;
  ctx.strokeRect(offsetX, offsetY, boardSize, boardSize);
  ctx.restore();

  // Background grid cells
  for (let i = 0; i < 8; i++) {
    for (let j = 0; j < 8; j++) {
      const cx = offsetX + i * cellSize;
      const cy = offsetY + j * cellSize;
      ctx.fillStyle = (i + j) % 2 === 0 ? '#0F172A' : '#162038';
      ctx.fillRect(cx, cy, cellSize, cellSize);
      ctx.strokeStyle = 'rgba(0, 229, 255, 0.15)';
      ctx.lineWidth = 1;
      ctx.strokeRect(cx, cy, cellSize, cellSize);
    }
  }

  // Draw 24-step perimeter track
  const trackCoords = getTrackCoordinates();
  for (let step = 0; step < trackCoords.length; step++) {
    const pt = trackCoords[step];
    ctx.fillStyle = (step === 0) ? '#00E5FF33' : (step === 12 ? '#FF8C0033' : '#1E293B');
    ctx.beginPath();
    ctx.arc(pt.x, pt.y, cellSize * 0.38, 0, Math.PI * 2);
    ctx.fill();
    ctx.strokeStyle = (step === 0) ? '#00E5FF' : (step === 12 ? '#FF8C00' : '#334155');
    ctx.stroke();

    ctx.fillStyle = '#64748B';
    ctx.font = '10px sans-serif';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText(step, pt.x, pt.y);
  }

  // Draw Player Token (Cyan Neon)
  const pCoord = trackCoords[playerPos % MAX_STEPS];
  ctx.save();
  ctx.shadowColor = '#00E5FF';
  ctx.shadowBlur = 12;
  ctx.fillStyle = '#00E5FF';
  ctx.beginPath();
  ctx.arc(pCoord.x - 4, pCoord.y - 4, cellSize * 0.32, 0, Math.PI * 2);
  ctx.fill();
  ctx.fillStyle = '#000000';
  ctx.font = 'bold 12px sans-serif';
  ctx.fillText('P1', pCoord.x - 4, pCoord.y - 4);
  ctx.restore();

  // Draw Bot Token (Orange Neon)
  const bCoord = trackCoords[botPos % MAX_STEPS];
  ctx.save();
  ctx.shadowColor = '#FF8C00';
  ctx.shadowBlur = 12;
  ctx.fillStyle = '#FF8C00';
  ctx.beginPath();
  ctx.arc(bCoord.x + 4, bCoord.y + 4, cellSize * 0.32, 0, Math.PI * 2);
  ctx.fill();
  ctx.fillStyle = '#000000';
  ctx.font = 'bold 12px sans-serif';
  ctx.fillText('AI', bCoord.x + 4, bCoord.y + 4);
  ctx.restore();

  // Draw Center Dice Button
  diceBtn.x = W / 2;
  diceBtn.y = H - 75;
  ctx.save();
  ctx.shadowColor = turn === 'PLAYER' ? '#00E5FF' : '#FF8C00';
  ctx.shadowBlur = 15;
  ctx.fillStyle = '#0F172A';
  ctx.strokeStyle = turn === 'PLAYER' ? '#00E5FF' : '#FF8C00';
  ctx.lineWidth = 3;
  ctx.beginPath();
  ctx.roundRect(diceBtn.x - diceBtn.size/2, diceBtn.y - diceBtn.size/2, diceBtn.size, diceBtn.size, 16);
  ctx.fill();
  ctx.stroke();

  // Draw Dice Dots or Number
  ctx.fillStyle = '#FFFFFF';
  ctx.font = 'bold 32px sans-serif';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillText(diceValue, diceBtn.x, diceBtn.y);
  ctx.restore();

  // Status text
  ctx.fillStyle = '#F8FAFC';
  ctx.font = 'bold 15px sans-serif';
  ctx.textAlign = 'center';
  ctx.fillText(message, W / 2, offsetY - 14);

  // Turn Indicator
  ctx.fillStyle = turn === 'PLAYER' ? '#00E5FF' : '#FF8C00';
  ctx.font = '12px sans-serif';
  ctx.fillText(turn === 'PLAYER' ? "YOUR TURN (Cyan)" : "AI BOT'S TURN (Orange)", W / 2, H - 120);
}

function getTrackCoordinates() {
  const coords = [];
  const startX = offsetX + cellSize * 0.5;
  const startY = offsetY + cellSize * 0.5;
  // Top edge (7 steps)
  for (let c = 0; c < 7; c++) coords.push({ x: startX + c * cellSize, y: startY });
  // Right edge (5 steps)
  for (let r = 1; r < 6; r++) coords.push({ x: startX + 6 * cellSize, y: startY + r * cellSize });
  // Bottom edge (6 steps)
  for (let c = 6; c >= 1; c--) coords.push({ x: startX + c * cellSize, y: startY + 6 * cellSize });
  // Left edge (6 steps)
  for (let r = 6; r >= 1; r--) coords.push({ x: startX, y: startY + r * cellSize });
  return coords.slice(0, MAX_STEPS);
}

function rollDice() {
  if (isRolling) return;
  isRolling = true;
  playDiceSound();
  let count = 0;
  const animInterval = setInterval(() => {
    diceValue = Math.floor(Math.random() * 6) + 1;
    count++;
    if (count > 8) {
      clearInterval(animInterval);
      isRolling = false;
      onRollComplete();
    }
  }, 60);
}

function onRollComplete() {
  if (turn === 'PLAYER') {
    playerPos += diceValue;
    playerScore += diceValue * 10;
    document.getElementById('hud-score').innerText = 'SCORE: ' + playerScore;
    notifyScore(playerScore);
    playScoreSound();

    if (playerPos >= MAX_STEPS) {
      message = "🎉 VICTORY! You won the Ludo Match!";
      notifyGameOver(playerScore, { winner: 'PLAYER', score: playerScore });
      return;
    }

    message = "You rolled a " + diceValue + "! Bot's turn...";
    turn = 'BOT';
    setTimeout(botTurn, 1200);
  } else {
    botPos += diceValue;
    playJumpSound();
    if (botPos >= MAX_STEPS) {
      message = "💀 Game Over! Bot finished first!";
      notifyGameOver(playerScore, { winner: 'BOT', score: playerScore });
      return;
    }
    message = "Bot rolled a " + diceValue + "! Tap Dice to Roll!";
    turn = 'PLAYER';
  }
}

function botTurn() {
  if (turn !== 'BOT') return;
  rollDice();
}

function handleTouch(evt) {
  evt.preventDefault();
  const touch = evt.touches ? evt.touches[0] : evt;
  const rect = canvas.getBoundingClientRect();
  const tx = touch.clientX - rect.left;
  const ty = touch.clientY - rect.top;

  if (turn === 'PLAYER' && !isRolling) {
    const dist = Math.hypot(tx - diceBtn.x, ty - diceBtn.y);
    if (dist < diceBtn.size) {
      rollDice();
    }
  }
}

canvas.addEventListener('touchstart', handleTouch, { passive: false });
canvas.addEventListener('mousedown', handleTouch);

function loop() {
  drawBoard();
  requestAnimationFrame(loop);
}
loop();
</script>
""" + getFooterBoilerplate()
    }

    /**
     * 2. TURBO CYBER RACER (Highway Dodge Racing Game).
     */
    private fun getTurboRacerHtml(): String {
        return getHeaderBoilerplate("🏎️ Turbo Cyber Racer") + """
<script>
const canvas = document.getElementById('gameCanvas');
const ctx = canvas.getContext('2d');
let W, H;

function resize() {
  W = window.innerWidth;
  H = window.innerHeight;
  canvas.width = W;
  canvas.height = H;
}
window.addEventListener('resize', resize);
resize();

// Player Car
const player = {
  x: W / 2,
  y: H - 140,
  w: 44,
  h: 75,
  color: '#00E5FF',
  speed: 0,
  targetX: W / 2
};

let roadLines = [];
for (let i = 0; i < 15; i++) {
  roadLines.push({ y: i * 60 });
}

let traffic = [];
let particles = [];
let score = 0;
let speed = 7;
let gameOver = false;
let roadWidth = 280;

function spawnTraffic() {
  if (gameOver) return;
  const roadLeft = (W - roadWidth) / 2 + 30;
  const roadRight = (W + roadWidth) / 2 - 30;
  const laneX = roadLeft + Math.random() * (roadRight - roadLeft);
  const colors = ['#FF2A85', '#FFE600', '#A855F7', '#10B981'];
  traffic.push({
    x: laneX,
    y: -80,
    w: 42,
    h: 70,
    color: colors[Math.floor(Math.random() * colors.length)],
    speed: speed * (0.4 + Math.random() * 0.4)
  });
}
setInterval(spawnTraffic, 1400);

function update() {
  if (gameOver) return;

  // Smooth car steering towards touch position
  player.x += (player.targetX - player.x) * 0.15;
  const roadLeft = (W - roadWidth) / 2 + 25;
  const roadRight = (W + roadWidth) / 2 - 25;
  player.x = Math.max(roadLeft, Math.min(roadRight, player.x));

  // Move road lines
  for (let l of roadLines) {
    l.y += speed;
    if (l.y > H) l.y = -40;
  }

  // Move traffic
  for (let i = traffic.length - 1; i >= 0; i--) {
    const t = traffic[i];
    t.y += speed - t.speed;

    // Collision check
    if (Math.abs(t.x - player.x) < (t.w + player.w) * 0.42 &&
        Math.abs(t.y - player.y) < (t.h + player.h) * 0.45) {
      playCrashSound();
      gameOver = true;
      notifyGameOver(score, { score });
      createExplosion(player.x, player.y);
      return;
    }

    // Passed car bonus
    if (t.y > H + 50) {
      traffic.splice(i, 1);
      score += 50;
      speed = Math.min(18, speed + 0.15);
      document.getElementById('hud-score').innerText = 'SCORE: ' + score;
      notifyScore(score);
      playScoreSound();
    }
  }

  // Particle exhaust trail
  if (Math.random() < 0.6) {
    particles.push({
      x: player.x - 12 + Math.random() * 24,
      y: player.y + player.h / 2,
      vx: (Math.random() - 0.5) * 2,
      vy: 4 + Math.random() * 3,
      alpha: 1,
      size: 4 + Math.random() * 4,
      color: '#00E5FF'
    });
  }

  // Update particles
  for (let i = particles.length - 1; i >= 0; i--) {
    const p = particles[i];
    p.x += p.vx;
    p.y += p.vy;
    p.alpha -= 0.05;
    if (p.alpha <= 0) particles.splice(i, 1);
  }
}

function createExplosion(x, y) {
  for (let i = 0; i < 40; i++) {
    particles.push({
      x: x,
      y: y,
      vx: (Math.random() - 0.5) * 12,
      vy: (Math.random() - 0.5) * 12,
      alpha: 1,
      size: 6 + Math.random() * 6,
      color: '#FF2A85'
    });
  }
}

function drawCar(x, y, w, h, color, isPlayer) {
  ctx.save();
  ctx.translate(x, y);

  // Neon Underglow
  ctx.shadowColor = color;
  ctx.shadowBlur = isPlayer ? 18 : 10;
  ctx.fillStyle = color;
  ctx.beginPath();
  ctx.roundRect(-w/2, -h/2, w, h, 10);
  ctx.fill();

  // Windshield
  ctx.fillStyle = '#070B14';
  ctx.beginPath();
  ctx.roundRect(-w/2 + 6, -h/2 + 14, w - 12, 18, 4);
  ctx.fill();

  // Headlights / Taillights
  ctx.fillStyle = isPlayer ? '#FFFFFF' : '#FF2A85';
  ctx.fillRect(-w/2 + 4, isPlayer ? -h/2 + 2 : h/2 - 6, 8, 4);
  ctx.fillRect(w/2 - 12, isPlayer ? -h/2 + 2 : h/2 - 6, 8, 4);

  ctx.restore();
}

function render() {
  ctx.fillStyle = '#070B14';
  ctx.fillRect(0, 0, W, H);

  // Highway surface
  roadWidth = Math.min(W * 0.88, 380);
  const roadLeft = (W - roadWidth) / 2;
  ctx.fillStyle = '#0F172A';
  ctx.fillRect(roadLeft, 0, roadWidth, H);

  // Highway borders (Glowing Neon Curbs)
  ctx.strokeStyle = '#2563EB';
  ctx.lineWidth = 4;
  ctx.beginPath();
  ctx.moveTo(roadLeft, 0); ctx.lineTo(roadLeft, H);
  ctx.moveTo(roadLeft + roadWidth, 0); ctx.lineTo(roadLeft + roadWidth, H);
  ctx.stroke();

  // Center dashed road markings
  ctx.strokeStyle = '#FFE600';
  ctx.lineWidth = 3;
  ctx.setLineDash([25, 20]);
  ctx.beginPath();
  ctx.moveTo(W / 2, 0);
  ctx.lineTo(W / 2, H);
  ctx.stroke();
  ctx.setLineDash([]);

  // Particles
  for (let p of particles) {
    ctx.save();
    ctx.globalAlpha = p.alpha;
    ctx.fillStyle = p.color;
    ctx.beginPath();
    ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();
  }

  // Draw Traffic Cars
  for (let t of traffic) {
    drawCar(t.x, t.y, t.w, t.h, t.color, false);
  }

  // Draw Player Car
  if (!gameOver) {
    drawCar(player.x, player.y, player.w, player.h, player.color, true);
  } else {
    // Game Over Banner
    ctx.save();
    ctx.fillStyle = 'rgba(15, 23, 42, 0.85)';
    ctx.fillRect(0, H/2 - 70, W, 140);
    ctx.fillStyle = '#FF2A85';
    ctx.font = 'bold 28px sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText('CRASHED! GAME OVER', W/2, H/2 - 15);
    ctx.fillStyle = '#FFFFFF';
    ctx.font = '16px sans-serif';
    ctx.fillText('Tap screen to Restart Turbo Race', W/2, H/2 + 25);
    ctx.restore();
  }
}

function handleTouch(evt) {
  evt.preventDefault();
  const touch = evt.touches ? evt.touches[0] : evt;
  const rect = canvas.getBoundingClientRect();
  const tx = touch.clientX - rect.left;

  if (gameOver) {
    // Restart
    traffic = [];
    particles = [];
    score = 0;
    speed = 7;
    gameOver = false;
    player.x = W / 2;
    player.targetX = W / 2;
    document.getElementById('hud-score').innerText = 'SCORE: 0';
    return;
  }

  player.targetX = tx;
}

canvas.addEventListener('touchmove', handleTouch, { passive: false });
canvas.addEventListener('touchstart', handleTouch, { passive: false });
canvas.addEventListener('mousemove', (e) => { if (e.buttons > 0) handleTouch(e); });
canvas.addEventListener('mousedown', handleTouch);

function loop() {
  update();
  render();
  requestAnimationFrame(loop);
}
loop();
</script>
""" + getFooterBoilerplate()
    }

    /**
     * 3. CYBER DRONE FLAP (One-Tap Flying Physics Game).
     */
    private fun getCyberFlapHtml(): String {
        return getHeaderBoilerplate("🛸 Cyber Drone Flap") + """
<script>
const canvas = document.getElementById('gameCanvas');
const ctx = canvas.getContext('2d');
let W, H;

function resize() {
  W = window.innerWidth;
  H = window.innerHeight;
  canvas.width = W;
  canvas.height = H;
}
window.addEventListener('resize', resize);
resize();

const drone = {
  x: 70,
  y: H / 2,
  radius: 18,
  vy: 0,
  gravity: 0.42,
  jumpPower: -7.5
};

let pillars = [];
let particles = [];
let score = 0;
let gameOver = false;
let started = false;
const gap = 150;
const pillarWidth = 55;

function spawnPillar() {
  if (gameOver || !started) return;
  const topH = 50 + Math.random() * (H - gap - 120);
  pillars.push({
    x: W + 10,
    topHeight: topH,
    bottomY: topH + gap,
    passed: false
  });
}
setInterval(spawnPillar, 1700);

function jump() {
  if (!started) {
    started = true;
    gameOver = false;
    score = 0;
    drone.y = H / 2;
    drone.vy = 0;
    pillars = [];
  }
  if (gameOver) {
    gameOver = false;
    score = 0;
    drone.y = H / 2;
    drone.vy = 0;
    pillars = [];
    document.getElementById('hud-score').innerText = 'SCORE: 0';
    return;
  }
  drone.vy = drone.jumpPower;
  playJumpSound();

  // Particle burst
  for (let i = 0; i < 8; i++) {
    particles.push({
      x: drone.x,
      y: drone.y + 10,
      vx: -2 - Math.random() * 3,
      vy: 1 + (Math.random() - 0.5) * 3,
      alpha: 1,
      color: '#00E5FF'
    });
  }
}

function update() {
  if (!started || gameOver) return;

  drone.vy += drone.gravity;
  drone.y += drone.vy;

  // Bounds
  if (drone.y + drone.radius > H || drone.y - drone.radius < 0) {
    playCrashSound();
    gameOver = true;
    notifyGameOver(score, { score });
    return;
  }

  // Move pillars
  for (let i = pillars.length - 1; i >= 0; i--) {
    const p = pillars[i];
    p.x -= 3.2;

    // Collision Check
    const inX = drone.x + drone.radius > p.x && drone.x - drone.radius < p.x + pillarWidth;
    const inY = drone.y - drone.radius < p.topHeight || drone.y + drone.radius > p.bottomY;
    if (inX && inY) {
      playCrashSound();
      gameOver = true;
      notifyGameOver(score, { score });
      return;
    }

    // Score count
    if (!p.passed && p.x + pillarWidth < drone.x) {
      p.passed = true;
      score += 10;
      document.getElementById('hud-score').innerText = 'SCORE: ' + score;
      notifyScore(score);
      playScoreSound();
    }

    if (p.x < -pillarWidth) {
      pillars.splice(i, 1);
    }
  }

  // Update particles
  for (let i = particles.length - 1; i >= 0; i--) {
    const pt = particles[i];
    pt.x += pt.vx;
    pt.y += pt.vy;
    pt.alpha -= 0.04;
    if (pt.alpha <= 0) particles.splice(i, 1);
  }
}

function render() {
  ctx.fillStyle = '#070B14';
  ctx.fillRect(0, 0, W, H);

  // Background neon grid lines
  ctx.strokeStyle = 'rgba(30, 58, 138, 0.25)';
  ctx.lineWidth = 1;
  for (let x = 0; x < W; x += 40) {
    ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, H); ctx.stroke();
  }

  // Draw Pillars (High-voltage laser barriers)
  for (let p of pillars) {
    // Top Pillar
    ctx.save();
    ctx.shadowColor = '#FF2A85';
    ctx.shadowBlur = 12;
    ctx.fillStyle = '#1E122A';
    ctx.strokeStyle = '#FF2A85';
    ctx.lineWidth = 2;
    ctx.fillRect(p.x, 0, pillarWidth, p.topHeight);
    ctx.strokeRect(p.x, 0, pillarWidth, p.topHeight);

    // Bottom Pillar
    ctx.fillRect(p.x, p.bottomY, pillarWidth, H - p.bottomY);
    ctx.strokeRect(p.x, p.bottomY, pillarWidth, H - p.bottomY);
    ctx.restore();
  }

  // Particles
  for (let pt of particles) {
    ctx.save();
    ctx.globalAlpha = pt.alpha;
    ctx.fillStyle = pt.color;
    ctx.beginPath();
    ctx.arc(pt.x, pt.y, 4, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();
  }

  // Draw Cyber Drone
  ctx.save();
  ctx.shadowColor = '#00E5FF';
  ctx.shadowBlur = 16;
  ctx.fillStyle = '#00E5FF';
  ctx.beginPath();
  ctx.arc(drone.x, drone.y, drone.radius, 0, Math.PI * 2);
  ctx.fill();

  // Drone Cockpit
  ctx.fillStyle = '#070B14';
  ctx.beginPath();
  ctx.arc(drone.x + 4, drone.y, drone.radius * 0.45, 0, Math.PI * 2);
  ctx.fill();
  ctx.restore();

  // Start / Game Over overlay
  if (!started) {
    ctx.fillStyle = '#00E5FF';
    ctx.font = 'bold 24px sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText('🛸 TAP ANYWHERE TO FLY', W/2, H/2);
  } else if (gameOver) {
    ctx.fillStyle = '#FF2A85';
    ctx.font = 'bold 28px sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText('⚡ SYSTEM OVERLOAD!', W/2, H/2 - 20);
    ctx.fillStyle = '#FFFFFF';
    ctx.font = '16px sans-serif';
    ctx.fillText('Tap to Relaunch Drone', W/2, H/2 + 20);
  }
}

canvas.addEventListener('touchstart', (e) => { e.preventDefault(); jump(); }, { passive: false });
canvas.addEventListener('mousedown', jump);

function loop() {
  update();
  render();
  requestAnimationFrame(loop);
}
loop();
</script>
""" + getFooterBoilerplate()
    }

    /**
     * 4. COSMIC DEFENDER 2D (Space Shooter Arcade Game).
     */
    private fun getCosmicInvadersHtml(): String {
        return getHeaderBoilerplate("🚀 Cosmic Defender 2D") + """
<script>
const canvas = document.getElementById('gameCanvas');
const ctx = canvas.getContext('2d');
let W, H;

function resize() {
  W = window.innerWidth;
  H = window.innerHeight;
  canvas.width = W;
  canvas.height = H;
}
window.addEventListener('resize', resize);
resize();

const ship = { x: W / 2, y: H - 90, size: 22, targetX: W / 2 };
let bullets = [];
let aliens = [];
let stars = [];
let particles = [];
let score = 0;
let gameOver = false;

for (let i = 0; i < 45; i++) {
  stars.push({ x: Math.random() * W, y: Math.random() * H, speed: 0.8 + Math.random() * 2 });
}

function spawnAlienWave() {
  if (gameOver) return;
  const count = 4 + Math.floor(Math.random() * 3);
  for (let i = 0; i < count; i++) {
    aliens.push({
      x: 30 + (W - 60) * (i / (count - 1)),
      y: -30,
      size: 16,
      vx: (Math.random() - 0.5) * 1.5,
      vy: 1.2 + Math.random() * 1.5,
      color: ['#FF2A85', '#FFE600', '#A855F7'][Math.floor(Math.random() * 3)]
    });
  }
}
setInterval(spawnAlienWave, 2600);

// Auto-fire blasters every 220ms
setInterval(() => {
  if (!gameOver) {
    bullets.push({ x: ship.x, y: ship.y - ship.size, vy: -12 });
    playLaserSound();
  }
}, 240);

function update() {
  if (gameOver) return;

  ship.x += (ship.targetX - ship.x) * 0.2;
  ship.x = Math.max(ship.size, Math.min(W - ship.size, ship.x));

  // Stars background
  for (let s of stars) {
    s.y += s.speed;
    if (s.y > H) s.y = 0;
  }

  // Bullets
  for (let i = bullets.length - 1; i >= 0; i--) {
    const b = bullets[i];
    b.y += b.vy;
    if (b.y < -10) bullets.splice(i, 1);
  }

  // Aliens
  for (let i = aliens.length - 1; i >= 0; i--) {
    const a = aliens[i];
    a.x += a.vx;
    a.y += a.vy;

    // Ship collision
    if (Math.hypot(a.x - ship.x, a.y - ship.y) < a.size + ship.size) {
      playCrashSound();
      gameOver = true;
      notifyGameOver(score, { score });
      return;
    }

    // Bullet collision
    for (let j = bullets.length - 1; j >= 0; j--) {
      const b = bullets[j];
      if (Math.hypot(a.x - b.x, a.y - b.y) < a.size + 8) {
        aliens.splice(i, 1);
        bullets.splice(j, 1);
        score += 25;
        document.getElementById('hud-score').innerText = 'SCORE: ' + score;
        notifyScore(score);
        playScoreSound();
        createSparks(a.x, a.y, a.color);
        break;
      }
    }

    if (a.y > H + 30) aliens.splice(i, 1);
  }

  // Particles
  for (let i = particles.length - 1; i >= 0; i--) {
    const pt = particles[i];
    pt.x += pt.vx;
    pt.y += pt.vy;
    pt.alpha -= 0.05;
    if (pt.alpha <= 0) particles.splice(i, 1);
  }
}

function createSparks(x, y, color) {
  for (let i = 0; i < 15; i++) {
    particles.push({
      x, y,
      vx: (Math.random() - 0.5) * 6,
      vy: (Math.random() - 0.5) * 6,
      alpha: 1,
      color
    });
  }
}

function render() {
  ctx.fillStyle = '#070B14';
  ctx.fillRect(0, 0, W, H);

  // Draw Starfield
  ctx.fillStyle = '#FFFFFF';
  for (let s of stars) {
    ctx.fillRect(s.x, s.y, 1.8, 1.8);
  }

  // Draw Bullets
  ctx.save();
  ctx.shadowColor = '#00E5FF';
  ctx.shadowBlur = 10;
  ctx.fillStyle = '#00E5FF';
  for (let b of bullets) {
    ctx.fillRect(b.x - 2, b.y, 4, 12);
  }
  ctx.restore();

  // Draw Aliens
  for (let a of aliens) {
    ctx.save();
    ctx.shadowColor = a.color;
    ctx.shadowBlur = 12;
    ctx.fillStyle = a.color;
    ctx.beginPath();
    ctx.arc(a.x, a.y, a.size, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();
  }

  // Draw Particles
  for (let pt of particles) {
    ctx.save();
    ctx.globalAlpha = pt.alpha;
    ctx.fillStyle = pt.color;
    ctx.beginPath();
    ctx.arc(pt.x, pt.y, 3, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();
  }

  // Draw Starship
  if (!gameOver) {
    ctx.save();
    ctx.shadowColor = '#00E5FF';
    ctx.shadowBlur = 16;
    ctx.fillStyle = '#00E5FF';
    ctx.beginPath();
    ctx.moveTo(ship.x, ship.y - ship.size);
    ctx.lineTo(ship.x - ship.size, ship.y + ship.size);
    ctx.lineTo(ship.x + ship.size, ship.y + ship.size);
    ctx.closePath();
    ctx.fill();

    // Reactor Core
    ctx.fillStyle = '#FFE600';
    ctx.beginPath();
    ctx.arc(ship.x, ship.y + 6, 6, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();
  } else {
    ctx.fillStyle = '#FF2A85';
    ctx.font = 'bold 28px sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText('🚀 STARSHIP DESTROYED!', W/2, H/2 - 20);
    ctx.fillStyle = '#FFFFFF';
    ctx.font = '16px sans-serif';
    ctx.fillText('Tap anywhere to Deploy New Ship', W/2, H/2 + 20);
  }
}

function handleTouch(evt) {
  evt.preventDefault();
  const touch = evt.touches ? evt.touches[0] : evt;
  const rect = canvas.getBoundingClientRect();
  const tx = touch.clientX - rect.left;

  if (gameOver) {
    gameOver = false;
    score = 0;
    aliens = [];
    bullets = [];
    document.getElementById('hud-score').innerText = 'SCORE: 0';
    return;
  }
  ship.targetX = tx;
}

canvas.addEventListener('touchmove', handleTouch, { passive: false });
canvas.addEventListener('touchstart', handleTouch, { passive: false });
canvas.addEventListener('mousemove', (e) => { if (e.buttons > 0) handleTouch(e); });
canvas.addEventListener('mousedown', handleTouch);

function loop() {
  update();
  render();
  requestAnimationFrame(loop);
}
loop();
</script>
""" + getFooterBoilerplate()
    }

    /**
     * 5. NEON BRICK BREAKER (Arkanoid Arcade Game).
     */
    private fun getNeonArkanoidHtml(): String {
        return getHeaderBoilerplate("🧱 Neon Brick Breaker") + """
<script>
const canvas = document.getElementById('gameCanvas');
const ctx = canvas.getContext('2d');
let W, H;

function resize() {
  W = window.innerWidth;
  H = window.innerHeight;
  canvas.width = W;
  canvas.height = H;
}
window.addEventListener('resize', resize);
resize();

const paddle = { w: 90, h: 14, x: W / 2 - 45, y: H - 80 };
const ball = { x: W / 2, y: H - 110, r: 8, vx: 4, vy: -5 };
let bricks = [];
let score = 0;
let gameOver = false;

function initBricks() {
  bricks = [];
  const rows = 5;
  const cols = 6;
  const bWidth = (W - 40) / cols;
  const bHeight = 22;
  const colors = ['#00E5FF', '#FF2A85', '#FFE600', '#10B981', '#A855F7'];

  for (let r = 0; r < rows; r++) {
    for (let c = 0; c < cols; c++) {
      bricks.push({
        x: 20 + c * bWidth,
        y: 60 + r * (bHeight + 8),
        w: bWidth - 6,
        h: bHeight,
        color: colors[r % colors.length],
        active: true
      });
    }
  }
}
initBricks();

function update() {
  if (gameOver) return;

  ball.x += ball.vx;
  ball.y += ball.vy;

  // Wall bounce
  if (ball.x - ball.r < 0 || ball.x + ball.r > W) {
    ball.vx = -ball.vx;
    playJumpSound();
  }
  if (ball.y - ball.r < 0) {
    ball.vy = -ball.vy;
    playJumpSound();
  }

  // Paddle bounce
  if (ball.y + ball.r >= paddle.y && ball.y - ball.r <= paddle.y + paddle.h &&
      ball.x >= paddle.x && ball.x <= paddle.x + paddle.w) {
    ball.vy = -Math.abs(ball.vy);
    const hitPoint = (ball.x - (paddle.x + paddle.w / 2)) / (paddle.w / 2);
    ball.vx = hitPoint * 6;
    playScoreSound();
  }

  // Brick collision
  for (let b of bricks) {
    if (b.active) {
      if (ball.x > b.x && ball.x < b.x + b.w && ball.y - ball.r < b.y + b.h && ball.y + ball.r > b.y) {
        b.active = false;
        ball.vy = -ball.vy;
        score += 20;
        document.getElementById('hud-score').innerText = 'SCORE: ' + score;
        notifyScore(score);
        playScoreSound();
        break;
      }
    }
  }

  // Bottom edge loss
  if (ball.y > H + 20) {
    playCrashSound();
    gameOver = true;
    notifyGameOver(score, { score });
  }

  // Win check
  if (bricks.every(b => !b.active)) {
    initBricks();
    ball.x = W / 2;
    ball.y = H - 110;
    ball.vy = -5;
  }
}

function render() {
  ctx.fillStyle = '#070B14';
  ctx.fillRect(0, 0, W, H);

  // Draw Bricks
  for (let b of bricks) {
    if (b.active) {
      ctx.save();
      ctx.shadowColor = b.color;
      ctx.shadowBlur = 8;
      ctx.fillStyle = b.color;
      ctx.fillRect(b.x, b.y, b.w, b.h);
      ctx.restore();
    }
  }

  // Draw Paddle
  ctx.save();
  ctx.shadowColor = '#00E5FF';
  ctx.shadowBlur = 12;
  ctx.fillStyle = '#00E5FF';
  ctx.fillRect(paddle.x, paddle.y, paddle.w, paddle.h);
  ctx.restore();

  // Draw Ball
  ctx.save();
  ctx.shadowColor = '#FFFFFF';
  ctx.shadowBlur = 12;
  ctx.fillStyle = '#FFFFFF';
  ctx.beginPath();
  ctx.arc(ball.x, ball.y, ball.r, 0, Math.PI * 2);
  ctx.fill();
  ctx.restore();

  if (gameOver) {
    ctx.fillStyle = '#FF2A85';
    ctx.font = 'bold 28px sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText('BALL LOST! GAME OVER', W/2, H/2);
    ctx.fillStyle = '#FFFFFF';
    ctx.font = '16px sans-serif';
    ctx.fillText('Tap to Restart Game', W/2, H/2 + 35);
  }
}

function handleTouch(evt) {
  evt.preventDefault();
  const touch = evt.touches ? evt.touches[0] : evt;
  const rect = canvas.getBoundingClientRect();
  const tx = touch.clientX - rect.left;

  if (gameOver) {
    gameOver = false;
    score = 0;
    document.getElementById('hud-score').innerText = 'SCORE: 0';
    initBricks();
    ball.x = W / 2;
    ball.y = H - 110;
    ball.vx = 4;
    ball.vy = -5;
    return;
  }
  paddle.x = Math.max(0, Math.min(W - paddle.w, tx - paddle.w / 2));
}

canvas.addEventListener('touchmove', handleTouch, { passive: false });
canvas.addEventListener('touchstart', handleTouch, { passive: false });
canvas.addEventListener('mousemove', (e) => { if (e.buttons > 0) handleTouch(e); });
canvas.addEventListener('mousedown', handleTouch);

function loop() {
  update();
  render();
  requestAnimationFrame(loop);
}
loop();
</script>
""" + getFooterBoilerplate()
    }

    /**
     * 6. CYBER MATRIX SNAKE (Arcade Snake Game).
     */
    private fun getMatrixSnakeHtml(): String {
        return getHeaderBoilerplate("🐍 Cyber Matrix Snake") + """
<script>
const canvas = document.getElementById('gameCanvas');
const ctx = canvas.getContext('2d');
let W, H, gridSize = 20;

function resize() {
  W = window.innerWidth;
  H = window.innerHeight;
  canvas.width = W;
  canvas.height = H;
}
window.addEventListener('resize', resize);
resize();

let snake = [{ x: 10, y: 15 }, { x: 9, y: 15 }, { x: 8, y: 15 }];
let dir = { x: 1, y: 0 };
let nextDir = { x: 1, y: 0 };
let food = { x: 15, y: 15 };
let score = 0;
let gameOver = false;
let lastTick = 0;
const tickSpeed = 110; // ms per step

function spawnFood() {
  const cols = Math.floor(W / gridSize);
  const rows = Math.floor((H - 60) / gridSize);
  food.x = Math.floor(Math.random() * (cols - 2)) + 1;
  food.y = Math.floor(Math.random() * (rows - 4)) + 3;
}
spawnFood();

function update(time) {
  if (gameOver) return;

  if (time - lastTick > tickSpeed) {
    lastTick = time;
    dir = { ...nextDir };
    const head = { x: snake[0].x + dir.x, y: snake[0].y + dir.y };

    const maxCols = Math.floor(W / gridSize);
    const maxRows = Math.floor(H / gridSize);

    // Wall collision
    if (head.x < 0 || head.x >= maxCols || head.y < 2 || head.y >= maxRows) {
      playCrashSound();
      gameOver = true;
      notifyGameOver(score, { score });
      return;
    }

    // Body collision
    for (let s of snake) {
      if (s.x === head.x && s.y === head.y) {
        playCrashSound();
        gameOver = true;
        notifyGameOver(score, { score });
        return;
      }
    }

    snake.unshift(head);

    // Food eat
    if (head.x === food.x && head.y === food.y) {
      score += 10;
      document.getElementById('hud-score').innerText = 'SCORE: ' + score;
      notifyScore(score);
      playScoreSound();
      spawnFood();
    } else {
      snake.pop();
    }
  }
}

function render() {
  ctx.fillStyle = '#070B14';
  ctx.fillRect(0, 0, W, H);

  // Background Grid dots
  ctx.fillStyle = 'rgba(0, 229, 255, 0.08)';
  for (let x = 0; x < W; x += gridSize) {
    for (let y = 40; y < H; y += gridSize) {
      ctx.fillRect(x + gridSize/2 - 1, y + gridSize/2 - 1, 2, 2);
    }
  }

  // Draw Food (Glowing Green Orb)
  ctx.save();
  ctx.shadowColor = '#10B981';
  ctx.shadowBlur = 15;
  ctx.fillStyle = '#10B981';
  ctx.beginPath();
  ctx.arc(food.x * gridSize + gridSize/2, food.y * gridSize + gridSize/2, gridSize * 0.45, 0, Math.PI * 2);
  ctx.fill();
  ctx.restore();

  // Draw Snake
  for (let i = 0; i < snake.length; i++) {
    const s = snake[i];
    ctx.save();
    ctx.shadowColor = i === 0 ? '#00E5FF' : '#2563EB';
    ctx.shadowBlur = i === 0 ? 12 : 6;
    ctx.fillStyle = i === 0 ? '#00E5FF' : '#38BDF8';
    ctx.beginPath();
    ctx.roundRect(s.x * gridSize + 1, s.y * gridSize + 1, gridSize - 2, gridSize - 2, 4);
    ctx.fill();
    ctx.restore();
  }

  if (gameOver) {
    ctx.fillStyle = '#FF2A85';
    ctx.font = 'bold 28px sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText('GAME OVER!', W/2, H/2 - 20);
    ctx.fillStyle = '#FFFFFF';
    ctx.font = '16px sans-serif';
    ctx.fillText('Swipe or Tap to Play Again', W/2, H/2 + 20);
  }
}

// Swipe handling
let touchStartX = 0;
let touchStartY = 0;

canvas.addEventListener('touchstart', (e) => {
  e.preventDefault();
  touchStartX = e.touches[0].clientX;
  touchStartY = e.touches[0].clientY;
  if (gameOver) {
    gameOver = false;
    score = 0;
    snake = [{ x: 10, y: 15 }, { x: 9, y: 15 }, { x: 8, y: 15 }];
    dir = { x: 1, y: 0 };
    nextDir = { x: 1, y: 0 };
    document.getElementById('hud-score').innerText = 'SCORE: 0';
    spawnFood();
  }
}, { passive: false });

canvas.addEventListener('touchend', (e) => {
  const dx = e.changedTouches[0].clientX - touchStartX;
  const dy = e.changedTouches[0].clientY - touchStartY;
  if (Math.abs(dx) > Math.abs(dy)) {
    if (dx > 25 && dir.x === 0) nextDir = { x: 1, y: 0 };
    else if (dx < -25 && dir.x === 0) nextDir = { x: -1, y: 0 };
  } else {
    if (dy > 25 && dir.y === 0) nextDir = { x: 0, y: 1 };
    else if (dy < -25 && dir.y === 0) nextDir = { x: 0, y: -1 };
  }
});

function loop(t) {
  update(t);
  render();
  requestAnimationFrame(loop);
}
requestAnimationFrame(loop);
</script>
""" + getFooterBoilerplate()
    }
}
