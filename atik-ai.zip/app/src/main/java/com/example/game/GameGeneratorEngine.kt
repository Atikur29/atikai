package com.example.game

import android.util.Log
import com.example.ai.GeminiService
import com.example.data.ChatRepository
import com.example.data.GameProjectEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.UUID

/**
 * Natural language 2D Game Generator Engine (Step 26 Requirement 2).
 * Synthesizes HTML5 Canvas & JavaScript game code from user voice/text prompts.
 */
class GameGeneratorEngine(
    private val repository: ChatRepository,
    private val geminiService: GeminiService
) {

    companion object {
        private const val TAG = "GameGeneratorEngine"
    }

    /**
     * Check if a user input prompt is requesting game generation or playing.
     */
    fun isGamePrompt(prompt: String): Boolean {
        val lower = prompt.trim().lowercase()
        val gameKeywords = listOf(
            "game", "গেম", "খেলা", "play", "ludo", "লুডু", "racing", "কার রেসিং",
            "flappy", "bird", "পাখি", "shooter", "invader", "arkanoid", "brick", "snake", "সাপ",
            "বানাও", "তৈরি করো", "arcade", "generate game", "make a game", "create game"
        )
        return gameKeywords.any { lower.contains(it) }
    }

    /**
     * Parse prompt and generate a 2D HTML5/Canvas game.
     */
    suspend fun generateGameFromPrompt(
        prompt: String,
        apiKey: String? = null
    ): GameProjectEntity = withContext(Dispatchers.IO) {
        val lower = prompt.trim().lowercase()
        val matchedTemplate = GameTemplateType.fromPrompt(lower)

        if (matchedTemplate != null) {
            // Instant Archetype Generation
            val id = UUID.randomUUID().toString()
            val game = GameProjectEntity(
                id = id,
                title = matchedTemplate.title,
                genre = matchedTemplate.genre.displayName,
                prompt = prompt,
                htmlContent = GameTemplates.getTemplateHtml(matchedTemplate),
                thumbnailEmoji = matchedTemplate.emoji,
                highScore = 0,
                playCount = 0,
                createdAt = System.currentTimeMillis()
            )
            repository.saveGame(game)
            return@withContext game
        }

        // Custom AI Synthesis via Gemini if custom prompt provided
        try {
            val systemPrompt = """
                You are a master HTML5 Canvas 2D Game Developer for mobile browsers.
                Create a complete, single-file HTML5 Canvas + JavaScript 2D game for this request: "$prompt".
                Requirements:
                1. Output ONLY valid, standalone HTML with <!DOCTYPE html><html><head><style>...</style></head><body><canvas id="gameCanvas"></canvas><script>...game loop...</script></body></html>.
                2. Do NOT use markdown code blocks or explanations, return purely the raw HTML.
                3. Must support responsive touch controls (touchstart, touchmove, touchend).
                4. Background must be dark (#070B14) with neon colors (#00E5FF, #FF2A85, #FFE600).
                5. Integrate: if (window.AndroidBridge) { window.AndroidBridge.postScore(score); }
                6. 60 FPS requestAnimationFrame game loop.
            """.trimIndent()

            val aiResponseResult = geminiService.generateReply(
                prompt = systemPrompt,
                history = emptyList(),
                languageMode = com.example.ai.LanguageMode.ENGLISH,
                memories = emptyList(),
                customApiKey = apiKey
            )
            val aiResponse = aiResponseResult.getOrNull() ?: ""

            val cleanHtml = cleanHtmlResponse(aiResponse)
            if (cleanHtml.contains("<canvas") && cleanHtml.contains("<script")) {
                val id = UUID.randomUUID().toString()
                val game = GameProjectEntity(
                    id = id,
                    title = deriveTitleFromPrompt(prompt),
                    genre = "AI Custom 2D",
                    prompt = prompt,
                    htmlContent = cleanHtml,
                    thumbnailEmoji = "✨",
                    createdAt = System.currentTimeMillis()
                )
                repository.saveGame(game)
                return@withContext game
            }
        } catch (e: Exception) {
            Log.e(TAG, "Gemini custom game generation failed, falling back to archetype", e)
        }

        // Fallback to Turbo Racer or Cosmic Invaders
        val fallback = if (lower.contains("space") || lower.contains("shoot")) {
            GameTemplateType.COSMIC_INVADERS
        } else {
            GameTemplateType.TURBO_RACER
        }

        val fallbackGame = GameProjectEntity(
            id = UUID.randomUUID().toString(),
            title = fallback.title,
            genre = fallback.genre.displayName,
            prompt = prompt,
            htmlContent = GameTemplates.getTemplateHtml(fallback),
            thumbnailEmoji = fallback.emoji,
            createdAt = System.currentTimeMillis()
        )
        repository.saveGame(fallbackGame)
        fallbackGame
    }

    /**
     * Seeds initial popular games if database is empty.
     */
    suspend fun seedDefaultGamesIfEmpty() = withContext(Dispatchers.IO) {
        val count = repository.getGameCount()
        if (count == 0) {
            GameTemplateType.values().forEach { template ->
                val game = GameProjectEntity(
                    id = "template_${template.id}",
                    title = template.title,
                    genre = template.genre.displayName,
                    prompt = template.description,
                    htmlContent = GameTemplates.getTemplateHtml(template),
                    thumbnailEmoji = template.emoji,
                    highScore = 0,
                    playCount = 0,
                    createdAt = System.currentTimeMillis()
                )
                repository.saveGame(game)
            }
        }
    }

    private fun cleanHtmlResponse(raw: String): String {
        var clean = raw.trim()
        if (clean.startsWith("```html")) {
            clean = clean.removePrefix("```html").trim()
        } else if (clean.startsWith("```")) {
            clean = clean.removePrefix("```").trim()
        }
        if (clean.endsWith("```")) {
            clean = clean.removeSuffix("```").trim()
        }
        return clean
    }

    private fun deriveTitleFromPrompt(prompt: String): String {
        val trimmed = prompt.trim()
        val words = trimmed.split(" ")
        return if (words.size <= 4) trimmed.capitalize() else words.take(4).joinToString(" ").capitalize() + " 2D"
    }
}
