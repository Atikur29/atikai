package com.example.knowledge

/**
 * Model representing a comprehensive tech & earning guide topic.
 */
data class TechGuideTopic(
    val id: String,
    val title: String,
    val banglaTitle: String,
    val category: GuideCategory,
    val iconEmoji: String,
    val subtitle: String,
    val difficulty: String,
    val estimatedTime: String,
    val keySkills: List<String>,
    val promptQuery: String,
    val structuredContent: String,
    val actionSteps: List<String>,
    val subChips: List<String>
)

enum class GuideCategory(val label: String, val banglaLabel: String) {
    ONLINE_EARNING("Online Earning", "অনলাইন আয় ও ফ্রিল্যান্সিং"),
    APP_DEV("App Development", "মোবাইল অ্যাপ ডেভেলপমেন্ট"),
    AI_TOOLS("AI Tools Masterclass", "এআই টুলস ও অটোমেশন"),
    FREELANCING("Freelancing", "মার্কেটপ্লেস ও ক্লায়েন্ট হান্টিং"),
    SAFE_TECH("Safe Tech", "সাইবার নিরাপত্তা ও নিরাপদ টেক"),
    PASSIVE_INCOME("Passive Income", "প্যাসিভ ইনকাম ও ডিজিটাল প্রোডাক্টস")
}

data class QuickSuggestionChip(
    val id: String,
    val label: String,
    val banglaLabel: String,
    val icon: String,
    val prompt: String,
    val category: GuideCategory
)

object TechKnowledgeEngine {

    val QUICK_SUGGESTION_CHIPS = listOf(
        QuickSuggestionChip(
            id = "earning_ideas",
            label = "💰 Online Earning Ideas",
            banglaLabel = "💰 Online Earning Ideas",
            icon = "💰",
            prompt = "আতিক, ২০২৬ সালে ঘরে বসে অনলাইন থেকে টেকসই উপায়ে আয় করার সবচেয়ে লাভজনক ও বিশ্বস্ত উপায়গুলো কী কী? বিস্তারিত রোডম্যাপ, প্রয়োজনীয় স্কিল এবং বাস্তব পদক্ষেপসহ ধাপে ধাপে বুঝিয়ে দাও।",
            category = GuideCategory.ONLINE_EARNING
        ),
        QuickSuggestionChip(
            id = "app_dev_guide",
            label = "📱 App Development Guide",
            banglaLabel = "📱 App Development Guide",
            icon = "📱",
            prompt = "আতিক, আধুনিক অ্যান্ড্রয়েড অ্যাপ ডেভেলপমেন্ট (Kotlin + Jetpack Compose) শেখার সম্পূর্ণ গাইডলাইন দাও। কীভাবে একটি অ্যাপ তৈরি থেকে গুগল প্লে স্টোরে রিলিজ ও মনিটাইজেশন (AdMob/In-App Purchase) করা যায় তা বিস্তারিত বুঝিয়ে দাও।",
            category = GuideCategory.APP_DEV
        ),
        QuickSuggestionChip(
            id = "ai_tools_masterclass",
            label = "🤖 AI Tools Masterclass",
            banglaLabel = "🤖 AI Tools Masterclass",
            icon = "🤖",
            prompt = "আতিক, প্রতিদিনের কাজ সহজ করতে এবং উৎপাদনশীলতা বহুগুণ বাড়াতে সেরা AI টুলস (যেমন Gemini, ChatGPT, Midjourney, Cursor) ব্যবহারের মাস্টারক্লাস গাইডলাইন দাও। প্রম্পট ইঞ্জিনিয়ারিংয়ের গোপন কৌশল ও রিয়েল-ওয়ার্ল্ড অটোমেশন ওয়ার্কফ্লো ব্যাখ্যা করো।",
            category = GuideCategory.AI_TOOLS
        ),
        QuickSuggestionChip(
            id = "freelancing_roadmap",
            label = "💼 Freelancing Roadmap",
            banglaLabel = "💼 Freelancing Roadmap",
            icon = "💼",
            prompt = "আতিক, একজন নতুন ফ্রিল্যান্সার হিসেবে Upwork ও Fiverr-এ সফল ক্যারিয়ার গড়ার নিখুঁত রোডম্যাপ দাও। কীভাবে সেরা নিচ নির্বাচন করতে হয়, প্রোফাইল অপটিমাইজেশন, উইনিং বিডিং প্রপোজাল লেখার নিয়ম এবং বাংলাদেশ থেকে নিরাপদে পেমেন্ট (Payoneer/Wise) তোলার পদ্ধতি বিস্তারিত বলো।",
            category = GuideCategory.FREELANCING
        ),
        QuickSuggestionChip(
            id = "safe_tech_tutorials",
            label = "🛡️ Safe Tech Tutorials",
            banglaLabel = "🛡️ Safe Tech Tutorials",
            icon = "🛡️",
            prompt = "আতিক, ইন্টারনেটে নিরাপদে থাকার জন্য জরুরি সাইবার সিকিউরিটি গাইডলাইন দাও। অনলাইন স্ক্যাম, ফেক চাকরির ফাঁদ, সোশ্যাল মিডিয়া হ্যাকিং থেকে বাঁচার উপায় এবং ডেটা প্রাইভেসি রক্ষার নিরাপদ টেকনিকগুলো সহজ ভাষায় বুঝিয়ে দাও।",
            category = GuideCategory.SAFE_TECH
        ),
        QuickSuggestionChip(
            id = "passive_income",
            label = "🚀 Passive Income Tips",
            banglaLabel = "🚀 Passive Income Tips",
            icon = "🚀",
            prompt = "আতিক, প্রযুক্তি ব্যবহার করে ডিজিটাল প্রোডাক্ট বিক্রি, মাইক্রো-SaaS বা কনটেন্ট অটোমেশনের মাধ্যমে প্যাসিভ ইনকাম (Passive Income) গড়ার বাস্তবসম্মত আইডিয়া ও বাস্তবায়ন নির্দেশিকা দাও।",
            category = GuideCategory.PASSIVE_INCOME
        ),
        QuickSuggestionChip(
            id = "play_2d_games",
            label = "🎮 Play 2D Arcade & Ludo",
            banglaLabel = "🎮 লুডু ও আর্কেড গেম খেলো",
            icon = "🎮",
            prompt = "আতিক, লুডু গেম খেলব। 2D HTML5 ক্যানভাস গেম চালু করো!",
            category = GuideCategory.AI_TOOLS
        )
    )

    val CURATED_TOPICS = listOf(
        TechGuideTopic(
            id = "topic_earning_mastery",
            title = "High-Income Online Earning Roadmap 2026",
            banglaTitle = "অনলাইন আয়ের সর্বোচ্চ লাভজনক স্কিল ও রোডম্যাপ",
            category = GuideCategory.ONLINE_EARNING,
            iconEmoji = "💰",
            subtitle = "কোন স্কিলগুলো শিখলে সবচেয়ে দ্রুত আন্তর্জাতিক ক্লায়েন্ট পাওয়া যায়",
            difficulty = "Beginner to Advanced",
            estimatedTime = "15 min read",
            keySkills = listOf("Android/iOS Dev", "AI Prompting", "Full-Stack Web", "Digital Marketing"),
            promptQuery = "আতিক, ২০২৬ সালে ঘরে বসে অনলাইন থেকে টেকসই উপায়ে আয় করার সবচেয়ে লাভজনক ও বিশ্বস্ত উপায়গুলো কী কী? বিস্তারিত রোডম্যাপ, প্রয়োজনীয় স্কিল এবং বাস্তব পদক্ষেপসহ ধাপে ধাপে বুঝিয়ে দাও।",
            structuredContent = """
# 💰 হাই-ইনকাম অনলাইন আর্নিং মাস্টার রোডম্যাপ

ঘরে বসে আন্তর্জাতিক অঙ্গনে কাজ করে আয় করার জন্য শুধুমাত্র ক্লিক করে টাকা আয়ের মিথ্যা ফাঁদে না পড়ে একটি নির্দিষ্ট ও মূল্যবান কারিগরি দক্ষতা (High-Income Skill) অর্জন করা আবশ্যক।

---

### ১. সর্বোচ্চ চাহিদাসম্পন্ন ৫টি স্কিল (২০২৬)
1. **মোবাইল ও ওয়েব অ্যাপ ডেভেলপমেন্ট (Kotlin, Flutter, Next.js):** প্রতিটি ব্যবসার জন্য এখন কাস্টম অ্যাপ অপরিহার্য। প্রজেক্ট প্রতি $500 থেকে $5,000+ পর্যন্ত বাজেট পাওয়া যায়।
2. **AI ইন্টিগ্রেশন ও অটোমেশন (Prompt Engineering & Python):** বড় বড় কোম্পানিগুলো তাদের কাজ স্বয়ংক্রিয় করতে জেমিনি ও চ্যাটজিপিটি এপিআই ব্যবহার করছে।
3. **UI/UX ডিজাইন (Figma):** সুন্দর এবং ব্যবহারবান্ধব ইন্টারফেস তৈরির কাজের চাহিদা বিশ্বজুড়ে শীর্ষে।
4. **টেকনিক্যাল কনটেন্ট ও এসইও কপিরাইটিং:** এআই যুগেও মানুষের খাঁটি গবেষণাধর্মী বিশ্লেষণের মূল্য সবচেয়ে বেশি।
5. **সাইবার সিকিউরিটি ও ক্লাউড অডিট (AWS/Linux):** সার্ভার সিকিউরিটি এবং ডেটা প্রটেকশনের কাজ।

---

### ২. প্রথম ১০০ ডলার আয়ের ৩-ধাপের অ্যাকশন প্ল্যান
* **ধাপ ১: ফাউন্ডেশন (মাস ১-২):** যেকোনো একটি স্কিল বাছাই করে অন্তত ২টি চমৎকার লাইভ প্রজেক্ট তৈরি করুন (যেমন একটি সম্পূর্ণ ফাংশনাল অ্যাপ বা ওয়েবসাইট)।
* **ধাপ ২: প্রুফ অব ওয়ার্ক (মাস ৩):** GitHub, Behance বা LinkedIn-এ আপনার কাজের স্যাম্পল ও ভিডিও ডেমো নিয়মিত শেয়ার করুন।
* **ধাপ ৩: ডিরেক্ট আউটরিচ ও মার্কেটপ্লেস:** Upwork, Fiverr এবং LinkedIn-এ টার্গেটেড ক্লায়েন্টদের তাদের সমস্যার সমাধান সম্বলিত ছোট ভিডিও বা ডেমো পাঠান।

---

### ৩. পেমেন্ট সংগ্রহ (বাংলাদেশ ও আন্তর্জাতিক)
* **Payoneer / Wise:** সরাসরি ব্যাংক একাউন্টে রেমিট্যান্স হিসেবে বৈধ উপায়ে ডলার নিয়ে আসার সেরা মাধ্যম (ব্যাংক এশিয়ার রেমিট্যান্স ক্যাশ ব্যাক সাপোর্টসহ)।
* **Direct Bank Wire:** বড় প্রজেক্টের জন্য সুইফট কোড (SWIFT) দিয়ে সরাসরি ব্যাংকে লেনদেন।
            """.trimIndent(),
            actionSteps = listOf(
                "যেকোনো একটি প্রধান স্কিল নির্বাচন করুন (উদা: অ্যান্ড্রয়েড ডেভেলপমেন্ট)",
                "অন্তত ৩টি মানসম্মত পোর্টফোলিও প্রজেক্ট তৈরি করে গিটহাবে আপলোড করুন",
                "LinkedIn এবং Upwork-এ পেশাদার প্রোফাইল তৈরি করুন",
                "দৈনিক অন্তত ৫ জন সম্ভাব্য ক্লায়েন্টকে তাদের প্রজেক্টে সাহায্যের ডেমো পাঠান",
                "পেমেন্টের জন্য পেওনিয়ার বা ব্যাংক একাউন্ট ভেরিফাই করে প্রস্তুত রাখুন"
            ),
            subChips = listOf("Fiverr Secrets", "Upwork Proposal", "Portfolio Building", "Client Outreach")
        ),
        TechGuideTopic(
            id = "topic_app_dev",
            title = "Modern Android App Development Blueprint",
            banglaTitle = "আধুনিক অ্যান্ড্রয়েড অ্যাপ ডেভেলপমেন্ট সম্পূর্ণ গাইড",
            category = GuideCategory.APP_DEV,
            iconEmoji = "📱",
            subtitle = "Kotlin, Jetpack Compose, Gemini AI ও Play Store মনিটাইজেশন",
            difficulty = "All Levels",
            estimatedTime = "20 min read",
            keySkills = listOf("Kotlin", "Jetpack Compose", "Coroutines & Flow", "Room DB", "AdMob"),
            promptQuery = "আতিক, আধুনিক অ্যান্ড্রয়েড অ্যাপ ডেভেলপমেন্ট (Kotlin + Jetpack Compose) শেখার সম্পূর্ণ গাইডলাইন দাও। কীভাবে একটি অ্যাপ তৈরি থেকে গুগল প্লে স্টোরে রিলিজ ও মনিটাইজেশন (AdMob/In-App Purchase) করা যায় তা বিস্তারিত বুঝিয়ে দাও।",
            structuredContent = """
# 📱 আধুনিক অ্যান্ড্রয়েড অ্যাপ ডেভেলপমেন্ট ব্লুপ্রিন্ট

অ্যান্ড্রয়েড এখন আর জটিল XML ভিউর মধ্যে সীমাবদ্ধ নেই। বর্তমানে গুগলের সুপারিশকৃত প্রযুক্তি হলো **Kotlin + Jetpack Compose**।

---

### ১. আধুনিক টেক স্ট্যাক
* **ভাষা (Language):** Kotlin (Clean, Null-safe, Coroutine সমর্থিত)।
* **ইউআই ফ্রেমওয়ার্ক (UI):** Jetpack Compose (Declarative UI, যা React/Flutter এর চেয়েও আধুনিক)।
* **আর্কিটেকচার (Architecture):** Clean Architecture + MVVM (Model-View-ViewModel) + StateFlow।
* **লোকাল ডেটাবেজ:** Room Database (SQLite এর আধুনিক টাইপ-সেফ সংস্করণ)।
* **নেটওয়ার্কিং:** Retrofit অথবা Ktor Client।
* **এআই ইন্টিগ্রেশন:** Google Gemini API / Firebase Vertex AI।

---

### ২. অ্যাপ থেকে আয় করার ৪টি সেরা উপায়
1. **AdMob বিজ্ঞাপন:** ব্যানার, ইন্টারস্টিশিয়াল ও রিওয়ার্ডেড ভিডিও বিজ্ঞাপন যুক্ত করে প্রতি ১০০০ ইমপ্রেশনে ভালো রেভিনিউ।
2. **প্রিমিয়াম সাবস্ক্রিপশন (Google Play Billing):** পেইড ফিচার আনলক বা মাসিক/বাৎসরিক মেম্বারশিপ।
3. **পেইড অ্যাপ (Upfront Payment):** বিশেষায়িত ইউটিলিটি টুল তৈরি করে সরাসরি ডাউনলোডের সময় ফি নেওয়া।
4. **ফ্রিল্যান্স ক্লায়েন্ট প্রজেক্ট:** স্থানীয় ও আন্তর্জাতিক স্টার্টআপের জন্য অ্যাপ তৈরি করে দেওয়া ($300-$3,000+)।

---

### ৩. গুগল প্লে স্টোরে রিলিজ করার নিয়ম
* $25 ওয়ান-টাইম ফি দিয়ে Google Play Console অ্যাকাউন্ট খুলুন।
* অ্যাপটি Android App Bundle (`.aab`) ফরম্যাটে সাইন করে এক্সপোর্ট করুন।
* প্রাইভেসি পলিসি পেজ এবং আকর্ষণীয় স্ক্রিনশট ও অ্যাপ আইকন যুক্ত করুন।
* ২০ জন ক্লোজড টেস্টার দিয়ে ১৪ দিন টেস্টিং সম্পন্ন করার পর প্রোডাকশনে লাইভ করুন।
            """.trimIndent(),
            actionSteps = listOf(
                "Android Studio ইনস্টল করে Kotlin ও Jetpack Compose এর বেসিক শিখুন",
                "একটি রিয়েল-ওয়ার্ল্ড অ্যাপ তৈরি করুন (যেমন: এআই নোটবুক, চ্যাটবট বা ট্র্যাকার)",
                "Play Console অ্যাকাউন্ট তৈরি করে পলিসি নির্দেশিকা ভালোভাবে পড়ুন",
                "AdMob বা Google Play Billing যুক্ত করে মনিটাইজেশন সেটআপ করুন",
                "সফলভাবে প্লে স্টোরে পাবলিশ করে মার্কেটিং ও ইউজার ফিডব্যাক সংগ্রহ করুন"
            ),
            subChips = listOf("Jetpack Compose", "Play Store Rules", "AdMob Setup", "MVVM Pattern")
        ),
        TechGuideTopic(
            id = "topic_ai_masterclass",
            title = "AI Tools Masterclass & Automation Workflows",
            banglaTitle = "এআই টুলস মাস্টারক্লাস ও স্বয়ংক্রিয় কাজের ওয়ার্কফ্লো",
            category = GuideCategory.AI_TOOLS,
            iconEmoji = "🤖",
            subtitle = "প্রম্পট ইঞ্জিনিয়ারিং, কনটেন্ট তৈরি ও কাজের গতি ১০ গুণ বাড়ানো",
            difficulty = "Beginner to Intermediate",
            estimatedTime = "12 min read",
            keySkills = listOf("Prompt Engineering", "Gemini API", "ChatGPT Workflows", "Midjourney / Imagen"),
            promptQuery = "আতিক, প্রতিদিনের কাজ সহজ করতে এবং উৎপাদনশীলতা বহুগুণ বাড়াতে সেরা AI টুলস (যেমন Gemini, ChatGPT, Midjourney, Cursor) ব্যবহারের মাস্টারক্লাস গাইডলাইন দাও। প্রম্পট ইঞ্জিনিয়ারিংয়ের গোপন কৌশল ও রিয়েল-ওয়ার্ল্ড অটোমেশন ওয়ার্কফ্লো ব্যাখ্যা করো।",
            structuredContent = """
# 🤖 এআই টুলস মাস্টারক্লাস ও ওয়ার্কফ্লো

এআই আপনার চাকরি বা ক্যারিয়ার কেড়ে নেবে না, বরং যে ব্যক্তি এআই দক্ষভাবে ব্যবহার করতে পারেন তিনি অন্যদের চেয়ে বহুগুণ এগিয়ে যাবেন।

---

### ১. সেরা প্রম্পট ইঞ্জিনিয়ারিংয়ের ৩টি গোপন নিয়ম
1. **রোল ও কনটেক্সট দেওয়া:** "You are an expert Senior Android Architect..."
2. **নির্দিষ্ট লক্ষ্য ও সীমাবদ্ধতা:** "Explain in 3 bullet points, without introductory fluff, in professional Bengali..."
3. **ফিউ-শট লার্নিং (Few-Shot Examples):** কাঙ্ক্ষিত আউটপুটের ১টি বাস্তব উদাহরণ প্রম্পটে দিয়ে দিন।

---

### ২. ফ্রিল্যান্সিংয়ে এআই ব্যবহারের বাস্তব উদাহরণ
* **কোডিং স্পিডআপ:** জটিল অ্যালগরিদম বা রেগুলার এক্সপ্রেশন লিখিয়ে নেওয়া এবং কোডের বাগ মুহূর্তের মধ্যে খুঁজে বের করা।
* **ক্লায়েন্ট প্রপোজাল জেনারেশন:** ক্লায়েন্টের জব পোস্ট বিশ্লেষণ করে ব্যক্তিগতকৃত উইনিং কভার লেটার ড্রাফট করা।
* **গ্রাফিক্স ও কনসেপ্ট আর্ট:** মিডজার্নি বা ইমেজেনের সাহায্যে ক্লায়েন্টের জন্য অ্যাপ মকআপ বা ওয়েবসাইট ব্যানার ডিজাইন করা।
* **ভিডিও ও কনটেন্ট সামারি:** দীর্ঘ ১ ঘণ্টার টিউটোরিয়াল বা পডকাস্ট ২ মিনিটে পয়েন্ট আকারে সারাংশ করা।
            """.trimIndent(),
            actionSteps = listOf(
                "Gemini ও ChatGPT-তে 'Role + Task + Context + Format' ফরম্যাটে প্রম্পট লেখা প্র্যাকটিস করুন",
                "রোজকার পুনরাবৃত্তিমূলক কাজের একটি তালিকা বানিয়ে সেগুলোকে এআই দিয়ে অটোমেট করুন",
                "ইমেজ তৈরির জন্য Imagen বা Midjourney দিয়ে কনসেপ্ট তৈরি শিখুন",
                "Python স্ক্রিপ্ট দিয়ে এআই এপিআই কল করার প্রাথমিক কৌশল রপ্ত করুন"
            ),
            subChips = listOf("Prompt Formulas", "Coding with AI", "AI Automation", "API Integration")
        ),
        TechGuideTopic(
            id = "topic_safe_tech",
            title = "Cyber Security & Safe Tech Guidelines",
            banglaTitle = "সাইবার নিরাপত্তা ও অনলাইন স্ক্যাম থেকে বাঁচার নিয়ম",
            category = GuideCategory.SAFE_TECH,
            iconEmoji = "🛡️",
            subtitle = "হ্যাকিং, ফিশিং ও ভুয়া চাকরির ফাঁদ থেকে নিজের অ্যাকাউন্ট রক্ষা করা",
            difficulty = "Must Know for Everyone",
            estimatedTime = "10 min read",
            keySkills = listOf("2FA Security", "Phishing Detection", "API Key Safety", "Privacy Hygiene"),
            promptQuery = "আতিক, ইন্টারনেটে নিরাপদে থাকার জন্য জরুরি সাইবার সিকিউরিটি গাইডলাইন দাও। অনলাইন স্ক্যাম, ফেক চাকরির ফাঁদ, সোশ্যাল মিডিয়া হ্যাকিং থেকে বাঁচার উপায় এবং ডেটা প্রাইভেসি রক্ষার নিরাপদ টেকনিকগুলো সহজ ভাষায় বুঝিয়ে দাও।",
            structuredContent = """
# 🛡️ সাইবার নিরাপত্তা ও নিরাপদ টেক নির্দেশিকা

অনলাইনে আয় এবং কাজ করার ক্ষেত্রে সবচেয়ে বড় ঝুঁকি হলো প্রতারণা ও সাইবার অপরাধীদের ফাঁদ। নিজেকে ও নিজের অর্থ নিরাপদ রাখতে এই নিয়মগুলো মানা বাধ্যতামূলক।

---

### ১. অনলাইন স্ক্যাম চেনার ৫টি লাল সংকেত (Red Flags)
1. **কাজের আগে জামানত বা রেজিস্ট্রেশন ফি দাবি:** কোনো আসল ক্লায়েন্ট বা কোম্পানি কখনও কাজের বিনিময়ে আপনার কাছে টাকা চাইবে না।
2. **টেলিগ্রাম বা হোয়াটসঅ্যাপে কাজের প্রলোভন:** মার্কেটপ্লেস বা অফিশিয়াল ইমেইলের বাইরে গিয়ে অস্বচ্ছ পেমেন্টের প্রস্তাব।
3. **অস্বাভাবিক উচ্চ আয়ের প্রতিশ্রুতি:** "প্রতিদিন ৩০ মিনিট লাইক-শেয়ার করে ২০০০ টাকা আয়" সম্পূর্ণ ভুয়া ও স্ক্যাম।
4. **সন্দেহজনক লিঙ্ক বা APK ইনস্টল করতে বলা:** এটি আপনার ফোনের ওটিপি ও ব্যাংক তথ্য চুরির ম্যালওয়্যার।
5. **ফিশিং ইমেইল:** ব্যাংক বা গুগল থেকে আসার মতো দেখতে ফেক লগইন পেজ।

---

### ২. ডিজিটাল সুরক্ষার গোল্ডেন রুলস
* **টু-ফ্যাক্টর অথেনটিকেশন (2FA):** এসএমএস এর চেয়ে Google Authenticator বা বিটওয়ার্ডেন অ্যাপ ব্যবহার করুন।
* **এপিআই কি ও পাসওয়ার্ড সুরক্ষা:** কখনও গিটহাবে বা পাবলিক চ্যাটে আপনার গোপন API Key বা পাসওয়ার্ড পুশ করবেন না (`.env` ব্যবহার করুন)।
* **শক্তিশালী পাসওয়ার্ড:** প্রতিটি সাইটের জন্য ভিন্ন ভিন্ন পাসপ্যাকিং ব্যবহার করুন।
            """.trimIndent(),
            actionSteps = listOf(
                "নিজের গুগল, ফেসবুক ও ব্যাংক অ্যাকাউন্টে অবিলম্বে 2FA চালু করুন",
                "কোনো লিংকে ক্লিক করার আগে ডোমেইন নেম (URL) সতর্কতার সাথে যাচাই করুন",
                "কাজের আগে টাকা চাইলে অবিলম্বে ব্লক করুন এবং রিপোর্ট করুন",
                "ডেভেলপমেন্টে API Key সবসময় BuildConfig বা Environment ফাইলে সংরক্ষণ করুন"
            ),
            subChips = listOf("Spot Scams", "2FA Setup", "API Security", "Privacy Checklist")
        )
    )

    fun findTopicById(id: String): TechGuideTopic? {
        return CURATED_TOPICS.find { it.id == id }
    }

    fun searchTopics(query: String): List<TechGuideTopic> {
        val q = query.trim().lowercase()
        if (q.isBlank()) return CURATED_TOPICS
        return CURATED_TOPICS.filter {
            it.title.lowercase().contains(q) ||
            it.banglaTitle.lowercase().contains(q) ||
            it.subtitle.lowercase().contains(q) ||
            it.keySkills.any { skill -> skill.lowercase().contains(q) }
        }
    }

    fun getInstantGuide(query: String): String? {
        val match = searchTopics(query).firstOrNull() ?: return null
        return """
            ### ${match.iconEmoji} ${match.title} (${match.banglaTitle})
            *Category: ${match.category.label} • Difficulty: ${match.difficulty}*
            
            ${match.structuredContent}
            
            **Action Roadmap:**
            ${match.actionSteps.mapIndexed { idx, s -> "${idx + 1}. $s" }.joinToString("\n")}
        """.trimIndent()
    }
}
