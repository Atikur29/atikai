package com.example.network

import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.os.Build
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn

/**
 * Network connection type classification.
 */
enum class NetworkConnectionType(val displayName: String) {
    WIFI("Wi-Fi Network"),
    CELLULAR("Cellular Data"),
    ETHERNET("Ethernet"),
    VPN("Secure VPN"),
    OFFLINE("Offline / Disconnected")
}

/**
 * Real-time Network Connectivity Monitor for Atik AI (Step 12 Requirement 2).
 * Continuously listens to system network changes via ConnectivityManager.NetworkCallback.
 * Seamlessly toggles between Online Cloud AI and Offline Local AI modes.
 */
class NetworkConnectivityMonitor(
    private val context: Context,
    private val scope: CoroutineScope = CoroutineScope(Dispatchers.Default)
) {
    private val connectivityManager =
        context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager

    private val _isRealOnline = MutableStateFlow(checkInitialConnectivity())
    val isRealOnline: StateFlow<Boolean> = _isRealOnline.asStateFlow()

    private val _connectionType = MutableStateFlow(determineConnectionType())
    val connectionType: StateFlow<NetworkConnectionType> = _connectionType.asStateFlow()

    // Simulation toggle to allow user/developer testing offline mode without Airplane Mode
    private val _isSimulationOffline = MutableStateFlow(false)
    val isSimulationOffline: StateFlow<Boolean> = _isSimulationOffline.asStateFlow()

    // Effective online state: true only when real online AND simulation offline is disabled
    val isEffectiveOnline: StateFlow<Boolean> = combine(_isRealOnline, _isSimulationOffline) { real, simulated ->
        real && !simulated
    }.stateIn(scope, SharingStarted.Eagerly, checkInitialConnectivity())

    private val networkCallback = object : ConnectivityManager.NetworkCallback() {
        override fun onAvailable(network: Network) {
            updateNetworkStatus()
        }

        override fun onLost(network: Network) {
            updateNetworkStatus()
        }

        override fun onCapabilitiesChanged(network: Network, networkCapabilities: NetworkCapabilities) {
            updateNetworkStatus()
        }
    }

    init {
        registerCallback()
    }

    private fun registerCallback() {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                connectivityManager?.registerDefaultNetworkCallback(networkCallback)
            } else {
                val request = NetworkRequest.Builder()
                    .addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
                    .build()
                connectivityManager?.registerNetworkCallback(request, networkCallback)
            }
        } catch (_: Exception) {
            _isRealOnline.value = checkInitialConnectivity()
        }
    }

    fun updateNetworkStatus() {
        val cm = connectivityManager ?: return
        val activeNetwork = cm.activeNetwork
        val capabilities = cm.getNetworkCapabilities(activeNetwork)
        val hasInternet = capabilities != null &&
                capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) &&
                capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)

        _isRealOnline.value = hasInternet
        _connectionType.value = determineConnectionType()
    }

    private fun checkInitialConnectivity(): Boolean {
        val cm = connectivityManager ?: return false
        val activeNetwork = cm.activeNetwork ?: return false
        val capabilities = cm.getNetworkCapabilities(activeNetwork) ?: return false
        return capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }

    private fun determineConnectionType(): NetworkConnectionType {
        val cm = connectivityManager ?: return NetworkConnectionType.OFFLINE
        val activeNetwork = cm.activeNetwork ?: return NetworkConnectionType.OFFLINE
        val capabilities = cm.getNetworkCapabilities(activeNetwork) ?: return NetworkConnectionType.OFFLINE

        return when {
            capabilities.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> NetworkConnectionType.WIFI
            capabilities.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> NetworkConnectionType.CELLULAR
            capabilities.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> NetworkConnectionType.ETHERNET
            capabilities.hasTransport(NetworkCapabilities.TRANSPORT_VPN) -> NetworkConnectionType.VPN
            else -> NetworkConnectionType.OFFLINE
        }
    }

    fun toggleOfflineSimulation(enable: Boolean) {
        _isSimulationOffline.value = enable
    }

    fun destroy() {
        try {
            connectivityManager?.unregisterNetworkCallback(networkCallback)
        } catch (_: Exception) {
        }
    }
}
