package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "chat_sessions")
data class ChatSessionEntity(
    @PrimaryKey val id: String,
    val title: String,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
    val pinned: Boolean = false
)

@Entity(tableName = "chat_messages")
data class ChatMessageEntity(
    @PrimaryKey val id: String,
    val sessionId: String,
    val role: String, // "user", "model"
    val content: String,
    val timestamp: Long = System.currentTimeMillis(),
    val attachedFileName: String? = null,
    val attachedFileType: String? = null
)

@Entity(tableName = "memories")
data class MemoryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val key: String,
    val value: String,
    val category: String, // "Profile", "Preference", "Project", "Rule"
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "user_files")
data class SavedFileEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val fileName: String,
    val fileUri: String,
    val fileSize: String,
    val mimeType: String,
    val previewText: String? = null,
    val uploadedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "generated_images")
data class GeneratedImageEntity(
    @PrimaryKey val id: String,
    val prompt: String,
    val imageUrl: String,
    val sessionId: String,
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "user_settings")
data class UserSettingEntity(
    @PrimaryKey val key: String,
    val value: String,
    val updatedAt: Long = System.currentTimeMillis()
)

/**
 * Local Room offline persistent user note entity (Step 23 Requirement 1).
 */
@Entity(tableName = "user_notes")
data class NoteEntity(
    @PrimaryKey val id: String = java.util.UUID.randomUUID().toString(),
    val title: String,
    val content: String,
    val category: String = "General",
    val isPinned: Boolean = false,
    val isSynced: Boolean = true,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)

/**
 * Queue item for actions taken while offline to sync once connection returns (Step 23 Requirement 3).
 */
@Entity(tableName = "offline_sync_queue")
data class OfflineActionEntity(
    @PrimaryKey val id: String = java.util.UUID.randomUUID().toString(),
    val actionType: String, // "CHAT_MESSAGE", "CREATE_NOTE", "SYSTEM_COMMAND", "WORKFLOW_TRIGGER"
    val payloadJson: String,
    val description: String,
    val createdAt: Long = System.currentTimeMillis(),
    val status: String = "PENDING" // "PENDING", "SYNCING", "COMPLETED", "FAILED"
)

/**
 * Local Room persistent cache entry for offline fallback & instant recall (Step 23 Requirement 2 & 3).
 */
@Entity(tableName = "local_cache_entries")
data class CacheEntryEntity(
    @PrimaryKey val cacheKey: String, // Normalized prompt / query hash
    val queryText: String,
    val responsePayload: String, // Encrypted or plain cached response
    val category: String = "AI_REPLY", // "AI_REPLY", "TECH_GUIDE", "SYSTEM_SETTING", "MEMORY_DIGEST"
    val isEncrypted: Boolean = false,
    val createdAt: Long = System.currentTimeMillis(),
    val expiresAt: Long = System.currentTimeMillis() + (7 * 24 * 60 * 60 * 1000L), // 7 days TTL default
    val hitCount: Int = 1
)

/**
 * Smart Action audit log entity for accessibility automated messaging and calling (Step 24 Requirement 3).
 */
@Entity(tableName = "smart_action_audits")
data class SmartActionAuditEntity(
    @PrimaryKey val id: String = java.util.UUID.randomUUID().toString(),
    val targetApp: String, // "WHATSAPP", "IMO", "MESSAGES", "PHONE", "TELEGRAM"
    val recipient: String,
    val actionType: String, // "SEND_MESSAGE", "VOICE_CALL", "VIDEO_CALL", "DIAL_NUMBER"
    val messageSnippet: String? = null,
    val status: String = "SUCCESS", // "SUCCESS", "CONFIRMED", "CANCELLED", "FAILED", "PENDING_CONFIRMATION"
    val errorMessage: String? = null,
    val executionMode: String = "ACCESSIBILITY",
    val timestamp: Long = System.currentTimeMillis()
)

/**
 * Room persistence entity for dynamic app theme, button styles, font scale,
 * accent color, and background widget configuration (Step 25 Requirement 4).
 */
@Entity(tableName = "theme_configurations")
data class ThemeConfigEntity(
    @PrimaryKey val id: String = "active_theme_config",
    val themePreset: String = "FUTURISTIC_NEON", // FUTURISTIC_NEON, VINTAGE_80S, CYBERPUNK, AMOLED_DARK, MINIMAL_LIGHT
    val accentColorHex: String = "#00E5FF",
    val buttonStyle: String = "PILL_MODERN", // PILL_MODERN, ROUNDED_NEON, ANGULAR_TECH, OUTLINED_GLASS
    val fontScale: Float = 1.0f,
    val backgroundWidget: String = "NEON_MATRIX_GRID", // NEON_MATRIX_GRID, SYNTHWAVE_SUNSET, CYBER_PULSE_ORB, CLEAN_MINIMAL, STARFIELD_CONSTELLATION
    val updatedAt: Long = System.currentTimeMillis()
)

