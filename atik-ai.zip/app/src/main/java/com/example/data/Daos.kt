package com.example.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface ChatDao {
    @Query("SELECT * FROM chat_sessions ORDER BY pinned DESC, updatedAt DESC")
    fun getAllSessions(): Flow<List<ChatSessionEntity>>

    @Query("SELECT * FROM chat_sessions ORDER BY pinned DESC, updatedAt DESC")
    suspend fun getAllSessionsList(): List<ChatSessionEntity>

    @Query("SELECT COUNT(*) FROM chat_sessions")
    suspend fun getSessionCount(): Int

    @Query("SELECT * FROM chat_sessions WHERE id = :sessionId LIMIT 1")
    suspend fun getSessionById(sessionId: String): ChatSessionEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSession(session: ChatSessionEntity)

    @Update
    suspend fun updateSession(session: ChatSessionEntity)

    @Query("UPDATE chat_sessions SET title = :newTitle, updatedAt = :updatedAt WHERE id = :sessionId")
    suspend fun renameSession(sessionId: String, newTitle: String, updatedAt: Long = System.currentTimeMillis())

    @Query("DELETE FROM chat_sessions WHERE id = :sessionId")
    suspend fun deleteSession(sessionId: String)

    @Query("DELETE FROM chat_sessions")
    suspend fun deleteAllSessions()

    @Query("SELECT * FROM chat_messages WHERE sessionId = :sessionId ORDER BY timestamp ASC")
    fun getMessagesForSession(sessionId: String): Flow<List<ChatMessageEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMessage(message: ChatMessageEntity)

    @Query("DELETE FROM chat_messages WHERE sessionId = :sessionId")
    suspend fun deleteMessagesForSession(sessionId: String)

    @Query("DELETE FROM chat_messages")
    suspend fun deleteAllMessages()
}

@Dao
interface MemoryDao {
    @Query("SELECT * FROM memories ORDER BY timestamp DESC")
    fun getAllMemories(): Flow<List<MemoryEntity>>

    @Query("SELECT * FROM memories ORDER BY timestamp DESC")
    suspend fun getAllMemoriesList(): List<MemoryEntity>

    @Query("SELECT COUNT(*) FROM memories")
    suspend fun getMemoryCount(): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMemory(memory: MemoryEntity)

    @Update
    suspend fun updateMemory(memory: MemoryEntity)

    @Query("DELETE FROM memories WHERE id = :id")
    suspend fun deleteMemory(id: Long)

    @Query("DELETE FROM memories")
    suspend fun deleteAllMemories()
}

@Dao
interface FileDao {
    @Query("SELECT * FROM user_files ORDER BY uploadedAt DESC")
    fun getAllFiles(): Flow<List<SavedFileEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertFile(file: SavedFileEntity)

    @Query("DELETE FROM user_files WHERE id = :id")
    suspend fun deleteFile(id: Long)
}

@Dao
interface GeneratedImageDao {
    @Query("SELECT * FROM generated_images ORDER BY timestamp DESC")
    fun getAllGeneratedImages(): Flow<List<GeneratedImageEntity>>

    @Query("SELECT * FROM generated_images WHERE sessionId = :sessionId ORDER BY timestamp ASC")
    fun getImagesForSession(sessionId: String): Flow<List<GeneratedImageEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertGeneratedImage(image: GeneratedImageEntity)

    @Query("DELETE FROM generated_images WHERE id = :id")
    suspend fun deleteGeneratedImage(id: String)

    @Query("DELETE FROM generated_images")
    suspend fun deleteAllGeneratedImages()
}

@Dao
interface UserSettingDao {
    @Query("SELECT * FROM user_settings")
    fun getAllSettings(): Flow<List<UserSettingEntity>>

    @Query("SELECT value FROM user_settings WHERE `key` = :key LIMIT 1")
    suspend fun getSetting(key: String): String?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun setSetting(setting: UserSettingEntity)

    @Query("DELETE FROM user_settings WHERE `key` = :key")
    suspend fun deleteSetting(key: String)
}

@Dao
interface NoteDao {
    @Query("SELECT * FROM user_notes ORDER BY isPinned DESC, updatedAt DESC")
    fun getAllNotes(): Flow<List<NoteEntity>>

    @Query("SELECT * FROM user_notes WHERE title LIKE '%' || :query || '%' OR content LIKE '%' || :query || '%' ORDER BY isPinned DESC, updatedAt DESC")
    fun searchNotes(query: String): Flow<List<NoteEntity>>

    @Query("SELECT * FROM user_notes WHERE id = :id LIMIT 1")
    suspend fun getNoteById(id: String): NoteEntity?

    @Query("SELECT COUNT(*) FROM user_notes")
    suspend fun getNoteCount(): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertNote(note: NoteEntity)

    @Update
    suspend fun updateNote(note: NoteEntity)

    @Query("DELETE FROM user_notes WHERE id = :id")
    suspend fun deleteNote(id: String)

    @Query("DELETE FROM user_notes")
    suspend fun deleteAllNotes()
}

@Dao
interface OfflineSyncDao {
    @Query("SELECT * FROM offline_sync_queue WHERE status = 'PENDING' ORDER BY createdAt ASC")
    fun getAllPendingActions(): Flow<List<OfflineActionEntity>>

    @Query("SELECT * FROM offline_sync_queue WHERE status = 'PENDING' ORDER BY createdAt ASC")
    suspend fun getPendingActionsList(): List<OfflineActionEntity>

    @Query("SELECT COUNT(*) FROM offline_sync_queue WHERE status = 'PENDING'")
    fun getPendingCountFlow(): Flow<Int>

    @Query("SELECT COUNT(*) FROM offline_sync_queue WHERE status = 'PENDING'")
    suspend fun getPendingCount(): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAction(action: OfflineActionEntity)

    @Query("UPDATE offline_sync_queue SET status = :status WHERE id = :id")
    suspend fun updateActionStatus(id: String, status: String)

    @Query("DELETE FROM offline_sync_queue WHERE id = :id")
    suspend fun deleteAction(id: String)

    @Query("DELETE FROM offline_sync_queue WHERE status = 'COMPLETED'")
    suspend fun clearCompletedActions()

    @Query("DELETE FROM offline_sync_queue")
    suspend fun clearAllActions()
}

@Dao
interface CacheDao {
    @Query("SELECT * FROM local_cache_entries WHERE cacheKey = :key LIMIT 1")
    suspend fun getEntry(key: String): CacheEntryEntity?

    @Query("SELECT * FROM local_cache_entries WHERE queryText LIKE '%' || :query || '%' LIMIT 1")
    suspend fun findEntryByQuery(query: String): CacheEntryEntity?

    @Query("SELECT COUNT(*) FROM local_cache_entries")
    fun getCacheCountFlow(): Flow<Int>

    @Query("SELECT COUNT(*) FROM local_cache_entries")
    suspend fun getCacheCount(): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertEntry(entry: CacheEntryEntity)

    @Query("UPDATE local_cache_entries SET hitCount = hitCount + 1 WHERE cacheKey = :key")
    suspend fun incrementHitCount(key: String)

    @Query("DELETE FROM local_cache_entries WHERE expiresAt < :currentTime")
    suspend fun pruneExpired(currentTime: Long = System.currentTimeMillis()): Int

    @Query("DELETE FROM local_cache_entries")
    suspend fun clearAllCache()
}

@Dao
interface SmartActionDao {
    @Query("SELECT * FROM smart_action_audits ORDER BY timestamp DESC")
    fun getAllAuditsFlow(): Flow<List<SmartActionAuditEntity>>

    @Query("SELECT * FROM smart_action_audits ORDER BY timestamp DESC LIMIT :limit")
    fun getRecentAuditsFlow(limit: Int = 30): Flow<List<SmartActionAuditEntity>>

    @Query("SELECT * FROM smart_action_audits ORDER BY timestamp DESC LIMIT :limit")
    suspend fun getRecentAudits(limit: Int = 30): List<SmartActionAuditEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAudit(audit: SmartActionAuditEntity): Long

    @Query("UPDATE smart_action_audits SET status = :status, errorMessage = :errorMessage WHERE id = :id")
    suspend fun updateAuditStatus(id: String, status: String, errorMessage: String? = null)

    @Query("DELETE FROM smart_action_audits")
    suspend fun clearAllAudits()
}

@Dao
interface ThemeDao {
    @Query("SELECT * FROM theme_configurations WHERE id = 'active_theme_config' LIMIT 1")
    fun getThemeConfigFlow(): Flow<ThemeConfigEntity?>

    @Query("SELECT * FROM theme_configurations WHERE id = 'active_theme_config' LIMIT 1")
    suspend fun getThemeConfig(): ThemeConfigEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveThemeConfig(config: ThemeConfigEntity)
}

