package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class SocialPlatform(
    val id: String,
    val displayName: String,
    val charLimit: Int,
    val optimalTimeDescription: String,
    val iconEmoji: String,
    val primaryColorHex: Long
) {
    FACEBOOK("FACEBOOK", "Facebook", 63206, "1:00 PM – 4:00 PM (Weekdays)", "📘", 0xFF1877F2),
    INSTAGRAM("INSTAGRAM", "Instagram", 2200, "11:00 AM – 1:00 PM & 7:00 PM – 9:00 PM", "📸", 0xFFE1306C),
    TIKTOK("TIKTOK", "TikTok", 4000, "7:00 PM – 10:00 PM (High FYP Velocity)", "🎵", 0xFF00F2FE),
    TELEGRAM("TELEGRAM", "Telegram", 4096, "10:00 AM – 12:00 PM & 6:00 PM – 8:00 PM", "✈️", 0xFF229ED9),
    ALL("ALL", "All Platforms", 2200, "Multi-Platform Peak Broadcast", "🌐", 0xFF00E5FF);

    companion object {
        fun fromId(id: String): SocialPlatform {
            return values().firstOrNull { it.id.equals(id, ignoreCase = true) } ?: ALL
        }
    }
}

enum class PostStatus(val displayName: String, val badgeColorHex: Long) {
    DRAFT("Draft", 0xFF9E9E9E),
    SCHEDULED("Scheduled", 0xFF00E5FF),
    QUEUED("Queued", 0xFF7C4DFF),
    PUBLISHED("Published", 0xFF00E676)
}

@Entity(tableName = "social_posts")
data class SocialPostEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val platform: String = "ALL", // FACEBOOK, INSTAGRAM, TIKTOK, TELEGRAM, ALL
    val title: String,
    val caption: String,
    val hashtags: String = "",
    val scheduledTimeMillis: Long = System.currentTimeMillis() + 3600000L, // default 1h ahead
    val status: String = "SCHEDULED", // DRAFT, SCHEDULED, QUEUED, PUBLISHED
    val mediaUri: String? = null,
    val estimatedEngagementScore: Int = 85,
    val targetAudience: String = "General Audience",
    val tone: String = "Viral & Engaging",
    val createdAt: Long = System.currentTimeMillis()
)
