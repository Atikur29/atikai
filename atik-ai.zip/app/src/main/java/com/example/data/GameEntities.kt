package com.example.data

import androidx.room.Dao
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

/**
 * Entity representing an AI-Generated HTML5/Canvas 2D Game Project (Step 26 Requirement 2 & 4).
 */
@Entity(tableName = "game_projects")
data class GameProjectEntity(
    @PrimaryKey val id: String,
    val title: String,
    val genre: String,
    val prompt: String,
    val htmlContent: String,
    val thumbnailEmoji: String = "🎮",
    val highScore: Int = 0,
    val playCount: Int = 0,
    val lastPlayedAt: Long = 0L,
    val createdAt: Long = System.currentTimeMillis(),
    val gameStateJson: String? = null
)

/**
 * Entity for logging game scores and player leaderboards (Step 26 Requirement 4).
 */
@Entity(tableName = "game_scores")
data class GameScoreEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val gameId: String,
    val score: Int,
    val playerName: String = "Atikur Rahman",
    val durationSeconds: Int = 0,
    val timestamp: Long = System.currentTimeMillis()
)

/**
 * DAO for Game Projects and Scores persistence via Room DB (Step 26 Requirement 4).
 */
@Dao
interface GameDao {
    @Query("SELECT * FROM game_projects ORDER BY lastPlayedAt DESC, createdAt DESC")
    fun getAllGamesFlow(): Flow<List<GameProjectEntity>>

    @Query("SELECT * FROM game_projects WHERE id = :id LIMIT 1")
    suspend fun getGameById(id: String): GameProjectEntity?

    @Query("SELECT * FROM game_projects WHERE id = :id LIMIT 1")
    fun getGameByIdFlow(id: String): Flow<GameProjectEntity?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertGame(game: GameProjectEntity)

    @Update
    suspend fun updateGame(game: GameProjectEntity)

    @Query("DELETE FROM game_projects WHERE id = :id")
    suspend fun deleteGame(id: String)

    @Query("UPDATE game_projects SET highScore = MAX(highScore, :score), playCount = playCount + 1, lastPlayedAt = :timestamp WHERE id = :id")
    suspend fun recordGamePlayed(id: String, score: Int, timestamp: Long = System.currentTimeMillis())

    @Query("UPDATE game_projects SET gameStateJson = :stateJson WHERE id = :id")
    suspend fun saveGameState(id: String, stateJson: String)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertScore(score: GameScoreEntity): Long

    @Query("SELECT * FROM game_scores WHERE gameId = :gameId ORDER BY score DESC, timestamp DESC LIMIT :limit")
    fun getHighScoresForGame(gameId: String, limit: Int = 10): Flow<List<GameScoreEntity>>

    @Query("SELECT * FROM game_scores ORDER BY timestamp DESC LIMIT :limit")
    fun getRecentScores(limit: Int = 20): Flow<List<GameScoreEntity>>

    @Query("SELECT COUNT(*) FROM game_projects")
    suspend fun getGameCount(): Int
}
