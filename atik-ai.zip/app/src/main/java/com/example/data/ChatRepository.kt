package com.example.data

import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flowOf
import java.util.UUID

class ChatRepository(
    private val chatDao: ChatDao,
    private val memoryDao: MemoryDao,
    private val fileDao: FileDao,
    private val generatedImageDao: GeneratedImageDao? = null,
    private val userSettingDao: UserSettingDao? = null,
    private val socialPostDao: SocialPostDao? = null,
    private val automationDao: AutomationDao? = null,
    private val noteDao: NoteDao? = null,
    private val offlineSyncDao: OfflineSyncDao? = null,
    private val cacheDao: CacheDao? = null,
    private val smartActionDao: SmartActionDao? = null,
    private val themeDao: ThemeDao? = null,
    private val gameDao: GameDao? = null
) {
    // Game Studio & Runtime Engine (Step 26)
    val games: Flow<List<GameProjectEntity>> = gameDao?.getAllGamesFlow() ?: flowOf(emptyList<GameProjectEntity>())

    suspend fun getGameById(id: String): GameProjectEntity? = gameDao?.getGameById(id)

    fun getGameByIdFlow(id: String): Flow<GameProjectEntity?> = gameDao?.getGameByIdFlow(id) ?: flowOf<GameProjectEntity?>(null)

    suspend fun saveGame(game: GameProjectEntity) {
        gameDao?.insertGame(game)
    }

    suspend fun deleteGame(id: String) {
        gameDao?.deleteGame(id)
    }

    suspend fun recordGameScore(gameId: String, score: Int, playerName: String = "Atikur Rahman", durationSeconds: Int = 0) {
        gameDao?.recordGamePlayed(gameId, score)
        gameDao?.insertScore(GameScoreEntity(
            gameId = gameId,
            score = score,
            playerName = playerName,
            durationSeconds = durationSeconds,
            timestamp = System.currentTimeMillis()
        ))
    }

    suspend fun saveGameState(gameId: String, stateJson: String) {
        gameDao?.saveGameState(gameId, stateJson)
    }

    fun getGameLeaderboard(gameId: String): Flow<List<GameScoreEntity>> =
        gameDao?.getHighScoresForGame(gameId) ?: flowOf(emptyList<GameScoreEntity>())

    suspend fun getGameCount(): Int = gameDao?.getGameCount() ?: 0

    // Sessions
    val sessions: Flow<List<ChatSessionEntity>> = chatDao.getAllSessions()

    fun getMessages(sessionId: String): Flow<List<ChatMessageEntity>> =
        chatDao.getMessagesForSession(sessionId)

    suspend fun getSessionCount(): Int = chatDao.getSessionCount()

    suspend fun getAllSessionsList(): List<ChatSessionEntity> = chatDao.getAllSessionsList()

    suspend fun createNewSession(initialTitle: String = "নতুন আলোচনা"): ChatSessionEntity {
        val newSession = ChatSessionEntity(
            id = UUID.randomUUID().toString(),
            title = initialTitle,
            createdAt = System.currentTimeMillis(),
            updatedAt = System.currentTimeMillis()
        )
        chatDao.insertSession(newSession)
        return newSession
    }

    suspend fun getSessionById(sessionId: String): ChatSessionEntity? {
        return chatDao.getSessionById(sessionId)
    }

    suspend fun renameSession(sessionId: String, newTitle: String) {
        chatDao.renameSession(sessionId, newTitle)
    }

    suspend fun deleteSession(sessionId: String) {
        chatDao.deleteMessagesForSession(sessionId)
        chatDao.deleteSession(sessionId)
    }

    suspend fun clearAllSessions() {
        chatDao.deleteAllMessages()
        chatDao.deleteAllSessions()
    }

    suspend fun addMessage(
        sessionId: String,
        role: String,
        content: String,
        attachedFileName: String? = null,
        attachedFileType: String? = null
    ): ChatMessageEntity {
        val message = ChatMessageEntity(
            id = UUID.randomUUID().toString(),
            sessionId = sessionId,
            role = role,
            content = content,
            timestamp = System.currentTimeMillis(),
            attachedFileName = attachedFileName,
            attachedFileType = attachedFileType
        )
        chatDao.insertMessage(message)

        // Update session's updatedAt time
        val session = chatDao.getSessionById(sessionId)
        if (session != null) {
            val updatedTitle = if (session.title == "নতুন আলোচনা" && role == "user") {
                val preview = content.take(30).trim()
                if (preview.isNotBlank()) preview else session.title
            } else {
                session.title
            }
            chatDao.updateSession(session.copy(title = updatedTitle, updatedAt = System.currentTimeMillis()))
        }
        return message
    }

    // Memories
    val memories: Flow<List<MemoryEntity>> = memoryDao.getAllMemories()

    suspend fun getAllMemoriesSync(): List<MemoryEntity> = memoryDao.getAllMemoriesList()

    suspend fun getMemoryCount(): Int = memoryDao.getMemoryCount()

    suspend fun addMemory(key: String, value: String, category: String) {
        memoryDao.insertMemory(
            MemoryEntity(
                key = key.trim(),
                value = value.trim(),
                category = category
            )
        )
    }

    suspend fun updateMemory(memory: MemoryEntity) {
        memoryDao.updateMemory(memory)
    }

    suspend fun deleteMemory(id: Long) {
        memoryDao.deleteMemory(id)
    }

    // Files
    val files: Flow<List<SavedFileEntity>> = fileDao.getAllFiles()

    suspend fun addFile(
        fileName: String,
        fileUri: String,
        fileSize: String,
        mimeType: String,
        previewText: String? = null
    ) {
        fileDao.insertFile(
            SavedFileEntity(
                fileName = fileName,
                fileUri = fileUri,
                fileSize = fileSize,
                mimeType = mimeType,
                previewText = previewText
            )
        )
    }

    suspend fun deleteFile(id: Long) {
        fileDao.deleteFile(id)
    }

    // Generated Images Metadata
    val allGeneratedImages: Flow<List<GeneratedImageEntity>>? = generatedImageDao?.getAllGeneratedImages()

    suspend fun addGeneratedImage(prompt: String, imageUrl: String, sessionId: String): GeneratedImageEntity? {
        if (generatedImageDao == null) return null
        val entity = GeneratedImageEntity(
            id = UUID.randomUUID().toString(),
            prompt = prompt,
            imageUrl = imageUrl,
            sessionId = sessionId,
            timestamp = System.currentTimeMillis()
        )
        generatedImageDao.insertGeneratedImage(entity)
        return entity
    }

    suspend fun deleteGeneratedImage(id: String) {
        generatedImageDao?.deleteGeneratedImage(id)
    }

    // User Settings
    suspend fun saveSetting(key: String, value: String) {
        userSettingDao?.setSetting(UserSettingEntity(key = key, value = value, updatedAt = System.currentTimeMillis()))
    }

    suspend fun getSetting(key: String): String? {
        return userSettingDao?.getSetting(key)
    }

    // Social Media Posts & Queue
    val socialPosts: Flow<List<SocialPostEntity>> = socialPostDao?.getAllPosts() ?: kotlinx.coroutines.flow.flowOf(emptyList())

    suspend fun saveSocialPost(post: SocialPostEntity): Long {
        return socialPostDao?.insertPost(post) ?: -1L
    }

    suspend fun updateSocialPost(post: SocialPostEntity) {
        socialPostDao?.updatePost(post)
    }

    suspend fun updateSocialPostStatus(id: Long, status: String) {
        socialPostDao?.updateStatus(id, status)
    }

    suspend fun rescheduleSocialPost(id: Long, newTime: Long) {
        socialPostDao?.reschedulePost(id, newTime)
    }

    suspend fun deleteSocialPost(id: Long) {
        socialPostDao?.deletePost(id)
    }

    suspend fun clearPublishedSocialPosts() {
        socialPostDao?.clearPublishedPosts()
    }

    // Tasks & Automation (Step 13)
    val allTasks: Flow<List<TaskItemEntity>> = automationDao?.getAllTasks() ?: kotlinx.coroutines.flow.flowOf(emptyList())
    val pendingTasks: Flow<List<TaskItemEntity>> = automationDao?.getPendingTasks() ?: kotlinx.coroutines.flow.flowOf(emptyList())
    suspend fun getPendingTasksList(): List<TaskItemEntity> = automationDao?.getPendingTasksList() ?: emptyList()

    suspend fun addTask(
        title: String,
        description: String = "",
        priority: String = "MEDIUM",
        category: String = "Work",
        dueDateMillis: Long? = null
    ): TaskItemEntity {
        val task = TaskItemEntity(
            title = title.trim(),
            description = description.trim(),
            priority = priority,
            category = category,
            dueDateMillis = dueDateMillis
        )
        automationDao?.insertTask(task)
        return task
    }

    suspend fun updateTask(task: TaskItemEntity) {
        automationDao?.updateTask(task)
    }

    suspend fun setTaskCompleted(id: String, isCompleted: Boolean) {
        automationDao?.setTaskCompleted(id, isCompleted)
    }

    suspend fun deleteTask(id: String) {
        automationDao?.deleteTask(id)
    }

    suspend fun clearCompletedTasks() {
        automationDao?.clearCompletedTasks()
    }

    // Routines
    val allRoutines: Flow<List<RoutineEntity>> = automationDao?.getAllRoutines() ?: kotlinx.coroutines.flow.flowOf(emptyList())

    suspend fun updateRoutine(routine: RoutineEntity) {
        automationDao?.updateRoutine(routine)
    }

    suspend fun setRoutineEnabled(id: String, isEnabled: Boolean) {
        automationDao?.setRoutineEnabled(id, isEnabled)
    }

    suspend fun setRoutineTime(id: String, time: String) {
        automationDao?.setRoutineTime(id, time)
    }

    suspend fun setRoutineLastRun(id: String, timestamp: Long) {
        automationDao?.setRoutineLastRun(id, timestamp)
    }

    // Reminders
    val allReminders: Flow<List<ReminderEntity>> = automationDao?.getAllReminders() ?: kotlinx.coroutines.flow.flowOf(emptyList())

    suspend fun addReminder(title: String, timeFormatted: String, timeMillis: Long, isAlarm: Boolean = false): ReminderEntity {
        val reminder = ReminderEntity(
            title = title.trim(),
            timeFormatted = timeFormatted,
            timeMillis = timeMillis,
            isAlarm = isAlarm
        )
        automationDao?.insertReminder(reminder)
        return reminder
    }

    suspend fun deleteReminder(id: String) {
        automationDao?.deleteReminder(id)
    }

    // Workflows (Step 22)
    val allWorkflows: Flow<List<WorkflowEntity>> = automationDao?.getAllWorkflows() ?: kotlinx.coroutines.flow.flowOf(emptyList())

    suspend fun insertWorkflow(workflow: WorkflowEntity) {
        automationDao?.insertWorkflow(workflow)
    }

    suspend fun updateWorkflow(workflow: WorkflowEntity) {
        automationDao?.updateWorkflow(workflow)
    }

    suspend fun setWorkflowEnabled(id: String, isEnabled: Boolean) {
        automationDao?.setWorkflowEnabled(id, isEnabled)
    }

    suspend fun setWorkflowLastRun(id: String, timestamp: Long, result: String) {
        automationDao?.setWorkflowLastRun(id, timestamp, result)
    }

    suspend fun deleteWorkflow(id: String) {
        automationDao?.deleteWorkflow(id)
    }

    // === User Notes (Step 23 Requirement 1) ===
    val allNotes: Flow<List<NoteEntity>> = noteDao?.getAllNotes() ?: kotlinx.coroutines.flow.flowOf(emptyList())

    fun searchNotes(query: String): Flow<List<NoteEntity>> =
        noteDao?.searchNotes(query) ?: kotlinx.coroutines.flow.flowOf(emptyList())

    suspend fun getNoteCount(): Int = noteDao?.getNoteCount() ?: 0

    suspend fun addNote(
        title: String,
        content: String,
        category: String = "General",
        isPinned: Boolean = false,
        isSynced: Boolean = true
    ): NoteEntity {
        val note = NoteEntity(
            title = title.trim(),
            content = content.trim(),
            category = category,
            isPinned = isPinned,
            isSynced = isSynced,
            createdAt = System.currentTimeMillis(),
            updatedAt = System.currentTimeMillis()
        )
        noteDao?.insertNote(note)
        return note
    }

    suspend fun updateNote(note: NoteEntity) {
        noteDao?.updateNote(note.copy(updatedAt = System.currentTimeMillis()))
    }

    suspend fun deleteNote(id: String) {
        noteDao?.deleteNote(id)
    }

    // === Offline Sync Action Queue (Step 23 Requirement 3) ===
    val pendingOfflineActions: Flow<List<OfflineActionEntity>> =
        offlineSyncDao?.getAllPendingActions() ?: kotlinx.coroutines.flow.flowOf(emptyList())

    val pendingOfflineCountFlow: Flow<Int> =
        offlineSyncDao?.getPendingCountFlow() ?: kotlinx.coroutines.flow.flowOf(0)

    suspend fun getPendingOfflineCount(): Int =
        offlineSyncDao?.getPendingCount() ?: 0

    suspend fun getPendingOfflineActionsList(): List<OfflineActionEntity> =
        offlineSyncDao?.getPendingActionsList() ?: emptyList()

    suspend fun enqueueOfflineAction(
        actionType: String,
        payloadJson: String,
        description: String
    ): OfflineActionEntity {
        val action = OfflineActionEntity(
            actionType = actionType,
            payloadJson = payloadJson,
            description = description,
            createdAt = System.currentTimeMillis(),
            status = "PENDING"
        )
        offlineSyncDao?.insertAction(action)
        return action
    }

    suspend fun updateOfflineActionStatus(id: String, status: String) {
        offlineSyncDao?.updateActionStatus(id, status)
    }

    suspend fun deleteOfflineAction(id: String) {
        offlineSyncDao?.deleteAction(id)
    }

    suspend fun clearCompletedOfflineActions() {
        offlineSyncDao?.clearCompletedActions()
    }

    // === Local Cache Persistence (Step 23 Requirement 2 & 3) ===
    val cacheCountFlow: Flow<Int> = cacheDao?.getCacheCountFlow() ?: kotlinx.coroutines.flow.flowOf(0)

    suspend fun getCachedEntry(cacheKey: String): CacheEntryEntity? {
        val entry = cacheDao?.getEntry(cacheKey)
        if (entry != null) {
            cacheDao.incrementHitCount(cacheKey)
        }
        return entry
    }

    suspend fun findCachedQuery(query: String): CacheEntryEntity? {
        return cacheDao?.findEntryByQuery(query)
    }

    suspend fun cacheResponse(
        cacheKey: String,
        queryText: String,
        responsePayload: String,
        category: String = "AI_REPLY",
        isEncrypted: Boolean = false,
        ttlMillis: Long = 7 * 24 * 60 * 60 * 1000L
    ) {
        val entry = CacheEntryEntity(
            cacheKey = cacheKey,
            queryText = queryText,
            responsePayload = responsePayload,
            category = category,
            isEncrypted = isEncrypted,
            createdAt = System.currentTimeMillis(),
            expiresAt = System.currentTimeMillis() + ttlMillis,
            hitCount = 1
        )
        cacheDao?.insertEntry(entry)
    }

    suspend fun pruneExpiredCache(): Int {
        return cacheDao?.pruneExpired(System.currentTimeMillis()) ?: 0
    }

    suspend fun clearAllCache() {
        cacheDao?.clearAllCache()
    }

    suspend fun getCacheCount(): Int = cacheDao?.getCacheCount() ?: 0

    // === Smart Actions & Accessibility Auditing (Step 24 Requirement 3) ===
    val allSmartAuditsFlow: Flow<List<SmartActionAuditEntity>> =
        smartActionDao?.getAllAuditsFlow() ?: kotlinx.coroutines.flow.flowOf(emptyList())

    val recentSmartAuditsFlow: Flow<List<SmartActionAuditEntity>> =
        smartActionDao?.getRecentAuditsFlow(30) ?: kotlinx.coroutines.flow.flowOf(emptyList())

    suspend fun recordSmartActionAudit(audit: SmartActionAuditEntity): Long {
        return smartActionDao?.insertAudit(audit) ?: 0L
    }

    suspend fun updateSmartActionStatus(id: String, status: String, errorMessage: String? = null) {
        smartActionDao?.updateAuditStatus(id, status, errorMessage)
    }

    suspend fun clearSmartActionAudits() {
        smartActionDao?.clearAllAudits()
    }

    // === Dynamic Theme Engine Persistence (Step 25 Requirement 4) ===
    val themeConfigFlow: Flow<ThemeConfigEntity?> =
        themeDao?.getThemeConfigFlow() ?: kotlinx.coroutines.flow.flowOf(null)

    suspend fun getThemeConfig(): ThemeConfigEntity? {
        return themeDao?.getThemeConfig()
    }

    suspend fun saveThemeConfig(config: ThemeConfigEntity) {
        themeDao?.saveThemeConfig(config)
    }

    // === Storage Diagnostics Metrics (Step 23 Requirement 1 & 4) ===
    suspend fun getStorageMetrics(): LocalDatabaseMetrics {
        val sCount = chatDao.getSessionCount()
        val mCount = memoryDao.getMemoryCount()
        val nCount = noteDao?.getNoteCount() ?: 0
        val pSync = offlineSyncDao?.getPendingCount() ?: 0
        val cCount = cacheDao?.getCacheCount() ?: 0
        val aCount = smartActionDao?.getRecentAudits(100)?.size ?: 0
        val estKb = (sCount * 2L + mCount * 1L + nCount * 3L + pSync * 1L + cCount * 4L + aCount * 2L + 24L).coerceAtLeast(32L)

        return LocalDatabaseMetrics(
            sessionCount = sCount,
            memoryCount = mCount,
            noteCount = nCount,
            pendingSyncCount = pSync,
            cachedQueryCount = cCount,
            smartActionAuditCount = aCount,
            estimatedDbSizeKb = estKb
        )
    }

    suspend fun clearAllDatabaseData() {
        chatDao.deleteAllMessages()
        chatDao.deleteAllSessions()
        memoryDao.deleteAllMemories()
        generatedImageDao?.deleteAllGeneratedImages()
        noteDao?.deleteAllNotes()
        offlineSyncDao?.clearAllActions()
        cacheDao?.clearAllCache()
        smartActionDao?.clearAllAudits()
    }
}

/**
 * Diagnostics model summarizing local Room storage, cache entries, and pending sync status.
 */
data class LocalDatabaseMetrics(
    val sessionCount: Int = 0,
    val memoryCount: Int = 0,
    val noteCount: Int = 0,
    val pendingSyncCount: Int = 0,
    val cachedQueryCount: Int = 0,
    val smartActionAuditCount: Int = 0,
    val estimatedDbSizeKb: Long = 0L
)
