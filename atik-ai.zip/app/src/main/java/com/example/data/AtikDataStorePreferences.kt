package com.example.data

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

val Context.offlineDataStore by preferencesDataStore(name = "atik_offline_preferences")

/**
 * DataStore storage persistence engine for Atik AI system settings,
 * offline mode policies, and automatic background sync states (Step 23 Requirement 1).
 */
class AtikDataStorePreferences(private val context: Context) {

    companion object {
        val KEY_AUTO_SYNC_ENABLED = booleanPreferencesKey("auto_sync_enabled")
        val KEY_OFFLINE_FALLBACK_PERSONA = booleanPreferencesKey("offline_fallback_persona")
        val KEY_OFFLINE_STORAGE_PERSISTENCE = booleanPreferencesKey("offline_storage_persistence")
        val KEY_LAST_SYNC_TIMESTAMP = longPreferencesKey("last_sync_timestamp")
        val KEY_LAST_SYNC_STATUS = stringPreferencesKey("last_sync_status")
        val KEY_SYNC_ONLY_ON_WIFI = booleanPreferencesKey("sync_only_on_wifi")
        val KEY_OFFLINE_CACHE_PRUNING = booleanPreferencesKey("offline_cache_pruning")
        // Step 24 Smart Action & Accessibility Guardrails
        val KEY_SMART_ACTION_ENABLED = booleanPreferencesKey("smart_action_enabled")
        val KEY_REQUIRE_CONFIRMATION = booleanPreferencesKey("require_confirmation")
        val KEY_COUNTDOWN_SECONDS = longPreferencesKey("countdown_seconds")
        val KEY_WHATSAPP_ACTION_ENABLED = booleanPreferencesKey("whatsapp_action_enabled")
        val KEY_IMO_ACTION_ENABLED = booleanPreferencesKey("imo_action_enabled")
        val KEY_SMS_ACTION_ENABLED = booleanPreferencesKey("sms_action_enabled")
        val KEY_PHONE_ACTION_ENABLED = booleanPreferencesKey("phone_action_enabled")
    }

    val smartActionEnabled: Flow<Boolean> = context.offlineDataStore.data.map {
        it[KEY_SMART_ACTION_ENABLED] ?: true
    }

    val requireConfirmation: Flow<Boolean> = context.offlineDataStore.data.map {
        it[KEY_REQUIRE_CONFIRMATION] ?: true
    }

    val countdownSeconds: Flow<Long> = context.offlineDataStore.data.map {
        it[KEY_COUNTDOWN_SECONDS] ?: 5L
    }

    val whatsappActionEnabled: Flow<Boolean> = context.offlineDataStore.data.map {
        it[KEY_WHATSAPP_ACTION_ENABLED] ?: true
    }

    val imoActionEnabled: Flow<Boolean> = context.offlineDataStore.data.map {
        it[KEY_IMO_ACTION_ENABLED] ?: true
    }

    val smsActionEnabled: Flow<Boolean> = context.offlineDataStore.data.map {
        it[KEY_SMS_ACTION_ENABLED] ?: true
    }

    val phoneActionEnabled: Flow<Boolean> = context.offlineDataStore.data.map {
        it[KEY_PHONE_ACTION_ENABLED] ?: true
    }

    val autoSyncEnabled: Flow<Boolean> = context.offlineDataStore.data.map {
        it[KEY_AUTO_SYNC_ENABLED] ?: true
    }

    val offlineFallbackPersona: Flow<Boolean> = context.offlineDataStore.data.map {
        it[KEY_OFFLINE_FALLBACK_PERSONA] ?: true
    }

    val offlineStoragePersistence: Flow<Boolean> = context.offlineDataStore.data.map {
        it[KEY_OFFLINE_STORAGE_PERSISTENCE] ?: true
    }

    val lastSyncTimestamp: Flow<Long> = context.offlineDataStore.data.map {
        it[KEY_LAST_SYNC_TIMESTAMP] ?: System.currentTimeMillis()
    }

    val lastSyncStatus: Flow<String> = context.offlineDataStore.data.map {
        it[KEY_LAST_SYNC_STATUS] ?: "Local Database Synced & Ready"
    }

    val syncOnlyOnWifi: Flow<Boolean> = context.offlineDataStore.data.map {
        it[KEY_SYNC_ONLY_ON_WIFI] ?: false
    }

    suspend fun setAutoSyncEnabled(enabled: Boolean) {
        context.offlineDataStore.edit { it[KEY_AUTO_SYNC_ENABLED] = enabled }
    }

    suspend fun setOfflineFallbackPersona(enabled: Boolean) {
        context.offlineDataStore.edit { it[KEY_OFFLINE_FALLBACK_PERSONA] = enabled }
    }

    suspend fun setOfflineStoragePersistence(enabled: Boolean) {
        context.offlineDataStore.edit { it[KEY_OFFLINE_STORAGE_PERSISTENCE] = enabled }
    }

    suspend fun updateSyncStatus(timestamp: Long, status: String) {
        context.offlineDataStore.edit {
            it[KEY_LAST_SYNC_TIMESTAMP] = timestamp
            it[KEY_LAST_SYNC_STATUS] = status
        }
    }

    suspend fun setSyncOnlyOnWifi(onlyWifi: Boolean) {
        context.offlineDataStore.edit { it[KEY_SYNC_ONLY_ON_WIFI] = onlyWifi }
    }

    suspend fun setSmartActionEnabled(enabled: Boolean) {
        context.offlineDataStore.edit { it[KEY_SMART_ACTION_ENABLED] = enabled }
    }

    suspend fun setRequireConfirmation(required: Boolean) {
        context.offlineDataStore.edit { it[KEY_REQUIRE_CONFIRMATION] = required }
    }

    suspend fun setCountdownSeconds(seconds: Long) {
        context.offlineDataStore.edit { it[KEY_COUNTDOWN_SECONDS] = seconds }
    }

    suspend fun setWhatsappActionEnabled(enabled: Boolean) {
        context.offlineDataStore.edit { it[KEY_WHATSAPP_ACTION_ENABLED] = enabled }
    }

    suspend fun setImoActionEnabled(enabled: Boolean) {
        context.offlineDataStore.edit { it[KEY_IMO_ACTION_ENABLED] = enabled }
    }

    suspend fun setSmsActionEnabled(enabled: Boolean) {
        context.offlineDataStore.edit { it[KEY_SMS_ACTION_ENABLED] = enabled }
    }

    suspend fun setPhoneActionEnabled(enabled: Boolean) {
        context.offlineDataStore.edit { it[KEY_PHONE_ACTION_ENABLED] = enabled }
    }
}
