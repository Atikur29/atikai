package com.example.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
    entities = [
        ChatSessionEntity::class,
        ChatMessageEntity::class,
        MemoryEntity::class,
        SavedFileEntity::class,
        GeneratedImageEntity::class,
        UserSettingEntity::class,
        SocialPostEntity::class,
        TaskItemEntity::class,
        RoutineEntity::class,
        ReminderEntity::class,
        WorkflowEntity::class,
        NoteEntity::class,
        OfflineActionEntity::class,
        CacheEntryEntity::class,
        SmartActionAuditEntity::class,
        ThemeConfigEntity::class,
        GameProjectEntity::class,
        GameScoreEntity::class
    ],
    version = 10,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun chatDao(): ChatDao
    abstract fun memoryDao(): MemoryDao
    abstract fun fileDao(): FileDao
    abstract fun generatedImageDao(): GeneratedImageDao
    abstract fun userSettingDao(): UserSettingDao
    abstract fun socialPostDao(): SocialPostDao
    abstract fun automationDao(): AutomationDao
    abstract fun noteDao(): NoteDao
    abstract fun offlineSyncDao(): OfflineSyncDao
    abstract fun cacheDao(): CacheDao
    abstract fun smartActionDao(): SmartActionDao
    abstract fun themeDao(): ThemeDao
    abstract fun gameDao(): GameDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "atik_ai_database"
                )
                .fallbackToDestructiveMigration()
                .addCallback(object : RoomDatabase.Callback() {
                    override fun onCreate(db: SupportSQLiteDatabase) {
                        super.onCreate(db)
                        // Seed initial memory for Atikur Rahman
                        CoroutineScope(Dispatchers.IO).launch {
                            val database = getDatabase(context)
                            database.memoryDao().insertMemory(
                                MemoryEntity(
                                    key = "User Name",
                                    value = "Atikur Rahman (আতিকুর রহমান)",
                                    category = "Profile"
                                )
                            )
                            database.memoryDao().insertMemory(
                                MemoryEntity(
                                    key = "Preferred Title",
                                    value = "আতিক ভাই (Atik Bhai)",
                                    category = "Preference"
                                )
                            )
                            database.memoryDao().insertMemory(
                                MemoryEntity(
                                    key = "Default Language",
                                    value = "Bangla (bn-BD) with fluent Banglish and English support",
                                    category = "Preference"
                                )
                            )
                            database.memoryDao().insertMemory(
                                MemoryEntity(
                                    key = "App Role",
                                    value = "Atik AI - Dedicated elite personal AI assistant",
                                    category = "Rule"
                                )
                            )

                            // Pre-seed default routines (Step 13)
                            database.automationDao().insertRoutine(
                                RoutineEntity(
                                    id = "routine_morning",
                                    type = "MORNING_BRIEFING",
                                    title = "Morning Executive Briefing",
                                    scheduledTime = "08:00 AM",
                                    isEnabled = true,
                                    includeWeather = true,
                                    includeSchedule = true,
                                    includeTasks = true
                                )
                            )
                            database.automationDao().insertRoutine(
                                RoutineEntity(
                                    id = "routine_evening",
                                    type = "EVENING_SUMMARY",
                                    title = "Evening Accomplishment Summary",
                                    scheduledTime = "09:00 PM",
                                    isEnabled = true,
                                    includeWeather = false,
                                    includeSchedule = true,
                                    includeTasks = true
                                )
                            )
                            database.automationDao().insertRoutine(
                                RoutineEntity(
                                    id = "routine_focus",
                                    type = "WORK_FOCUS",
                                    title = "Afternoon Deep Work Sprint",
                                    scheduledTime = "02:30 PM",
                                    isEnabled = true,
                                    includeWeather = false,
                                    includeSchedule = false,
                                    includeTasks = true
                                )
                            )

                            // Pre-seed starter tasks
                            database.automationDao().insertTask(
                                TaskItemEntity(
                                    title = "Review Atik AI Android Architecture",
                                    description = "Verify local offline engine, voice sync, and routine automations",
                                    priority = "HIGH",
                                    category = "AI Development"
                                )
                            )
                            database.automationDao().insertTask(
                                TaskItemEntity(
                                    title = "Prepare Client Proposal for Mobile Project",
                                    description = "Draft milestone estimates and deliverables",
                                    priority = "MEDIUM",
                                    category = "Work"
                                )
                            )

                            // Pre-seed starter Macro Workflows (Step 22)
                            database.automationDao().insertWorkflow(
                                WorkflowEntity(
                                    id = "workflow_morning",
                                    name = "Morning Power-Up Routine",
                                    description = "Read live morning news, verify battery/storage health, and turn on Wi-Fi.",
                                    iconEmoji = "🌅",
                                    scheduledTime = "07:30 AM",
                                    isEnabled = true,
                                    actionsCsv = "read_news,check_system,turn_on_wifi,briefing"
                                )
                            )
                            database.automationDao().insertWorkflow(
                                WorkflowEntity(
                                    id = "workflow_deep_work",
                                    name = "Deep Work Focus Sprint",
                                    description = "Engage silent sound profile, boost memory RAM, and post priority briefing.",
                                    iconEmoji = "⚡",
                                    scheduledTime = "09:30 AM",
                                    isEnabled = true,
                                    actionsCsv = "silent_profile,optimize_memory,push_alert"
                                )
                            )
                            database.automationDao().insertWorkflow(
                                WorkflowEntity(
                                    id = "workflow_night_rest",
                                    name = "Night Reflection & Rest",
                                    description = "Mute audio alerts, inspect device telemetry, and speak bedtime reflection.",
                                    iconEmoji = "🌙",
                                    scheduledTime = "10:30 PM",
                                    isEnabled = true,
                                    actionsCsv = "silent_profile,check_system,briefing"
                                )
                            )
                        }
                    }
                })
                .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
