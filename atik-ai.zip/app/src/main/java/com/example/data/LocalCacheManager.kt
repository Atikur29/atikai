package com.example.data

import android.content.Context
import android.util.Log
import com.example.security.DataEncryptionEngine
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.security.MessageDigest
import java.util.Locale

/**
 * Statistics snapshot for local Room cache.
 */
data class CacheMetrics(
    val totalEntries: Int = 0,
    val totalHits: Int = 0,
    val estimatedKb: Long = 0L,
    val lastPruneTime: Long = System.currentTimeMillis()
)

/**
 * Local Cache Manager & Offline Fallback Engine (Step 23 Requirement 2 & 3).
 * Provides fast, encrypted persistent caching for user queries, Gemini responses,
 * offline knowledge snippets, and system configurations with automatic TTL expiry and LRU retention.
 */
class LocalCacheManager(
    private val context: Context,
    private val repository: ChatRepository,
    private val encryptionEngine: DataEncryptionEngine,
    private val scope: CoroutineScope = CoroutineScope(Dispatchers.IO)
) {
    private val _cacheMetrics = MutableStateFlow(CacheMetrics())
    val cacheMetrics: StateFlow<CacheMetrics> = _cacheMetrics.asStateFlow()

    init {
        scope.launch {
            refreshMetrics()
            seedEssentialOfflineKnowledge()
        }
    }

    /**
     * Hashes prompt string to produce a collision-resistant normalized cache key.
     */
    fun computeCacheKey(prompt: String): String {
        val normalized = prompt.trim().lowercase(Locale.ROOT)
        return try {
            val md = MessageDigest.getInstance("SHA-256")
            val digest = md.digest(normalized.toByteArray(Charsets.UTF_8))
            digest.take(16).joinToString("") { "%02x".format(it) }
        } catch (_: Exception) {
            "key_" + normalized.hashCode().toString()
        }
    }

    /**
     * Looks up cached response by exact key or semantic query match.
     * Decrypts if the cached entry was securely encrypted.
     */
    suspend fun getCachedResponse(prompt: String): String? {
        val key = computeCacheKey(prompt)
        val entry = repository.getCachedEntry(key) ?: repository.findCachedQuery(prompt.trim())
        if (entry == null) return null

        // Check if expired
        if (System.currentTimeMillis() > entry.expiresAt) {
            return null
        }

        val result = if (entry.isEncrypted) {
            encryptionEngine.decrypt(entry.responsePayload)
        } else {
            entry.responsePayload
        }

        updateHitMetrics()
        return result
    }

    /**
     * Caches response with optional encryption and custom TTL (default 7 days).
     */
    suspend fun cacheResponse(
        prompt: String,
        response: String,
        category: String = "AI_REPLY",
        encrypt: Boolean = false,
        ttlHours: Int = 168
    ) {
        val key = computeCacheKey(prompt)
        val payload = if (encrypt) {
            encryptionEngine.encrypt(response)
        } else {
            response
        }

        repository.cacheResponse(
            cacheKey = key,
            queryText = prompt.trim(),
            responsePayload = payload,
            category = category,
            isEncrypted = encrypt,
            ttlMillis = ttlHours * 3600 * 1000L
        )
        refreshMetrics()
    }

    /**
     * Prunes expired cache records to keep database footprint lean.
     */
    suspend fun pruneExpiredCache(): Int {
        val pruned = repository.pruneExpiredCache()
        refreshMetrics()
        return pruned
    }

    /**
     * Clears all cache entries from Room database.
     */
    suspend fun clearAllCache() {
        repository.clearAllCache()
        refreshMetrics()
    }

    suspend fun refreshMetrics() {
        val count = repository.getCacheCount()
        _cacheMetrics.value = CacheMetrics(
            totalEntries = count,
            totalHits = _cacheMetrics.value.totalHits,
            estimatedKb = (count * 4L + 8L).coerceAtLeast(12L),
            lastPruneTime = System.currentTimeMillis()
        )
    }

    private fun updateHitMetrics() {
        _cacheMetrics.value = _cacheMetrics.value.copy(
            totalHits = _cacheMetrics.value.totalHits + 1
        )
    }

    /**
     * Seeds essential offline queries so Atik AI immediately answers core questions offline.
     */
    private suspend fun seedEssentialOfflineKnowledge() {
        try {
            val count = repository.getCacheCount()
            if (count > 0) return

            cacheResponse(
                prompt = "what can you do offline",
                response = "🛡️ **[Atik AI Offline Capabilities]**\n\nWhen internet is disconnected, I remain fully operational on your device:\n• **Offline Calculator:** Arithmetic, currency exchange (~122.50 USD to BDT), square roots & percentages.\n• **Device Controls:** Wi-Fi, Flashlight, Sound profiles, Airplane mode & Battery telemetry.\n• **Local Notes & Reminders:** Take, search, and manage persistent notes.\n• **Tech Academy Guides:** Android Kotlin, Git, Linux, Docker, Python cheat sheets.\n• **Encrypted Vault:** AES-256 local persistent memory.\n\n*(Seamlessly queued for cloud sync once reconnected)*",
                category = "OFFLINE_CORE",
                encrypt = false
            )

            cacheResponse(
                prompt = "who is atikur rahman",
                response = "👑 **[User Profile - Atikur Rahman]**\n\nAtikur Rahman (আতিকুর রহমান / Atik Bhai) is a software engineer and the creator/master of Atik AI. I am customized to serve as his elite mobile executive assistant with native bilingual support (Bangla & English).",
                category = "PROFILE",
                encrypt = true
            )
        } catch (e: Exception) {
            Log.e("LocalCacheManager", "Error seeding offline cache: ${e.message}")
        }
    }
}
