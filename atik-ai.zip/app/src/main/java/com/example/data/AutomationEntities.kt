package com.example.data

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow
import java.util.UUID

/**
 * Task entity representing user to-do items with priority and completion states.
 */
@Entity(tableName = "tasks")
data class TaskItemEntity(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val title: String,
    val description: String = "",
    val priority: String = "MEDIUM", // LOW, MEDIUM, HIGH, URGENT
    val category: String = "Work", // Work, Personal, AI Development, Learning, Health
    val dueDateMillis: Long? = null,
    val isCompleted: Boolean = false,
    val createdAtMillis: Long = System.currentTimeMillis()
)

/**
 * Automated routine configuration (Morning Briefing, Evening Summary, Work Focus, Night Meditation).
 */
@Entity(tableName = "routines")
data class RoutineEntity(
    @PrimaryKey val id: String,
    val type: String, // MORNING_BRIEFING, EVENING_SUMMARY, WORK_FOCUS, NIGHT_MEDITATION
    val title: String,
    val scheduledTime: String = "08:00 AM",
    val isEnabled: Boolean = true,
    val includeWeather: Boolean = true,
    val includeSchedule: Boolean = true,
    val includeTasks: Boolean = true,
    val lastRunTimestamp: Long = 0L
)

/**
 * Smart scheduled reminders and alarms.
 */
@Entity(tableName = "reminders")
data class ReminderEntity(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val title: String,
    val timeFormatted: String,
    val timeMillis: Long,
    val isAlarm: Boolean = false,
    val isCompleted: Boolean = false,
    val createdAtMillis: Long = System.currentTimeMillis()
)

/**
 * Smart Workflow Entity representing combined macro triggers and routines (Step 22 Requirement 2).
 * e.g., "Morning Routine: read live news + check system status + turn on Wi-Fi".
 */
@Entity(tableName = "workflows")
data class WorkflowEntity(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val name: String,
    val description: String = "",
    val iconEmoji: String = "⚡",
    val scheduledTime: String = "07:30 AM",
    val isEnabled: Boolean = true,
    val actionsCsv: String = "read_news,check_system,turn_on_wifi",
    val triggerType: String = "SCHEDULED", // SCHEDULED, MANUAL, VOICE
    val lastRunTimestamp: Long = 0L,
    val lastRunResult: String = "Ready to execute",
    val createdAtMillis: Long = System.currentTimeMillis()
)

@Dao
interface AutomationDao {
    // Tasks
    @Query("SELECT * FROM tasks ORDER BY isCompleted ASC, createdAtMillis DESC")
    fun getAllTasks(): Flow<List<TaskItemEntity>>

    @Query("SELECT * FROM tasks WHERE isCompleted = 0 ORDER BY createdAtMillis DESC")
    fun getPendingTasks(): Flow<List<TaskItemEntity>>

    @Query("SELECT * FROM tasks WHERE isCompleted = 0 ORDER BY createdAtMillis DESC")
    suspend fun getPendingTasksList(): List<TaskItemEntity>

    @Query("SELECT * FROM tasks WHERE id = :id")
    suspend fun getTaskById(id: String): TaskItemEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTask(task: TaskItemEntity)

    @Update
    suspend fun updateTask(task: TaskItemEntity)

    @Query("UPDATE tasks SET isCompleted = :isCompleted WHERE id = :id")
    suspend fun setTaskCompleted(id: String, isCompleted: Boolean)

    @Query("DELETE FROM tasks WHERE id = :id")
    suspend fun deleteTask(id: String)

    @Query("DELETE FROM tasks WHERE isCompleted = 1")
    suspend fun clearCompletedTasks()

    // Routines
    @Query("SELECT * FROM routines ORDER BY scheduledTime ASC")
    fun getAllRoutines(): Flow<List<RoutineEntity>>

    @Query("SELECT * FROM routines WHERE id = :id")
    suspend fun getRoutineById(id: String): RoutineEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRoutine(routine: RoutineEntity)

    @Update
    suspend fun updateRoutine(routine: RoutineEntity)

    @Query("UPDATE routines SET isEnabled = :isEnabled WHERE id = :id")
    suspend fun setRoutineEnabled(id: String, isEnabled: Boolean)

    @Query("UPDATE routines SET scheduledTime = :time WHERE id = :id")
    suspend fun setRoutineTime(id: String, time: String)

    @Query("UPDATE routines SET lastRunTimestamp = :timestamp WHERE id = :id")
    suspend fun setRoutineLastRun(id: String, timestamp: Long)

    // Reminders
    @Query("SELECT * FROM reminders ORDER BY timeMillis ASC")
    fun getAllReminders(): Flow<List<ReminderEntity>>

    @Query("SELECT * FROM reminders WHERE isCompleted = 0 ORDER BY timeMillis ASC")
    fun getActiveReminders(): Flow<List<ReminderEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertReminder(reminder: ReminderEntity)

    @Update
    suspend fun updateReminder(reminder: ReminderEntity)

    @Query("DELETE FROM reminders WHERE id = :id")
    suspend fun deleteReminder(id: String)

    // Workflows (Step 22)
    @Query("SELECT * FROM workflows ORDER BY scheduledTime ASC")
    fun getAllWorkflows(): Flow<List<WorkflowEntity>>

    @Query("SELECT * FROM workflows WHERE id = :id")
    suspend fun getWorkflowById(id: String): WorkflowEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertWorkflow(workflow: WorkflowEntity)

    @Update
    suspend fun updateWorkflow(workflow: WorkflowEntity)

    @Query("UPDATE workflows SET isEnabled = :isEnabled WHERE id = :id")
    suspend fun setWorkflowEnabled(id: String, isEnabled: Boolean)

    @Query("UPDATE workflows SET lastRunTimestamp = :timestamp, lastRunResult = :result WHERE id = :id")
    suspend fun setWorkflowLastRun(id: String, timestamp: Long, result: String)

    @Query("DELETE FROM workflows WHERE id = :id")
    suspend fun deleteWorkflow(id: String)
}
