package com.example.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface SocialPostDao {

    @Query("SELECT * FROM social_posts ORDER BY scheduledTimeMillis ASC")
    fun getAllPosts(): Flow<List<SocialPostEntity>>

    @Query("SELECT * FROM social_posts WHERE platform = :platform ORDER BY scheduledTimeMillis ASC")
    fun getPostsByPlatform(platform: String): Flow<List<SocialPostEntity>>

    @Query("SELECT * FROM social_posts WHERE status = :status ORDER BY scheduledTimeMillis ASC")
    fun getPostsByStatus(status: String): Flow<List<SocialPostEntity>>

    @Query("SELECT * FROM social_posts WHERE id = :id LIMIT 1")
    suspend fun getPostById(id: Long): SocialPostEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPost(post: SocialPostEntity): Long

    @Update
    suspend fun updatePost(post: SocialPostEntity)

    @Query("UPDATE social_posts SET status = :status WHERE id = :id")
    suspend fun updateStatus(id: Long, status: String)

    @Query("UPDATE social_posts SET scheduledTimeMillis = :newTime WHERE id = :id")
    suspend fun reschedulePost(id: Long, newTime: Long)

    @Query("DELETE FROM social_posts WHERE id = :id")
    suspend fun deletePost(id: Long)

    @Query("DELETE FROM social_posts WHERE status = 'PUBLISHED'")
    suspend fun clearPublishedPosts()

    @Query("SELECT COUNT(*) FROM social_posts")
    suspend fun getPostCount(): Int
}
