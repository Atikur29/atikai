package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.BookmarkBorder
import androidx.compose.material.icons.filled.ChatBubbleOutline
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.ContentPaste
import androidx.compose.material.icons.filled.Link
import androidx.compose.material.icons.filled.OpenInNew
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Summarize
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.news.ArticleSummaryResult
import com.example.news.NewsArticle
import com.example.news.NewsCategory
import com.example.news.WebSearchAnswer
import com.example.ui.theme.AtikBorder
import com.example.ui.theme.AtikElectricBlue
import com.example.ui.theme.AtikNeonAzure
import com.example.ui.theme.AtikNeonCyan
import com.example.ui.theme.AtikSuccess
import com.example.ui.theme.AtikSurface
import com.example.ui.theme.AtikSurfaceHighlight
import com.example.ui.theme.AtikSurfaceVariant
import com.example.ui.theme.AtikTextMuted
import com.example.ui.theme.AtikTextPrimary
import com.example.ui.theme.AtikTextSecondary

/**
 * Smart Web Search & Live News Aggregator Screen (Step 18).
 * Real-time internet search with citations, categorized breaking news hub,
 * and link-paste web article summarizer.
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun NewsScreen(
    articles: List<NewsArticle>,
    selectedCategory: NewsCategory,
    isSearching: Boolean,
    searchAnswer: WebSearchAnswer?,
    isSummarizing: Boolean,
    articleSummary: ArticleSummaryResult?,
    isRefreshingNews: Boolean,
    onSearch: (String) -> Unit,
    onSummarizeUrl: (String) -> Unit,
    onSelectCategory: (NewsCategory) -> Unit,
    onToggleBookmark: (String) -> Unit,
    onRefreshNews: () -> Unit,
    onSendToChat: (String) -> Unit,
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    BackHandler { onBack() }
    val context = LocalContext.current

    var searchQuery by remember { mutableStateOf("") }
    var urlToSummarize by remember { mutableStateOf("") }
    var showSummarizerPanel by remember { mutableStateOf(false) }

    val filteredArticles = remember(articles, selectedCategory) {
        if (selectedCategory == NewsCategory.ALL) articles
        else articles.filter { it.category == selectedCategory }
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFF04080D))
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(10.dp))
            // Header Bar
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(
                        onClick = onBack,
                        modifier = Modifier.testTag("btn_news_back")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                            tint = AtikTextPrimary
                        )
                    }
                    Spacer(modifier = Modifier.width(4.dp))
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(
                                Brush.linearGradient(
                                    colors = listOf(AtikElectricBlue, AtikNeonCyan)
                                )
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Public,
                            contentDescription = "Web & News Hub",
                            tint = Color.White,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = "Smart Search & News Hub",
                            color = AtikTextPrimary,
                            fontSize = 17.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Live Web Grounding & Breaking Feeds",
                            color = AtikNeonAzure,
                            fontSize = 11.5.sp
                        )
                    }
                }

                IconButton(
                    onClick = onRefreshNews,
                    enabled = !isRefreshingNews,
                    modifier = Modifier.testTag("btn_refresh_news")
                ) {
                    if (isRefreshingNews) {
                        CircularProgressIndicator(modifier = Modifier.size(20.dp), color = AtikNeonCyan, strokeWidth = 2.dp)
                    } else {
                        Icon(Icons.Default.Refresh, contentDescription = "Refresh", tint = AtikNeonCyan)
                    }
                }
            }
        }

        // Section 1: Live Web Search Bar
        item {
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = AtikSurface),
                border = BorderStroke(1.dp, AtikBorder),
                modifier = Modifier.fillMaxWidth().testTag("card_web_search")
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = "Live Internet Search & Grounding",
                        color = AtikTextPrimary,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedTextField(
                        value = searchQuery,
                        onValueChange = { searchQuery = it },
                        placeholder = { Text("Search live facts, current events, or topics...", fontSize = 12.sp, color = AtikTextMuted) },
                        leadingIcon = {
                            Icon(Icons.Default.Search, contentDescription = null, tint = AtikNeonCyan, modifier = Modifier.size(18.dp))
                        },
                        trailingIcon = {
                            if (searchQuery.isNotEmpty()) {
                                IconButton(onClick = { searchQuery = "" }) {
                                    Icon(Icons.Default.Close, contentDescription = "Clear", tint = AtikTextMuted, modifier = Modifier.size(16.dp))
                                }
                            }
                        },
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = AtikNeonCyan,
                            unfocusedBorderColor = AtikBorder
                        ),
                        modifier = Modifier.fillMaxWidth().testTag("input_web_search")
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    // Trending suggestions chips
                    val trendingQueries = listOf(
                        "Latest AI model updates",
                        "Quantum computing breakthroughs",
                        "Global markets today",
                        "Space exploration milestones"
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        trendingQueries.forEach { query ->
                            Surface(
                                onClick = {
                                    searchQuery = query
                                    onSearch(query)
                                },
                                shape = RoundedCornerShape(8.dp),
                                color = AtikSurfaceVariant,
                                border = BorderStroke(0.6.dp, AtikBorder),
                                modifier = Modifier.testTag("chip_trending_${query.take(10)}")
                            ) {
                                Text(
                                    text = "🔍 $query",
                                    color = AtikTextSecondary,
                                    fontSize = 10.5.sp,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp)
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Button(
                        onClick = {
                            if (searchQuery.isNotBlank()) onSearch(searchQuery)
                        },
                        enabled = searchQuery.isNotBlank() && !isSearching,
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = AtikElectricBlue),
                        modifier = Modifier.fillMaxWidth().height(42.dp).testTag("btn_execute_web_search")
                    ) {
                        if (isSearching) {
                            CircularProgressIndicator(modifier = Modifier.size(16.dp), color = Color.White, strokeWidth = 2.dp)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Searching Internet...", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        } else {
                            Icon(Icons.Default.Search, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Search Live Web", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        // Live Search Results Card
        if (searchAnswer != null) {
            item {
                Card(
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = AtikSurfaceVariant),
                    border = BorderStroke(1.dp, AtikNeonCyan.copy(alpha = 0.5f)),
                    modifier = Modifier.fillMaxWidth().testTag("card_search_results")
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = "Search Synthesis",
                                    color = AtikNeonCyan,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "• ${searchAnswer.latencyMs}ms",
                                    color = AtikTextMuted,
                                    fontSize = 10.5.sp
                                )
                            }

                            Row {
                                IconButton(
                                    onClick = {
                                        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                        clipboard.setPrimaryClip(ClipData.newPlainText("Search Answer", searchAnswer.directAnswer))
                                        Toast.makeText(context, "Search answer copied", Toast.LENGTH_SHORT).show()
                                    },
                                    modifier = Modifier.size(30.dp)
                                ) {
                                    Icon(Icons.Default.ContentCopy, null, tint = AtikTextMuted, modifier = Modifier.size(15.dp))
                                }
                                IconButton(
                                    onClick = {
                                        onSendToChat("Discuss search result for \"${searchAnswer.query}\":\n\n${searchAnswer.directAnswer}")
                                    },
                                    modifier = Modifier.size(30.dp)
                                ) {
                                    Icon(Icons.Default.ChatBubbleOutline, null, tint = AtikNeonAzure, modifier = Modifier.size(15.dp))
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = searchAnswer.directAnswer,
                            color = AtikTextPrimary,
                            fontSize = 13.sp,
                            lineHeight = 18.sp
                        )

                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "Verified Sources & Citations",
                            color = AtikTextSecondary,
                            fontSize = 11.5.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                        Spacer(modifier = Modifier.height(6.dp))

                        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            searchAnswer.sources.take(3).forEach { src ->
                                Surface(
                                    onClick = {
                                        try {
                                            val browserIntent = Intent(Intent.ACTION_VIEW, Uri.parse(src.url))
                                            context.startActivity(browserIntent)
                                        } catch (_: Exception) {
                                            Toast.makeText(context, "Could not open URL", Toast.LENGTH_SHORT).show()
                                        }
                                    },
                                    shape = RoundedCornerShape(8.dp),
                                    color = AtikSurface,
                                    border = BorderStroke(0.6.dp, AtikBorder),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Row(
                                        modifier = Modifier.padding(8.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(
                                                text = src.title,
                                                color = AtikNeonAzure,
                                                fontSize = 11.5.sp,
                                                fontWeight = FontWeight.SemiBold,
                                                maxLines = 1,
                                                overflow = TextOverflow.Ellipsis
                                            )
                                            Text(
                                                text = src.source,
                                                color = AtikTextMuted,
                                                fontSize = 10.sp
                                            )
                                        }
                                        Icon(Icons.Default.OpenInNew, null, tint = AtikNeonCyan, modifier = Modifier.size(14.dp))
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // Section 2: Web Article Summarizer Accordion
        item {
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = AtikSurface),
                border = BorderStroke(1.dp, AtikBorder),
                modifier = Modifier.fillMaxWidth().testTag("card_article_summarizer")
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Summarize, contentDescription = null, tint = AtikNeonAzure, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text(
                                    text = "Web Article Summarizer",
                                    color = AtikTextPrimary,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "Extract key takeaways from any URL",
                                    color = AtikTextMuted,
                                    fontSize = 10.5.sp
                                )
                            }
                        }

                        Button(
                            onClick = { showSummarizerPanel = !showSummarizerPanel },
                            colors = ButtonDefaults.buttonColors(containerColor = AtikSurfaceVariant),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.height(32.dp).testTag("btn_toggle_summarizer_panel")
                        ) {
                            Text(
                                text = if (showSummarizerPanel) "Collapse" else "Open Tool",
                                color = AtikNeonCyan,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    AnimatedVisibility(visible = showSummarizerPanel) {
                        Column(modifier = Modifier.padding(top = 12.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                OutlinedTextField(
                                    value = urlToSummarize,
                                    onValueChange = { urlToSummarize = it },
                                    placeholder = { Text("https://example.com/article...", fontSize = 11.sp, color = AtikTextMuted) },
                                    singleLine = true,
                                    leadingIcon = { Icon(Icons.Default.Link, null, tint = AtikNeonCyan, modifier = Modifier.size(16.dp)) },
                                    colors = OutlinedTextFieldDefaults.colors(
                                        focusedBorderColor = AtikNeonCyan,
                                        unfocusedBorderColor = AtikBorder
                                    ),
                                    modifier = Modifier.weight(1f).testTag("input_summarize_url")
                                )

                                Spacer(modifier = Modifier.width(6.dp))

                                IconButton(
                                    onClick = {
                                        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                        val item = clipboard.primaryClip?.getItemAt(0)?.text?.toString().orEmpty()
                                        if (item.startsWith("http")) {
                                            urlToSummarize = item
                                        } else {
                                            Toast.makeText(context, "No valid URL on clipboard", Toast.LENGTH_SHORT).show()
                                        }
                                    },
                                    modifier = Modifier
                                        .size(48.dp)
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(AtikSurfaceVariant)
                                        .testTag("btn_paste_url")
                                ) {
                                    Icon(Icons.Default.ContentPaste, contentDescription = "Paste", tint = AtikNeonCyan, modifier = Modifier.size(18.dp))
                                }
                            }

                            Spacer(modifier = Modifier.height(10.dp))

                            Button(
                                onClick = {
                                    if (urlToSummarize.isNotBlank()) onSummarizeUrl(urlToSummarize)
                                },
                                enabled = urlToSummarize.isNotBlank() && !isSummarizing,
                                shape = RoundedCornerShape(10.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = AtikElectricBlue),
                                modifier = Modifier.fillMaxWidth().height(40.dp).testTag("btn_summarize_url_action")
                            ) {
                                if (isSummarizing) {
                                    CircularProgressIndicator(modifier = Modifier.size(16.dp), color = Color.White, strokeWidth = 2.dp)
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Extracting & Summarizing...", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                } else {
                                    Icon(Icons.Default.Summarize, null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Summarize Article", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            }
        }

        // Article Summary Result Card
        if (articleSummary != null) {
            item {
                Card(
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = AtikSurfaceVariant),
                    border = BorderStroke(1.dp, AtikNeonAzure.copy(alpha = 0.5f)),
                    modifier = Modifier.fillMaxWidth().testTag("card_article_summary_result")
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Surface(
                                shape = RoundedCornerShape(6.dp),
                                color = AtikNeonCyan.copy(alpha = 0.15f),
                                border = BorderStroke(0.6.dp, AtikNeonCyan)
                            ) {
                                Text(
                                    text = articleSummary.domain,
                                    color = AtikNeonCyan,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }

                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = "${articleSummary.readingTime} • ${articleSummary.sentiment}",
                                    color = AtikTextMuted,
                                    fontSize = 10.sp
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                IconButton(
                                    onClick = {
                                        val fullText = "${articleSummary.title}\n\nExecutive Summary:\n${articleSummary.executiveSummary}\n\nKey Takeaways:\n" +
                                                articleSummary.keyTakeaways.joinToString("\n") { "• $it" }
                                        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                        clipboard.setPrimaryClip(ClipData.newPlainText("Summary", fullText))
                                        Toast.makeText(context, "Summary copied to clipboard", Toast.LENGTH_SHORT).show()
                                    },
                                    modifier = Modifier.size(28.dp)
                                ) {
                                    Icon(Icons.Default.ContentCopy, null, tint = AtikTextMuted, modifier = Modifier.size(14.dp))
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = articleSummary.title,
                            color = AtikTextPrimary,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold
                        )

                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = articleSummary.executiveSummary,
                            color = AtikTextSecondary,
                            fontSize = 12.sp,
                            lineHeight = 17.sp
                        )

                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = "Key Takeaways:",
                            color = AtikNeonAzure,
                            fontSize = 11.5.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(4.dp))

                        articleSummary.keyTakeaways.forEach { takeaway ->
                            Row(
                                modifier = Modifier.padding(vertical = 2.dp),
                                verticalAlignment = Alignment.Top
                            ) {
                                Icon(Icons.Default.CheckCircle, null, tint = AtikSuccess, modifier = Modifier.size(13.dp).padding(top = 2.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(takeaway, color = AtikTextPrimary, fontSize = 11.5.sp, lineHeight = 16.sp)
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        Button(
                            onClick = {
                                onSendToChat("Let's analyze this article:\nTitle: ${articleSummary.title}\nSummary: ${articleSummary.executiveSummary}")
                            },
                            shape = RoundedCornerShape(8.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = AtikSurfaceHighlight),
                            modifier = Modifier.fillMaxWidth().height(36.dp)
                        ) {
                            Icon(Icons.Default.ChatBubbleOutline, null, tint = AtikNeonCyan, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Discuss in Chat with Atik", color = AtikNeonCyan, fontSize = 11.5.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        // Section 3: News Aggregator Hub & Category Filter
        item {
            Column {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Breaking News Feeds",
                        color = AtikTextPrimary,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "${filteredArticles.size} articles",
                        color = AtikTextMuted,
                        fontSize = 11.sp
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Category Chips
                Row(
                    modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    NewsCategory.values().forEach { cat ->
                        val isSelected = selectedCategory == cat
                        FilterChip(
                            selected = isSelected,
                            onClick = { onSelectCategory(cat) },
                            label = { Text("${cat.emoji} ${cat.displayName}", fontSize = 11.sp) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = AtikElectricBlue.copy(alpha = 0.35f),
                                selectedLabelColor = AtikNeonCyan
                            ),
                            border = BorderStroke(0.8.dp, if (isSelected) AtikNeonCyan else AtikBorder),
                            modifier = Modifier.testTag("news_cat_${cat.name}")
                        )
                    }
                }
            }
        }

        // Article Items
        items(filteredArticles, key = { it.id }) { article ->
            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = AtikSurface),
                border = BorderStroke(1.dp, AtikBorder),
                modifier = Modifier.fillMaxWidth().testTag("news_article_${article.id}")
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    // Top Metadata
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Surface(
                                shape = RoundedCornerShape(6.dp),
                                color = AtikSurfaceVariant,
                                border = BorderStroke(0.6.dp, AtikBorder)
                            ) {
                                Text(
                                    text = article.source,
                                    color = AtikNeonCyan,
                                    fontSize = 10.5.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "• ${article.publishedTime}",
                                color = AtikTextMuted,
                                fontSize = 10.5.sp
                            )
                        }

                        IconButton(
                            onClick = { onToggleBookmark(article.id) },
                            modifier = Modifier.size(28.dp).testTag("btn_bookmark_${article.id}")
                        ) {
                            Icon(
                                imageVector = if (article.isBookmarked) Icons.Default.Bookmark else Icons.Default.BookmarkBorder,
                                contentDescription = "Bookmark",
                                tint = if (article.isBookmarked) AtikNeonCyan else AtikTextMuted,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    Text(
                        text = article.title,
                        color = AtikTextPrimary,
                        fontSize = 13.5.sp,
                        fontWeight = FontWeight.Bold,
                        lineHeight = 18.sp
                    )

                    Spacer(modifier = Modifier.height(4.dp))

                    Text(
                        text = article.summary,
                        color = AtikTextSecondary,
                        fontSize = 11.5.sp,
                        lineHeight = 16.sp,
                        maxLines = 3,
                        overflow = TextOverflow.Ellipsis
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    // Tags
                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(4.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        article.tags.forEach { tag ->
                            Text(
                                text = "#$tag",
                                color = AtikTextMuted,
                                fontSize = 9.5.sp
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Actions Row
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Summarize
                        Surface(
                            onClick = {
                                urlToSummarize = article.sourceUrl
                                showSummarizerPanel = true
                                onSummarizeUrl(article.sourceUrl)
                            },
                            shape = RoundedCornerShape(8.dp),
                            color = AtikSurfaceVariant,
                            border = BorderStroke(0.6.dp, AtikBorder),
                            modifier = Modifier.weight(1f).testTag("btn_quick_summarize_${article.id}")
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                                horizontalArrangement = Arrangement.Center,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(Icons.Default.Summarize, null, tint = AtikNeonAzure, modifier = Modifier.size(13.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Summarize", color = AtikTextPrimary, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                            }
                        }

                        // Discuss in Chat
                        Surface(
                            onClick = {
                                onSendToChat("Let's discuss this breaking story:\n\nTitle: ${article.title}\nSource: ${article.source}\nSummary: ${article.summary}")
                            },
                            shape = RoundedCornerShape(8.dp),
                            color = AtikSurfaceVariant,
                            border = BorderStroke(0.6.dp, AtikBorder),
                            modifier = Modifier.weight(1f).testTag("btn_quick_discuss_${article.id}")
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                                horizontalArrangement = Arrangement.Center,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(Icons.Default.ChatBubbleOutline, null, tint = AtikNeonCyan, modifier = Modifier.size(13.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Chat", color = AtikTextPrimary, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                            }
                        }

                        // Open in browser
                        Surface(
                            onClick = {
                                try {
                                    val browserIntent = Intent(Intent.ACTION_VIEW, Uri.parse(article.sourceUrl))
                                    context.startActivity(browserIntent)
                                } catch (_: Exception) {
                                    Toast.makeText(context, "Cannot open URL", Toast.LENGTH_SHORT).show()
                                }
                            },
                            shape = RoundedCornerShape(8.dp),
                            color = AtikSurfaceVariant,
                            border = BorderStroke(0.6.dp, AtikBorder),
                            modifier = Modifier.size(32.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(Icons.Default.OpenInNew, null, tint = AtikTextMuted, modifier = Modifier.size(14.dp))
                            }
                        }
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(30.dp))
        }
    }
}
