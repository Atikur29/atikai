package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val AtikBlack = Color(0xFF07080C)
val AtikSurface = Color(0xFF10131D)
val AtikSurfaceVariant = Color(0xFF161C2C)
val AtikSurfaceHighlight = Color(0xFF1D2439)
val AtikBorder = Color(0xFF232D45)

val AtikElectricBlue = Color(0xFF2563EB)
val AtikNeonCyan = Color(0xFF00E5FF)
val AtikNeonAzure = Color(0xFF38BDF8)
val AtikCobalt = Color(0xFF1D4ED8)

val AtikTextPrimary = Color(0xFFF8FAFC)
val AtikTextSecondary = Color(0xFF94A3B8)
val AtikTextMuted = Color(0xFF64748B)

val AtikUserBubble = Color(0xFF1E293B)
val AtikAiBubble = Color(0xFF111624)
val AtikCodeBg = Color(0xFF0A0E18)
val AtikSuccess = Color(0xFF10B981)
val AtikWarning = Color(0xFFF59E0B)
val AtikError = Color(0xFFEF4444)

// Semantic Theme Accents
val AtikAmber = Color(0xFFF59E0B)
val AtikEmerald = Color(0xFF10B981)
val AtikDanger = Color(0xFFEF4444)
val AtikBlue = Color(0xFF2563EB)
val AtikPurple = Color(0xFFA855F7)
val AtikBackground = Color(0xFF07080C)
val AtikCardBackground = Color(0xFF161C2C)

// Futuristic Light Mode Colors
val AtikLightBackground = Color(0xFFF1F5F9)
val AtikLightSurface = Color(0xFFFFFFFF)
val AtikLightSurfaceVariant = Color(0xFFE2E8F0)
val AtikLightSurfaceHighlight = Color(0xFFF8FAFC)
val AtikLightBorder = Color(0xFFCBD5E1)
val AtikLightTextPrimary = Color(0xFF0F172A)
val AtikLightTextSecondary = Color(0xFF475569)
val AtikLightTextMuted = Color(0xFF64748B)
val AtikLightElectricBlue = Color(0xFF0284C7)
val AtikLightNeonCyan = Color(0xFF0EA5E9)
