package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.Gamepad
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.SportsEsports
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.GameProjectEntity
import com.example.data.GameScoreEntity
import com.example.game.GameTemplateType
import com.example.ui.components.GamePlayerCanvas
import com.example.ui.theme.AtikBorder
import com.example.ui.theme.AtikElectricBlue
import com.example.ui.theme.AtikNeonAzure
import com.example.ui.theme.AtikNeonCyan
import com.example.ui.theme.AtikSurface
import com.example.ui.theme.AtikSurfaceHighlight
import com.example.ui.theme.AtikSurfaceVariant
import com.example.ui.theme.AtikTextMuted
import com.example.ui.theme.AtikTextPrimary
import com.example.ui.theme.AtikTextSecondary
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * AI-Powered In-App Game Generator & 2D Arcade Studio (Step 26 Requirements 1, 2, 3, 4).
 */
@Composable
fun GameStudioScreen(
    games: List<GameProjectEntity>,
    recentScores: List<GameScoreEntity>,
    isGenerating: Boolean,
    onGenerateGame: (prompt: String) -> Unit,
    onDeleteGame: (id: String) -> Unit,
    onScoreLogged: (gameId: String, score: Int, durationSeconds: Int) -> Unit,
    onSaveState: (gameId: String, stateJson: String) -> Unit,
    onStartVoiceInput: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    var promptInput by remember { mutableStateOf("") }
    var activeGame by remember { mutableStateOf<GameProjectEntity?>(null) }
    var selectedTab by remember { mutableStateOf(0) } // 0: Library & Generator, 1: High Scores
    val dateFormatter = remember { SimpleDateFormat("MMM d, h:mm a", Locale.getDefault()) }

    // If a game is active, render the dedicated Game Player Canvas (Requirement 3)
    if (activeGame != null) {
        GamePlayerCanvas(
            game = activeGame!!,
            onClose = { activeGame = null },
            onScoreLogged = { score, duration ->
                onScoreLogged(activeGame!!.id, score, duration)
            },
            onSaveState = { stateJson ->
                onSaveState(activeGame!!.id, stateJson)
            }
        )
        return
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFF070B14))
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 16.dp, bottom = 96.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // 1. Studio Header Banner
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("game_studio_header_card"),
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = AtikSurface),
                border = BorderStroke(1.dp, AtikNeonCyan.copy(alpha = 0.5f))
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Surface(
                                shape = CircleShape,
                                color = AtikNeonCyan.copy(alpha = 0.15f),
                                modifier = Modifier.size(42.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(
                                        imageVector = Icons.Default.SportsEsports,
                                        contentDescription = null,
                                        tint = AtikNeonCyan,
                                        modifier = Modifier.size(24.dp)
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(
                                    text = "AI 2D Game Studio",
                                    color = AtikTextPrimary,
                                    fontSize = 17.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "HTML5 Canvas • 60 FPS • Room DB Scores",
                                    color = AtikNeonCyan,
                                    fontSize = 11.sp
                                )
                            }
                        }

                        Surface(
                            shape = RoundedCornerShape(99.dp),
                            color = AtikSurfaceHighlight,
                            border = BorderStroke(1.dp, AtikBorder)
                        ) {
                            Text(
                                text = "${games.size} Games",
                                color = AtikTextSecondary,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Text(
                        text = "Describe any 2D arcade, board, or racing game in English or Bangla. Atik AI will synthesize the HTML5 canvas logic, touch controls, sound synthesis, and high score tracking!",
                        color = AtikTextMuted,
                        fontSize = 12.sp,
                        lineHeight = 17.sp
                    )
                }
            }
        }

        // 2. AI Game Crafter Input Bar
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("game_generator_crafter_card"),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = AtikSurfaceVariant),
                border = BorderStroke(1.dp, AtikBorder)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = AtikNeonCyan, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Craft Game from Prompt",
                            color = AtikTextPrimary,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    OutlinedTextField(
                        value = promptInput,
                        onValueChange = { promptInput = it },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("input_game_prompt"),
                        placeholder = {
                            Text("e.g. 'লুডু গেম বানাও', 'High speed neon car racer', 'Flappy bird space drone'...", color = AtikTextMuted, fontSize = 12.sp)
                        },
                        trailingIcon = {
                            IconButton(onClick = onStartVoiceInput) {
                                Icon(Icons.Default.Mic, contentDescription = "Voice Dictation", tint = AtikNeonCyan)
                            }
                        },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = AtikNeonCyan,
                            unfocusedBorderColor = AtikBorder,
                            focusedTextColor = AtikTextPrimary,
                            unfocusedTextColor = AtikTextPrimary
                        ),
                        shape = RoundedCornerShape(12.dp)
                    )

                    Button(
                        onClick = {
                            if (promptInput.isNotBlank()) {
                                onGenerateGame(promptInput)
                                promptInput = ""
                            }
                        },
                        enabled = promptInput.isNotBlank() && !isGenerating,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("btn_generate_game"),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = AtikElectricBlue,
                            contentColor = Color.White
                        ),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        if (isGenerating) {
                            CircularProgressIndicator(modifier = Modifier.size(18.dp), color = Color.White, strokeWidth = 2.dp)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Synthesizing Game Logic...", fontWeight = FontWeight.Bold)
                        } else {
                            Icon(Icons.Default.Gamepad, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Generate & Launch Game", fontWeight = FontWeight.Bold)
                        }
                    }

                    // Quick 1-Tap Template Chips (Requirement 2)
                    Text(
                        text = "Instant Pre-built Archetypes:",
                        color = AtikTextSecondary,
                        fontSize = 11.5.sp,
                        fontWeight = FontWeight.Medium
                    )

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        GameTemplateType.values().forEach { template ->
                            Surface(
                                onClick = { onGenerateGame(template.title) },
                                shape = RoundedCornerShape(10.dp),
                                color = AtikSurfaceHighlight,
                                border = BorderStroke(1.dp, AtikBorder),
                                modifier = Modifier.testTag("chip_template_${template.id}")
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(template.emoji, fontSize = 13.sp)
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = template.title,
                                        fontSize = 12.sp,
                                        color = AtikTextPrimary,
                                        fontWeight = FontWeight.Medium
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // 3. Tab Selector: [Game Library] | [High Scores]
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Surface(
                    onClick = { selectedTab = 0 },
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(12.dp),
                    color = if (selectedTab == 0) AtikSurfaceHighlight else AtikSurface,
                    border = BorderStroke(1.dp, if (selectedTab == 0) AtikNeonCyan else AtikBorder)
                ) {
                    Row(
                        modifier = Modifier.padding(vertical = 10.dp),
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.SportsEsports, contentDescription = null, tint = if (selectedTab == 0) AtikNeonCyan else AtikTextMuted, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Game Library (${games.size})",
                            color = if (selectedTab == 0) AtikNeonCyan else AtikTextMuted,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                Surface(
                    onClick = { selectedTab = 1 },
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(12.dp),
                    color = if (selectedTab == 1) AtikSurfaceHighlight else AtikSurface,
                    border = BorderStroke(1.dp, if (selectedTab == 1) AtikNeonCyan else AtikBorder)
                ) {
                    Row(
                        modifier = Modifier.padding(vertical = 10.dp),
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.EmojiEvents, contentDescription = null, tint = if (selectedTab == 1) Color(0xFFFFE600) else AtikTextMuted, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Leaderboard (${recentScores.size})",
                            color = if (selectedTab == 1) Color(0xFFFFE600) else AtikTextMuted,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }

        // 4. Content by Tab
        if (selectedTab == 0) {
            // Games List
            if (games.isEmpty()) {
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(containerColor = AtikSurface),
                        border = BorderStroke(1.dp, AtikBorder)
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(24.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text("🎮", fontSize = 36.sp)
                            Spacer(modifier = Modifier.height(8.dp))
                            Text("No games generated yet!", color = AtikTextPrimary, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                            Text("Tap any template above or type a prompt to craft your first 2D game.", color = AtikTextMuted, fontSize = 12.sp)
                        }
                    }
                }
            } else {
                items(games, key = { it.id }) { game ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("game_item_${game.id}"),
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(containerColor = AtikSurface),
                        border = BorderStroke(1.dp, AtikBorder)
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(14.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Surface(
                                        shape = RoundedCornerShape(10.dp),
                                        color = AtikSurfaceHighlight,
                                        modifier = Modifier.size(38.dp)
                                    ) {
                                        Box(contentAlignment = Alignment.Center) {
                                            Text(game.thumbnailEmoji, fontSize = 20.sp)
                                        }
                                    }
                                    Spacer(modifier = Modifier.width(10.dp))
                                    Column {
                                        Text(
                                            text = game.title,
                                            color = AtikTextPrimary,
                                            fontSize = 14.5.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                        Text(
                                            text = game.genre,
                                            color = AtikNeonCyan,
                                            fontSize = 11.sp
                                        )
                                    }
                                }

                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Surface(
                                        shape = RoundedCornerShape(8.dp),
                                        color = AtikSurfaceHighlight,
                                        border = BorderStroke(1.dp, AtikBorder)
                                    ) {
                                        Row(
                                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Icon(Icons.Default.EmojiEvents, contentDescription = null, tint = Color(0xFFFFE600), modifier = Modifier.size(13.dp))
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text(
                                                text = "${game.highScore}",
                                                color = Color(0xFFFFE600),
                                                fontSize = 11.5.sp,
                                                fontWeight = FontWeight.Bold
                                            )
                                        }
                                    }

                                    Spacer(modifier = Modifier.width(6.dp))

                                    IconButton(
                                        onClick = { onDeleteGame(game.id) },
                                        modifier = Modifier.size(32.dp)
                                    ) {
                                        Icon(Icons.Default.DeleteOutline, contentDescription = "Delete Game", tint = AtikTextMuted, modifier = Modifier.size(18.dp))
                                    }
                                }
                            }

                            if (game.prompt.isNotBlank()) {
                                Text(
                                    text = "Prompt: \"${game.prompt}\"",
                                    color = AtikTextMuted,
                                    fontSize = 11.sp,
                                    maxLines = 2
                                )
                            }

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "Played ${game.playCount} times",
                                    color = AtikTextSecondary,
                                    fontSize = 10.5.sp
                                )

                                Button(
                                    onClick = { activeGame = game },
                                    colors = ButtonDefaults.buttonColors(containerColor = AtikNeonCyan, contentColor = Color.Black),
                                    shape = RoundedCornerShape(10.dp),
                                    modifier = Modifier.testTag("btn_play_game_${game.id}")
                                ) {
                                    Icon(Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Play Now", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                }
                            }
                        }
                    }
                }
            }
        } else {
            // High Scores & Leaderboard List (Requirement 4)
            if (recentScores.isEmpty()) {
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(containerColor = AtikSurface),
                        border = BorderStroke(1.dp, AtikBorder)
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(24.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text("🏆", fontSize = 36.sp)
                            Spacer(modifier = Modifier.height(8.dp))
                            Text("No scores recorded yet", color = AtikTextPrimary, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                            Text("Play games to earn high scores and log them to the Room Database.", color = AtikTextMuted, fontSize = 12.sp)
                        }
                    }
                }
            } else {
                items(recentScores) { scoreItem ->
                    Surface(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        color = AtikSurface,
                        border = BorderStroke(1.dp, AtikBorder)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 14.dp, vertical = 10.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Surface(
                                    shape = CircleShape,
                                    color = Color(0xFFFFE600).copy(alpha = 0.2f),
                                    modifier = Modifier.size(34.dp)
                                ) {
                                    Box(contentAlignment = Alignment.Center) {
                                        Text("🏆", fontSize = 16.sp)
                                    }
                                }
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Text(
                                        text = scoreItem.playerName,
                                        color = AtikTextPrimary,
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = dateFormatter.format(Date(scoreItem.timestamp)),
                                        color = AtikTextMuted,
                                        fontSize = 10.5.sp
                                    )
                                }
                            }

                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = AtikSurfaceHighlight,
                                border = BorderStroke(1.dp, Color(0xFFFFE600))
                            ) {
                                Text(
                                    text = "${scoreItem.score} PTS",
                                    color = Color(0xFFFFE600),
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
