package com.example.ui.screens

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.Camera
import androidx.camera.core.CameraControl
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.ImageProxy
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.CenterFocusStrong
import androidx.compose.material.icons.filled.ChatBubbleOutline
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.FlashOff
import androidx.compose.material.icons.filled.FlashOn
import androidx.compose.material.icons.filled.FlipCameraAndroid
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.OpenInBrowser
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.TextFields
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import com.example.ai.OcrResult
import com.example.ai.QrBarcodeResult
import com.example.ai.VisionAiAnalysisResult
import com.example.ai.VisionAiPreset
import com.example.ai.VisionScanMode
import com.example.ui.theme.AtikBlack
import com.example.ui.theme.AtikBorder
import com.example.ui.theme.AtikElectricBlue
import com.example.ui.theme.AtikNeonAzure
import com.example.ui.theme.AtikNeonCyan
import com.example.ui.theme.AtikSurface
import com.example.ui.theme.AtikSurfaceHighlight
import com.example.ui.theme.AtikSurfaceVariant
import com.example.ui.theme.AtikTextMuted
import com.example.ui.theme.AtikTextPrimary
import com.example.ui.theme.AtikTextSecondary
import kotlinx.coroutines.launch
import java.nio.ByteBuffer
import java.util.concurrent.Executors

@Composable
fun VisionScreen(
    scanMode: VisionScanMode,
    activePreset: VisionAiPreset,
    qrResult: QrBarcodeResult?,
    ocrResult: OcrResult?,
    aiResult: VisionAiAnalysisResult?,
    isAnalyzing: Boolean,
    statusMessage: String?,
    onSetMode: (VisionScanMode) -> Unit,
    onSetPreset: (VisionAiPreset) -> Unit,
    onQrDetected: (QrBarcodeResult) -> Unit,
    onOcrDetected: (OcrResult) -> Unit,
    onCaptureImage: (Bitmap) -> Unit,
    onSelectGalleryImage: (Bitmap) -> Unit,
    onClearResults: () -> Unit,
    onSendToChat: (prompt: String) -> Unit,
    onSpeakText: (String) -> Unit,
    onClose: (() -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val coroutineScope = rememberCoroutineScope()

    var hasCameraPermission by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
        )
    }

    val cameraPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        hasCameraPermission = granted
    }

    // Camera controls
    var lensFacing by remember { mutableIntStateOf(CameraSelector.LENS_FACING_BACK) }
    var isTorchOn by remember { mutableStateOf(false) }
    var cameraControl: CameraControl? by remember { mutableStateOf(null) }
    var imageCapture: ImageCapture? by remember { mutableStateOf(null) }

    // Android Photo Picker
    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        if (uri != null) {
            try {
                context.contentResolver.openInputStream(uri)?.use { stream ->
                    val bitmap = BitmapFactory.decodeStream(stream)
                    if (bitmap != null) {
                        onSelectGalleryImage(bitmap)
                    }
                }
            } catch (e: Exception) {
                Toast.makeText(context, "Failed to load image: ${e.message}", Toast.LENGTH_SHORT).show()
            }
        }
    }

    // Laser scanning animation for Barcode & OCR
    val infiniteTransition = rememberInfiniteTransition(label = "laser_transition")
    val laserProgress by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(2200, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "laser_pos"
    )

    // Pulse animation for AI reticle
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 0.95f,
        targetValue = 1.05f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse_scale"
    )

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(AtikBlack)
    ) {
        if (!hasCameraPermission) {
            // Close / Exit button if requested
            if (onClose != null) {
                IconButton(
                    onClick = onClose,
                    modifier = Modifier
                        .statusBarsPadding()
                        .padding(16.dp)
                        .align(Alignment.TopStart)
                        .size(40.dp)
                        .clip(CircleShape)
                        .background(AtikSurfaceHighlight)
                        .border(1.dp, AtikBorder, CircleShape)
                        .testTag("vision_permission_close_btn")
                ) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "Close Vision",
                        tint = Color.White,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }

            // Permission Fallback Screen
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Box(
                    modifier = Modifier
                        .size(80.dp)
                        .clip(CircleShape)
                        .background(AtikSurfaceHighlight)
                        .border(1.5.dp, AtikNeonCyan, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.CameraAlt,
                        contentDescription = "Camera Permission",
                        tint = AtikNeonCyan,
                        modifier = Modifier.size(36.dp)
                    )
                }

                Spacer(modifier = Modifier.height(20.dp))

                Text(
                    text = "Camera Permission Required",
                    color = AtikTextPrimary,
                    fontSize = 19.sp,
                    fontWeight = FontWeight.Bold
                )

                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    text = "Atik AI Vision requires camera access to perform live object inspection, high-speed QR/Barcode scanning, and document OCR.",
                    color = AtikTextSecondary,
                    fontSize = 13.5.sp,
                    textAlign = TextAlign.Center,
                    lineHeight = 20.sp,
                    modifier = Modifier.padding(horizontal = 16.dp)
                )

                Spacer(modifier = Modifier.height(24.dp))

                Button(
                    onClick = { cameraPermissionLauncher.launch(Manifest.permission.CAMERA) },
                    colors = ButtonDefaults.buttonColors(containerColor = AtikElectricBlue),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth(0.75f)
                        .height(48.dp)
                        .testTag("vision_grant_camera_permission_btn")
                ) {
                    Icon(imageVector = Icons.Default.CameraAlt, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Grant Camera Access", fontWeight = FontWeight.Bold)
                }

                Spacer(modifier = Modifier.height(12.dp))

                OutlinedButton(
                    onClick = {
                        photoPickerLauncher.launch(
                            PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                        )
                    },
                    border = BorderStroke(1.dp, AtikBorder),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth(0.75f)
                        .height(48.dp)
                        .testTag("vision_upload_gallery_fallback_btn")
                ) {
                    Icon(imageVector = Icons.Default.Image, contentDescription = null, tint = AtikNeonCyan, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Upload Photo From Gallery", color = AtikTextPrimary)
                }
            }
        } else {
            // Live Camera Viewfinder using CameraX
            AndroidView(
                factory = { ctx ->
                    val previewView = PreviewView(ctx).apply {
                        scaleType = PreviewView.ScaleType.FILL_CENTER
                    }
                    val cameraProviderFuture = ProcessCameraProvider.getInstance(ctx)
                    val analysisExecutor = Executors.newSingleThreadExecutor()

                    cameraProviderFuture.addListener({
                        val cameraProvider = cameraProviderFuture.get()

                        val preview = Preview.Builder().build().also {
                            it.setSurfaceProvider(previewView.surfaceProvider)
                        }

                        imageCapture = ImageCapture.Builder()
                            .setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY)
                            .build()

                        val imageAnalysis = ImageAnalysis.Builder()
                            .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                            .build()

                        // Wire up real-time scanner analyzer
                        var lastScanTimestamp = 0L
                        imageAnalysis.setAnalyzer(analysisExecutor) { imageProxy ->
                            val now = System.currentTimeMillis()
                            // Rate limit scanning to once every 350ms to save CPU
                            if (now - lastScanTimestamp > 350L) {
                                lastScanTimestamp = now
                                if (scanMode == VisionScanMode.QR_BARCODE && qrResult == null) {
                                    com.example.ai.VisionScannerEngine(ctx).scanBarcodeFromProxy(
                                        imageProxy = imageProxy,
                                        onSuccess = { res ->
                                            ContextCompat.getMainExecutor(ctx).execute {
                                                onQrDetected(res)
                                            }
                                        }
                                    )
                                } else {
                                    imageProxy.close()
                                }
                            } else {
                                imageProxy.close()
                            }
                        }

                        val cameraSelector = CameraSelector.Builder()
                            .requireLensFacing(lensFacing)
                            .build()

                        try {
                            cameraProvider.unbindAll()
                            val camera: Camera = cameraProvider.bindToLifecycle(
                                lifecycleOwner,
                                cameraSelector,
                                preview,
                                imageCapture,
                                imageAnalysis
                            )
                            cameraControl = camera.cameraControl
                            cameraControl?.enableTorch(isTorchOn)
                        } catch (e: Exception) {
                            // Binding error
                        }
                    }, ContextCompat.getMainExecutor(ctx))

                    previewView
                },
                update = {
                    cameraControl?.enableTorch(isTorchOn)
                },
                modifier = Modifier.fillMaxSize()
            )

            // Scanning Reticle & HUD Overlay
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 24.dp, vertical = 72.dp),
                contentAlignment = Alignment.Center
            ) {
                when (scanMode) {
                    VisionScanMode.QR_BARCODE -> {
                        // Square QR Target Box with Laser Scanline
                        Box(
                            modifier = Modifier
                                .size(260.dp)
                                .border(1.5.dp, AtikNeonCyan.copy(alpha = 0.6f), RoundedCornerShape(18.dp))
                        ) {
                            Canvas(modifier = Modifier.fillMaxSize()) {
                                val w = size.width
                                val h = size.height
                                val cornerLen = 32.dp.toPx()
                                val strokeWidth = 3.5.dp.toPx()
                                val cornerColor = Color(0xFF00E5FF)

                                // Top-Left
                                drawLine(cornerColor, Offset(0f, 0f), Offset(cornerLen, 0f), strokeWidth)
                                drawLine(cornerColor, Offset(0f, 0f), Offset(0f, cornerLen), strokeWidth)
                                // Top-Right
                                drawLine(cornerColor, Offset(w, 0f), Offset(w - cornerLen, 0f), strokeWidth)
                                drawLine(cornerColor, Offset(w, 0f), Offset(w, cornerLen), strokeWidth)
                                // Bottom-Left
                                drawLine(cornerColor, Offset(0f, h), Offset(cornerLen, h), strokeWidth)
                                drawLine(cornerColor, Offset(0f, h), Offset(0f, h - cornerLen), strokeWidth)
                                // Bottom-Right
                                drawLine(cornerColor, Offset(w, h), Offset(w - cornerLen, h), strokeWidth)
                                drawLine(cornerColor, Offset(w, h), Offset(w, h - cornerLen), strokeWidth)

                                // Moving laser scanning line
                                val laserY = h * laserProgress
                                drawLine(
                                    color = Color(0xFF00E5FF),
                                    start = Offset(8.dp.toPx(), laserY),
                                    end = Offset(w - 8.dp.toPx(), laserY),
                                    strokeWidth = 2.5.dp.toPx()
                                )
                            }

                            // Subtitle inside viewfinder
                            Text(
                                text = "ALIGN QR / BARCODE",
                                color = AtikNeonCyan,
                                fontSize = 10.5.sp,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 1.sp,
                                modifier = Modifier
                                    .align(Alignment.BottomCenter)
                                    .padding(bottom = 12.dp)
                            )
                        }
                    }

                    VisionScanMode.OCR_TEXT -> {
                        // Document Framing Box
                        Box(
                            modifier = Modifier
                                .fillMaxWidth(0.92f)
                                .height(320.dp)
                                .border(1.5.dp, Color(0xFF7C4DFF).copy(alpha = 0.6f), RoundedCornerShape(16.dp))
                        ) {
                            Canvas(modifier = Modifier.fillMaxSize()) {
                                val w = size.width
                                val h = size.height
                                val laserY = h * laserProgress
                                drawLine(
                                    color = Color(0xFFB388FF),
                                    start = Offset(12.dp.toPx(), laserY),
                                    end = Offset(w - 12.dp.toPx(), laserY),
                                    strokeWidth = 2.dp.toPx()
                                )
                            }

                            Text(
                                text = "POINT AT TEXT OR DOCUMENT",
                                color = Color(0xFFB388FF),
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 1.sp,
                                modifier = Modifier
                                    .align(Alignment.BottomCenter)
                                    .padding(bottom = 12.dp)
                            )
                        }
                    }

                    VisionScanMode.OBJECT_AI -> {
                        // Futuristic AI Target Reticle
                        Box(
                            modifier = Modifier
                                .size((250 * pulseScale).dp)
                                .border(1.2.dp, AtikNeonCyan.copy(alpha = 0.5f), CircleShape)
                        ) {
                            Canvas(modifier = Modifier.fillMaxSize()) {
                                val center = Offset(size.width / 2, size.height / 2)
                                val radius = size.width / 2
                                drawCircle(
                                    color = Color(0xFF00E5FF).copy(alpha = 0.08f),
                                    radius = radius
                                )
                                // Crosshairs
                                drawLine(
                                    color = Color(0xFF00E5FF).copy(alpha = 0.7f),
                                    start = Offset(center.x - 20.dp.toPx(), center.y),
                                    end = Offset(center.x + 20.dp.toPx(), center.y),
                                    strokeWidth = 1.5.dp.toPx()
                                )
                                drawLine(
                                    color = Color(0xFF00E5FF).copy(alpha = 0.7f),
                                    start = Offset(center.x, center.y - 20.dp.toPx()),
                                    end = Offset(center.x, center.y + 20.dp.toPx()),
                                    strokeWidth = 1.5.dp.toPx()
                                )
                            }

                            Text(
                                text = activePreset.label.uppercase(),
                                color = AtikNeonCyan,
                                fontSize = 10.5.sp,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 1.2.sp,
                                modifier = Modifier
                                    .align(Alignment.BottomCenter)
                                    .padding(bottom = 16.dp)
                            )
                        }
                    }
                }
            }

            // Top Control Overlay: Modes & Quick Settings
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .align(Alignment.TopCenter)
                    .statusBarsPadding()
                    .padding(horizontal = 14.dp, vertical = 8.dp)
            ) {
                // Top Action Bar
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        if (onClose != null) {
                            IconButton(
                                onClick = onClose,
                                modifier = Modifier
                                    .size(38.dp)
                                    .clip(CircleShape)
                                    .background(AtikSurface.copy(alpha = 0.85f))
                                    .border(0.8.dp, AtikBorder, CircleShape)
                                    .testTag("vision_close_btn")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Close,
                                    contentDescription = "Close Vision",
                                    tint = Color.White,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(8.dp))
                        }

                        // Title Badge
                        Surface(
                            color = AtikSurface.copy(alpha = 0.85f),
                            shape = RoundedCornerShape(12.dp),
                            border = BorderStroke(0.8.dp, AtikBorder)
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Default.CenterFocusStrong,
                                    contentDescription = null,
                                    tint = AtikNeonCyan,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "ATIK VISION AI",
                                    color = AtikTextPrimary,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    letterSpacing = 0.5.sp
                                )
                            }
                        }
                    }

                    // Torch & Lens Switching Controls
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(
                            onClick = {
                                isTorchOn = !isTorchOn
                                cameraControl?.enableTorch(isTorchOn)
                            },
                            modifier = Modifier
                                .size(38.dp)
                                .clip(CircleShape)
                                .background(if (isTorchOn) AtikNeonCyan else AtikSurface.copy(alpha = 0.85f))
                                .border(0.8.dp, AtikBorder, CircleShape)
                                .testTag("vision_toggle_torch_btn")
                        ) {
                            Icon(
                                imageVector = if (isTorchOn) Icons.Default.FlashOn else Icons.Default.FlashOff,
                                contentDescription = "Toggle Torch",
                                tint = if (isTorchOn) AtikBlack else Color.White,
                                modifier = Modifier.size(18.dp)
                            )
                        }

                        Spacer(modifier = Modifier.width(8.dp))

                        IconButton(
                            onClick = {
                                lensFacing = if (lensFacing == CameraSelector.LENS_FACING_BACK) {
                                    CameraSelector.LENS_FACING_FRONT
                                } else {
                                    CameraSelector.LENS_FACING_BACK
                                }
                            },
                            modifier = Modifier
                                .size(38.dp)
                                .clip(CircleShape)
                                .background(AtikSurface.copy(alpha = 0.85f))
                                .border(0.8.dp, AtikBorder, CircleShape)
                                .testTag("vision_switch_camera_btn")
                        ) {
                            Icon(
                                imageVector = Icons.Default.FlipCameraAndroid,
                                contentDescription = "Switch Camera",
                                tint = Color.White,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Mode Selector Bar (AI Vision, QR & Barcode, OCR Text)
                Surface(
                    color = AtikSurface.copy(alpha = 0.88f),
                    shape = RoundedCornerShape(16.dp),
                    border = BorderStroke(0.8.dp, AtikBorder),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(4.dp),
                        horizontalArrangement = Arrangement.SpaceEvenly
                    ) {
                        VisionScanMode.values().forEach { mode ->
                            val isSelected = scanMode == mode
                            val modeIcon = when (mode) {
                                VisionScanMode.OBJECT_AI -> Icons.Default.AutoAwesome
                                VisionScanMode.QR_BARCODE -> Icons.Default.QrCodeScanner
                                VisionScanMode.OCR_TEXT -> Icons.Default.TextFields
                            }
                            val modeLabel = when (mode) {
                                VisionScanMode.OBJECT_AI -> "AI Vision"
                                VisionScanMode.QR_BARCODE -> "QR / Barcode"
                                VisionScanMode.OCR_TEXT -> "OCR Text"
                            }

                            Surface(
                                onClick = { onSetMode(mode) },
                                shape = RoundedCornerShape(12.dp),
                                color = if (isSelected) AtikNeonAzure.copy(alpha = 0.25f) else Color.Transparent,
                                border = if (isSelected) BorderStroke(1.dp, AtikNeonCyan) else null,
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("vision_mode_${mode.name}")
                            ) {
                                Row(
                                    modifier = Modifier.padding(vertical = 8.dp),
                                    horizontalArrangement = Arrangement.Center,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        imageVector = modeIcon,
                                        contentDescription = null,
                                        tint = if (isSelected) AtikNeonCyan else AtikTextMuted,
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Spacer(modifier = Modifier.width(5.dp))
                                    Text(
                                        text = modeLabel,
                                        color = if (isSelected) AtikTextPrimary else AtikTextMuted,
                                        fontSize = 11.5.sp,
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                                    )
                                }
                            }
                        }
                    }
                }

                // Preset Chips for AI Vision Mode
                if (scanMode == VisionScanMode.OBJECT_AI) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        VisionAiPreset.values().forEach { preset ->
                            val isPresetSelected = activePreset == preset
                            Surface(
                                onClick = { onSetPreset(preset) },
                                shape = RoundedCornerShape(10.dp),
                                color = if (isPresetSelected) AtikElectricBlue.copy(alpha = 0.3f) else AtikSurface.copy(alpha = 0.8f),
                                border = BorderStroke(
                                    0.8.dp,
                                    if (isPresetSelected) AtikNeonCyan else AtikBorder
                                ),
                                modifier = Modifier.testTag("preset_${preset.name}")
                            ) {
                                Text(
                                    text = preset.label,
                                    color = if (isPresetSelected) AtikNeonCyan else AtikTextSecondary,
                                    fontSize = 11.sp,
                                    fontWeight = if (isPresetSelected) FontWeight.Bold else FontWeight.Normal,
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                                )
                            }
                        }
                    }
                }
            }

            // Bottom Shutter & Gallery Controls
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .align(Alignment.BottomCenter)
                    .navigationBarsPadding()
                    .padding(bottom = 18.dp, start = 20.dp, end = 20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Status message indicator
                if (isAnalyzing || !statusMessage.isNullOrBlank()) {
                    Surface(
                        color = AtikSurface.copy(alpha = 0.9f),
                        shape = RoundedCornerShape(14.dp),
                        border = BorderStroke(0.8.dp, AtikBorder),
                        modifier = Modifier
                            .fillMaxWidth(0.85f)
                            .padding(bottom = 12.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.Center
                        ) {
                            if (isAnalyzing) {
                                CircularProgressIndicator(
                                    color = AtikNeonCyan,
                                    modifier = Modifier.size(16.dp),
                                    strokeWidth = 2.dp
                                )
                                Spacer(modifier = Modifier.width(10.dp))
                            }
                            Text(
                                text = statusMessage ?: "Processing image...",
                                color = AtikTextPrimary,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }
                }

                // Shutter Bar
                Row(
                    modifier = Modifier.fillMaxWidth(0.9f),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Upload Photo from Gallery
                    IconButton(
                        onClick = {
                            photoPickerLauncher.launch(
                                PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                            )
                        },
                        modifier = Modifier
                            .size(50.dp)
                            .clip(CircleShape)
                            .background(AtikSurface.copy(alpha = 0.85f))
                            .border(1.dp, AtikBorder, CircleShape)
                            .testTag("vision_pick_gallery_image_btn")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Image,
                            contentDescription = "Upload from Gallery",
                            tint = AtikNeonCyan,
                            modifier = Modifier.size(24.dp)
                        )
                    }

                    // Main Shutter / Capture Button
                    Box(
                        modifier = Modifier
                            .size(76.dp)
                            .clip(CircleShape)
                            .background(
                                Brush.radialGradient(
                                    listOf(AtikElectricBlue, AtikNeonAzure)
                                )
                            )
                            .border(3.dp, Color.White.copy(alpha = 0.8f), CircleShape)
                            .clickable {
                                imageCapture?.let { cap ->
                                    cap.takePicture(
                                        ContextCompat.getMainExecutor(context),
                                        object : ImageCapture.OnImageCapturedCallback() {
                                            override fun onCaptureSuccess(image: ImageProxy) {
                                                val bitmap = imageProxyToBitmap(image)
                                                image.close()
                                                if (bitmap != null) {
                                                    onCaptureImage(bitmap)
                                                }
                                            }

                                            override fun onError(exception: ImageCaptureException) {
                                                Toast.makeText(context, "Capture failed: ${exception.message}", Toast.LENGTH_SHORT).show()
                                            }
                                        }
                                    )
                                }
                            }
                            .testTag("vision_shutter_capture_btn"),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = when (scanMode) {
                                VisionScanMode.OBJECT_AI -> Icons.Default.AutoAwesome
                                VisionScanMode.QR_BARCODE -> Icons.Default.QrCodeScanner
                                VisionScanMode.OCR_TEXT -> Icons.Default.TextFields
                            },
                            contentDescription = "Capture & Scan",
                            tint = Color.White,
                            modifier = Modifier.size(32.dp)
                        )
                    }

                    // Clear / Reset Button
                    IconButton(
                        onClick = { onClearResults() },
                        modifier = Modifier
                            .size(50.dp)
                            .clip(CircleShape)
                            .background(AtikSurface.copy(alpha = 0.85f))
                            .border(1.dp, AtikBorder, CircleShape)
                            .testTag("vision_clear_results_btn")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Refresh,
                            contentDescription = "Reset Vision",
                            tint = AtikTextMuted,
                            modifier = Modifier.size(22.dp)
                        )
                    }
                }
            }
        }

        // ================= RESULT PANELS / MODALS =================

        // 1. QR Code / Barcode Result Bottom Sheet
        AnimatedVisibility(
            visible = qrResult != null,
            enter = slideInVertically(initialOffsetY = { it }) + fadeIn(),
            exit = slideOutVertically(targetOffsetY = { it }) + fadeOut(),
            modifier = Modifier.align(Alignment.BottomCenter)
        ) {
            qrResult?.let { qr ->
                Surface(
                    color = AtikSurfaceVariant,
                    shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp),
                    border = BorderStroke(1.dp, AtikNeonCyan.copy(alpha = 0.8f)),
                    modifier = Modifier
                        .fillMaxWidth()
                        .navigationBarsPadding()
                        .testTag("qr_result_panel")
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(18.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Surface(
                                    color = AtikNeonCyan.copy(alpha = 0.2f),
                                    shape = RoundedCornerShape(8.dp),
                                    border = BorderStroke(0.8.dp, AtikNeonCyan)
                                ) {
                                    Text(
                                        text = qr.format.uppercase(),
                                        color = AtikNeonCyan,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = qr.valueType,
                                    color = AtikTextSecondary,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Medium
                                )
                            }

                            IconButton(onClick = { onClearResults() }, modifier = Modifier.size(28.dp)) {
                                Icon(Icons.Default.Close, contentDescription = "Close", tint = AtikTextMuted, modifier = Modifier.size(18.dp))
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        // Extracted Value Box
                        Surface(
                            color = AtikSurface,
                            shape = RoundedCornerShape(12.dp),
                            border = BorderStroke(0.8.dp, AtikBorder),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Text(
                                    text = "SCANNED CONTENT",
                                    color = AtikTextMuted,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    letterSpacing = 0.8.sp
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = qr.rawValue,
                                    color = AtikTextPrimary,
                                    fontSize = 14.sp,
                                    fontFamily = FontFamily.Monospace,
                                    maxLines = 4,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        // Action Buttons
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            // Copy Button
                            OutlinedButton(
                                onClick = {
                                    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                    clipboard.setPrimaryClip(ClipData.newPlainText("Barcode", qr.rawValue))
                                    Toast.makeText(context, "Copied to clipboard!", Toast.LENGTH_SHORT).show()
                                },
                                shape = RoundedCornerShape(12.dp),
                                border = BorderStroke(1.dp, AtikBorder),
                                modifier = Modifier
                                    .weight(1f)
                                    .height(44.dp)
                                    .testTag("qr_copy_btn")
                            ) {
                                Icon(Icons.Default.ContentCopy, contentDescription = null, tint = AtikNeonCyan, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Copy", color = AtikTextPrimary, fontSize = 12.sp)
                            }

                            // If URL: Open in Browser
                            if (qr.isUrl) {
                                Button(
                                    onClick = {
                                        try {
                                            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(qr.rawValue))
                                            context.startActivity(intent)
                                        } catch (e: Exception) {
                                            Toast.makeText(context, "Cannot open link: ${e.message}", Toast.LENGTH_SHORT).show()
                                        }
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = AtikElectricBlue),
                                    shape = RoundedCornerShape(12.dp),
                                    modifier = Modifier
                                        .weight(1.2f)
                                        .height(44.dp)
                                        .testTag("qr_open_link_btn")
                                ) {
                                    Icon(Icons.Default.OpenInBrowser, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Open Link", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                }
                            }

                            // Ask Atik AI in Chat
                            Button(
                                onClick = {
                                    onSendToChat("Please explain and inspect this scanned ${qr.format} code: ${qr.rawValue}")
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = AtikNeonAzure),
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier
                                    .weight(1.2f)
                                    .height(44.dp)
                                    .testTag("qr_ask_ai_btn")
                            ) {
                                Icon(Icons.Default.ChatBubbleOutline, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Ask Atik AI", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            }
                        }
                    }
                }
            }
        }

        // 2. OCR Text Result Bottom Sheet
        AnimatedVisibility(
            visible = ocrResult != null,
            enter = slideInVertically(initialOffsetY = { it }) + fadeIn(),
            exit = slideOutVertically(targetOffsetY = { it }) + fadeOut(),
            modifier = Modifier.align(Alignment.BottomCenter)
        ) {
            ocrResult?.let { ocr ->
                Surface(
                    color = AtikSurfaceVariant,
                    shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp),
                    border = BorderStroke(1.dp, Color(0xFF7C4DFF)),
                    modifier = Modifier
                        .fillMaxWidth()
                        .navigationBarsPadding()
                        .testTag("ocr_result_panel")
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(18.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = "OPTICAL CHARACTER RECOGNITION",
                                    color = Color(0xFFB388FF),
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    letterSpacing = 0.8.sp
                                )
                                Text(
                                    text = "${ocr.lineCount} lines • ${ocr.blockCount} blocks detected",
                                    color = AtikTextMuted,
                                    fontSize = 11.5.sp
                                )
                            }

                            IconButton(onClick = { onClearResults() }, modifier = Modifier.size(28.dp)) {
                                Icon(Icons.Default.Close, contentDescription = "Close", tint = AtikTextMuted, modifier = Modifier.size(18.dp))
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        // Extracted Text Box (Scrollable)
                        Surface(
                            color = AtikSurface,
                            shape = RoundedCornerShape(12.dp),
                            border = BorderStroke(0.8.dp, AtikBorder),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(160.dp)
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .padding(12.dp)
                                    .verticalScroll(rememberScrollState())
                            ) {
                                Text(
                                    text = ocr.fullText,
                                    color = AtikTextPrimary,
                                    fontSize = 13.5.sp,
                                    lineHeight = 20.sp
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        // Action Buttons: Single-Tap "Copy Text", "Ask AI", "Share"
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            // Primary Single-Tap "Copy Text" Action
                            Button(
                                onClick = {
                                    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                    clipboard.setPrimaryClip(ClipData.newPlainText("OCR Text", ocr.fullText))
                                    Toast.makeText(context, "Text copied to clipboard!", Toast.LENGTH_SHORT).show()
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF7C4DFF)),
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier
                                    .weight(1.3f)
                                    .height(44.dp)
                                    .testTag("ocr_copy_text_btn")
                            ) {
                                Icon(Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Copy Text", fontWeight = FontWeight.Bold, fontSize = 12.5.sp)
                            }

                            // Share Text
                            OutlinedButton(
                                onClick = {
                                    val shareIntent = Intent(Intent.ACTION_SEND).apply {
                                        type = "text/plain"
                                        putExtra(Intent.EXTRA_TEXT, ocr.fullText)
                                    }
                                    context.startActivity(Intent.createChooser(shareIntent, "Share Extracted Text"))
                                },
                                shape = RoundedCornerShape(12.dp),
                                border = BorderStroke(1.dp, AtikBorder),
                                modifier = Modifier
                                    .weight(1f)
                                    .height(44.dp)
                                    .testTag("ocr_share_text_btn")
                            ) {
                                Icon(Icons.Default.Share, contentDescription = null, tint = AtikTextSecondary, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Share", color = AtikTextPrimary, fontSize = 12.sp)
                            }

                            // Send to Atik AI Chat
                            Button(
                                onClick = {
                                    onSendToChat("Please analyze and explain the following extracted document text:\n\n${ocr.fullText}")
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = AtikElectricBlue),
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier
                                    .weight(1.2f)
                                    .height(44.dp)
                                    .testTag("ocr_send_to_ai_btn")
                            ) {
                                Icon(Icons.Default.AutoAwesome, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Ask AI", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            }
                        }
                    }
                }
            }
        }

        // 3. AI Vision Analysis Result Bottom Sheet
        AnimatedVisibility(
            visible = aiResult != null,
            enter = slideInVertically(initialOffsetY = { it }) + fadeIn(),
            exit = slideOutVertically(targetOffsetY = { it }) + fadeOut(),
            modifier = Modifier.align(Alignment.BottomCenter)
        ) {
            aiResult?.let { ai ->
                Surface(
                    color = AtikSurfaceVariant,
                    shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp),
                    border = BorderStroke(1.2.dp, AtikNeonCyan),
                    modifier = Modifier
                        .fillMaxWidth()
                        .navigationBarsPadding()
                        .testTag("vision_ai_result_panel")
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(18.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Surface(
                                    color = AtikNeonAzure.copy(alpha = 0.2f),
                                    shape = RoundedCornerShape(6.dp),
                                    border = BorderStroke(0.6.dp, AtikNeonAzure)
                                ) {
                                    Text(
                                        text = ai.category.uppercase(),
                                        color = AtikNeonCyan,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = ai.title,
                                    color = AtikTextPrimary,
                                    fontSize = 16.sp,
                                    fontWeight = FontWeight.Bold,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }

                            Row(verticalAlignment = Alignment.CenterVertically) {
                                // Speak Result Button
                                IconButton(
                                    onClick = { onSpeakText("${ai.title}. ${ai.summary}") },
                                    modifier = Modifier.size(32.dp)
                                ) {
                                    Icon(Icons.Default.VolumeUp, contentDescription = "Read aloud", tint = AtikNeonCyan, modifier = Modifier.size(18.dp))
                                }

                                IconButton(onClick = { onClearResults() }, modifier = Modifier.size(28.dp)) {
                                    Icon(Icons.Default.Close, contentDescription = "Close", tint = AtikTextMuted, modifier = Modifier.size(18.dp))
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        // Detailed Explanation Container
                        Surface(
                            color = AtikSurface,
                            shape = RoundedCornerShape(12.dp),
                            border = BorderStroke(0.8.dp, AtikBorder),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(200.dp)
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .padding(12.dp)
                                    .verticalScroll(rememberScrollState())
                            ) {
                                Text(
                                    text = ai.summary,
                                    color = AtikNeonAzure,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    lineHeight = 18.sp
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                HorizontalDivider(color = AtikBorder)
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = ai.explanation,
                                    color = AtikTextSecondary,
                                    fontSize = 13.sp,
                                    lineHeight = 19.sp
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        // Action Buttons: "Ask in Chat", "Copy Explanation"
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            OutlinedButton(
                                onClick = {
                                    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                    clipboard.setPrimaryClip(ClipData.newPlainText("AI Vision Analysis", ai.explanation))
                                    Toast.makeText(context, "Analysis copied to clipboard!", Toast.LENGTH_SHORT).show()
                                },
                                shape = RoundedCornerShape(12.dp),
                                border = BorderStroke(1.dp, AtikBorder),
                                modifier = Modifier
                                    .weight(1f)
                                    .height(44.dp)
                                    .testTag("vision_copy_ai_result_btn")
                            ) {
                                Icon(Icons.Default.ContentCopy, contentDescription = null, tint = AtikNeonCyan, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Copy", color = AtikTextPrimary, fontSize = 12.sp)
                            }

                            Button(
                                onClick = {
                                    onSendToChat("Regarding the image I just scanned (${ai.title}):\n\n${ai.summary}\n\nPlease elaborate further on this.")
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = AtikElectricBlue),
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier
                                    .weight(1.4f)
                                    .height(44.dp)
                                    .testTag("vision_continue_chat_btn")
                            ) {
                                Icon(Icons.Default.ChatBubbleOutline, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Continue in Chat", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            }
                        }
                    }
                }
            }
        }
    }
}

private fun imageProxyToBitmap(image: ImageProxy): Bitmap? {
    return try {
        image.toBitmap()
    } catch (e: Exception) {
        try {
            val planeProxy = image.planes[0]
            val buffer: ByteBuffer = planeProxy.buffer
            val bytes = ByteArray(buffer.remaining())
            buffer.get(bytes)
            val bitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.size) ?: return null

            val rotation = image.imageInfo.rotationDegrees
            if (rotation != 0) {
                val matrix = Matrix().apply { postRotate(rotation.toFloat()) }
                Bitmap.createBitmap(bitmap, 0, 0, bitmap.width, bitmap.height, matrix, true)
            } else {
                bitmap
            }
        } catch (e2: Exception) {
            null
        }
    }
}
