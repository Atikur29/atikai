package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.ChatBubbleOutline
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.Lightbulb
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.knowledge.GuideCategory
import com.example.knowledge.TechGuideTopic
import com.example.knowledge.TechKnowledgeEngine
import com.example.ui.theme.AtikBlack
import com.example.ui.theme.AtikBorder
import com.example.ui.theme.AtikElectricBlue
import com.example.ui.theme.AtikNeonAzure
import com.example.ui.theme.AtikNeonCyan
import com.example.ui.theme.AtikSuccess
import com.example.ui.theme.AtikSurface
import com.example.ui.theme.AtikSurfaceHighlight
import com.example.ui.theme.AtikSurfaceVariant
import com.example.ui.theme.AtikTextMuted
import com.example.ui.theme.AtikTextPrimary
import com.example.ui.theme.AtikTextSecondary

@Composable
fun TechGuidesScreen(
    onSendToChat: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    var searchQuery by remember { mutableStateOf("") }
    var selectedCategory by remember { mutableStateOf<GuideCategory?>(null) }
    var expandedTopicId by remember { mutableStateOf<String?>(TechKnowledgeEngine.CURATED_TOPICS.firstOrNull()?.id) }

    val filteredTopics = remember(searchQuery, selectedCategory) {
        val base = if (searchQuery.isBlank()) {
            TechKnowledgeEngine.CURATED_TOPICS
        } else {
            TechKnowledgeEngine.searchTopics(searchQuery)
        }
        if (selectedCategory == null) base else base.filter { it.category == selectedCategory }
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(AtikBlack)
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 12.dp, bottom = 96.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Hero Academy Header Card
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .shadow(12.dp, RoundedCornerShape(22.dp), spotColor = AtikNeonCyan),
                shape = RoundedCornerShape(22.dp),
                colors = CardDefaults.cardColors(containerColor = AtikSurface),
                border = BorderStroke(
                    1.dp,
                    Brush.linearGradient(listOf(AtikNeonCyan.copy(alpha = 0.6f), AtikElectricBlue.copy(alpha = 0.3f)))
                )
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Surface(
                            shape = CircleShape,
                            color = AtikSurfaceHighlight,
                            modifier = Modifier.size(46.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Text("🎓", fontSize = 24.sp)
                            }
                        }
                        Spacer(modifier = Modifier.width(14.dp))
                        Column {
                            Text(
                                text = "Earning & Tech Knowledge Hub",
                                color = AtikTextPrimary,
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "অনলাইন আয়, ফ্রিল্যান্সিং ও টেক গাইডলাইন",
                                color = AtikNeonAzure,
                                fontSize = 12.5.sp
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))
                    Text(
                        text = "আতিক এআই-এর বিশেষায়িত নলেজ বেস থেকে আন্তর্জাতিক মানের ফ্রিল্যান্সিং, আধুনিক মোবাইল অ্যাপ ডেভেলপমেন্ট ও এআই অটোমেশনের সুনির্দিষ্ট গাইডলাইন গ্রহণ করুন।",
                        color = AtikTextSecondary,
                        fontSize = 13.sp,
                        lineHeight = 19.sp
                    )
                }
            }
        }

        // Quick Suggestion Chips (Interactive Horizontally Scrollable)
        item {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    text = "QUICK SUGGESTION CHIPS",
                    color = AtikTextMuted,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp,
                    modifier = Modifier.padding(start = 4.dp)
                )

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    TechKnowledgeEngine.QUICK_SUGGESTION_CHIPS.forEach { chip ->
                        Surface(
                            onClick = { onSendToChat(chip.prompt) },
                            shape = RoundedCornerShape(20.dp),
                            color = AtikSurfaceVariant,
                            border = BorderStroke(1.dp, AtikBorder),
                            modifier = Modifier.testTag("tech_chip_${chip.id}")
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 14.dp, vertical = 9.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Text(chip.label, color = AtikTextPrimary, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                                Icon(
                                    imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                                    contentDescription = null,
                                    tint = AtikNeonCyan,
                                    modifier = Modifier.size(13.dp)
                                )
                            }
                        }
                    }
                }
            }
        }

        // Search Bar
        item {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("tech_guide_search_field"),
                placeholder = {
                    Text("Search guides (e.g., Earning, Kotlin, Upwork)...", color = AtikTextMuted, fontSize = 13.sp)
                },
                leadingIcon = {
                    Icon(Icons.Default.Search, contentDescription = "Search", tint = AtikTextMuted)
                },
                trailingIcon = {
                    if (searchQuery.isNotEmpty()) {
                        IconButton(onClick = { searchQuery = "" }) {
                            Icon(Icons.Default.Close, contentDescription = "Clear", tint = AtikTextMuted)
                        }
                    }
                },
                singleLine = true,
                shape = RoundedCornerShape(16.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = AtikNeonCyan,
                    unfocusedBorderColor = AtikBorder,
                    focusedContainerColor = AtikSurfaceVariant,
                    unfocusedContainerColor = AtikSurfaceVariant,
                    focusedTextColor = AtikTextPrimary,
                    unfocusedTextColor = AtikTextPrimary
                )
            )
        }

        // Category Filter Chips
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                FilterChip(
                    selected = selectedCategory == null,
                    onClick = { selectedCategory = null },
                    label = { Text("All Guides", fontSize = 12.sp) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = AtikNeonAzure.copy(alpha = 0.2f),
                        selectedLabelColor = AtikNeonCyan,
                        containerColor = AtikSurfaceVariant,
                        labelColor = AtikTextSecondary
                    ),
                    border = BorderStroke(1.dp, if (selectedCategory == null) AtikNeonCyan else AtikBorder)
                )

                GuideCategory.values().forEach { cat ->
                    val isSelected = selectedCategory == cat
                    FilterChip(
                        selected = isSelected,
                        onClick = { selectedCategory = if (isSelected) null else cat },
                        label = { Text(cat.label, fontSize = 12.sp) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = AtikNeonAzure.copy(alpha = 0.2f),
                            selectedLabelColor = AtikNeonCyan,
                            containerColor = AtikSurfaceVariant,
                            labelColor = AtikTextSecondary
                        ),
                        border = BorderStroke(1.dp, if (isSelected) AtikNeonCyan else AtikBorder)
                    )
                }
            }
        }

        // Guide Topic Cards
        items(filteredTopics, key = { it.id }) { topic ->
            val isExpanded = expandedTopicId == topic.id

            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(20.dp))
                    .clickable {
                        expandedTopicId = if (isExpanded) null else topic.id
                    }
                    .testTag("guide_card_${topic.id}"),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = AtikSurfaceVariant),
                border = BorderStroke(
                    1.dp,
                    if (isExpanded) AtikNeonCyan.copy(alpha = 0.7f) else AtikBorder
                )
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    // Header Row
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.weight(1f)
                        ) {
                            Text(topic.iconEmoji, fontSize = 26.sp)
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(
                                    text = topic.banglaTitle,
                                    color = AtikTextPrimary,
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = topic.title,
                                    color = AtikTextMuted,
                                    fontSize = 12.sp
                                )
                            }
                        }

                        IconButton(
                            onClick = { expandedTopicId = if (isExpanded) null else topic.id },
                            modifier = Modifier.size(32.dp)
                        ) {
                            Icon(
                                imageVector = if (isExpanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                                contentDescription = if (isExpanded) "Collapse" else "Expand",
                                tint = AtikNeonCyan
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Meta Row: difficulty & estimated time
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = AtikSurfaceHighlight
                        ) {
                            Text(
                                text = "⏱️ ${topic.estimatedTime}",
                                color = AtikTextSecondary,
                                fontSize = 11.sp,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                            )
                        }

                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = AtikSurfaceHighlight
                        ) {
                            Text(
                                text = "🎯 ${topic.difficulty}",
                                color = AtikNeonCyan,
                                fontSize = 11.sp,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = topic.subtitle,
                        color = AtikTextSecondary,
                        fontSize = 13.sp,
                        lineHeight = 18.sp
                    )

                    // Key Skills Tags
                    Spacer(modifier = Modifier.height(10.dp))
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        topic.keySkills.forEach { skill ->
                            Surface(
                                shape = RoundedCornerShape(6.dp),
                                color = AtikSurface,
                                border = BorderStroke(0.6.dp, AtikBorder)
                            ) {
                                Text(
                                    text = "#$skill",
                                    color = AtikTextMuted,
                                    fontSize = 11.sp,
                                    modifier = Modifier.padding(horizontal = 7.dp, vertical = 3.dp)
                                )
                            }
                        }
                    }

                    // Expandable Step-by-Step Action Roadmap
                    AnimatedVisibility(
                        visible = isExpanded,
                        enter = fadeIn() + expandVertically(),
                        exit = fadeOut() + shrinkVertically()
                    ) {
                        Column(modifier = Modifier.padding(top = 16.dp)) {
                            HorizontalDivider(color = AtikBorder, thickness = 0.8.dp)
                            Spacer(modifier = Modifier.height(12.dp))

                            Text(
                                text = "📌 ACTIONABLE STEP-BY-STEP CHECKLIST",
                                color = AtikNeonCyan,
                                fontSize = 11.5.sp,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 0.8.sp
                            )

                            Spacer(modifier = Modifier.height(8.dp))
                            topic.actionSteps.forEachIndexed { index, step ->
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 4.dp),
                                    verticalAlignment = Alignment.Top
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.CheckCircle,
                                        contentDescription = null,
                                        tint = AtikSuccess,
                                        modifier = Modifier
                                            .size(16.dp)
                                            .padding(top = 2.dp)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = "${index + 1}. $step",
                                        color = AtikTextPrimary,
                                        fontSize = 12.5.sp,
                                        lineHeight = 18.sp
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(14.dp))

                            // Sub-chips quick asks
                            Text(
                                text = "QUICK TOPIC QUESTIONS",
                                color = AtikTextMuted,
                                fontSize = 10.5.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .horizontalScroll(rememberScrollState()),
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                topic.subChips.forEach { subChip ->
                                    Surface(
                                        onClick = {
                                            onSendToChat("আতিক, '${topic.banglaTitle}'-এর অন্তর্গত '$subChip' বিষয়ে বাস্তব উদাহরণসহ বিস্তারিত পরামর্শ ও টিপস দাও।")
                                        },
                                        shape = RoundedCornerShape(12.dp),
                                        color = AtikSurfaceHighlight,
                                        border = BorderStroke(0.6.dp, AtikBorder)
                                    ) {
                                        Text(
                                            text = "💡 $subChip",
                                            color = AtikNeonAzure,
                                            fontSize = 11.5.sp,
                                            modifier = Modifier.padding(horizontal = 9.dp, vertical = 5.dp)
                                        )
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(16.dp))

                            // Launch in Chat Button
                            Button(
                                onClick = { onSendToChat(topic.promptQuery) },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("launch_guide_btn_${topic.id}"),
                                shape = RoundedCornerShape(14.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = AtikElectricBlue)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.ChatBubbleOutline,
                                    contentDescription = null,
                                    tint = Color.White,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "Ask Atik AI to Guide Me Step-by-Step",
                                    color = Color.White,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
