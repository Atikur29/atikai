package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.Crossfade
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CalendarToday
import androidx.compose.material.icons.filled.Campaign
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Insights
import androidx.compose.material.icons.filled.Lightbulb
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.QueryBuilder
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Tag
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.PostStatus
import com.example.data.SocialPlatform
import com.example.data.SocialPostEntity
import com.example.social.GeneratedSocialContent
import com.example.social.SocialMediaEngine
import com.example.ui.theme.AtikBlack
import com.example.ui.theme.AtikBorder
import com.example.ui.theme.AtikElectricBlue
import com.example.ui.theme.AtikError
import com.example.ui.theme.AtikNeonAzure
import com.example.ui.theme.AtikNeonCyan
import com.example.ui.theme.AtikSuccess
import com.example.ui.theme.AtikSurface
import com.example.ui.theme.AtikSurfaceHighlight
import com.example.ui.theme.AtikSurfaceVariant
import com.example.ui.theme.AtikTextMuted
import com.example.ui.theme.AtikTextPrimary
import com.example.ui.theme.AtikTextSecondary
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun SocialSchedulerScreen(
    posts: List<SocialPostEntity>,
    isGenerating: Boolean,
    generatedContent: GeneratedSocialContent?,
    socialEngine: SocialMediaEngine,
    onGenerateContent: (topic: String, platform: SocialPlatform, tone: String, audience: String) -> Unit,
    onSavePost: (post: SocialPostEntity) -> Unit,
    onUpdateStatus: (id: Long, status: String) -> Unit,
    onReschedulePost: (id: Long, newTime: Long) -> Unit,
    onDeletePost: (id: Long) -> Unit,
    onSendToChat: (prompt: String) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var selectedTab by remember { mutableIntStateOf(0) } // 0: Generator, 1: Scheduler & Queue, 2: Analytics & Growth
    var showCreateDialog by remember { mutableStateOf(false) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(AtikBlack)
    ) {
        // Top Header Banner
        Surface(
            color = AtikSurfaceVariant,
            border = BorderStroke(0.8.dp, AtikBorder),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(RoundedCornerShape(10.dp))
                                .background(AtikElectricBlue.copy(alpha = 0.25f))
                                .border(1.dp, AtikNeonCyan, RoundedCornerShape(10.dp)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Campaign,
                                contentDescription = null,
                                tint = AtikNeonCyan,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "Social Media AI Hub",
                                color = AtikTextPrimary,
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "Viral Content & Smart Scheduler Engine",
                                color = AtikTextMuted,
                                fontSize = 11.sp
                            )
                        }
                    }

                    // Quick Queue Action Button
                    Button(
                        onClick = { showCreateDialog = true },
                        colors = ButtonDefaults.buttonColors(containerColor = AtikElectricBlue),
                        shape = RoundedCornerShape(10.dp),
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                        modifier = Modifier
                            .height(34.dp)
                            .testTag("social_quick_new_post_btn")
                    ) {
                        Icon(imageVector = Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Queue Post", fontSize = 11.5.sp, fontWeight = FontWeight.Bold)
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Modern 3-Tab Selector
                TabRow(
                    selectedTabIndex = selectedTab,
                    containerColor = AtikSurface,
                    contentColor = AtikNeonCyan,
                    indicator = { tabPositions ->
                        TabRowDefaults.SecondaryIndicator(
                            modifier = Modifier.tabIndicatorOffset(tabPositions[selectedTab]),
                            color = AtikNeonCyan,
                            height = 2.5.dp
                        )
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(10.dp))
                ) {
                    Tab(
                        selected = selectedTab == 0,
                        onClick = { selectedTab = 0 },
                        text = {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.AutoAwesome, null, modifier = Modifier.size(15.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Content AI", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }
                        },
                        modifier = Modifier.testTag("social_tab_generator")
                    )
                    Tab(
                        selected = selectedTab == 1,
                        onClick = { selectedTab = 1 },
                        text = {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Schedule, null, modifier = Modifier.size(15.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Queue (${posts.count { it.status != "PUBLISHED" }})", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }
                        },
                        modifier = Modifier.testTag("social_tab_scheduler")
                    )
                    Tab(
                        selected = selectedTab == 2,
                        onClick = { selectedTab = 2 },
                        text = {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Insights, null, modifier = Modifier.size(15.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Growth Hub", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }
                        },
                        modifier = Modifier.testTag("social_tab_analytics")
                    )
                }
            }
        }

        // Active Tab Screen Content
        Crossfade(targetState = selectedTab, label = "social_tab_crossfade") { tab ->
            when (tab) {
                0 -> SocialContentGeneratorTab(
                    isGenerating = isGenerating,
                    generatedContent = generatedContent,
                    onGenerate = onGenerateContent,
                    onSaveToQueue = onSavePost,
                    onShare = { platform, text -> socialEngine.sharePost(context, platform, text) },
                    onSendToChat = onSendToChat
                )
                1 -> SocialSchedulerQueueTab(
                    posts = posts,
                    socialEngine = socialEngine,
                    onUpdateStatus = onUpdateStatus,
                    onReschedule = onReschedulePost,
                    onDelete = onDeletePost,
                    onShare = { platform, text -> socialEngine.sharePost(context, platform, text) },
                    onOpenCreateDialog = { showCreateDialog = true }
                )
                2 -> SocialAnalyticsGrowthTab(
                    socialEngine = socialEngine,
                    onSendToChat = onSendToChat
                )
            }
        }

        // Manual Create / Queue Post Dialog
        if (showCreateDialog) {
            ManualQueuePostDialog(
                socialEngine = socialEngine,
                onDismiss = { showCreateDialog = false },
                onSave = { post ->
                    onSavePost(post)
                    showCreateDialog = false
                    selectedTab = 1 // Switch to queue
                    Toast.makeText(context, "Post queued successfully!", Toast.LENGTH_SHORT).show()
                }
            )
        }
    }
}

/**
 * TAB 1: SOCIAL CONTENT GENERATOR
 */
@Composable
private fun SocialContentGeneratorTab(
    isGenerating: Boolean,
    generatedContent: GeneratedSocialContent?,
    onGenerate: (topic: String, platform: SocialPlatform, tone: String, audience: String) -> Unit,
    onSaveToQueue: (SocialPostEntity) -> Unit,
    onShare: (SocialPlatform, String) -> Unit,
    onSendToChat: (String) -> Unit
) {
    val context = LocalContext.current
    var topicInput by remember { mutableStateOf("") }
    var selectedPlatform by remember { mutableStateOf(SocialPlatform.ALL) }
    var selectedTone by remember { mutableStateOf("Viral & Engaging") }
    var selectedAudience by remember { mutableStateOf("Tech & Digital Creators") }

    val presetTopics = listOf(
        "Top 5 AI Automation Tools in 2026",
        "Python Coding Tip of the Day",
        "How to Earn from Home with AI",
        "Behind the Scenes Build Vlog",
        "New Feature Launch & Sneak Peek"
    )

    val tones = listOf("Viral & Engaging", "Educational & Informative", "Professional & Business", "Storytelling", "Hype & Launch")
    val audiences = listOf("Tech & Digital Creators", "Entrepreneurs & Freelancers", "General Audience", "Coders & Engineers")

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 14.dp, bottom = 80.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Platform Selection Row
        item {
            Column {
                Text(
                    text = "TARGET PLATFORM",
                    color = AtikNeonAzure,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 0.8.sp
                )
                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    SocialPlatform.values().forEach { platform ->
                        val isSelected = selectedPlatform == platform
                        Surface(
                            onClick = { selectedPlatform = platform },
                            shape = RoundedCornerShape(12.dp),
                            color = if (isSelected) Color(platform.primaryColorHex).copy(alpha = 0.25f) else AtikSurface,
                            border = BorderStroke(
                                if (isSelected) 1.2.dp else 0.8.dp,
                                if (isSelected) Color(platform.primaryColorHex) else AtikBorder
                            ),
                            modifier = Modifier.testTag("platform_chip_${platform.name.lowercase()}")
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(platform.iconEmoji, fontSize = 14.sp)
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = platform.displayName,
                                    color = if (isSelected) AtikTextPrimary else AtikTextSecondary,
                                    fontSize = 12.sp,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                                )
                            }
                        }
                    }
                }
            }
        }

        // Topic Input Card
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = AtikSurfaceVariant),
                border = BorderStroke(1.dp, AtikBorder),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = "POST TOPIC & INSPIRATION",
                        color = AtikTextMuted,
                        fontSize = 10.5.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 0.8.sp
                    )
                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedTextField(
                        value = topicInput,
                        onValueChange = { topicInput = it },
                        placeholder = { Text("e.g. 5 Game-Changing AI Tools for Developers in 2026...", color = AtikTextMuted, fontSize = 13.sp) },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = AtikNeonCyan,
                            unfocusedBorderColor = AtikBorder,
                            focusedTextColor = AtikTextPrimary,
                            unfocusedTextColor = AtikTextPrimary,
                            focusedContainerColor = AtikSurface,
                            unfocusedContainerColor = AtikSurface
                        ),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(88.dp)
                            .testTag("social_topic_input")
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    // Preset Quick Suggestions
                    Text("Quick Inspiration Presets:", color = AtikTextMuted, fontSize = 11.sp)
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        presetTopics.forEach { preset ->
                            Surface(
                                onClick = { topicInput = preset },
                                color = AtikSurface,
                                shape = RoundedCornerShape(8.dp),
                                border = BorderStroke(0.6.dp, AtikBorder)
                            ) {
                                Text(
                                    text = preset,
                                    color = AtikNeonAzure,
                                    fontSize = 11.sp,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Tone & Audience Row
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        // Tone Chip Bar
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Tone of Voice", color = AtikTextMuted, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            Spacer(modifier = Modifier.height(4.dp))
                            Surface(
                                color = AtikSurface,
                                shape = RoundedCornerShape(8.dp),
                                border = BorderStroke(0.8.dp, AtikBorder),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text(
                                    text = selectedTone,
                                    color = AtikTextPrimary,
                                    fontSize = 11.sp,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 7.dp)
                                )
                            }
                        }

                        // Audience Chip Bar
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Target Audience", color = AtikTextMuted, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            Spacer(modifier = Modifier.height(4.dp))
                            Surface(
                                color = AtikSurface,
                                shape = RoundedCornerShape(8.dp),
                                border = BorderStroke(0.8.dp, AtikBorder),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text(
                                    text = selectedAudience,
                                    color = AtikTextPrimary,
                                    fontSize = 11.sp,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 7.dp)
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Generate Button
                    Button(
                        onClick = {
                            val topic = topicInput.ifBlank { "Smart AI Automations for Modern Creators" }
                            onGenerate(topic, selectedPlatform, selectedTone, selectedAudience)
                        },
                        enabled = !isGenerating,
                        colors = ButtonDefaults.buttonColors(containerColor = AtikElectricBlue),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(46.dp)
                            .testTag("social_generate_btn")
                    ) {
                        if (isGenerating) {
                            CircularProgressIndicator(color = Color.White, modifier = Modifier.size(18.dp), strokeWidth = 2.dp)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Crafting Viral Copy with Atik AI…", fontWeight = FontWeight.Bold)
                        } else {
                            Icon(Icons.Default.AutoAwesome, null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Generate High-Converting Post", fontWeight = FontWeight.Bold, fontSize = 13.5.sp)
                        }
                    }
                }
            }
        }

        // Generated Output Card
        if (generatedContent != null) {
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = AtikSurfaceVariant),
                    border = BorderStroke(1.2.dp, AtikNeonCyan.copy(alpha = 0.8f)),
                    shape = RoundedCornerShape(18.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("social_generated_output_card")
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        // Card Header
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Surface(
                                    color = Color(generatedContent.platform.primaryColorHex).copy(alpha = 0.2f),
                                    shape = RoundedCornerShape(8.dp),
                                    border = BorderStroke(0.8.dp, Color(generatedContent.platform.primaryColorHex))
                                ) {
                                    Text(
                                        text = "${generatedContent.platform.iconEmoji} ${generatedContent.platform.displayName}",
                                        color = Color(generatedContent.platform.primaryColorHex),
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(8.dp))
                                Surface(
                                    color = AtikSuccess.copy(alpha = 0.15f),
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Text(
                                        text = "⚡ Viral Score: ${generatedContent.estimatedEngagementScore}%",
                                        color = AtikSuccess,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                                    )
                                }
                            }

                            // Quick Copy Full Post
                            IconButton(
                                onClick = {
                                    val clip = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                    clip.setPrimaryClip(ClipData.newPlainText("Social Post", generatedContent.fullFormattedPost))
                                    Toast.makeText(context, "Full post copied to clipboard!", Toast.LENGTH_SHORT).show()
                                },
                                modifier = Modifier.size(30.dp)
                            ) {
                                Icon(Icons.Default.ContentCopy, "Copy", tint = AtikNeonCyan, modifier = Modifier.size(18.dp))
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        // Hook Highlight Banner
                        Surface(
                            color = AtikSurfaceHighlight,
                            shape = RoundedCornerShape(10.dp),
                            border = BorderStroke(0.8.dp, AtikBorder),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(10.dp)) {
                                Text("ATTENTION HOOK (0–3s)", color = AtikNeonCyan, fontSize = 9.5.sp, fontWeight = FontWeight.Bold, letterSpacing = 0.8.sp)
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(generatedContent.hook, color = AtikTextPrimary, fontSize = 13.5.sp, fontWeight = FontWeight.Bold)
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        // Full Formatted Body Box
                        Surface(
                            color = AtikSurface,
                            shape = RoundedCornerShape(12.dp),
                            border = BorderStroke(0.8.dp, AtikBorder),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Text(
                                    text = generatedContent.caption,
                                    color = AtikTextPrimary,
                                    fontSize = 13.sp,
                                    lineHeight = 19.sp
                                )

                                Spacer(modifier = Modifier.height(10.dp))
                                HorizontalDivider(color = AtikBorder)
                                Spacer(modifier = Modifier.height(8.dp))

                                Text("CALL TO ACTION:", color = AtikTextMuted, fontSize = 9.5.sp, fontWeight = FontWeight.Bold)
                                Text(generatedContent.callToAction, color = AtikNeonAzure, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)

                                Spacer(modifier = Modifier.height(8.dp))

                                // Hashtag Flow
                                Text(
                                    text = generatedContent.hashtags.joinToString(" "),
                                    color = AtikNeonCyan,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Medium
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        // Optimal Timing Pill
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(horizontal = 4.dp)
                        ) {
                            Icon(Icons.Default.QueryBuilder, null, tint = AtikNeonAzure, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "Optimal Window: ${generatedContent.bestTimeRecommendation}",
                                color = AtikTextSecondary,
                                fontSize = 11.sp
                            )
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        // Action Buttons: Queue, Share, Send to Chat
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            // Queue Button
                            Button(
                                onClick = {
                                    val post = SocialPostEntity(
                                        platform = generatedContent.platform.name,
                                        title = generatedContent.hook.take(45),
                                        caption = generatedContent.caption + "\n\n" + generatedContent.callToAction,
                                        hashtags = generatedContent.hashtags.joinToString(" "),
                                        estimatedEngagementScore = generatedContent.estimatedEngagementScore,
                                        status = "QUEUED",
                                        scheduledTimeMillis = System.currentTimeMillis() + 3600000L * 3 // 3h later
                                    )
                                    onSaveToQueue(post)
                                    Toast.makeText(context, "Added to Post Queue!", Toast.LENGTH_SHORT).show()
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = AtikElectricBlue),
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier
                                    .weight(1.2f)
                                    .height(42.dp)
                                    .testTag("social_add_to_queue_btn")
                            ) {
                                Icon(Icons.Default.Schedule, null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Queue Post", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            }

                            // Share Now
                            OutlinedButton(
                                onClick = {
                                    onShare(generatedContent.platform, generatedContent.fullFormattedPost)
                                },
                                border = BorderStroke(1.dp, AtikBorder),
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier
                                    .weight(1f)
                                    .height(42.dp)
                                    .testTag("social_share_now_btn")
                            ) {
                                Icon(Icons.Default.Share, null, tint = AtikNeonCyan, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Share", color = AtikTextPrimary, fontSize = 12.sp)
                            }

                            // Ask AI to Refine in Chat
                            IconButton(
                                onClick = {
                                    onSendToChat("Please review and refine this social media post for ${generatedContent.platform.displayName}:\n\n${generatedContent.fullFormattedPost}")
                                },
                                modifier = Modifier
                                    .size(42.dp)
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(AtikSurface)
                                    .border(1.dp, AtikBorder, RoundedCornerShape(12.dp))
                                    .testTag("social_ask_chat_btn")
                            ) {
                                Icon(Icons.Default.AutoAwesome, "Refine in Chat", tint = AtikNeonCyan, modifier = Modifier.size(18.dp))
                            }
                        }
                    }
                }
            }
        }
    }
}

/**
 * TAB 2: POST SCHEDULER & QUEUE
 */
@Composable
private fun SocialSchedulerQueueTab(
    posts: List<SocialPostEntity>,
    socialEngine: SocialMediaEngine,
    onUpdateStatus: (id: Long, status: String) -> Unit,
    onReschedule: (id: Long, newTime: Long) -> Unit,
    onDelete: (id: Long) -> Unit,
    onShare: (SocialPlatform, String) -> Unit,
    onOpenCreateDialog: () -> Unit
) {
    val context = LocalContext.current
    val sdf = remember { SimpleDateFormat("EEE, MMM d • h:mm a", Locale.getDefault()) }
    var selectedFilter by remember { mutableStateOf("ALL") }

    val filteredPosts = when (selectedFilter) {
        "ALL" -> posts
        else -> posts.filter { it.platform.equals(selectedFilter, ignoreCase = true) }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 14.dp, bottom = 80.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Queue Metrics Summary
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = AtikSurfaceVariant),
                border = BorderStroke(1.dp, AtikBorder),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceAround,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    MetricCounter(label = "Queued", count = posts.count { it.status == "QUEUED" }, color = AtikNeonCyan)
                    MetricDivider()
                    MetricCounter(label = "Scheduled", count = posts.count { it.status == "SCHEDULED" }, color = AtikNeonAzure)
                    MetricDivider()
                    MetricCounter(label = "Published", count = posts.count { it.status == "PUBLISHED" }, color = AtikSuccess)
                }
            }
        }

        // Platform Filter Chips
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                listOf("ALL", "FACEBOOK", "INSTAGRAM", "TIKTOK", "TELEGRAM").forEach { filterTag ->
                    val isSelected = selectedFilter == filterTag
                    Surface(
                        onClick = { selectedFilter = filterTag },
                        shape = RoundedCornerShape(8.dp),
                        color = if (isSelected) AtikElectricBlue.copy(alpha = 0.3f) else AtikSurface,
                        border = BorderStroke(0.8.dp, if (isSelected) AtikNeonCyan else AtikBorder)
                    ) {
                        Text(
                            text = if (filterTag == "ALL") "All Queued" else filterTag,
                            color = if (isSelected) AtikNeonCyan else AtikTextMuted,
                            fontSize = 11.sp,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                        )
                    }
                }
            }
        }

        // Empty State or List of Posts
        if (filteredPosts.isEmpty()) {
            item {
                Surface(
                    color = AtikSurface,
                    shape = RoundedCornerShape(16.dp),
                    border = BorderStroke(1.dp, AtikBorder),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 24.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Box(
                            modifier = Modifier
                                .size(50.dp)
                                .clip(CircleShape)
                                .background(AtikSurfaceHighlight),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.CalendarToday, null, tint = AtikNeonCyan, modifier = Modifier.size(24.dp))
                        }
                        Spacer(modifier = Modifier.height(12.dp))
                        Text("No Posts in Queue", color = AtikTextPrimary, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            "Use the Content AI generator or tap 'Queue Post' to schedule your viral social media campaigns.",
                            color = AtikTextSecondary,
                            fontSize = 12.sp,
                            textAlign = TextAlign.Center
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        Button(
                            onClick = onOpenCreateDialog,
                            colors = ButtonDefaults.buttonColors(containerColor = AtikElectricBlue),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Icon(Icons.Default.Add, null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Create & Queue Post", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        } else {
            items(filteredPosts, key = { it.id }) { post ->
                val platformObj = SocialPlatform.fromId(post.platform)
                var showMenu by remember { mutableStateOf(false) }

                Card(
                    colors = CardDefaults.cardColors(containerColor = AtikSurfaceVariant),
                    border = BorderStroke(
                        0.8.dp,
                        if (post.status == "PUBLISHED") AtikSuccess.copy(alpha = 0.5f) else AtikBorder
                    ),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("post_card_${post.id}")
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        // Post Header Row
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Surface(
                                    color = Color(platformObj.primaryColorHex).copy(alpha = 0.2f),
                                    shape = RoundedCornerShape(6.dp)
                                ) {
                                    Text(
                                        text = "${platformObj.iconEmoji} ${platformObj.displayName}",
                                        color = Color(platformObj.primaryColorHex),
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(8.dp))
                                Surface(
                                    color = when (post.status) {
                                        "PUBLISHED" -> AtikSuccess.copy(alpha = 0.2f)
                                        "QUEUED" -> Color(0xFF7C4DFF).copy(alpha = 0.2f)
                                        else -> AtikNeonCyan.copy(alpha = 0.2f)
                                    },
                                    shape = RoundedCornerShape(6.dp)
                                ) {
                                    Text(
                                        text = post.status,
                                        color = when (post.status) {
                                            "PUBLISHED" -> AtikSuccess
                                            "QUEUED" -> Color(0xFFB388FF)
                                            else -> AtikNeonCyan
                                        },
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                            }

                            // Menu options
                            Box {
                                IconButton(onClick = { showMenu = true }, modifier = Modifier.size(28.dp)) {
                                    Icon(Icons.Default.MoreVert, "Options", tint = AtikTextMuted, modifier = Modifier.size(18.dp))
                                }
                                DropdownMenu(
                                    expanded = showMenu,
                                    onDismissRequest = { showMenu = false }
                                ) {
                                    DropdownMenuItem(
                                        text = { Text("Reschedule (+3 Hours)") },
                                        onClick = {
                                            onReschedule(post.id, post.scheduledTimeMillis + 3600000L * 3)
                                            showMenu = false
                                            Toast.makeText(context, "Rescheduled +3 hours", Toast.LENGTH_SHORT).show()
                                        }
                                    )
                                    DropdownMenuItem(
                                        text = { Text("Reschedule (Tomorrow)") },
                                        onClick = {
                                            onReschedule(post.id, post.scheduledTimeMillis + 86400000L)
                                            showMenu = false
                                            Toast.makeText(context, "Rescheduled to tomorrow", Toast.LENGTH_SHORT).show()
                                        }
                                    )
                                    DropdownMenuItem(
                                        text = { Text("Mark as Published") },
                                        onClick = {
                                            onUpdateStatus(post.id, "PUBLISHED")
                                            showMenu = false
                                        }
                                    )
                                    DropdownMenuItem(
                                        text = { Text("Delete Post", color = AtikError) },
                                        onClick = {
                                            onDelete(post.id)
                                            showMenu = false
                                        }
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        // Title / Hook
                        Text(
                            text = post.title,
                            color = AtikTextPrimary,
                            fontSize = 13.5.sp,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )

                        Spacer(modifier = Modifier.height(4.dp))

                        // Caption Preview
                        Text(
                            text = post.caption,
                            color = AtikTextSecondary,
                            fontSize = 12.sp,
                            maxLines = 3,
                            overflow = TextOverflow.Ellipsis,
                            lineHeight = 17.sp
                        )

                        if (post.hashtags.isNotBlank()) {
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = post.hashtags,
                                color = AtikNeonCyan,
                                fontSize = 11.sp,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }

                        Spacer(modifier = Modifier.height(10.dp))
                        HorizontalDivider(color = AtikBorder)
                        Spacer(modifier = Modifier.height(8.dp))

                        // Scheduled Time & Actions Row
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.QueryBuilder, null, tint = AtikNeonAzure, modifier = Modifier.size(13.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = sdf.format(Date(post.scheduledTimeMillis)),
                                    color = AtikTextMuted,
                                    fontSize = 11.sp
                                )
                            }

                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                // Copy
                                OutlinedButton(
                                    onClick = {
                                        val clip = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                        clip.setPrimaryClip(ClipData.newPlainText("Post", "${post.caption}\n\n${post.hashtags}"))
                                        Toast.makeText(context, "Copied post content!", Toast.LENGTH_SHORT).show()
                                    },
                                    shape = RoundedCornerShape(8.dp),
                                    border = BorderStroke(0.8.dp, AtikBorder),
                                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                                    modifier = Modifier.height(30.dp)
                                ) {
                                    Icon(Icons.Default.ContentCopy, null, tint = AtikTextSecondary, modifier = Modifier.size(12.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Copy", color = AtikTextPrimary, fontSize = 11.sp)
                                }

                                // Share / Post Now
                                Button(
                                    onClick = {
                                        onShare(platformObj, "${post.caption}\n\n${post.hashtags}")
                                        onUpdateStatus(post.id, "PUBLISHED")
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = AtikElectricBlue),
                                    shape = RoundedCornerShape(8.dp),
                                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                                    modifier = Modifier.height(30.dp)
                                ) {
                                    Icon(Icons.AutoMirrored.Filled.Send, null, modifier = Modifier.size(12.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Post Now", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

/**
 * TAB 3: MARKETING ANALYTICS & GROWTH DASHBOARD
 */
@Composable
private fun SocialAnalyticsGrowthTab(
    socialEngine: SocialMediaEngine,
    onSendToChat: (String) -> Unit
) {
    val context = LocalContext.current
    var testCaptionInput by remember {
        mutableStateOf("🚀 Big AI breakthrough in 2026! Here is how to automate 80% of your workflow without coding. Drop a comment below if you want the link!")
    }
    var testHashtagsInput by remember { mutableStateOf("#AI #Automation #TechTips #FutureOfWork #Productivity") }
    var selectedTestPlatform by remember { mutableStateOf(SocialPlatform.INSTAGRAM) }

    val estimation = remember(testCaptionInput, testHashtagsInput, selectedTestPlatform) {
        socialEngine.estimatePerformance(
            caption = testCaptionInput,
            hashtags = testHashtagsInput,
            platform = selectedTestPlatform,
            scheduledTimeMillis = System.currentTimeMillis()
        )
    }

    val trendingTags = remember { socialEngine.getTrendingHashtags() }
    val growthStrategies = remember { socialEngine.getGrowthStrategies() }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 14.dp, bottom = 80.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Performance Estimator Widget
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = AtikSurfaceVariant),
                border = BorderStroke(1.dp, AtikNeonCyan.copy(alpha = 0.5f)),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Speed, null, tint = AtikNeonCyan, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Post Performance Estimator", color = AtikTextPrimary, fontSize = 13.5.sp, fontWeight = FontWeight.Bold)
                        }

                        // Score Pill
                        Surface(
                            color = AtikElectricBlue.copy(alpha = 0.25f),
                            shape = RoundedCornerShape(8.dp),
                            border = BorderStroke(0.8.dp, AtikNeonCyan)
                        ) {
                            Text(
                                text = "Score: ${estimation.overallScore}/100",
                                color = AtikNeonCyan,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Progress bar
                    LinearProgressIndicator(
                        progress = { estimation.overallScore / 100f },
                        color = if (estimation.overallScore >= 85) AtikNeonCyan else AtikNeonAzure,
                        trackColor = AtikSurface,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(6.dp)
                            .clip(RoundedCornerShape(3.dp))
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    // 3 Metric Tiles
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        MetricTile("Readability", estimation.readabilityRating, Modifier.weight(1f))
                        MetricTile("Hook Strength", estimation.hookStrength, Modifier.weight(1f))
                        MetricTile("Hashtag Score", "${estimation.hashtagScore}%", Modifier.weight(1f))
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // AI Recommendations
                    Text("AI Audit Recommendations:", color = AtikTextMuted, fontSize = 10.5.sp, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(4.dp))
                    estimation.recommendations.forEach { rec ->
                        Row(modifier = Modifier.padding(vertical = 2.dp), verticalAlignment = Alignment.Top) {
                            Text("• ", color = AtikNeonCyan, fontSize = 12.sp)
                            Text(rec, color = AtikTextSecondary, fontSize = 11.5.sp, lineHeight = 16.sp)
                        }
                    }
                }
            }
        }

        // Trending Hashtags Cloud
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = AtikSurfaceVariant),
                border = BorderStroke(1.dp, AtikBorder),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.TrendingUp, null, tint = AtikNeonAzure, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Trending Viral Hashtags (2026)", color = AtikTextPrimary, fontSize = 13.5.sp, fontWeight = FontWeight.Bold)
                        }

                        // Copy All Tags
                        TextButton(
                            onClick = {
                                val clip = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                val allTags = trendingTags.joinToString(" ") { it.tag }
                                clip.setPrimaryClip(ClipData.newPlainText("Tags", allTags))
                                Toast.makeText(context, "Copied all trending tags!", Toast.LENGTH_SHORT).show()
                            }
                        ) {
                            Text("Copy All", color = AtikNeonCyan, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    // Flow of chips
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        trendingTags.chunked(2).forEach { rowTags ->
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                rowTags.forEach { item ->
                                    Surface(
                                        onClick = {
                                            val clip = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                            clip.setPrimaryClip(ClipData.newPlainText("Tag", item.tag))
                                            Toast.makeText(context, "Copied ${item.tag}", Toast.LENGTH_SHORT).show()
                                        },
                                        color = AtikSurface,
                                        shape = RoundedCornerShape(10.dp),
                                        border = BorderStroke(0.8.dp, AtikBorder),
                                        modifier = Modifier.weight(1f)
                                    ) {
                                        Row(
                                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Column {
                                                Text(item.tag, color = AtikNeonCyan, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                                Text(item.category, color = AtikTextMuted, fontSize = 9.5.sp)
                                            }
                                            Surface(
                                                color = AtikSurfaceHighlight,
                                                shape = RoundedCornerShape(6.dp)
                                            ) {
                                                Text(item.postVolume, color = AtikTextSecondary, fontSize = 9.sp, modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp))
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // Platform Algorithm Playbooks
        item {
            Text(
                text = "ALGORITHM PLAYBOOKS & GROWTH SECRETS",
                color = AtikNeonAzure,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 0.8.sp
            )
        }

        items(growthStrategies) { strategy ->
            Card(
                colors = CardDefaults.cardColors(containerColor = AtikSurfaceVariant),
                border = BorderStroke(0.8.dp, AtikBorder),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(strategy.platform.iconEmoji, fontSize = 16.sp)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(strategy.platform.displayName, color = AtikTextPrimary, fontSize = 13.5.sp, fontWeight = FontWeight.Bold)
                        }

                        Surface(
                            color = AtikSurfaceHighlight,
                            shape = RoundedCornerShape(6.dp)
                        ) {
                            Text(
                                text = strategy.optimalPostingFrequency,
                                color = AtikTextMuted,
                                fontSize = 10.sp,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(strategy.algorithmSecret, color = AtikTextSecondary, fontSize = 12.sp, lineHeight = 17.sp)

                    Spacer(modifier = Modifier.height(8.dp))

                    Text("Tactical Hacks:", color = AtikNeonCyan, fontSize = 10.5.sp, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(4.dp))
                    strategy.actionableHacks.forEach { hack ->
                        Row(modifier = Modifier.padding(vertical = 1.dp)) {
                            Text("✓ ", color = AtikSuccess, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            Text(hack, color = AtikTextSecondary, fontSize = 11.5.sp)
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedButton(
                        onClick = {
                            onSendToChat("Provide a comprehensive 30-day viral growth plan for ${strategy.platform.displayName} targeting tech & digital earning audiences.")
                        },
                        shape = RoundedCornerShape(10.dp),
                        border = BorderStroke(0.8.dp, AtikBorder),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.Lightbulb, null, tint = AtikNeonCyan, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Ask Atik AI for 30-Day Growth Plan", color = AtikTextPrimary, fontSize = 11.5.sp)
                    }
                }
            }
        }
    }
}

/**
 * DIALOG: MANUAL QUEUE POST
 */
@Composable
private fun ManualQueuePostDialog(
    socialEngine: SocialMediaEngine,
    onDismiss: () -> Unit,
    onSave: (SocialPostEntity) -> Unit
) {
    var platform by remember { mutableStateOf(SocialPlatform.INSTAGRAM) }
    var title by remember { mutableStateOf("") }
    var caption by remember { mutableStateOf("") }
    var hashtags by remember { mutableStateOf("#AI #Tech #Innovation") }

    val optimalSlots = remember(platform) { socialEngine.calculateOptimalPostTimes(platform) }
    var selectedTimeSlotIndex by remember { mutableIntStateOf(0) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Schedule, null, tint = AtikNeonCyan, modifier = Modifier.size(20.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text("Queue New Post", color = AtikTextPrimary, fontSize = 16.sp, fontWeight = FontWeight.Bold)
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Platform Pick
                Text("Select Platform:", color = AtikTextMuted, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    SocialPlatform.values().forEach { p ->
                        val isSelected = platform == p
                        Surface(
                            onClick = { platform = p },
                            shape = RoundedCornerShape(8.dp),
                            color = if (isSelected) Color(p.primaryColorHex).copy(alpha = 0.25f) else AtikSurface,
                            border = BorderStroke(0.8.dp, if (isSelected) Color(p.primaryColorHex) else AtikBorder)
                        ) {
                            Text(
                                text = "${p.iconEmoji} ${p.displayName}",
                                color = if (isSelected) AtikTextPrimary else AtikTextMuted,
                                fontSize = 11.sp,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp)
                            )
                        }
                    }
                }

                // Title
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("Headline / Topic", fontSize = 12.sp) },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = AtikNeonCyan,
                        unfocusedBorderColor = AtikBorder,
                        focusedTextColor = AtikTextPrimary,
                        unfocusedTextColor = AtikTextPrimary
                    ),
                    modifier = Modifier.fillMaxWidth().testTag("queue_title_input")
                )

                // Caption
                OutlinedTextField(
                    value = caption,
                    onValueChange = { caption = it },
                    label = { Text("Post Caption", fontSize = 12.sp) },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = AtikNeonCyan,
                        unfocusedBorderColor = AtikBorder,
                        focusedTextColor = AtikTextPrimary,
                        unfocusedTextColor = AtikTextPrimary
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(100.dp)
                        .testTag("queue_caption_input")
                )

                // Hashtags
                OutlinedTextField(
                    value = hashtags,
                    onValueChange = { hashtags = it },
                    label = { Text("Hashtags", fontSize = 12.sp) },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = AtikNeonCyan,
                        unfocusedBorderColor = AtikBorder,
                        focusedTextColor = AtikTextPrimary,
                        unfocusedTextColor = AtikTextPrimary
                    ),
                    modifier = Modifier.fillMaxWidth().testTag("queue_hashtags_input")
                )

                // Smart Optimal Post Timing
                Text("Smart Optimal Timing:", color = AtikTextMuted, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    optimalSlots.forEachIndexed { index, (label, _) ->
                        val isSelected = selectedTimeSlotIndex == index
                        Surface(
                            onClick = { selectedTimeSlotIndex = index },
                            color = if (isSelected) AtikElectricBlue.copy(alpha = 0.3f) else AtikSurface,
                            shape = RoundedCornerShape(8.dp),
                            border = BorderStroke(0.8.dp, if (isSelected) AtikNeonCyan else AtikBorder),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = if (isSelected) Icons.Default.Check else Icons.Default.Schedule,
                                    contentDescription = null,
                                    tint = if (isSelected) AtikNeonCyan else AtikTextMuted,
                                    modifier = Modifier.size(14.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = label,
                                    color = if (isSelected) AtikTextPrimary else AtikTextSecondary,
                                    fontSize = 11.sp,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                                )
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val chosenTime = optimalSlots.getOrNull(selectedTimeSlotIndex)?.second
                        ?: (System.currentTimeMillis() + 3600000L)

                    val newPost = SocialPostEntity(
                        platform = platform.name,
                        title = title.ifBlank { "Untitled Post" },
                        caption = caption.ifBlank { "New Social Post" },
                        hashtags = hashtags,
                        scheduledTimeMillis = chosenTime,
                        status = "QUEUED",
                        estimatedEngagementScore = (82..95).random()
                    )
                    onSave(newPost)
                },
                colors = ButtonDefaults.buttonColors(containerColor = AtikElectricBlue),
                modifier = Modifier.testTag("dialog_save_queue_btn")
            ) {
                Text("Schedule Post", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel", color = AtikTextMuted)
            }
        },
        containerColor = AtikSurfaceVariant
    )
}

@Composable
private fun MetricCounter(label: String, count: Int, color: Color) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
            text = count.toString(),
            color = color,
            fontSize = 18.sp,
            fontWeight = FontWeight.Bold
        )
        Text(text = label, color = AtikTextMuted, fontSize = 10.sp)
    }
}

@Composable
private fun MetricDivider() {
    Box(
        modifier = Modifier
            .height(24.dp)
            .width(1.dp)
            .background(AtikBorder)
    )
}

@Composable
private fun MetricTile(title: String, value: String, modifier: Modifier = Modifier) {
    Surface(
        color = AtikSurface,
        shape = RoundedCornerShape(10.dp),
        border = BorderStroke(0.8.dp, AtikBorder),
        modifier = modifier
    ) {
        Column(
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(title, color = AtikTextMuted, fontSize = 9.sp)
            Spacer(modifier = Modifier.height(2.dp))
            Text(value, color = AtikNeonCyan, fontSize = 11.5.sp, fontWeight = FontWeight.Bold, maxLines = 1)
        }
    }
}
