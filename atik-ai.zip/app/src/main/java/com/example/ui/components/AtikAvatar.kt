package com.example.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.ui.theme.AtikBlack
import com.example.ui.theme.AtikBorder
import com.example.ui.theme.AtikElectricBlue
import com.example.ui.theme.AtikNeonAzure
import com.example.ui.theme.AtikNeonCyan
import com.example.ui.theme.AtikSurfaceVariant

/**
 * Standard Atik AI Avatar with Chinese Kung-Fu warrior identity (with dual waist daggers/churi).
 */
@Composable
fun AtikAvatar(
    size: Dp = 44.dp,
    isPulsing: Boolean = false,
    onClick: (() -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "avatar_pulse")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 0.96f,
        targetValue = if (isPulsing) 1.15f else 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(900, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse_scale"
    )

    Box(
        modifier = modifier
            .size(size)
            .then(if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier)
            .testTag("atik_avatar"),
        contentAlignment = Alignment.Center
    ) {
        // Glowing martial aura when pulsing
        if (isPulsing) {
            Canvas(modifier = Modifier.size(size * pulseScale)) {
                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(
                            AtikNeonCyan.copy(alpha = 0.40f),
                            AtikNeonAzure.copy(alpha = 0.18f),
                            Color.Transparent
                        )
                    )
                )
            }
        }

        // Circular Kung-Fu warrior avatar image with high-tech cyan/azure gradient border
        Box(
            modifier = Modifier
                .size(size)
                .shadow(elevation = 6.dp, shape = CircleShape, spotColor = AtikNeonCyan)
                .clip(CircleShape)
                .background(AtikBlack)
                .border(
                    width = (size.value * 0.045f).coerceIn(1.2f, 2.5f).dp,
                    brush = Brush.sweepGradient(
                        listOf(
                            AtikNeonCyan,
                            AtikElectricBlue,
                            AtikNeonAzure,
                            AtikNeonCyan
                        )
                    ),
                    shape = CircleShape
                ),
            contentAlignment = Alignment.Center
        ) {
            Image(
                painter = painterResource(id = R.drawable.img_kungfu_warrior_avatar),
                contentDescription = "Atik AI Chinese Kung-Fu Warrior Avatar",
                modifier = Modifier
                    .size(size)
                    .clip(CircleShape),
                contentScale = ContentScale.Crop
            )
        }
    }
}

/**
 * Prominent Kung-Fu Warrior Avatar Graphic for the top center of the clean chat screen.
 * Displays the stylish warrior wearing two waist daggers (churi) as the identity of Atik AI.
 */
@Composable
fun KungFuAvatarIdentity(
    size: Dp = 100.dp,
    isPulsing: Boolean = false,
    onAvatarClick: (() -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "hero_avatar_pulse")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 0.98f,
        targetValue = if (isPulsing) 1.18f else 1.04f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "hero_pulse_scale"
    )

    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = modifier.testTag("kungfu_identity_header")
    ) {
        Box(
            modifier = Modifier
                .size(size * 1.2f)
                .then(if (onAvatarClick != null) Modifier.clickable(onClick = onAvatarClick) else Modifier),
            contentAlignment = Alignment.Center
        ) {
            // Radial martial aura glow
            Canvas(modifier = Modifier.size(size * pulseScale * 1.15f)) {
                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(
                            AtikNeonCyan.copy(alpha = if (isPulsing) 0.45f else 0.22f),
                            AtikElectricBlue.copy(alpha = if (isPulsing) 0.25f else 0.10f),
                            Color.Transparent
                        )
                    )
                )
                // Geometric martial energy ring
                drawCircle(
                    color = AtikNeonCyan.copy(alpha = if (isPulsing) 0.35f else 0.15f),
                    style = Stroke(width = 1.2.dp.toPx())
                )
            }

            // Outer decorative ring
            Box(
                modifier = Modifier
                    .size(size)
                    .shadow(elevation = 12.dp, shape = CircleShape, spotColor = AtikNeonCyan)
                    .clip(CircleShape)
                    .background(AtikBlack)
                    .border(
                        width = 2.5.dp,
                        brush = Brush.sweepGradient(
                            listOf(
                                AtikNeonCyan,
                                AtikElectricBlue,
                                AtikNeonAzure,
                                Color(0xFFFFD700), // Subtle martial gold accent
                                AtikNeonCyan
                            )
                        ),
                        shape = CircleShape
                    ),
                contentAlignment = Alignment.Center
            ) {
                Image(
                    painter = painterResource(id = R.drawable.img_kungfu_warrior_avatar),
                    contentDescription = "Atik AI Chinese Kung-Fu Warrior Avatar with two waist daggers",
                    modifier = Modifier
                        .size(size)
                        .clip(CircleShape),
                    contentScale = ContentScale.Crop
                )
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Identity Badge
        Surface(
            shape = RoundedCornerShape(12.dp),
            color = AtikSurfaceVariant.copy(alpha = 0.85f),
            border = BorderStroke(0.8.dp, AtikBorder),
            onClick = { onAvatarClick?.invoke() }
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "⚔️",
                    fontSize = 12.sp,
                    modifier = Modifier.padding(end = 6.dp)
                )
                Text(
                    text = "ATIK AI",
                    color = AtikNeonCyan,
                    fontSize = 11.5.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.2.sp
                )
            }
        }
    }
}
