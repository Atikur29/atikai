package com.example.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.ColorScheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.unit.dp
import com.example.data.ThemeConfigEntity

/**
 * Predefined App Themes for Atik AI (Step 25 Requirement 2).
 */
enum class ThemePreset(
    val id: String,
    val displayName: String,
    val iconEmoji: String,
    val description: String,
    val defaultBackground: Color,
    val defaultSurface: Color,
    val defaultSurfaceVariant: Color,
    val defaultSurfaceHighlight: Color,
    val defaultBorder: Color,
    val defaultAccentCyan: Color,
    val defaultAccentBlue: Color,
    val defaultTextPrimary: Color,
    val defaultTextSecondary: Color,
    val isDark: Boolean,
    val previewGradient: List<Color>
) {
    FUTURISTIC_NEON(
        id = "FUTURISTIC_NEON",
        displayName = "Futuristic Neon",
        iconEmoji = "⚡",
        description = "Cosmic obsidian with high-voltage electric cyan & laser blue neon radiance",
        defaultBackground = Color(0xFF070B14),
        defaultSurface = Color(0xFF0F172A),
        defaultSurfaceVariant = Color(0xFF162038),
        defaultSurfaceHighlight = Color(0xFF1E2E50),
        defaultBorder = Color(0xFF1E3A8A),
        defaultAccentCyan = Color(0xFF00E5FF),
        defaultAccentBlue = Color(0xFF2563EB),
        defaultTextPrimary = Color(0xFFF8FAFC),
        defaultTextSecondary = Color(0xFF94A3B8),
        isDark = true,
        previewGradient = listOf(Color(0xFF070B14), Color(0xFF00E5FF), Color(0xFF2563EB))
    ),
    VINTAGE_80S(
        id = "VINTAGE_80S",
        displayName = "Vintage 80s",
        iconEmoji = "📼",
        description = "Retro synthwave dusk purple with hot magenta & sunset amber radiance",
        defaultBackground = Color(0xFF140824),
        defaultSurface = Color(0xFF220E3D),
        defaultSurfaceVariant = Color(0xFF33155A),
        defaultSurfaceHighlight = Color(0xFF4A1F82),
        defaultBorder = Color(0xFF86198F),
        defaultAccentCyan = Color(0xFFFF2A85), // Hot pink
        defaultAccentBlue = Color(0xFFFF8C00), // Sunset orange
        defaultTextPrimary = Color(0xFFFDF4FF),
        defaultTextSecondary = Color(0xFFE879F9),
        isDark = true,
        previewGradient = listOf(Color(0xFF140824), Color(0xFFFF2A85), Color(0xFFFF8C00))
    ),
    CYBERPUNK(
        id = "CYBERPUNK",
        displayName = "Cyberpunk",
        iconEmoji = "🦾",
        description = "High-contrast midnight matrix black with radioactive neon yellow & neon teal",
        defaultBackground = Color(0xFF0B0B10),
        defaultSurface = Color(0xFF14141E),
        defaultSurfaceVariant = Color(0xFF1F1F2E),
        defaultSurfaceHighlight = Color(0xFF2C2C40),
        defaultBorder = Color(0xFFEAB308),
        defaultAccentCyan = Color(0xFF00FFCC),
        defaultAccentBlue = Color(0xFFFFE600),
        defaultTextPrimary = Color(0xFFFFFFFF),
        defaultTextSecondary = Color(0xFFA1A1AA),
        isDark = true,
        previewGradient = listOf(Color(0xFF0B0B10), Color(0xFFFFE600), Color(0xFF00FFCC))
    ),
    AMOLED_DARK(
        id = "AMOLED_DARK",
        displayName = "AMOLED Dark",
        iconEmoji = "🖤",
        description = "Pure pitch-black (#000000) for ultimate OLED power efficiency & crisp clarity",
        defaultBackground = Color(0xFF000000),
        defaultSurface = Color(0xFF0A0A0A),
        defaultSurfaceVariant = Color(0xFF141414),
        defaultSurfaceHighlight = Color(0xFF202020),
        defaultBorder = Color(0xFF2E2E2E),
        defaultAccentCyan = Color(0xFF10B981), // Emerald green
        defaultAccentBlue = Color(0xFF059669),
        defaultTextPrimary = Color(0xFFFFFFFF),
        defaultTextSecondary = Color(0xFFA3A3A3),
        isDark = true,
        previewGradient = listOf(Color(0xFF000000), Color(0xFF141414), Color(0xFF10B981))
    ),
    MINIMAL_LIGHT(
        id = "MINIMAL_LIGHT",
        displayName = "Minimal Light",
        iconEmoji = "☀️",
        description = "Crisp porcelain daylight canvas with royal cobalt blue & refined graphite accents",
        defaultBackground = Color(0xFFF8FAFC),
        defaultSurface = Color(0xFFFFFFFF),
        defaultSurfaceVariant = Color(0xFFF1F5F9),
        defaultSurfaceHighlight = Color(0xFFE2E8F0),
        defaultBorder = Color(0xFFCBD5E1),
        defaultAccentCyan = Color(0xFF0284C7),
        defaultAccentBlue = Color(0xFF2563EB),
        defaultTextPrimary = Color(0xFF0F172A),
        defaultTextSecondary = Color(0xFF475569),
        isDark = false,
        previewGradient = listOf(Color(0xFFF8FAFC), Color(0xFFFFFFFF), Color(0xFF2563EB))
    );

    companion object {
        fun fromId(id: String?): ThemePreset {
            return values().firstOrNull { it.id.equals(id, ignoreCase = true) } ?: FUTURISTIC_NEON
        }
    }
}

/**
 * Button Style Variants (Step 25 Requirement 1 & 3).
 */
enum class AppButtonStyle(val displayName: String, val icon: String, val description: String) {
    PILL_MODERN("Modern Pill", "💊", "Smooth rounded capsule stadium shapes (99dp)"),
    ROUNDED_NEON("Rounded Neon", "✨", "Curved borders with neon accent stroke (14dp)"),
    ANGULAR_TECH("Angular Cyber", "📐", "Sharp cybernetic technical corners (4dp)"),
    OUTLINED_GLASS("Outlined Glass", "🪟", "Translucent glass with prominent crisp border (10dp)");

    fun getShape(): Shape {
        return when (this) {
            PILL_MODERN -> RoundedCornerShape(99.dp)
            ROUNDED_NEON -> RoundedCornerShape(14.dp)
            ANGULAR_TECH -> RoundedCornerShape(4.dp)
            OUTLINED_GLASS -> RoundedCornerShape(10.dp)
        }
    }

    companion object {
        fun fromName(name: String?): AppButtonStyle {
            return values().firstOrNull { it.name.equals(name, ignoreCase = true) } ?: PILL_MODERN
        }
    }
}

/**
 * Dynamic Home-Screen Background Widget Styles (Step 25 Requirement 3).
 */
enum class BackgroundWidgetType(val displayName: String, val iconEmoji: String, val description: String) {
    NEON_MATRIX_GRID("Neon Matrix Grid", "🌐", "High-tech cyberspace grid with radiant horizon perspective"),
    SYNTHWAVE_SUNSET("Synthwave Sunset", "🌅", "Retro 80s dusk radial glow with horizon stripes"),
    CYBER_PULSE_ORB("Cyber Energy Orb", "🔮", "Subtle breathing ambient energy core with fluid aura"),
    CLEAN_MINIMAL("Clean Minimalist", "✨", "Pure uncluttered elegant canvas without extra overlays"),
    STARFIELD_CONSTELLATION("Starfield Nebula", "🌌", "Cosmic starry constellation dots with subtle twinkle");

    companion object {
        fun fromName(name: String?): BackgroundWidgetType {
            return values().firstOrNull { it.name.equals(name, ignoreCase = true) } ?: NEON_MATRIX_GRID
        }
    }
}

/**
 * Palette of curated accent colors.
 */
data class AccentColorOption(
    val name: String,
    val hex: String,
    val color: Color
)

val PRESET_ACCENT_COLORS = listOf(
    AccentColorOption("Electric Cyan", "#00E5FF", Color(0xFF00E5FF)),
    AccentColorOption("Laser Pink", "#FF2A85", Color(0xFFFF2A85)),
    AccentColorOption("Cyber Yellow", "#FFE600", Color(0xFFFFE600)),
    AccentColorOption("Emerald Matrix", "#10B981", Color(0xFF10B981)),
    AccentColorOption("Royal Cobalt", "#2563EB", Color(0xFF2563EB)),
    AccentColorOption("Violet Flare", "#A855F7", Color(0xFFA855F7)),
    AccentColorOption("Sunset Orange", "#FF8C00", Color(0xFFFF8C00)),
    AccentColorOption("Pure White", "#FFFFFF", Color(0xFFFFFFFF))
)

/**
 * Full Theme Configuration State across the application.
 */
data class DynamicThemeState(
    val preset: ThemePreset = ThemePreset.FUTURISTIC_NEON,
    val accentColorHex: String = "#00E5FF",
    val buttonStyle: AppButtonStyle = AppButtonStyle.PILL_MODERN,
    val fontScale: Float = 1.0f,
    val backgroundWidget: BackgroundWidgetType = BackgroundWidgetType.NEON_MATRIX_GRID
) {
    val accentColor: Color get() = try {
        Color(android.graphics.Color.parseColor(accentColorHex))
    } catch (e: Exception) {
        preset.defaultAccentCyan
    }

    fun toCustomColors(): AtikCustomColors {
        return AtikCustomColors(
            isDark = preset.isDark,
            background = preset.defaultBackground,
            surface = preset.defaultSurface,
            surfaceVariant = preset.defaultSurfaceVariant,
            surfaceHighlight = preset.defaultSurfaceHighlight,
            border = preset.defaultBorder,
            textPrimary = preset.defaultTextPrimary,
            textSecondary = preset.defaultTextSecondary,
            textMuted = if (preset.isDark) Color(0xFF64748B) else Color(0xFF94A3B8),
            accentCyan = accentColor,
            accentBlue = preset.defaultAccentBlue
        )
    }

    fun toM3ColorScheme(): ColorScheme {
        return if (preset.isDark) {
            darkColorScheme(
                primary = accentColor,
                onPrimary = if (preset == ThemePreset.MINIMAL_LIGHT) Color.White else Color.Black,
                primaryContainer = preset.defaultSurfaceVariant,
                onPrimaryContainer = preset.defaultTextPrimary,
                secondary = preset.defaultAccentBlue,
                onSecondary = Color.White,
                secondaryContainer = preset.defaultSurfaceHighlight,
                onSecondaryContainer = accentColor,
                tertiary = accentColor,
                onTertiary = Color.Black,
                background = preset.defaultBackground,
                onBackground = preset.defaultTextPrimary,
                surface = preset.defaultSurface,
                onSurface = preset.defaultTextPrimary,
                surfaceVariant = preset.defaultSurfaceVariant,
                onSurfaceVariant = preset.defaultTextSecondary,
                outline = preset.defaultBorder,
                error = Color(0xFFEF4444)
            )
        } else {
            lightColorScheme(
                primary = accentColor,
                onPrimary = Color.White,
                primaryContainer = Color(0xFFE0F2FE),
                onPrimaryContainer = preset.defaultTextPrimary,
                secondary = preset.defaultAccentBlue,
                onSecondary = Color.White,
                secondaryContainer = preset.defaultSurfaceVariant,
                onSecondaryContainer = accentColor,
                tertiary = accentColor,
                onTertiary = Color.White,
                background = preset.defaultBackground,
                onBackground = preset.defaultTextPrimary,
                surface = preset.defaultSurface,
                onSurface = preset.defaultTextPrimary,
                surfaceVariant = preset.defaultSurfaceVariant,
                onSurfaceVariant = preset.defaultTextSecondary,
                outline = preset.defaultBorder,
                error = Color(0xFFEF4444)
            )
        }
    }

    fun toEntity(): ThemeConfigEntity {
        return ThemeConfigEntity(
            id = "active_theme_config",
            themePreset = preset.id,
            accentColorHex = accentColorHex,
            buttonStyle = buttonStyle.name,
            fontScale = fontScale,
            backgroundWidget = backgroundWidget.name,
            updatedAt = System.currentTimeMillis()
        )
    }

    companion object {
        fun fromEntity(entity: ThemeConfigEntity?): DynamicThemeState {
            if (entity == null) return DynamicThemeState()
            return DynamicThemeState(
                preset = ThemePreset.fromId(entity.themePreset),
                accentColorHex = entity.accentColorHex,
                buttonStyle = AppButtonStyle.fromName(entity.buttonStyle),
                fontScale = entity.fontScale.coerceIn(0.85f, 1.30f),
                backgroundWidget = BackgroundWidgetType.fromName(entity.backgroundWidget)
            )
        }
    }
}
