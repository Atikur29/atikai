package com.example.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.AtikBlack
import com.example.ui.theme.AtikElectricBlue
import com.example.ui.theme.AtikError
import com.example.ui.theme.AtikNeonAzure
import com.example.ui.theme.AtikNeonCyan
import com.example.ui.theme.AtikTextPrimary
import com.example.ui.theme.AtikTextSecondary

@Composable
fun AudioRecorderBar(
    spokenText: String,
    rmsDb: Float,
    onStopListening: () -> Unit,
    modifier: Modifier = Modifier
) {
    val transition = rememberInfiniteTransition(label = "audio_bars")
    val bar1 by transition.animateFloat(
        initialValue = 0.3f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(350, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "b1"
    )
    val bar2 by transition.animateFloat(
        initialValue = 0.7f,
        targetValue = 0.2f,
        animationSpec = infiniteRepeatable(tween(420, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "b2"
    )
    val bar3 by transition.animateFloat(
        initialValue = 0.4f,
        targetValue = 0.95f,
        animationSpec = infiniteRepeatable(tween(310, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "b3"
    )
    val bar4 by transition.animateFloat(
        initialValue = 0.9f,
        targetValue = 0.35f,
        animationSpec = infiniteRepeatable(tween(490, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "b4"
    )

    Row(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .background(
                Brush.horizontalGradient(
                    listOf(
                        Color(0xFF0F172A),
                        Color(0xFF1E293B)
                    )
                )
            )
            .border(1.5.dp, AtikNeonCyan.copy(alpha = 0.6f), RoundedCornerShape(20.dp))
            .padding(horizontal = 14.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Red recording pulse indicator
        Box(
            modifier = Modifier
                .size(12.dp)
                .clip(CircleShape)
                .background(AtikError)
        )

        Spacer(modifier = Modifier.width(10.dp))

        // Animated sound bars
        Row(
            modifier = Modifier.width(44.dp),
            horizontalArrangement = Arrangement.spacedBy(4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .width(4.dp)
                    .height((8 + 18 * bar1).dp)
                    .clip(RoundedCornerShape(2.dp))
                    .background(AtikNeonCyan)
            )
            Box(
                modifier = Modifier
                    .width(4.dp)
                    .height((8 + 18 * bar2).dp)
                    .clip(RoundedCornerShape(2.dp))
                    .background(AtikNeonAzure)
            )
            Box(
                modifier = Modifier
                    .width(4.dp)
                    .height((8 + 18 * bar3).dp)
                    .clip(RoundedCornerShape(2.dp))
                    .background(AtikElectricBlue)
            )
            Box(
                modifier = Modifier
                    .width(4.dp)
                    .height((8 + 18 * bar4).dp)
                    .clip(RoundedCornerShape(2.dp))
                    .background(AtikNeonCyan)
            )
        }

        Spacer(modifier = Modifier.width(10.dp))

        Text(
            text = if (spokenText.isNotBlank()) spokenText else "Listening...",
            color = if (spokenText.isNotBlank()) AtikTextPrimary else AtikTextSecondary,
            fontSize = 14.sp,
            fontWeight = FontWeight.Medium,
            maxLines = 1,
            modifier = Modifier.weight(1f)
        )

        IconButton(
            onClick = onStopListening,
            modifier = Modifier
                .size(36.dp)
                .clip(CircleShape)
                .background(AtikError.copy(alpha = 0.2f))
        ) {
            Icon(
                imageVector = Icons.Default.Stop,
                contentDescription = "Stop listening",
                tint = AtikError,
                modifier = Modifier.size(18.dp)
            )
        }
    }
}
