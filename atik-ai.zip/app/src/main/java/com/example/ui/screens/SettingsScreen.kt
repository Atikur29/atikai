package com.example.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.OpenInNew
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.RecordVoiceOver
import androidx.compose.material.icons.filled.SmartToy
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Widgets
import androidx.compose.material.icons.filled.Hearing
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.MusicNote
import com.example.voice.WakeWordSensitivity
import com.example.voice.AudioCueType
import com.example.data.NoteEntity
import com.example.data.LocalDatabaseMetrics
import androidx.compose.material.icons.filled.Sync
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material.icons.filled.CloudDone
import androidx.compose.material.icons.filled.CloudOff
import androidx.compose.material.icons.filled.CleaningServices
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.TextButton
import android.provider.Settings
import android.os.Build
import com.example.widget.VoiceShortcut
import com.example.performance.MemoryDiagnostics
import com.example.performance.StorageDiagnostics
import com.example.performance.PowerProfileMode
import com.example.performance.OptimizationResult
import com.example.ui.components.PerformanceDashboardCard
import com.example.ui.components.PrivacyDashboardCard
import com.example.translation.VoiceAccent
import com.example.translation.TranslationResult
import com.example.ui.components.TranslationStudioCard
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ai.AVAILABLE_MODELS
import com.example.ai.LanguageMode
import com.example.ui.components.AtikAvatar
import com.example.ui.theme.AppThemeMode
import com.example.ui.theme.AtikBlack
import com.example.ui.theme.AtikBorder
import com.example.ui.theme.AtikElectricBlue
import com.example.ui.theme.AtikNeonAzure
import com.example.ui.theme.AtikNeonCyan
import com.example.ui.theme.AtikSuccess
import com.example.ui.theme.AtikSurface
import com.example.ui.theme.AtikSurfaceHighlight
import com.example.ui.theme.AtikSurfaceVariant
import com.example.ui.theme.AtikTextMuted
import com.example.ui.theme.AtikTextPrimary
import com.example.ui.theme.AtikTextSecondary
import com.example.ui.components.AvatarPosition
import com.example.ui.components.KungFuStance
import com.example.ui.theme.AtikWarning
import com.example.voice.VoiceGender
import com.example.ui.theme.ThemePreset
import com.example.ui.theme.AccentColorOption
import com.example.ui.theme.AppButtonStyle
import com.example.ui.theme.BackgroundWidgetType
import com.example.ui.theme.DynamicThemeState
import com.example.ui.components.DynamicThemeStudioSheet

@Composable
fun SettingsScreen(
    currentLanguage: LanguageMode,
    selectedModel: String,
    customApiKey: String,
    isKeyConfigured: Boolean,
    autoReadTts: Boolean,
    speechRate: Float = 1.0f,
    voicePitch: Float = 1.0f,
    voiceGender: VoiceGender = VoiceGender.DYNAMIC,
    themeMode: AppThemeMode = AppThemeMode.CYBERPUNK_DARK,
    userName: String = "Atikur Rahman",
    preferredTitle: String = "Atik Bhai",
    greetingStyle: String = "Time-Aware",
    avatarVisible: Boolean = true,
    avatarScale: Float = 1.0f,
    avatarPosition: AvatarPosition = AvatarPosition.CENTER_HERO,
    avatarGestureSpeed: Float = 1.0f,
    avatarStance: KungFuStance = KungFuStance.IDLE_GUARD,
    onLanguageChange: (LanguageMode) -> Unit,
    onModelChange: (String) -> Unit,
    onSaveApiKey: (String) -> Unit,
    onAutoReadToggle: (Boolean) -> Unit,
    onSpeechRateChange: (Float) -> Unit = {},
    onVoicePreferencesChange: ((speed: Float, pitch: Float, gender: VoiceGender) -> Unit)? = null,
    onThemeModeChange: ((AppThemeMode) -> Unit)? = null,
    onSavePersonalProfile: ((name: String, title: String, style: String) -> Unit)? = null,
    onTestVoiceAudition: (() -> Unit)? = null,
    onAvatarSettingsChange: ((visible: Boolean, scale: Float, position: AvatarPosition, speed: Float, stance: KungFuStance) -> Unit)? = null,
    onPerformStanceAction: ((KungFuStance) -> Unit)? = null,
    isNetworkOnline: Boolean = true,
    connectionTypeName: String = "Wi-Fi Network",
    isSimulationOffline: Boolean = false,
    onToggleSimulationOffline: ((Boolean) -> Unit)? = null,
    isFloatingBubbleEnabled: Boolean = true,
    floatingBubbleSizeDp: Int = 60,
    isSystemOverlayActive: Boolean = false,
    shortcuts: List<VoiceShortcut> = emptyList(),
    onToggleFloatingBubble: ((Boolean) -> Unit)? = null,
    onSetFloatingBubbleSize: ((Int) -> Unit)? = null,
    onToggleSystemOverlay: ((Boolean) -> Unit)? = null,
    onAddShortcut: ((title: String, trigger: String, prompt: String, emoji: String) -> Unit)? = null,
    onDeleteShortcut: ((String) -> Unit)? = null,
    memoryDiagnostics: MemoryDiagnostics = MemoryDiagnostics(),
    storageDiagnostics: StorageDiagnostics = StorageDiagnostics(),
    powerProfile: PowerProfileMode = PowerProfileMode.BALANCED,
    isOptimizing: Boolean = false,
    lastOptimizationResult: OptimizationResult? = null,
    onRunOptimization: (() -> Unit)? = null,
    onRefreshDiagnostics: (() -> Unit)? = null,
    onSelectPowerProfile: ((PowerProfileMode) -> Unit)? = null,
    onToggleAutoClean: ((Boolean) -> Unit)? = null,
    isBiometricEnabled: Boolean = false,
    hasMasterPin: Boolean = false,
    onToggleBiometric: ((Boolean) -> Unit)? = null,
    onSetMasterPin: ((String) -> Unit)? = null,
    onLockAppNow: (() -> Unit)? = null,
    onExportEncryptedBackup: (() -> String)? = null,
    onRestoreEncryptedBackup: ((String) -> Boolean)? = null,
    onClearAllLocalData: (() -> Unit)? = null,
    userAccent: VoiceAccent = VoiceAccent.US_ENGLISH,
    onSelectVoiceAccent: ((VoiceAccent) -> Unit)? = null,
    isWakeWordEnabled: Boolean = true,
    wakeWordSensitivity: WakeWordSensitivity = WakeWordSensitivity.MEDIUM,
    isHandsFreeDuplex: Boolean = true,
    isAudioChimeEnabled: Boolean = true,
    isHapticEnabled: Boolean = true,
    onToggleWakeWord: ((Boolean) -> Unit)? = null,
    onSetSensitivity: ((WakeWordSensitivity) -> Unit)? = null,
    onSetSensitivityByWeight: ((Float) -> Unit)? = null,
    onToggleDuplex: ((Boolean) -> Unit)? = null,
    onToggleAudioChime: ((Boolean) -> Unit)? = null,
    onToggleHaptic: ((Boolean) -> Unit)? = null,
    onTestChime: (() -> Unit)? = null,
    onTestAudioCue: ((AudioCueType) -> Unit)? = null,
    isSyncingData: Boolean = false,
    syncStatusText: String = "Local Database Synced & Ready",
    pendingOfflineCount: Int = 0,
    lastSyncTimestamp: Long = 0L,
    autoSyncEnabled: Boolean = true,
    offlineFallbackPersona: Boolean = true,
    syncOnlyOnWifi: Boolean = false,
    databaseMetrics: LocalDatabaseMetrics = LocalDatabaseMetrics(),
    notes: List<NoteEntity> = emptyList(),
    onSyncNow: (() -> Unit)? = null,
    onToggleAutoSync: ((Boolean) -> Unit)? = null,
    onToggleOfflineFallback: ((Boolean) -> Unit)? = null,
    onToggleSyncOnlyOnWifi: ((Boolean) -> Unit)? = null,
    onClearOfflineCache: (() -> Unit)? = null,
    onAddNote: ((title: String, content: String) -> Unit)? = null,
    onDeleteNote: ((String) -> Unit)? = null,
    dynamicThemeState: DynamicThemeState = DynamicThemeState(),
    onSelectThemePreset: ((ThemePreset) -> Unit)? = null,
    onSelectAccentColor: ((AccentColorOption) -> Unit)? = null,
    onSelectButtonStyle: ((AppButtonStyle) -> Unit)? = null,
    onSelectFontScale: ((Float) -> Unit)? = null,
    onSelectBackgroundWidget: ((BackgroundWidgetType) -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var keyInputValue by remember(customApiKey) { mutableStateOf(customApiKey) }
    var keySavedToast by remember { mutableStateOf(false) }

    var showAddShortcutDialog by remember { mutableStateOf(false) }
    var showAddNoteDialog by remember { mutableStateOf(false) }
    var showDynamicThemeStudio by remember { mutableStateOf(false) }

    // Local profile state
    var editName by remember(userName) { mutableStateOf(userName) }
    var editTitle by remember(preferredTitle) { mutableStateOf(preferredTitle) }
    var editGreetingStyle by remember(greetingStyle) { mutableStateOf(greetingStyle) }
    var profileSavedSuccess by remember { mutableStateOf(false) }

    // Local voice slider states for immediate interactive feedback
    var currentSpeed by remember(speechRate) { mutableFloatStateOf(speechRate) }
    var currentPitch by remember(voicePitch) { mutableFloatStateOf(voicePitch) }
    var selectedVoiceGender by remember(voiceGender) { mutableStateOf(voiceGender) }

    // Local avatar customization states (Step 11)
    var currentAvatarVisible by remember(avatarVisible) { mutableStateOf(avatarVisible) }
    var currentAvatarScale by remember(avatarScale) { mutableFloatStateOf(avatarScale) }
    var currentAvatarPosition by remember(avatarPosition) { mutableStateOf(avatarPosition) }
    var currentGestureSpeed by remember(avatarGestureSpeed) { mutableFloatStateOf(avatarGestureSpeed) }
    var currentAvatarStance by remember(avatarStance) { mutableStateOf(avatarStance) }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 16.dp, bottom = 96.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // App & Persona Header Card
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("settings_header_card"),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = AtikSurfaceVariant),
                border = BorderStroke(1.dp, AtikBorder)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    AtikAvatar(size = 52.dp, isPulsing = true)

                    Spacer(modifier = Modifier.width(14.dp))

                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Atik AI Assistant",
                            color = AtikTextPrimary,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "Owner & Master: $userName ($preferredTitle)",
                            color = AtikNeonCyan,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "Kung-Fu Warrior Persona • v2.5 Enterprise Edition",
                            color = AtikTextMuted,
                            fontSize = 11.sp
                        )
                    }
                }
            }
        }

        // Section 1: Dynamic Theme Engine (Step 10 Requirement 1)
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("settings_theme_card"),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = AtikSurface),
                border = BorderStroke(1.dp, AtikBorder)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Palette,
                            contentDescription = null,
                            tint = AtikNeonCyan,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Dynamic Theme Engine",
                            color = AtikTextPrimary,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Spacer(modifier = Modifier.height(4.dp))

                    Text(
                        text = "Select the interface visual atmosphere across all screens.",
                        color = AtikTextMuted,
                        fontSize = 12.sp
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        AppThemeMode.values().forEach { mode ->
                            val isSelected = mode == themeMode
                            Surface(
                                onClick = { onThemeModeChange?.invoke(mode) },
                                shape = RoundedCornerShape(12.dp),
                                color = if (isSelected) AtikSurfaceHighlight else AtikSurfaceVariant,
                                border = BorderStroke(
                                    1.dp,
                                    if (isSelected) AtikNeonCyan else AtikBorder
                                ),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("theme_option_${mode.name}")
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(12.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        modifier = Modifier.weight(1f)
                                    ) {
                                        // Visual color swatch
                                        Box(
                                            modifier = Modifier
                                                .size(28.dp)
                                                .clip(CircleShape)
                                                .background(
                                                    when (mode) {
                                                        AppThemeMode.CYBERPUNK_DARK -> Brush.linearGradient(
                                                            listOf(Color(0xFF00E5FF), Color(0xFF0A0F1D))
                                                        )
                                                        AppThemeMode.FUTURISTIC_LIGHT -> Brush.linearGradient(
                                                            listOf(Color(0xFF0284C7), Color(0xFFF0F4F8))
                                                        )
                                                        AppThemeMode.SYSTEM_DEFAULT -> Brush.linearGradient(
                                                            listOf(Color(0xFF64748B), Color(0xFF1E293B))
                                                        )
                                                    }
                                                )
                                                .border(1.dp, AtikBorder, CircleShape)
                                        )

                                        Spacer(modifier = Modifier.width(12.dp))

                                        Column {
                                            Text(
                                                text = mode.displayName,
                                                color = if (isSelected) AtikNeonCyan else AtikTextPrimary,
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 14.sp
                                            )
                                            Text(
                                                text = mode.description,
                                                color = AtikTextMuted,
                                                fontSize = 11.sp
                                            )
                                        }
                                    }

                                    if (isSelected) {
                                        Icon(
                                            imageVector = Icons.Default.Check,
                                            contentDescription = "Selected",
                                            tint = AtikNeonCyan,
                                            modifier = Modifier.size(18.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))
                    HorizontalDivider(color = AtikBorder, thickness = 1.dp)
                    Spacer(modifier = Modifier.height(14.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "Dynamic Theme Studio (Step 25)",
                                color = AtikTextPrimary,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "Active: ${dynamicThemeState.preset.displayName} • ${dynamicThemeState.buttonStyle.displayName}",
                                color = AtikTextMuted,
                                fontSize = 11.sp
                            )
                        }

                        Button(
                            onClick = { showDynamicThemeStudio = true },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = dynamicThemeState.accentColor,
                                contentColor = if (dynamicThemeState.preset == ThemePreset.MINIMAL_LIGHT) Color.White else Color.Black
                            ),
                            shape = dynamicThemeState.buttonStyle.getShape(),
                            modifier = Modifier.testTag("btn_settings_open_theme_studio")
                        ) {
                            Icon(Icons.Default.Tune, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Studio", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Text(
                        text = "5 Predefined Presets:",
                        color = AtikTextSecondary,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        ThemePreset.values().forEach { preset ->
                            val isSel = dynamicThemeState.preset == preset
                            Surface(
                                onClick = { onSelectThemePreset?.invoke(preset) },
                                shape = RoundedCornerShape(10.dp),
                                color = if (isSel) AtikSurfaceHighlight else AtikSurfaceVariant,
                                border = BorderStroke(1.dp, if (isSel) dynamicThemeState.accentColor else AtikBorder),
                                modifier = Modifier.testTag("settings_theme_preset_${preset.id}")
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(preset.iconEmoji, fontSize = 12.sp)
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = preset.displayName,
                                        fontSize = 11.5.sp,
                                        fontWeight = if (isSel) FontWeight.Bold else FontWeight.Normal,
                                        color = if (isSel) dynamicThemeState.accentColor else AtikTextPrimary
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // Section 2: Personal Welcome & User Profile (Step 10 Requirement 3)
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("settings_profile_card"),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = AtikSurface),
                border = BorderStroke(1.dp, AtikBorder)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Person,
                            contentDescription = null,
                            tint = AtikNeonCyan,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Personal Profile & Greetings",
                            color = AtikTextPrimary,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Customize your dynamic welcome dashboard and assistant titles.",
                        color = AtikTextMuted,
                        fontSize = 12.sp
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    Text("Full Name", color = AtikTextSecondary, fontSize = 12.sp)
                    Spacer(modifier = Modifier.height(4.dp))
                    OutlinedTextField(
                        value = editName,
                        onValueChange = { editName = it },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("profile_name_input"),
                        singleLine = true,
                        shape = RoundedCornerShape(12.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = AtikTextPrimary,
                            unfocusedTextColor = AtikTextPrimary,
                            focusedBorderColor = AtikNeonCyan,
                            unfocusedBorderColor = AtikBorder,
                            focusedContainerColor = AtikSurfaceVariant,
                            unfocusedContainerColor = AtikSurfaceVariant
                        )
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    Text("Preferred Title / Calling Honorific", color = AtikTextSecondary, fontSize = 12.sp)
                    Spacer(modifier = Modifier.height(4.dp))
                    OutlinedTextField(
                        value = editTitle,
                        onValueChange = { editTitle = it },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("profile_title_input"),
                        singleLine = true,
                        placeholder = { Text("e.g. Atik Bhai, Boss, Commander") },
                        shape = RoundedCornerShape(12.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = AtikTextPrimary,
                            unfocusedTextColor = AtikTextPrimary,
                            focusedBorderColor = AtikNeonCyan,
                            unfocusedBorderColor = AtikBorder,
                            focusedContainerColor = AtikSurfaceVariant,
                            unfocusedContainerColor = AtikSurfaceVariant
                        )
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    Text("Dynamic Greeting Style", color = AtikTextSecondary, fontSize = 12.sp)
                    Spacer(modifier = Modifier.height(6.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        listOf("Time-Aware", "Traditional Respectful", "Energetic High-Tech").forEach { style ->
                            val isSelected = editGreetingStyle == style
                            Surface(
                                onClick = { editGreetingStyle = style },
                                shape = RoundedCornerShape(10.dp),
                                color = if (isSelected) AtikSurfaceHighlight else AtikSurfaceVariant,
                                border = BorderStroke(1.dp, if (isSelected) AtikNeonCyan else AtikBorder),
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("greeting_style_$style")
                            ) {
                                Text(
                                    text = style,
                                    color = if (isSelected) AtikNeonCyan else AtikTextPrimary,
                                    fontSize = 11.5.sp,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                    modifier = Modifier.padding(vertical = 8.dp, horizontal = 6.dp),
                                    textAlign = androidx.compose.ui.text.style.TextAlign.Center
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        if (profileSavedSuccess) {
                            Text(
                                text = "✓ Profile Updated!",
                                color = AtikSuccess,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                        } else {
                            Spacer(modifier = Modifier.width(1.dp))
                        }

                        Button(
                            onClick = {
                                onSavePersonalProfile?.invoke(editName, editTitle, editGreetingStyle)
                                profileSavedSuccess = true
                            },
                            shape = RoundedCornerShape(10.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = AtikElectricBlue),
                            modifier = Modifier.testTag("save_profile_button")
                        ) {
                            Text("Save Profile", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        // Section 3: Voice Customization & Speech Tuning (Step 10 Requirement 2)
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("settings_voice_card"),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = AtikSurface),
                border = BorderStroke(1.dp, AtikBorder)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.RecordVoiceOver,
                                contentDescription = null,
                                tint = AtikNeonCyan,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "AI Voice Customization",
                                color = AtikTextPrimary,
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        // Audition Voice Button
                        Button(
                            onClick = {
                                onVoicePreferencesChange?.invoke(currentSpeed, currentPitch, selectedVoiceGender)
                                onTestVoiceAudition?.invoke()
                            },
                            shape = RoundedCornerShape(10.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = AtikSurfaceHighlight,
                                contentColor = AtikNeonCyan
                            ),
                            border = BorderStroke(1.dp, AtikNeonCyan.copy(alpha = 0.5f)),
                            modifier = Modifier.testTag("voice_audition_button")
                        ) {
                            Icon(Icons.Default.VolumeUp, null, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Audition", fontSize = 11.5.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Auto Read Responses Toggle
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Auto-Read Responses",
                                color = AtikTextPrimary,
                                fontSize = 13.5.sp,
                                fontWeight = FontWeight.Medium
                            )
                            Text(
                                text = "Automatically read AI answers out loud using TTS",
                                color = AtikTextMuted,
                                fontSize = 11.sp
                            )
                        }

                        Switch(
                            checked = autoReadTts,
                            onCheckedChange = onAutoReadToggle,
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = AtikNeonCyan,
                                checkedTrackColor = AtikElectricBlue
                            ),
                            modifier = Modifier.testTag("auto_read_toggle")
                        )
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Voice Gender & Persona Options
                    Text("Voice Persona & Tone", color = AtikTextSecondary, fontSize = 12.sp)
                    Spacer(modifier = Modifier.height(6.dp))

                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        VoiceGender.values().forEach { gender ->
                            val isSelected = selectedVoiceGender == gender
                            Surface(
                                onClick = {
                                    selectedVoiceGender = gender
                                    onVoicePreferencesChange?.invoke(currentSpeed, currentPitch, gender)
                                },
                                shape = RoundedCornerShape(10.dp),
                                color = if (isSelected) AtikSurfaceHighlight else AtikSurfaceVariant,
                                border = BorderStroke(1.dp, if (isSelected) AtikNeonCyan else AtikBorder),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("voice_gender_${gender.name}")
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(10.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = gender.displayName,
                                            color = if (isSelected) AtikNeonCyan else AtikTextPrimary,
                                            fontSize = 13.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                        Text(
                                            text = gender.description,
                                            color = AtikTextMuted,
                                            fontSize = 10.5.sp
                                        )
                                    }
                                    if (isSelected) {
                                        Icon(
                                            Icons.Default.Check,
                                            contentDescription = null,
                                            tint = AtikNeonCyan,
                                            modifier = Modifier.size(16.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Regional Voice Accent Picker (Step 17 Requirement 2)
                    Text("Regional Speech Accent (Multi-Language)", color = AtikTextSecondary, fontSize = 12.sp)
                    Spacer(modifier = Modifier.height(6.dp))

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        VoiceAccent.values().forEach { accent ->
                            val isAccentSelected = userAccent == accent
                            Surface(
                                onClick = { onSelectVoiceAccent?.invoke(accent) },
                                shape = RoundedCornerShape(10.dp),
                                color = if (isAccentSelected) AtikSurfaceHighlight else AtikSurfaceVariant,
                                border = BorderStroke(1.dp, if (isAccentSelected) AtikNeonCyan else AtikBorder),
                                modifier = Modifier.testTag("accent_chip_${accent.id}")
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(accent.flagEmoji, fontSize = 16.sp)
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Column {
                                        Text(
                                            text = accent.displayName,
                                            color = if (isAccentSelected) AtikNeonCyan else AtikTextPrimary,
                                            fontSize = 11.5.sp,
                                            fontWeight = if (isAccentSelected) FontWeight.Bold else FontWeight.Medium
                                        )
                                        Text(
                                            text = accent.region,
                                            color = AtikTextMuted,
                                            fontSize = 9.5.sp
                                        )
                                    }
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Speech Rate Slider
                    Column {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Speech Speed", color = AtikTextSecondary, fontSize = 13.sp)
                            Text(
                                text = String.format(java.util.Locale.US, "%.2fx", currentSpeed),
                                color = AtikNeonAzure,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        Slider(
                            value = currentSpeed,
                            onValueChange = {
                                currentSpeed = it
                                onSpeechRateChange(it)
                                onVoicePreferencesChange?.invoke(it, currentPitch, selectedVoiceGender)
                            },
                            valueRange = 0.6f..2.0f,
                            colors = SliderDefaults.colors(
                                thumbColor = AtikNeonCyan,
                                activeTrackColor = AtikElectricBlue,
                                inactiveTrackColor = AtikBorder
                            ),
                            modifier = Modifier.testTag("voice_speed_slider")
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    // Speech Pitch Slider
                    Column {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Voice Pitch Frequency", color = AtikTextSecondary, fontSize = 13.sp)
                            Text(
                                text = String.format(java.util.Locale.US, "%.2fx", currentPitch),
                                color = AtikNeonAzure,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        Slider(
                            value = currentPitch,
                            onValueChange = {
                                currentPitch = it
                                onVoicePreferencesChange?.invoke(currentSpeed, it, selectedVoiceGender)
                            },
                            valueRange = 0.6f..1.5f,
                            colors = SliderDefaults.colors(
                                thumbColor = AtikNeonCyan,
                                activeTrackColor = AtikElectricBlue,
                                inactiveTrackColor = AtikBorder
                            ),
                            modifier = Modifier.testTag("voice_pitch_slider")
                        )
                    }
                }
            }
        }

        // Section 3B: Interactive Live Voice Assistant & Wake-Word Engine (Step 21)
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("settings_wake_word_card"),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = AtikSurface),
                border = BorderStroke(1.dp, AtikBorder)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Hearing,
                                contentDescription = null,
                                tint = AtikNeonCyan,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Live Voice & Wake-Word Engine",
                                color = AtikTextPrimary,
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        // Test Chime Button
                        Button(
                            onClick = { onTestChime?.invoke() },
                            shape = RoundedCornerShape(10.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = AtikSurfaceHighlight,
                                contentColor = AtikNeonCyan
                            ),
                            border = BorderStroke(1.dp, AtikNeonCyan.copy(alpha = 0.5f)),
                            modifier = Modifier.testTag("settings_test_wake_chime_btn")
                        ) {
                            Icon(Icons.Default.MusicNote, null, modifier = Modifier.size(13.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Test Chime", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    Text(
                        text = "Real-time hands-free voice wake detection, conversational duplex loop, and discrete feedback cues.",
                        color = AtikTextMuted,
                        fontSize = 11.5.sp
                    )

                    // Wake-Word Master Toggle
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Hands-Free Wake-Word Detection",
                                color = AtikTextPrimary,
                                fontSize = 13.5.sp,
                                fontWeight = FontWeight.Medium
                            )
                            Text(
                                text = "Listen for \"Hey Atik\" or \"Atik AI\" hands-free",
                                color = AtikTextMuted,
                                fontSize = 11.sp
                            )
                        }

                        Switch(
                            checked = isWakeWordEnabled,
                            onCheckedChange = { onToggleWakeWord?.invoke(it) },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = AtikNeonCyan,
                                checkedTrackColor = AtikElectricBlue
                            ),
                            modifier = Modifier.testTag("settings_wake_word_switch")
                        )
                    }

                    // Trigger Phrases
                    Column {
                        Text("Active Trigger Phrases", color = AtikTextSecondary, fontSize = 11.5.sp)
                        Spacer(modifier = Modifier.height(4.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            listOf("Hey Atik", "Atik AI", "Hello Atik", "Ok Atik").forEach { phrase ->
                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = AtikSurfaceVariant,
                                    border = BorderStroke(0.8.dp, AtikBorder)
                                ) {
                                    Row(
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Icon(Icons.Default.CheckCircle, null, tint = AtikNeonCyan, modifier = Modifier.size(11.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text(phrase, color = AtikTextPrimary, fontSize = 10.5.sp, fontWeight = FontWeight.SemiBold)
                                    }
                                }
                            }
                        }
                    }

                    // Wake-Word Sensitivity Slider & Presets
                    Column {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Wake Sensitivity", color = AtikTextSecondary, fontSize = 13.sp)
                            Text(
                                text = String.format(java.util.Locale.US, "%.2f (%s)", wakeWordSensitivity.weight, wakeWordSensitivity.displayName.split(" ").first()),
                                color = AtikNeonCyan,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        Slider(
                            value = wakeWordSensitivity.weight,
                            onValueChange = { weight ->
                                onSetSensitivityByWeight?.invoke(weight)
                            },
                            valueRange = 0.15f..0.95f,
                            colors = SliderDefaults.colors(
                                thumbColor = AtikNeonCyan,
                                activeTrackColor = AtikElectricBlue,
                                inactiveTrackColor = AtikBorder
                            ),
                            modifier = Modifier.testTag("settings_wake_sensitivity_slider")
                        )

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            WakeWordSensitivity.values().forEach { sens ->
                                val isSelected = wakeWordSensitivity == sens
                                Surface(
                                    onClick = { onSetSensitivity?.invoke(sens) },
                                    shape = RoundedCornerShape(8.dp),
                                    color = if (isSelected) AtikSurfaceHighlight else AtikSurfaceVariant,
                                    border = BorderStroke(0.8.dp, if (isSelected) AtikNeonCyan else AtikBorder),
                                    modifier = Modifier.weight(1f).testTag("settings_sens_chip_${sens.name}")
                                ) {
                                    Text(
                                        text = sens.name,
                                        color = if (isSelected) AtikNeonCyan else AtikTextPrimary,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                                        modifier = Modifier.padding(vertical = 6.dp)
                                    )
                                }
                            }
                        }
                        Text(
                            text = wakeWordSensitivity.description,
                            color = AtikTextMuted,
                            fontSize = 10.5.sp,
                            modifier = Modifier.padding(top = 4.dp)
                        )
                    }

                    // Continuous Conversational Duplex Mode
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Continuous Duplex Conversation",
                                color = AtikTextPrimary,
                                fontSize = 13.5.sp,
                                fontWeight = FontWeight.Medium
                            )
                            Text(
                                text = "Re-opens mic automatically after AI speaks for hands-free dialog",
                                color = AtikTextMuted,
                                fontSize = 11.sp
                            )
                        }

                        Switch(
                            checked = isHandsFreeDuplex,
                            onCheckedChange = { onToggleDuplex?.invoke(it) },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = AtikNeonCyan,
                                checkedTrackColor = AtikElectricBlue
                            ),
                            modifier = Modifier.testTag("settings_duplex_switch")
                        )
                    }

                    // Discrete Audio Chimes Toggle
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Discrete Audio Chimes",
                                color = AtikTextPrimary,
                                fontSize = 13.5.sp,
                                fontWeight = FontWeight.Medium
                            )
                            Text(
                                text = "Sound cues on wake, query processing, and completion",
                                color = AtikTextMuted,
                                fontSize = 11.sp
                            )
                        }

                        Switch(
                            checked = isAudioChimeEnabled,
                            onCheckedChange = { onToggleAudioChime?.invoke(it) },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = AtikNeonCyan,
                                checkedTrackColor = AtikElectricBlue
                            ),
                            modifier = Modifier.testTag("settings_chimes_switch")
                        )
                    }

                    // Tactile Haptic Pulses Toggle
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Tactile Haptic Pulses",
                                color = AtikTextPrimary,
                                fontSize = 13.5.sp,
                                fontWeight = FontWeight.Medium
                            )
                            Text(
                                text = "Subtle vibration pulse on voice-wake & response delivery",
                                color = AtikTextMuted,
                                fontSize = 11.sp
                            )
                        }

                        Switch(
                            checked = isHapticEnabled,
                            onCheckedChange = { onToggleHaptic?.invoke(it) },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = AtikNeonCyan,
                                checkedTrackColor = AtikElectricBlue
                            ),
                            modifier = Modifier.testTag("settings_haptics_switch")
                        )
                    }

                    // Sound & Haptic Cue Audition Palette
                    Column {
                        Text("Audition Discrete Audio Cues & Haptics", color = AtikTextSecondary, fontSize = 11.5.sp)
                        Spacer(modifier = Modifier.height(6.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Surface(
                                onClick = { onTestAudioCue?.invoke(AudioCueType.WAKE) ?: onTestChime?.invoke() },
                                shape = RoundedCornerShape(8.dp),
                                color = AtikSurfaceVariant,
                                border = BorderStroke(0.8.dp, AtikBorder),
                                modifier = Modifier.weight(1f).testTag("settings_cue_wake")
                            ) {
                                Text(
                                    "Wake 🔔",
                                    color = AtikNeonCyan,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                                    modifier = Modifier.padding(vertical = 8.dp)
                                )
                            }
                            Surface(
                                onClick = { onTestAudioCue?.invoke(AudioCueType.PROCESSING) ?: onTestChime?.invoke() },
                                shape = RoundedCornerShape(8.dp),
                                color = AtikSurfaceVariant,
                                border = BorderStroke(0.8.dp, AtikBorder),
                                modifier = Modifier.weight(1f).testTag("settings_cue_processing")
                            ) {
                                Text(
                                    "Process ⚡",
                                    color = Color(0xFFB388FF),
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                                    modifier = Modifier.padding(vertical = 8.dp)
                                )
                            }
                            Surface(
                                onClick = { onTestAudioCue?.invoke(AudioCueType.SUCCESS) ?: onTestChime?.invoke() },
                                shape = RoundedCornerShape(8.dp),
                                color = AtikSurfaceVariant,
                                border = BorderStroke(0.8.dp, AtikBorder),
                                modifier = Modifier.weight(1f).testTag("settings_cue_success")
                            ) {
                                Text(
                                    "Success ✨",
                                    color = Color(0xFF00E676),
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                                    modifier = Modifier.padding(vertical = 8.dp)
                                )
                            }
                            Surface(
                                onClick = { onTestAudioCue?.invoke(AudioCueType.ERROR) ?: onTestChime?.invoke() },
                                shape = RoundedCornerShape(8.dp),
                                color = AtikSurfaceVariant,
                                border = BorderStroke(0.8.dp, AtikBorder),
                                modifier = Modifier.weight(1f).testTag("settings_cue_error")
                            ) {
                                Text(
                                    "Alert ⚠️",
                                    color = Color(0xFFFF5252),
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                                    modifier = Modifier.padding(vertical = 8.dp)
                                )
                            }
                        }
                    }
                }
            }
        }

        // Section 4: Kung-Fu Warrior Avatar Engine (Step 11 Requirement 3 & 4)
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("settings_avatar_card"),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = AtikSurface),
                border = BorderStroke(1.dp, AtikBorder)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("🥋", fontSize = 20.sp)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Kung-Fu Warrior Avatar",
                                color = AtikTextPrimary,
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        // Test Action Stance Button
                        Button(
                            onClick = {
                                onPerformStanceAction?.invoke(currentAvatarStance)
                            },
                            shape = RoundedCornerShape(10.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = AtikSurfaceHighlight,
                                contentColor = AtikNeonCyan
                            ),
                            border = BorderStroke(1.dp, AtikNeonCyan.copy(alpha = 0.5f)),
                            modifier = Modifier.testTag("avatar_action_test_btn")
                        ) {
                            Text("Test Pose", fontSize = 11.5.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Customize character visual presence, martial stances, and animation pacing.",
                        color = AtikTextMuted,
                        fontSize = 12.sp
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    // 1. Visibility Switch
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Avatar Visibility", color = AtikTextPrimary, fontSize = 13.5.sp, fontWeight = FontWeight.Medium)
                            Text("Display warrior embodiment on home dashboard", color = AtikTextMuted, fontSize = 11.sp)
                        }
                        Switch(
                            checked = currentAvatarVisible,
                            onCheckedChange = {
                                currentAvatarVisible = it
                                onAvatarSettingsChange?.invoke(it, currentAvatarScale, currentAvatarPosition, currentGestureSpeed, currentAvatarStance)
                            },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = AtikNeonCyan,
                                checkedTrackColor = AtikElectricBlue
                            ),
                            modifier = Modifier.testTag("avatar_settings_visibility_switch")
                        )
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // 2. Avatar Scale Slider
                    Column {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Character Scale", color = AtikTextSecondary, fontSize = 13.sp)
                            Text(
                                text = String.format(java.util.Locale.US, "%.1fx", currentAvatarScale),
                                color = AtikNeonAzure,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        Slider(
                            value = currentAvatarScale,
                            onValueChange = {
                                currentAvatarScale = it
                                onAvatarSettingsChange?.invoke(currentAvatarVisible, it, currentAvatarPosition, currentGestureSpeed, currentAvatarStance)
                            },
                            valueRange = 0.7f..1.4f,
                            colors = SliderDefaults.colors(
                                thumbColor = AtikNeonCyan,
                                activeTrackColor = AtikElectricBlue,
                                inactiveTrackColor = AtikBorder
                            ),
                            modifier = Modifier.testTag("avatar_settings_scale_slider")
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // 3. Gesture Speed Slider
                    Column {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Martial Gesture Speed", color = AtikTextSecondary, fontSize = 13.sp)
                            Text(
                                text = String.format(java.util.Locale.US, "%.2fx", currentGestureSpeed),
                                color = AtikNeonAzure,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        Slider(
                            value = currentGestureSpeed,
                            onValueChange = {
                                currentGestureSpeed = it
                                onAvatarSettingsChange?.invoke(currentAvatarVisible, currentAvatarScale, currentAvatarPosition, it, currentAvatarStance)
                            },
                            valueRange = 0.5f..2.0f,
                            colors = SliderDefaults.colors(
                                thumbColor = AtikNeonCyan,
                                activeTrackColor = AtikElectricBlue,
                                inactiveTrackColor = AtikBorder
                            ),
                            modifier = Modifier.testTag("avatar_settings_speed_slider")
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // 4. Position & Docking Options
                    Text("Avatar Position Overlay", color = AtikTextSecondary, fontSize = 12.sp)
                    Spacer(modifier = Modifier.height(6.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        AvatarPosition.values().forEach { pos ->
                            val isSel = currentAvatarPosition == pos
                            Surface(
                                onClick = {
                                    currentAvatarPosition = pos
                                    onAvatarSettingsChange?.invoke(currentAvatarVisible, currentAvatarScale, pos, currentGestureSpeed, currentAvatarStance)
                                },
                                shape = RoundedCornerShape(10.dp),
                                color = if (isSel) AtikSurfaceHighlight else AtikSurfaceVariant,
                                border = BorderStroke(1.dp, if (isSel) AtikNeonCyan else AtikBorder),
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("avatar_settings_pos_${pos.id}")
                            ) {
                                Text(
                                    text = pos.displayName,
                                    color = if (isSel) AtikNeonCyan else AtikTextPrimary,
                                    fontSize = 11.sp,
                                    fontWeight = if (isSel) FontWeight.Bold else FontWeight.Normal,
                                    modifier = Modifier.padding(vertical = 8.dp, horizontal = 4.dp),
                                    textAlign = androidx.compose.ui.text.style.TextAlign.Center
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // 5. Default Martial Stance Options
                    Text("Default Action Stance", color = AtikTextSecondary, fontSize = 12.sp)
                    Spacer(modifier = Modifier.height(6.dp))

                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        KungFuStance.values().forEach { stance ->
                            val isSel = currentAvatarStance == stance
                            Surface(
                                onClick = {
                                    currentAvatarStance = stance
                                    onAvatarSettingsChange?.invoke(currentAvatarVisible, currentAvatarScale, currentAvatarPosition, currentGestureSpeed, stance)
                                },
                                shape = RoundedCornerShape(10.dp),
                                color = if (isSel) AtikSurfaceHighlight else AtikSurfaceVariant,
                                border = BorderStroke(1.dp, if (isSel) AtikNeonCyan else AtikBorder),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("avatar_settings_stance_${stance.id}")
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(10.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text(stance.iconEmoji, fontSize = 16.sp)
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Column {
                                            Text(
                                                text = stance.displayName,
                                                color = if (isSel) AtikNeonCyan else AtikTextPrimary,
                                                fontSize = 13.sp,
                                                fontWeight = FontWeight.Bold
                                            )
                                            Text(
                                                text = stance.description,
                                                color = AtikTextMuted,
                                                fontSize = 10.5.sp
                                            )
                                        }
                                    }
                                    if (isSel) {
                                        Icon(
                                            Icons.Default.Check,
                                            contentDescription = null,
                                            tint = AtikNeonCyan,
                                            modifier = Modifier.size(16.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // Section 5: Offline AI Capabilities & On-Device Storage Persistence Engine (Step 23)
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("settings_network_offline_card"),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = AtikSurface),
                border = BorderStroke(1.dp, if (!isNetworkOnline) Color(0xFFFFB300) else AtikBorder)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp)
                ) {
                    // Header Row
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(if (isNetworkOnline) "🌐" else "⚡", fontSize = 20.sp)
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text(
                                    text = "Offline AI & Storage Persistence",
                                    color = AtikTextPrimary,
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "Room database, DataStore & automated sync engine",
                                    color = AtikTextMuted,
                                    fontSize = 11.sp
                                )
                            }
                        }

                        // Status badge pill
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = if (isNetworkOnline) AtikSuccess.copy(alpha = 0.15f) else Color(0xFFFFB300).copy(alpha = 0.20f),
                            border = BorderStroke(1.dp, if (isNetworkOnline) AtikSuccess else Color(0xFFFFB300))
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(6.dp)
                                        .clip(CircleShape)
                                        .background(if (isNetworkOnline) AtikSuccess else Color(0xFFFFB300))
                                )
                                Spacer(modifier = Modifier.width(5.dp))
                                Text(
                                    text = if (isNetworkOnline) "Cloud Online" else "Offline Active",
                                    color = if (isNetworkOnline) AtikSuccess else Color(0xFFFFE082),
                                    fontSize = 10.5.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Connection Link & Sync Status Row
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = AtikSurfaceVariant,
                        border = BorderStroke(0.8.dp, AtikBorder),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("Physical Network Link", color = AtikTextMuted, fontSize = 11.5.sp)
                                Text(connectionTypeName, color = AtikNeonAzure, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                            }
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("Background Data Sync", color = AtikTextMuted, fontSize = 11.5.sp)
                                Text(syncStatusText, color = if (isSyncingData) AtikNeonCyan else AtikTextSecondary, fontSize = 11.5.sp, fontWeight = FontWeight.Medium)
                            }
                            if (pendingOfflineCount > 0) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text("Pending Sync Queue", color = Color(0xFFFFE082), fontSize = 11.5.sp, fontWeight = FontWeight.Bold)
                                    Text("$pendingOfflineCount action(s) waiting for cloud sync", color = Color(0xFFFFB300), fontSize = 11.sp)
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Room Local Storage Diagnostics Card
                    Text("Local Room Database Footprint", color = AtikTextSecondary, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(6.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = AtikSurfaceHighlight,
                            border = BorderStroke(0.6.dp, AtikBorder),
                            modifier = Modifier.weight(1f)
                        ) {
                            Column(modifier = Modifier.padding(8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                Text("💬 Messages", color = AtikTextMuted, fontSize = 10.sp)
                                Text("${databaseMetrics.sessionCount} Sessions", color = AtikTextPrimary, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = AtikSurfaceHighlight,
                            border = BorderStroke(0.6.dp, AtikBorder),
                            modifier = Modifier.weight(1f)
                        ) {
                            Column(modifier = Modifier.padding(8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                Text("📝 Notes", color = AtikTextMuted, fontSize = 10.sp)
                                Text("${databaseMetrics.noteCount} Saved", color = AtikNeonCyan, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = AtikSurfaceHighlight,
                            border = BorderStroke(0.6.dp, AtikBorder),
                            modifier = Modifier.weight(1f)
                        ) {
                            Column(modifier = Modifier.padding(8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                Text("📦 Storage", color = AtikTextMuted, fontSize = 10.sp)
                                Text("~${databaseMetrics.estimatedDbSizeKb} KB", color = AtikTextPrimary, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Sync Now Button
                    Button(
                        onClick = { onSyncNow?.invoke() },
                        enabled = !isSyncingData,
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = AtikElectricBlue),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("btn_sync_offline_data_now")
                    ) {
                        Icon(Icons.Default.Sync, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            if (isSyncingData) "Synchronizing Offline Data..." else "Sync Offline Data Now",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // DataStore Configuration Switches
                    Text("Storage & Sync Policies", color = AtikTextSecondary, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(8.dp))

                    // Auto-sync switch
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Automatic Background Sync", color = AtikTextPrimary, fontSize = 12.5.sp, fontWeight = FontWeight.SemiBold)
                            Text("Automatically sync offline queries and notes once network is restored", color = AtikTextMuted, fontSize = 11.sp)
                        }
                        Switch(
                            checked = autoSyncEnabled,
                            onCheckedChange = { onToggleAutoSync?.invoke(it) },
                            colors = SwitchDefaults.colors(checkedThumbColor = AtikNeonCyan, checkedTrackColor = AtikElectricBlue),
                            modifier = Modifier.testTag("switch_auto_sync")
                        )
                    }

                    // Sync only on Wi-Fi switch
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Sync Only Over Wi-Fi", color = AtikTextPrimary, fontSize = 12.5.sp, fontWeight = FontWeight.SemiBold)
                            Text("Conserve mobile data by waiting for an active Wi-Fi link", color = AtikTextMuted, fontSize = 11.sp)
                        }
                        Switch(
                            checked = syncOnlyOnWifi,
                            onCheckedChange = { onToggleSyncOnlyOnWifi?.invoke(it) },
                            colors = SwitchDefaults.colors(checkedThumbColor = AtikNeonCyan, checkedTrackColor = AtikElectricBlue),
                            modifier = Modifier.testTag("switch_sync_wifi_only")
                        )
                    }

                    // Offline Fallback Persona switch
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Graceful Offline Fallback Engine", color = AtikTextPrimary, fontSize = 12.5.sp, fontWeight = FontWeight.SemiBold)
                            Text("Execute device controls, calculator & martial voice without cloud", color = AtikTextMuted, fontSize = 11.sp)
                        }
                        Switch(
                            checked = offlineFallbackPersona,
                            onCheckedChange = { onToggleOfflineFallback?.invoke(it) },
                            colors = SwitchDefaults.colors(checkedThumbColor = AtikNeonCyan, checkedTrackColor = AtikElectricBlue),
                            modifier = Modifier.testTag("switch_offline_fallback")
                        )
                    }

                    // Simulate Offline Mode switch
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Simulate Offline Mode", color = AtikTextPrimary, fontSize = 12.5.sp, fontWeight = FontWeight.SemiBold)
                            Text("Test local calculations and persistent storage without toggling Airplane Mode", color = AtikTextMuted, fontSize = 11.sp)
                        }
                        Switch(
                            checked = isSimulationOffline,
                            onCheckedChange = { onToggleSimulationOffline?.invoke(it) },
                            colors = SwitchDefaults.colors(checkedThumbColor = Color(0xFFFFB300), checkedTrackColor = Color(0xFFFFB300).copy(alpha = 0.5f)),
                            modifier = Modifier.testTag("settings_simulate_offline_switch")
                        )
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Local Persistent Notes Vault (Step 23 Requirement 1)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Local User Notes Vault", color = AtikTextSecondary, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        Button(
                            onClick = { showAddNoteDialog = true },
                            colors = ButtonDefaults.buttonColors(containerColor = AtikSurfaceHighlight),
                            shape = RoundedCornerShape(8.dp),
                            border = BorderStroke(1.dp, AtikBorder),
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                            modifier = Modifier.height(28.dp).testTag("btn_open_add_note")
                        ) {
                            Text("+ New Note", color = AtikNeonCyan, fontSize = 10.5.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    if (notes.isEmpty()) {
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = AtikSurfaceVariant,
                            border = BorderStroke(0.8.dp, AtikBorder),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = "No local notes recorded yet. Say \"Take note: [idea]\" or tap + New Note.",
                                color = AtikTextMuted,
                                fontSize = 11.sp,
                                modifier = Modifier.padding(10.dp)
                            )
                        }
                    } else {
                        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            notes.take(3).forEach { note ->
                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = AtikSurfaceVariant,
                                    border = BorderStroke(0.8.dp, AtikBorder),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Row(
                                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 7.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(note.title, color = AtikTextPrimary, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                            Text(note.content, color = AtikTextMuted, fontSize = 10.5.sp, maxLines = 1)
                                        }
                                        IconButton(
                                            onClick = { onDeleteNote?.invoke(note.id) },
                                            modifier = Modifier.size(24.dp)
                                        ) {
                                            Icon(Icons.Default.Delete, contentDescription = "Delete Note", tint = AtikTextMuted, modifier = Modifier.size(15.dp))
                                        }
                                    }
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Storage Pruning Action
                    Button(
                        onClick = { onClearOfflineCache?.invoke() },
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = AtikSurfaceHighlight,
                            contentColor = AtikTextSecondary
                        ),
                        border = BorderStroke(1.dp, AtikBorder),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("btn_prune_offline_cache")
                    ) {
                        Icon(Icons.Default.CleaningServices, contentDescription = null, modifier = Modifier.size(15.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Prune Completed Sync Logs & Cache", fontSize = 11.5.sp)
                    }
                }
            }
        }

        // Section 6: Floating Widget & Quick Voice Shortcuts (Step 14)
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("settings_floating_widget_card"),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = AtikSurface),
                border = BorderStroke(1.dp, AtikBorder)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("🥋", fontSize = 20.sp)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Floating Assistant & Voice Shortcuts",
                                color = AtikTextPrimary,
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = if (isFloatingBubbleEnabled) AtikSuccess.copy(alpha = 0.15f) else AtikSurfaceVariant,
                            border = BorderStroke(1.dp, if (isFloatingBubbleEnabled) AtikSuccess else AtikBorder)
                        ) {
                            Text(
                                text = if (isFloatingBubbleEnabled) "Active" else "Disabled",
                                color = if (isFloatingBubbleEnabled) AtikSuccess else AtikTextMuted,
                                fontSize = 10.5.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Instant floating action bubble and direct voice trigger shortcut engine.",
                        color = AtikTextMuted,
                        fontSize = 12.sp
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    // In-App Draggable Floating Bubble Toggle
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "In-App Floating Assistant Bubble",
                                color = AtikTextPrimary,
                                fontSize = 13.5.sp,
                                fontWeight = FontWeight.Medium
                            )
                            Text(
                                text = "Draggable widget on screen for one-tap voice overlay peek",
                                color = AtikTextMuted,
                                fontSize = 11.sp
                            )
                        }
                        Switch(
                            checked = isFloatingBubbleEnabled,
                            onCheckedChange = { onToggleFloatingBubble?.invoke(it) },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = AtikNeonCyan,
                                checkedTrackColor = AtikElectricBlue
                            ),
                            modifier = Modifier.testTag("settings_floating_bubble_switch")
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Bubble Size Selector
                    Text("Bubble Dimension:", color = AtikTextSecondary, fontSize = 12.sp)
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        listOf(
                            48 to "Small (48dp)",
                            60 to "Standard (60dp)",
                            72 to "Hero (72dp)"
                        ).forEach { (size, label) ->
                            val isSel = floatingBubbleSizeDp == size
                            Surface(
                                onClick = { onSetFloatingBubbleSize?.invoke(size) },
                                shape = RoundedCornerShape(8.dp),
                                color = if (isSel) AtikSurfaceHighlight else AtikSurfaceVariant,
                                border = BorderStroke(1.dp, if (isSel) AtikNeonCyan else AtikBorder),
                                modifier = Modifier.weight(1f)
                            ) {
                                Text(
                                    text = label,
                                    color = if (isSel) AtikNeonCyan else AtikTextMuted,
                                    fontSize = 10.5.sp,
                                    fontWeight = if (isSel) FontWeight.Bold else FontWeight.Normal,
                                    modifier = Modifier.padding(vertical = 8.dp),
                                    textAlign = androidx.compose.ui.text.style.TextAlign.Center
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // System-Wide Window Overlay Service (Step 14 Requirement 1)
                    val hasOverlayPermission = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        Settings.canDrawOverlays(context)
                    } else true

                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = AtikSurfaceVariant,
                        border = BorderStroke(1.dp, if (hasOverlayPermission) AtikBorder else Color(0xFFFFB300)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = "System-Wide Overlay Service",
                                        color = AtikTextPrimary,
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = if (hasOverlayPermission) {
                                            "Allows floating bubble over any other Android application"
                                        } else {
                                            "Requires 'Draw over other apps' system permission"
                                        },
                                        color = if (hasOverlayPermission) AtikTextMuted else Color(0xFFFFB300),
                                        fontSize = 11.sp
                                    )
                                }

                                if (hasOverlayPermission) {
                                    Switch(
                                        checked = isSystemOverlayActive,
                                        onCheckedChange = { onToggleSystemOverlay?.invoke(it) },
                                        colors = SwitchDefaults.colors(
                                            checkedThumbColor = AtikNeonCyan,
                                            checkedTrackColor = AtikElectricBlue
                                        ),
                                        modifier = Modifier.testTag("settings_system_overlay_switch")
                                    )
                                } else {
                                    Button(
                                        onClick = {
                                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                                                val intent = Intent(
                                                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                                                    Uri.parse("package:" + context.packageName)
                                                )
                                                context.startActivity(intent)
                                            }
                                        },
                                        shape = RoundedCornerShape(8.dp),
                                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFFB300)),
                                        modifier = Modifier.testTag("settings_grant_overlay_btn")
                                    ) {
                                        Text("Grant", color = Color.Black, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Registered Quick Voice Shortcuts Section (Step 14 Requirement 2)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Registered Voice Shortcuts (${shortcuts.size})",
                            color = AtikTextSecondary,
                            fontSize = 12.5.sp,
                            fontWeight = FontWeight.SemiBold
                        )

                        TextButton(
                            onClick = { showAddShortcutDialog = true },
                            modifier = Modifier.testTag("btn_add_voice_shortcut")
                        ) {
                            Icon(Icons.Default.Add, null, tint = AtikNeonCyan, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Add Custom", color = AtikNeonCyan, fontSize = 11.5.sp)
                        }
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        shortcuts.forEach { sc ->
                            Surface(
                                shape = RoundedCornerShape(10.dp),
                                color = AtikSurfaceVariant,
                                border = BorderStroke(0.8.dp, AtikBorder),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(horizontal = 10.dp, vertical = 8.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                                        Text(sc.iconEmoji, fontSize = 16.sp)
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Column {
                                            Text(
                                                text = sc.title,
                                                color = AtikTextPrimary,
                                                fontSize = 12.5.sp,
                                                fontWeight = FontWeight.Bold
                                            )
                                            Text(
                                                text = "Trigger: \"${sc.triggerPhrase}\"",
                                                color = AtikNeonAzure,
                                                fontSize = 11.sp
                                            )
                                        }
                                    }

                                    if (sc.isCustom) {
                                        IconButton(
                                            onClick = { onDeleteShortcut?.invoke(sc.id) },
                                            modifier = Modifier.size(24.dp)
                                        ) {
                                            Icon(Icons.Default.Delete, "Delete", tint = AtikTextMuted, modifier = Modifier.size(14.dp))
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // Section 7: App Performance, Battery & Cache Optimization Engine (Step 15)
        item {
            PerformanceDashboardCard(
                memoryDiagnostics = memoryDiagnostics,
                storageDiagnostics = storageDiagnostics,
                powerProfile = powerProfile,
                isOptimizing = isOptimizing,
                lastOptimizationResult = lastOptimizationResult,
                onRunOptimization = { onRunOptimization?.invoke() },
                onRefreshDiagnostics = { onRefreshDiagnostics?.invoke() },
                onSelectPowerProfile = { onSelectPowerProfile?.invoke(it) },
                onToggleAutoClean = { onToggleAutoClean?.invoke(it) }
            )
        }

        // Section 8: Security, Privacy & Data Encryption Center (Step 16)
        item {
            PrivacyDashboardCard(
                isBiometricEnabled = isBiometricEnabled,
                hasMasterPin = hasMasterPin,
                onToggleBiometric = { onToggleBiometric?.invoke(it) },
                onSetMasterPin = { onSetMasterPin?.invoke(it) },
                onLockAppNow = { onLockAppNow?.invoke() },
                onExportEncryptedBackup = { onExportEncryptedBackup?.invoke() ?: "" },
                onRestoreEncryptedBackup = { onRestoreEncryptedBackup?.invoke(it) ?: false },
                onClearAllLocalData = { onClearAllLocalData?.invoke() }
            )
        }

        // Section 9: Bilingual Language Mode
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("settings_language_card"),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = AtikSurface),
                border = BorderStroke(1.dp, AtikBorder)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Language,
                            contentDescription = null,
                            tint = AtikNeonCyan,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Interaction Language Mode",
                            color = AtikTextPrimary,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        LanguageMode.values().forEach { mode ->
                            val isSelected = mode == currentLanguage
                            Surface(
                                onClick = { onLanguageChange(mode) },
                                shape = RoundedCornerShape(12.dp),
                                color = if (isSelected) AtikSurfaceHighlight else AtikSurfaceVariant,
                                border = BorderStroke(
                                    1.dp,
                                    if (isSelected) AtikNeonCyan else AtikBorder
                                ),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("language_option_${mode.name}")
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(12.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Column {
                                        Text(
                                            text = mode.displayName,
                                            color = if (isSelected) AtikNeonCyan else AtikTextPrimary,
                                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                            fontSize = 14.sp
                                        )
                                        Text(
                                            text = when (mode) {
                                                LanguageMode.BANGLA -> "Authentic & respectful Bengali dialogue"
                                                LanguageMode.ENGLISH -> "Fluent international English"
                                                LanguageMode.BANGLISH -> "Bengali written in Latin script (Banglish)"
                                            },
                                            color = AtikTextMuted,
                                            fontSize = 11.sp
                                        )
                                    }

                                    if (isSelected) {
                                        Icon(
                                            imageVector = Icons.Default.Check,
                                            contentDescription = "Selected",
                                            tint = AtikNeonCyan,
                                            modifier = Modifier.size(18.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // Section 5: AI Model Selection
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("settings_model_card"),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = AtikSurface),
                border = BorderStroke(1.dp, AtikBorder)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.SmartToy,
                            contentDescription = null,
                            tint = AtikNeonAzure,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "AI Model Engine",
                            color = AtikTextPrimary,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    AVAILABLE_MODELS.forEach { model ->
                        val isSelected = model.id == selectedModel
                        Surface(
                            onClick = { onModelChange(model.id) },
                            shape = RoundedCornerShape(12.dp),
                            color = if (isSelected) AtikSurfaceHighlight else AtikSurfaceVariant,
                            border = BorderStroke(
                                1.dp,
                                if (isSelected) AtikNeonCyan else AtikBorder
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(bottom = 8.dp)
                                .testTag("model_option_${model.id}")
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = model.name,
                                        color = if (isSelected) AtikNeonAzure else AtikTextPrimary,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 14.sp
                                    )
                                    Text(
                                        text = model.description,
                                        color = AtikTextMuted,
                                        fontSize = 11.sp
                                    )
                                }

                                if (isSelected) {
                                    Icon(
                                        imageVector = Icons.Default.Check,
                                        contentDescription = "Selected",
                                        tint = AtikNeonCyan,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // Section 6: API Configuration Area
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("settings_api_card"),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = AtikSurface),
                border = BorderStroke(1.dp, AtikBorder)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Key,
                                contentDescription = null,
                                tint = AtikNeonCyan,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Gemini API Configuration",
                                color = AtikTextPrimary,
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        // Status badge
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = if (isKeyConfigured) AtikSuccess.copy(alpha = 0.2f) else AtikWarning.copy(alpha = 0.2f),
                            border = BorderStroke(0.5.dp, if (isKeyConfigured) AtikSuccess else AtikWarning)
                        ) {
                            Text(
                                text = if (isKeyConfigured) "Connected" else "Default Key",
                                color = if (isKeyConfigured) AtikSuccess else AtikWarning,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Text(
                        text = "Paste a personal Gemini API Key from Google AI Studio. It is securely encrypted on your local device.",
                        color = AtikTextSecondary,
                        fontSize = 12.sp,
                        lineHeight = 17.sp
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedTextField(
                        value = keyInputValue,
                        onValueChange = { keyInputValue = it },
                        placeholder = { Text("AIzaSy...", color = AtikTextMuted, fontSize = 13.sp) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("api_key_input_field"),
                        singleLine = true,
                        shape = RoundedCornerShape(12.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = AtikTextPrimary,
                            unfocusedTextColor = AtikTextPrimary,
                            focusedBorderColor = AtikNeonCyan,
                            unfocusedBorderColor = AtikBorder,
                            focusedContainerColor = AtikSurfaceVariant,
                            unfocusedContainerColor = AtikSurfaceVariant
                        )
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedButton(
                            onClick = {
                                val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://aistudio.google.com/app/apikey"))
                                context.startActivity(intent)
                            },
                            shape = RoundedCornerShape(10.dp),
                            border = BorderStroke(1.dp, AtikNeonAzure.copy(alpha = 0.5f))
                        ) {
                            Icon(
                                imageVector = Icons.Default.OpenInNew,
                                contentDescription = null,
                                tint = AtikNeonAzure,
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Get Free Key", color = AtikNeonAzure, fontSize = 12.sp)
                        }

                        Button(
                            onClick = {
                                onSaveApiKey(keyInputValue)
                                keySavedToast = true
                            },
                            shape = RoundedCornerShape(10.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = AtikElectricBlue),
                            modifier = Modifier.testTag("save_api_key_button")
                        ) {
                            Text("Save Key", fontSize = 12.sp)
                        }
                    }
                }
            }
        }
    }

    if (showAddShortcutDialog) {
        var scTitle by remember { mutableStateOf("") }
        var scTrigger by remember { mutableStateOf("") }
        var scPrompt by remember { mutableStateOf("") }
        var scEmoji by remember { mutableStateOf("⚡") }

        AlertDialog(
            onDismissRequest = { showAddShortcutDialog = false },
            containerColor = AtikSurfaceVariant,
            title = {
                Text(
                    text = "Add Custom Voice Shortcut",
                    color = AtikTextPrimary,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = "Define a spoken trigger phrase that instantly executes an AI prompt or system workflow.",
                        color = AtikTextMuted,
                        fontSize = 11.5.sp
                    )

                    OutlinedTextField(
                        value = scTitle,
                        onValueChange = { scTitle = it },
                        label = { Text("Shortcut Name *") },
                        placeholder = { Text("e.g. Portfolio Analysis") },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = AtikNeonCyan,
                            unfocusedBorderColor = AtikBorder
                        ),
                        modifier = Modifier.fillMaxWidth().testTag("input_shortcut_title")
                    )

                    OutlinedTextField(
                        value = scTrigger,
                        onValueChange = { scTrigger = it },
                        label = { Text("Spoken Trigger Phrase *") },
                        placeholder = { Text("e.g. Check portfolio") },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = AtikNeonCyan,
                            unfocusedBorderColor = AtikBorder
                        ),
                        modifier = Modifier.fillMaxWidth().testTag("input_shortcut_trigger")
                    )

                    OutlinedTextField(
                        value = scPrompt,
                        onValueChange = { scPrompt = it },
                        label = { Text("AI Prompt / Action *") },
                        placeholder = { Text("e.g. Summarize current active goals and milestones") },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = AtikNeonCyan,
                            unfocusedBorderColor = AtikBorder
                        ),
                        modifier = Modifier.fillMaxWidth().testTag("input_shortcut_prompt")
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (scTitle.isNotBlank() && scTrigger.isNotBlank() && scPrompt.isNotBlank()) {
                            onAddShortcut?.invoke(scTitle, scTrigger, scPrompt, scEmoji)
                            showAddShortcutDialog = false
                        }
                    },
                    enabled = scTitle.isNotBlank() && scTrigger.isNotBlank() && scPrompt.isNotBlank(),
                    colors = ButtonDefaults.buttonColors(containerColor = AtikElectricBlue),
                    modifier = Modifier.testTag("dialog_confirm_add_shortcut")
                ) {
                    Text("Add Shortcut", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                androidx.compose.material3.TextButton(onClick = { showAddShortcutDialog = false }) {
                    Text("Cancel", color = AtikTextMuted)
                }
            }
        )
    }

    // Dynamic Theme Studio Bottom Sheet (Step 25)
    if (showDynamicThemeStudio) {
        DynamicThemeStudioSheet(
            isVisible = showDynamicThemeStudio,
            themeState = dynamicThemeState,
            onSelectPreset = { onSelectThemePreset?.invoke(it) },
            onSelectAccent = { onSelectAccentColor?.invoke(it) },
            onSelectButtonStyle = { onSelectButtonStyle?.invoke(it) },
            onSelectFontScale = { onSelectFontScale?.invoke(it) },
            onSelectBackgroundWidget = { onSelectBackgroundWidget?.invoke(it) },
            onDismiss = { showDynamicThemeStudio = false }
        )
    }
}
