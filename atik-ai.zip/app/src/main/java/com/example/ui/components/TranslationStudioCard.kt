package com.example.ui.components

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material.icons.filled.Translate
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.translation.GlobalLanguageCatalog
import com.example.translation.LanguageDetector
import com.example.translation.LanguageInfo
import com.example.translation.TranslationResult
import com.example.ui.theme.AtikBorder
import com.example.ui.theme.AtikElectricBlue
import com.example.ui.theme.AtikNeonAzure
import com.example.ui.theme.AtikNeonCyan
import com.example.ui.theme.AtikSuccess
import com.example.ui.theme.AtikSurface
import com.example.ui.theme.AtikSurfaceHighlight
import com.example.ui.theme.AtikSurfaceVariant
import com.example.ui.theme.AtikTextMuted
import com.example.ui.theme.AtikTextPrimary
import com.example.ui.theme.AtikTextSecondary
import java.util.Locale

/**
 * Global Multi-Language Translation Studio Card (Step 17).
 * Real-time translation supporting 100+ global languages, auto-detection,
 * accent-accurate voice playback, and quick language pair presets.
 */
@Composable
fun TranslationStudioCard(
    isTranslating: Boolean,
    lastResult: TranslationResult?,
    onTranslate: (text: String, sourceCode: String, targetCode: String) -> Unit,
    onPlayAudio: (text: String, locale: Locale) -> Unit,
    onSendToChat: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var inputText by remember { mutableStateOf("") }
    var sourceLangCode by remember { mutableStateOf("auto") }
    var targetLangCode by remember { mutableStateOf("bn") }

    var showSourcePicker by remember { mutableStateOf(false) }
    var showTargetPicker by remember { mutableStateOf(false) }

    // Live Auto-Detection display
    val liveDetected = remember(inputText) {
        if (inputText.length >= 2) LanguageDetector.detectLanguage(inputText) else null
    }

    val sourceLanguage = remember(sourceLangCode) {
        if (sourceLangCode == "auto") null else GlobalLanguageCatalog.findByCode(sourceLangCode)
    }
    val targetLanguage = remember(targetLangCode) {
        GlobalLanguageCatalog.findByCode(targetLangCode)
    }

    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("card_translation_studio"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = AtikSurface),
        border = BorderStroke(1.dp, AtikBorder)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(
                                Brush.linearGradient(
                                    colors = listOf(AtikElectricBlue, AtikNeonCyan)
                                )
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            Icons.Default.Translate,
                            contentDescription = "Translation Studio",
                            tint = Color.White,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = "Global Translation Studio",
                            color = AtikTextPrimary,
                            fontSize = 14.5.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "100+ languages • Auto-detect • Native accents",
                            color = AtikTextMuted,
                            fontSize = 11.sp
                        )
                    }
                }

                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = AtikNeonCyan.copy(alpha = 0.12f),
                    border = BorderStroke(1.dp, AtikNeonCyan.copy(alpha = 0.4f))
                ) {
                    Text(
                        text = "100+ Langs",
                        color = AtikNeonCyan,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 7.dp, vertical = 3.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Quick Language Pair Chips
            val quickPairs = listOf(
                Pair("en", "bn") to "🇺🇸 EN ⇄ 🇧🇩 BN",
                Pair("bn", "en") to "🇧🇩 BN ⇄ 🇺🇸 EN",
                Pair("en", "ar") to "🇺🇸 EN ⇄ 🇸🇦 AR",
                Pair("en", "es") to "🇺🇸 EN ⇄ 🇪🇸 ES",
                Pair("en", "fr") to "🇺🇸 EN ⇄ 🇫🇷 FR",
                Pair("en", "ja") to "🇺🇸 EN ⇄ 🇯🇵 JA",
                Pair("en", "hi") to "🇺🇸 EN ⇄ 🇮🇳 HI"
            )

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                quickPairs.forEach { (pair, label) ->
                    val isSelected = (sourceLangCode == pair.first && targetLangCode == pair.second)
                    FilterChip(
                        selected = isSelected,
                        onClick = {
                            sourceLangCode = pair.first
                            targetLangCode = pair.second
                            if (inputText.isNotBlank()) {
                                onTranslate(inputText, pair.first, pair.second)
                            }
                        },
                        label = { Text(label, fontSize = 10.5.sp) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = AtikElectricBlue.copy(alpha = 0.3f),
                            selectedLabelColor = AtikNeonCyan
                        ),
                        border = BorderStroke(0.8.dp, if (isSelected) AtikNeonCyan else AtikBorder)
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Language Selector Row (Source ⇄ Target)
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Source Button
                Surface(
                    onClick = { showSourcePicker = true },
                    shape = RoundedCornerShape(10.dp),
                    color = AtikSurfaceVariant,
                    border = BorderStroke(1.dp, AtikBorder),
                    modifier = Modifier
                        .weight(1f)
                        .testTag("btn_select_source_lang")
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center
                    ) {
                        Text(
                            text = if (sourceLanguage == null) "✨ Auto Detect" else "${sourceLanguage.flagEmoji} ${sourceLanguage.name}",
                            color = AtikTextPrimary,
                            fontSize = 11.5.sp,
                            fontWeight = FontWeight.SemiBold,
                            maxLines = 1
                        )
                    }
                }

                // Swap Button
                IconButton(
                    onClick = {
                        val currentSrc = if (sourceLangCode == "auto") {
                            liveDetected?.languageCode ?: "en"
                        } else {
                            sourceLangCode
                        }
                        sourceLangCode = targetLangCode
                        targetLangCode = currentSrc
                        if (inputText.isNotBlank()) {
                            onTranslate(inputText, sourceLangCode, targetLangCode)
                        }
                    },
                    modifier = Modifier.testTag("btn_swap_languages")
                ) {
                    Icon(
                        Icons.Default.SwapHoriz,
                        contentDescription = "Swap Languages",
                        tint = AtikNeonCyan,
                        modifier = Modifier.size(22.dp)
                    )
                }

                // Target Button
                Surface(
                    onClick = { showTargetPicker = true },
                    shape = RoundedCornerShape(10.dp),
                    color = AtikSurfaceVariant,
                    border = BorderStroke(1.dp, AtikBorder),
                    modifier = Modifier
                        .weight(1f)
                        .testTag("btn_select_target_lang")
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center
                    ) {
                        Text(
                            text = "${targetLanguage.flagEmoji} ${targetLanguage.name}",
                            color = AtikNeonCyan,
                            fontSize = 11.5.sp,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1
                        )
                    }
                }
            }

            // Real-time Detection Status Badge
            if (sourceLangCode == "auto" && liveDetected != null) {
                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Identified Language: ${liveDetected.flagEmoji} ${liveDetected.languageName} (${(liveDetected.confidence * 100).toInt()}% match)",
                        color = AtikNeonAzure,
                        fontSize = 10.5.sp,
                        fontWeight = FontWeight.Medium
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Text Input Field
            OutlinedTextField(
                value = inputText,
                onValueChange = { inputText = it },
                placeholder = {
                    Text(
                        text = "Enter words, phrases, or full paragraphs to translate...",
                        color = AtikTextMuted,
                        fontSize = 12.sp
                    )
                },
                maxLines = 5,
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = AtikNeonCyan,
                    unfocusedBorderColor = AtikBorder,
                    focusedTextColor = AtikTextPrimary,
                    unfocusedTextColor = AtikTextPrimary,
                    cursorColor = AtikNeonCyan
                ),
                trailingIcon = {
                    if (inputText.isNotEmpty()) {
                        IconButton(onClick = { inputText = "" }) {
                            Icon(Icons.Default.Close, contentDescription = "Clear", tint = AtikTextMuted, modifier = Modifier.size(16.dp))
                        }
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("input_translation_source")
            )

            Spacer(modifier = Modifier.height(10.dp))

            // Action Row: Character count & Translate Button
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "${inputText.length} chars",
                    color = AtikTextMuted,
                    fontSize = 10.5.sp
                )

                Button(
                    onClick = {
                        if (inputText.isNotBlank()) {
                            onTranslate(inputText, sourceLangCode, targetLangCode)
                        }
                    },
                    enabled = inputText.isNotBlank() && !isTranslating,
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = AtikElectricBlue,
                        contentColor = Color.White
                    ),
                    modifier = Modifier.testTag("btn_execute_translation")
                ) {
                    if (isTranslating) {
                        CircularProgressIndicator(modifier = Modifier.size(16.dp), color = Color.White, strokeWidth = 2.dp)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Translating...", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    } else {
                        Icon(Icons.Default.Translate, null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Translate Now", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }

            // Translation Output Card
            AnimatedVisibility(visible = lastResult != null) {
                lastResult?.let { res ->
                    Spacer(modifier = Modifier.height(14.dp))
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = AtikSurfaceVariant,
                        border = BorderStroke(1.dp, AtikNeonCyan.copy(alpha = 0.5f)),
                        modifier = Modifier.fillMaxWidth().testTag("card_translation_output")
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            // Result Sub-header
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = "${res.targetLanguage.flagEmoji} ${res.targetLanguage.name}",
                                        color = AtikNeonCyan,
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = "• ${res.latencyMs}ms",
                                        color = AtikTextMuted,
                                        fontSize = 10.sp
                                    )
                                }

                                Row {
                                    // Play Voice in Native Accent
                                    IconButton(
                                        onClick = {
                                            onPlayAudio(res.translatedText, res.targetLanguage.locale)
                                        },
                                        modifier = Modifier.size(32.dp).testTag("btn_tts_play_translation")
                                    ) {
                                        Icon(
                                            Icons.Default.VolumeUp,
                                            contentDescription = "Speak in Native Accent",
                                            tint = AtikNeonCyan,
                                            modifier = Modifier.size(18.dp)
                                        )
                                    }

                                    // Copy to Clipboard
                                    IconButton(
                                        onClick = {
                                            val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                            val clip = ClipData.newPlainText("Translation", res.translatedText)
                                            clipboard.setPrimaryClip(clip)
                                            Toast.makeText(context, "Translation copied to clipboard", Toast.LENGTH_SHORT).show()
                                        },
                                        modifier = Modifier.size(32.dp).testTag("btn_copy_translation")
                                    ) {
                                        Icon(
                                            Icons.Default.ContentCopy,
                                            contentDescription = "Copy",
                                            tint = AtikTextSecondary,
                                            modifier = Modifier.size(16.dp)
                                        )
                                    }

                                    // Send to Chat
                                    IconButton(
                                        onClick = {
                                            onSendToChat("Translate & Discuss: \"${res.translatedText}\" (${res.targetLanguage.name})")
                                        },
                                        modifier = Modifier.size(32.dp).testTag("btn_send_translation_chat")
                                    ) {
                                        Icon(
                                            Icons.Default.Send,
                                            contentDescription = "Send to Chat",
                                            tint = AtikNeonAzure,
                                            modifier = Modifier.size(16.dp)
                                        )
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(8.dp))

                            Text(
                                text = res.translatedText,
                                color = AtikTextPrimary,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Normal,
                                lineHeight = 20.sp
                            )
                        }
                    }
                }
            }
        }
    }

    // Language Picker Dialog (Source)
    if (showSourcePicker) {
        LanguagePickerDialog(
            title = "Select Source Language",
            includeAuto = true,
            selectedCode = sourceLangCode,
            onSelect = {
                sourceLangCode = it
                showSourcePicker = false
            },
            onDismiss = { showSourcePicker = false }
        )
    }

    // Language Picker Dialog (Target)
    if (showTargetPicker) {
        LanguagePickerDialog(
            title = "Select Target Language",
            includeAuto = false,
            selectedCode = targetLangCode,
            onSelect = {
                targetLangCode = it
                showTargetPicker = false
            },
            onDismiss = { showTargetPicker = false }
        )
    }
}

/**
 * Searchable Global Language Picker Dialog supporting 100+ languages.
 */
@Composable
fun LanguagePickerDialog(
    title: String,
    includeAuto: Boolean,
    selectedCode: String,
    onSelect: (String) -> Unit,
    onDismiss: () -> Unit
) {
    var searchQuery by remember { mutableStateOf("") }

    val filteredList = remember(searchQuery) {
        if (searchQuery.isBlank()) {
            GlobalLanguageCatalog.ALL_LANGUAGES
        } else {
            val q = searchQuery.trim().lowercase()
            GlobalLanguageCatalog.ALL_LANGUAGES.filter {
                it.name.lowercase().contains(q) ||
                        it.nativeName.lowercase().contains(q) ||
                        it.code.lowercase().contains(q) ||
                        it.region.lowercase().contains(q)
            }
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = AtikSurfaceVariant,
        title = {
            Column {
                Text(
                    text = title,
                    color = AtikTextPrimary,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    placeholder = { Text("Search 100+ languages or regions...", fontSize = 11.5.sp, color = AtikTextMuted) },
                    leadingIcon = { Icon(Icons.Default.Search, null, tint = AtikTextMuted, modifier = Modifier.size(16.dp)) },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = AtikNeonCyan,
                        unfocusedBorderColor = AtikBorder
                    ),
                    modifier = Modifier.fillMaxWidth().testTag("input_search_languages")
                )
            }
        },
        text = {
            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = 360.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                if (includeAuto && searchQuery.isBlank()) {
                    item {
                        Surface(
                            onClick = { onSelect("auto") },
                            shape = RoundedCornerShape(8.dp),
                            color = if (selectedCode == "auto") AtikSurfaceHighlight else Color.Transparent,
                            border = BorderStroke(0.6.dp, if (selectedCode == "auto") AtikNeonCyan else AtikBorder),
                            modifier = Modifier.fillMaxWidth().testTag("lang_picker_auto")
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("✨", fontSize = 16.sp)
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Text("Auto-Detect Language", color = AtikTextPrimary, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                                    Text("Identifies input language dynamically", color = AtikTextMuted, fontSize = 10.sp)
                                }
                            }
                        }
                    }
                }

                items(filteredList, key = { it.code }) { lang ->
                    val isSelected = selectedCode == lang.code
                    Surface(
                        onClick = { onSelect(lang.code) },
                        shape = RoundedCornerShape(8.dp),
                        color = if (isSelected) AtikSurfaceHighlight else Color.Transparent,
                        border = BorderStroke(0.6.dp, if (isSelected) AtikNeonCyan else AtikBorder),
                        modifier = Modifier.fillMaxWidth().testTag("lang_picker_${lang.code}")
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 9.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(lang.flagEmoji, fontSize = 18.sp)
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Text(
                                        text = lang.name,
                                        color = if (isSelected) AtikNeonCyan else AtikTextPrimary,
                                        fontSize = 13.sp,
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                                    )
                                    Text(
                                        text = "${lang.nativeName} • ${lang.region}",
                                        color = AtikTextMuted,
                                        fontSize = 10.5.sp
                                    )
                                }
                            }

                            Text(
                                text = lang.code.uppercase(),
                                color = AtikTextMuted,
                                fontSize = 10.5.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        },
        confirmButton = {},
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel", color = AtikTextMuted)
            }
        }
    )
}
