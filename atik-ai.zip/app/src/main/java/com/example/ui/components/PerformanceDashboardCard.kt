package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CleaningServices
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.RocketLaunch
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.performance.MemoryDiagnostics
import com.example.performance.OptimizationResult
import com.example.performance.PowerProfileMode
import com.example.performance.StorageDiagnostics
import com.example.ui.theme.AtikBorder
import com.example.ui.theme.AtikElectricBlue
import com.example.ui.theme.AtikNeonAzure
import com.example.ui.theme.AtikNeonCyan
import com.example.ui.theme.AtikSuccess
import com.example.ui.theme.AtikSurface
import com.example.ui.theme.AtikSurfaceHighlight
import com.example.ui.theme.AtikSurfaceVariant
import com.example.ui.theme.AtikTextMuted
import com.example.ui.theme.AtikTextPrimary
import com.example.ui.theme.AtikTextSecondary

/**
 * Performance, Battery & Cache Optimization Card (Step 15).
 * Real-time RAM/Heap diagnostics, Power Profile mode selector,
 * automated cache thresholds, and a one-tap Turbo Optimizer.
 */
@Composable
fun PerformanceDashboardCard(
    memoryDiagnostics: MemoryDiagnostics,
    storageDiagnostics: StorageDiagnostics,
    powerProfile: PowerProfileMode,
    isOptimizing: Boolean,
    lastOptimizationResult: OptimizationResult?,
    onRunOptimization: () -> Unit,
    onRefreshDiagnostics: () -> Unit,
    onSelectPowerProfile: (PowerProfileMode) -> Unit,
    onToggleAutoClean: (Boolean) -> Unit,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "turboPulse")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 1f,
        targetValue = if (isOptimizing) 1.08f else 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(600, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulseScale"
    )

    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("card_performance_dashboard"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = AtikSurface),
        border = BorderStroke(1.dp, AtikBorder)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(
                                Brush.linearGradient(
                                    colors = listOf(AtikElectricBlue, AtikNeonCyan)
                                )
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            Icons.Default.Speed,
                            contentDescription = "Performance Engine",
                            tint = Color.White,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = "Performance & Resource Engine",
                            color = AtikTextPrimary,
                            fontSize = 14.5.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Battery efficiency, RAM optimizer & cache cleaner",
                            color = AtikTextMuted,
                            fontSize = 11.sp
                        )
                    }
                }

                IconButton(
                    onClick = onRefreshDiagnostics,
                    modifier = Modifier.testTag("btn_refresh_diagnostics")
                ) {
                    Icon(
                        Icons.Default.Refresh,
                        contentDescription = "Refresh Metrics",
                        tint = AtikNeonCyan,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // RAM & Heap Telemetry Bar
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = AtikSurfaceVariant,
                border = BorderStroke(0.8.dp, AtikBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                Icons.Default.Memory,
                                contentDescription = null,
                                tint = AtikNeonCyan,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "RAM & JVM Heap Allocation",
                                color = AtikTextSecondary,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        }

                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = when (memoryDiagnostics.statusText) {
                                "Optimal" -> AtikSuccess.copy(alpha = 0.2f)
                                "Moderate" -> Color(0xFFFFB300).copy(alpha = 0.2f)
                                else -> Color(0xFFFF5252).copy(alpha = 0.2f)
                            },
                            border = BorderStroke(
                                0.6.dp,
                                when (memoryDiagnostics.statusText) {
                                    "Optimal" -> AtikSuccess
                                    "Moderate" -> Color(0xFFFFB300)
                                    else -> Color(0xFFFF5252)
                                }
                            )
                        ) {
                            Text(
                                text = memoryDiagnostics.statusText,
                                color = when (memoryDiagnostics.statusText) {
                                    "Optimal" -> AtikSuccess
                                    "Moderate" -> Color(0xFFFFB300)
                                    else -> Color(0xFFFF5252)
                                },
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    LinearProgressIndicator(
                        progress = { (memoryDiagnostics.heapUsagePercent / 100f).coerceIn(0f, 1f) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(6.dp)
                            .clip(RoundedCornerShape(3.dp)),
                        color = when {
                            memoryDiagnostics.heapUsagePercent < 50 -> AtikNeonCyan
                            memoryDiagnostics.heapUsagePercent < 80 -> Color(0xFFFFB300)
                            else -> Color(0xFFFF5252)
                        },
                        trackColor = AtikSurfaceHighlight
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "Used Heap: ${String.format("%.1f", memoryDiagnostics.usedHeapMb)} MB / ${String.format("%.1f", memoryDiagnostics.maxHeapMb)} MB (${memoryDiagnostics.heapUsagePercent}%)",
                            color = AtikTextMuted,
                            fontSize = 11.sp
                        )
                        Text(
                            text = "Device Free: ${memoryDiagnostics.availableSystemRamMb} MB",
                            color = AtikNeonAzure,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Cache & Storage Telemetry
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = AtikSurfaceVariant,
                border = BorderStroke(0.8.dp, AtikBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                Icons.Default.CleaningServices,
                                contentDescription = null,
                                tint = AtikNeonCyan,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "Temporary Disk & App Cache",
                                color = AtikTextSecondary,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        }

                        Text(
                            text = storageDiagnostics.totalCleanableFormatted,
                            color = AtikNeonCyan,
                            fontSize = 12.5.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Last cleaned: ${storageDiagnostics.lastCleanedFormatted}",
                        color = AtikTextMuted,
                        fontSize = 10.5.sp
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "Automated Threshold Purge",
                                color = AtikTextPrimary,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Medium
                            )
                            Text(
                                text = "Auto-cleans when cache exceeds ${storageDiagnostics.autoCleanThresholdMb} MB",
                                color = AtikTextMuted,
                                fontSize = 10.5.sp
                            )
                        }

                        Switch(
                            checked = storageDiagnostics.autoCleanEnabled,
                            onCheckedChange = { onToggleAutoClean(it) },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = AtikNeonCyan,
                                checkedTrackColor = AtikElectricBlue
                            ),
                            modifier = Modifier.testTag("switch_auto_clean")
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Power Profile Mode Selector (Battery & RAM Efficiency)
            Text(
                text = "Power & Performance Profile",
                color = AtikTextSecondary,
                fontSize = 12.sp,
                fontWeight = FontWeight.SemiBold
            )
            Spacer(modifier = Modifier.height(6.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                PowerProfileMode.values().forEach { mode ->
                    val isSelected = powerProfile == mode
                    Surface(
                        onClick = { onSelectPowerProfile(mode) },
                        shape = RoundedCornerShape(10.dp),
                        color = if (isSelected) AtikSurfaceHighlight else AtikSurfaceVariant,
                        border = BorderStroke(1.dp, if (isSelected) AtikNeonCyan else AtikBorder),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("profile_mode_${mode.name}")
                    ) {
                        Column(
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 8.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(mode.iconEmoji, fontSize = 16.sp)
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = mode.title,
                                color = if (isSelected) AtikNeonCyan else AtikTextPrimary,
                                fontSize = 10.5.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Optimization Sweep Button (One-tap boost)
            Button(
                onClick = onRunOptimization,
                enabled = !isOptimizing,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .scale(pulseScale)
                    .testTag("btn_run_optimization_sweep"),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = AtikElectricBlue,
                    contentColor = Color.White
                )
            ) {
                if (isOptimizing) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(20.dp),
                        color = Color.White,
                        strokeWidth = 2.dp
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Executing Turbo Sweep...", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                } else {
                    Icon(Icons.Default.RocketLaunch, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Boost Memory & Clean Cache", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                }
            }

            // Results Banner if recently completed
            AnimatedVisibility(visible = lastOptimizationResult != null && !isOptimizing) {
                lastOptimizationResult?.let { res ->
                    Spacer(modifier = Modifier.height(10.dp))
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = AtikSuccess.copy(alpha = 0.12f),
                        border = BorderStroke(1.dp, AtikSuccess),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                Icons.Default.AutoAwesome,
                                contentDescription = null,
                                tint = AtikSuccess,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text(
                                    text = "Turbo Boost Successful!",
                                    color = AtikSuccess,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "Freed ${res.freedMemoryMb} MB JVM heap, recovered ${res.clearedStorageFormatted} storage in ${res.executionTimeMs} ms.",
                                    color = AtikTextPrimary,
                                    fontSize = 11.sp
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
