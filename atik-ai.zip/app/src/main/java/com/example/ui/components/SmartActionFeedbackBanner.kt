package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.accessibility.SmartActionPhase
import com.example.ui.theme.AtikAmber
import com.example.ui.theme.AtikBackground
import com.example.ui.theme.AtikBlack
import com.example.ui.theme.AtikBlue
import com.example.ui.theme.AtikBorder
import com.example.ui.theme.AtikCardBackground
import com.example.ui.theme.AtikDanger
import com.example.ui.theme.AtikEmerald
import com.example.ui.theme.AtikPurple
import com.example.ui.theme.AtikSurfaceHighlight
import com.example.ui.theme.AtikTextPrimary
import com.example.ui.theme.AtikTextSecondary

/**
 * Real-time Action Feedback Overlay & Interactive Safety Consent Banner (Step 24 Requirement 3 & 4).
 * Displays live step-by-step progress, countdown timers, safety consent prompt, and instant abort button.
 */
@Composable
fun SmartActionFeedbackBanner(
    phase: SmartActionPhase,
    onConfirm: () -> Unit,
    onAbort: (String) -> Unit,
    onDismiss: () -> Unit,
    modifier: Modifier = Modifier
) {
    val isVisible = phase !is SmartActionPhase.Idle

    AnimatedVisibility(
        visible = isVisible,
        enter = slideInVertically(initialOffsetY = { -it }) + fadeIn(),
        exit = slideOutVertically(targetOffsetY = { -it }) + fadeOut(),
        modifier = modifier
    ) {
        val infiniteTransition = rememberInfiniteTransition(label = "pulse")
        val pulseScale by infiniteTransition.animateFloat(
            initialValue = 0.95f,
            targetValue = 1.05f,
            animationSpec = infiniteRepeatable(
                animation = tween(600),
                repeatMode = RepeatMode.Reverse
            ),
            label = "pulseScale"
        )

        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 6.dp),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(
                containerColor = when (phase) {
                    is SmartActionPhase.AwaitingConsent -> AtikSurfaceHighlight
                    is SmartActionPhase.Completed -> Color(0xFF0F291E)
                    is SmartActionPhase.Cancelled, is SmartActionPhase.Failed -> Color(0xFF2E1313)
                    else -> AtikCardBackground
                }
            ),
            border = BorderStroke(
                1.5.dp,
                when (phase) {
                    is SmartActionPhase.AwaitingConsent -> AtikAmber
                    is SmartActionPhase.Completed -> AtikEmerald
                    is SmartActionPhase.Cancelled, is SmartActionPhase.Failed -> AtikDanger
                    else -> AtikBlue
                }
            ),
            elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(14.dp)
            ) {
                when (phase) {
                    is SmartActionPhase.AwaitingConsent -> {
                        // Header with Countdown
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(12.dp)
                                        .scale(pulseScale)
                                        .clip(CircleShape)
                                        .background(AtikAmber)
                                )
                                Text(
                                    text = "🛡️ Safety Guardrail: Authorization Required",
                                    color = AtikAmber,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            Surface(
                                shape = RoundedCornerShape(10.dp),
                                color = AtikAmber.copy(alpha = 0.2f),
                                border = BorderStroke(1.dp, AtikAmber.copy(alpha = 0.5f))
                            ) {
                                Text(
                                    text = "${phase.secondsRemaining}s",
                                    color = AtikAmber,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Black,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        // Target Info Card
                        Surface(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(10.dp),
                            color = AtikBlack.copy(alpha = 0.5f),
                            border = BorderStroke(1.dp, AtikBorder)
                        ) {
                            Column(modifier = Modifier.padding(10.dp)) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Text(
                                        text = "${phase.request.targetApp.iconEmoji} ${phase.request.targetApp.displayName}",
                                        color = AtikTextPrimary,
                                        fontSize = 14.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = "• ${phase.request.actionType.displayName}",
                                        color = AtikBlue,
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Medium
                                    )
                                }
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "Recipient: ${phase.request.recipient}",
                                    color = AtikTextPrimary,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.SemiBold
                                )
                                if (!phase.request.messageText.isNullOrBlank()) {
                                    Spacer(modifier = Modifier.height(2.dp))
                                    Text(
                                        text = "\"${phase.request.messageText}\"",
                                        color = AtikTextSecondary,
                                        fontSize = 12.sp,
                                        maxLines = 2,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        // Progress Countdown Bar
                        val progress = (phase.secondsRemaining / 5f).coerceIn(0f, 1f)
                        LinearProgressIndicator(
                            progress = { progress },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(4.dp)
                                .clip(RoundedCornerShape(2.dp)),
                            color = AtikAmber,
                            trackColor = AtikBorder
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        // Interactive Action Buttons
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            OutlinedButton(
                                onClick = { onAbort("Cancelled by user via safety guardrail") },
                                modifier = Modifier.weight(1f),
                                colors = ButtonDefaults.outlinedButtonColors(
                                    contentColor = AtikDanger
                                ),
                                border = BorderStroke(1.dp, AtikDanger.copy(alpha = 0.6f)),
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Text(
                                    text = "🛑 Abort Action",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }

                            Button(
                                onClick = onConfirm,
                                modifier = Modifier.weight(1f),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = AtikEmerald,
                                    contentColor = Color.White
                                ),
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Text(
                                    text = "⚡ Send Now",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }

                    is SmartActionPhase.LaunchingApp,
                    is SmartActionPhase.LocatingContact,
                    is SmartActionPhase.ComposingMessage,
                    is SmartActionPhase.InitiatingCall,
                    is SmartActionPhase.ExecutingTouch -> {
                        val statusText = when (phase) {
                            is SmartActionPhase.LaunchingApp -> "🚀 Launching ${phase.app.displayName}..."
                            is SmartActionPhase.LocatingContact -> "🔍 Locating contact '${phase.recipient}' in ${phase.app.displayName}..."
                            is SmartActionPhase.ComposingMessage -> "✍️ Composing message for ${phase.recipient}..."
                            is SmartActionPhase.InitiatingCall -> "📞 Initiating ${phase.callType} with ${phase.recipient}..."
                            is SmartActionPhase.ExecutingTouch -> "🤖 ${phase.actionDescription}..."
                            else -> "⚡ Executing Smart Action..."
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(
                                modifier = Modifier.weight(1f),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(12.dp)
                                        .scale(pulseScale)
                                        .clip(CircleShape)
                                        .background(AtikBlue)
                                )
                                Column {
                                    Text(
                                        text = statusText,
                                        color = AtikTextPrimary,
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Bold,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    Text(
                                        text = "Automated Accessibility Engine active",
                                        color = AtikTextSecondary,
                                        fontSize = 11.sp
                                    )
                                }
                            }

                            OutlinedButton(
                                onClick = { onAbort("User stopped execution") },
                                colors = ButtonDefaults.outlinedButtonColors(
                                    contentColor = AtikDanger
                                ),
                                border = BorderStroke(1.dp, AtikDanger.copy(alpha = 0.5f)),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Text(
                                    text = "Stop",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))
                        LinearProgressIndicator(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(3.dp)
                                .clip(RoundedCornerShape(2.dp)),
                            color = AtikBlue,
                            trackColor = AtikBorder
                        )
                    }

                    is SmartActionPhase.Completed -> {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(
                                modifier = Modifier.weight(1f),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Surface(
                                    shape = CircleShape,
                                    color = AtikEmerald.copy(alpha = 0.2f),
                                    modifier = Modifier.size(28.dp)
                                ) {
                                    Box(contentAlignment = Alignment.Center) {
                                        Text(text = "✓", color = AtikEmerald, fontWeight = FontWeight.Black, fontSize = 16.sp)
                                    }
                                }
                                Column {
                                    Text(
                                        text = "Action Completed Successfully",
                                        color = AtikEmerald,
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = phase.feedbackSummary,
                                        color = AtikTextPrimary,
                                        fontSize = 12.sp,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                            }

                            Button(
                                onClick = onDismiss,
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = AtikEmerald.copy(alpha = 0.3f),
                                    contentColor = AtikEmerald
                                ),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Text(text = "Done", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }

                    is SmartActionPhase.Cancelled -> {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "Action Cancelled",
                                    color = AtikDanger,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = phase.reason,
                                    color = AtikTextSecondary,
                                    fontSize = 11.sp,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                            Button(
                                onClick = onDismiss,
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = AtikDanger.copy(alpha = 0.2f),
                                    contentColor = AtikDanger
                                ),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Text(text = "Dismiss", fontSize = 11.sp)
                            }
                        }
                    }

                    is SmartActionPhase.Failed -> {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "Execution Error",
                                    color = AtikDanger,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = phase.error,
                                    color = AtikTextSecondary,
                                    fontSize = 11.sp,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                            Button(
                                onClick = onDismiss,
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = AtikDanger.copy(alpha = 0.2f),
                                    contentColor = AtikDanger
                                ),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Text(text = "Dismiss", fontSize = 11.sp)
                            }
                        }
                    }

                    is SmartActionPhase.Idle -> {}
                }
            }
        }
    }
}
