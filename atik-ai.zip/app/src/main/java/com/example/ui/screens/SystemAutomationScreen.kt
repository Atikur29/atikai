package com.example.ui.screens

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.AirplanemodeActive
import androidx.compose.material.icons.filled.Bluetooth
import androidx.compose.material.icons.filled.ChatBubbleOutline
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.FlashlightOn
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.NotificationsOff
import androidx.compose.material.icons.filled.OpenInNew
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Vibration
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.device.AppShortcutItem
import com.example.device.SoundProfile
import com.example.device.SystemStatusSummary
import com.example.device.SystemSubMenuShortcut
import com.example.gallery.GalleryPhotoItem
import com.example.gallery.PhotoCategory
import com.example.gallery.SemanticSearchResult
import com.example.ui.theme.AtikBlack
import com.example.ui.theme.AtikBorder
import com.example.ui.theme.AtikElectricBlue
import com.example.ui.theme.AtikError
import com.example.ui.theme.AtikNeonAzure
import com.example.ui.theme.AtikNeonCyan
import com.example.ui.theme.AtikSuccess
import com.example.ui.theme.AtikSurface
import com.example.ui.theme.AtikSurfaceHighlight
import com.example.ui.theme.AtikSurfaceVariant
import com.example.ui.theme.AtikTextMuted
import com.example.ui.theme.AtikTextPrimary
import com.example.ui.theme.AtikTextSecondary

enum class SystemAutomationTab(val title: String, val icon: androidx.compose.ui.graphics.vector.ImageVector) {
    SYSTEM_CONTROLS("System & Airplane", Icons.Default.AirplanemodeActive),
    AI_GALLERY("AI Photo Finder", Icons.Default.Image),
    APP_LAUNCHER("Universal Launcher", Icons.Default.Settings)
}

/**
 * Deep System Automation & AI Gallery Hub (Step 20).
 * Dynamic system controls (Airplane Mode, Mobile Data, Wi-Fi, Bluetooth, Flashlight, Sound Profiles),
 * Semantic AI Photo Finder, and Universal App Launcher.
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun SystemAutomationScreen(
    systemStatus: SystemStatusSummary,
    soundProfile: SoundProfile,
    isFlashlightOn: Boolean,
    isAirplaneModeOn: Boolean,
    photos: List<GalleryPhotoItem>,
    selectedCategory: PhotoCategory,
    searchResult: SemanticSearchResult?,
    isAnalyzingPhoto: Boolean,
    appShortcuts: List<AppShortcutItem>,
    systemSubMenus: List<SystemSubMenuShortcut>,
    onToggleAirplaneMode: () -> Unit,
    onOpenMobileDataSettings: () -> Unit,
    onOpenWifiControls: () -> Unit,
    onOpenBluetoothControls: () -> Unit,
    onToggleFlashlight: () -> Unit,
    onSetSoundProfile: (SoundProfile) -> Unit,
    onOpenSubMenu: (String) -> Unit,
    onLaunchApp: (String) -> Unit,
    onSearchPhotos: (String) -> Unit,
    onSelectPhotoCategory: (PhotoCategory) -> Unit,
    onIndexDevicePhoto: (Uri) -> Unit,
    onSendToChat: (String) -> Unit,
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    BackHandler { onBack() }
    val context = LocalContext.current

    var activeTab by remember { mutableStateOf(SystemAutomationTab.SYSTEM_CONTROLS) }
    var gallerySearchQuery by remember { mutableStateOf("") }

    // Zero-permission Android Photo Picker contract (complying strictly with Play Store policies)
    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        if (uri != null) {
            onIndexDevicePhoto(uri)
            Toast.makeText(context, "Indexing photo with Vision AI...", Toast.LENGTH_SHORT).show()
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(AtikBlack)
    ) {
        // Header Bar
        Surface(
            color = AtikSurface,
            border = BorderStroke(1.dp, AtikBorder),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(
                            onClick = onBack,
                            modifier = Modifier.size(36.dp).testTag("btn_sys_back")
                        ) {
                            Icon(
                                Icons.AutoMirrored.Filled.ArrowBack,
                                contentDescription = "Back",
                                tint = AtikTextPrimary,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(6.dp))
                        Box(
                            modifier = Modifier
                                .size(34.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(
                                    Brush.linearGradient(
                                        colors = listOf(AtikElectricBlue, AtikNeonCyan)
                                    )
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                Icons.Default.Settings,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "System Automation & AI Gallery",
                                color = AtikTextPrimary,
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "Deep Hardware, Airplane Mode & Semantic Photos",
                                color = AtikNeonCyan,
                                fontSize = 11.sp
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Navigation Tabs
                ScrollableTabRow(
                    selectedTabIndex = activeTab.ordinal,
                    containerColor = AtikSurfaceVariant,
                    contentColor = AtikNeonCyan,
                    edgePadding = 8.dp,
                    modifier = Modifier.fillMaxWidth().height(38.dp)
                ) {
                    SystemAutomationTab.values().forEach { tab ->
                        Tab(
                            selected = activeTab == tab,
                            onClick = { activeTab = tab },
                            text = {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(tab.icon, contentDescription = null, modifier = Modifier.size(13.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(tab.title, fontSize = 11.5.sp, fontWeight = FontWeight.SemiBold)
                                }
                            },
                            modifier = Modifier.testTag("tab_sys_${tab.name}")
                        )
                    }
                }
            }
        }

        // Tab Content
        Box(modifier = Modifier.fillMaxSize().weight(1f)) {
            when (activeTab) {
                SystemAutomationTab.SYSTEM_CONTROLS -> {
                    SystemControlsTabContent(
                        systemStatus = systemStatus,
                        soundProfile = soundProfile,
                        isFlashlightOn = isFlashlightOn,
                        isAirplaneModeOn = isAirplaneModeOn,
                        systemSubMenus = systemSubMenus,
                        onToggleAirplaneMode = onToggleAirplaneMode,
                        onOpenMobileDataSettings = onOpenMobileDataSettings,
                        onOpenWifiControls = onOpenWifiControls,
                        onOpenBluetoothControls = onOpenBluetoothControls,
                        onToggleFlashlight = onToggleFlashlight,
                        onSetSoundProfile = onSetSoundProfile,
                        onOpenSubMenu = onOpenSubMenu
                    )
                }

                SystemAutomationTab.AI_GALLERY -> {
                    AiGalleryTabContent(
                        photos = photos,
                        selectedCategory = selectedCategory,
                        searchResult = searchResult,
                        searchQuery = gallerySearchQuery,
                        isAnalyzing = isAnalyzingPhoto,
                        onSearchChange = {
                            gallerySearchQuery = it
                            onSearchPhotos(it)
                        },
                        onSelectCategory = onSelectPhotoCategory,
                        onLaunchPhotoPicker = {
                            photoPickerLauncher.launch(
                                PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                            )
                        },
                        onSendToChat = onSendToChat
                    )
                }

                SystemAutomationTab.APP_LAUNCHER -> {
                    UniversalLauncherTabContent(
                        appShortcuts = appShortcuts,
                        systemSubMenus = systemSubMenus,
                        onLaunchApp = onLaunchApp,
                        onOpenSubMenu = onOpenSubMenu
                    )
                }
            }
        }
    }
}

/**
 * Tab 1: System Controls, Airplane Mode, Sound Profiles & Hardware Toggles
 */
@Composable
fun SystemControlsTabContent(
    systemStatus: SystemStatusSummary,
    soundProfile: SoundProfile,
    isFlashlightOn: Boolean,
    isAirplaneModeOn: Boolean,
    systemSubMenus: List<SystemSubMenuShortcut>,
    onToggleAirplaneMode: () -> Unit,
    onOpenMobileDataSettings: () -> Unit,
    onOpenWifiControls: () -> Unit,
    onOpenBluetoothControls: () -> Unit,
    onToggleFlashlight: () -> Unit,
    onSetSoundProfile: (SoundProfile) -> Unit,
    onOpenSubMenu: (String) -> Unit
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(10.dp))
            Text(
                text = "Primary Radio & Hardware Toggles",
                color = AtikTextPrimary,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold
            )
        }

        // Airplane Mode Card
        item {
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = AtikSurface),
                border = BorderStroke(1.dp, if (isAirplaneModeOn) AtikNeonCyan else AtikBorder),
                modifier = Modifier.fillMaxWidth().testTag("card_airplane_mode")
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .clip(CircleShape)
                                .background(if (isAirplaneModeOn) AtikElectricBlue.copy(alpha = 0.2f) else AtikSurfaceVariant),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                Icons.Default.AirplanemodeActive,
                                contentDescription = null,
                                tint = if (isAirplaneModeOn) AtikNeonCyan else AtikTextMuted,
                                modifier = Modifier.size(22.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = "Airplane Mode",
                                color = AtikTextPrimary,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = if (isAirplaneModeOn) "Active (Radios disabled)" else "Disabled (Cellular & Radios on)",
                                color = if (isAirplaneModeOn) AtikNeonCyan else AtikTextSecondary,
                                fontSize = 11.sp
                            )
                        }
                    }

                    Button(
                        onClick = onToggleAirplaneMode,
                        colors = ButtonDefaults.buttonColors(containerColor = AtikSurfaceVariant),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.height(34.dp).testTag("btn_toggle_airplane_mode")
                    ) {
                        Text(
                            text = "Settings",
                            color = AtikNeonCyan,
                            fontSize = 11.5.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Icon(Icons.Default.OpenInNew, null, tint = AtikNeonCyan, modifier = Modifier.size(12.dp))
                    }
                }
            }
        }

        // Hardware Controls Grid (Flashlight, Wi-Fi, Bluetooth, Mobile Data)
        item {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    // Flashlight
                    ControlTile(
                        title = "Flashlight",
                        subtitle = if (isFlashlightOn) "Torch ON" else "Torch OFF",
                        icon = Icons.Default.FlashlightOn,
                        isActive = isFlashlightOn,
                        onClick = onToggleFlashlight,
                        modifier = Modifier.weight(1f).testTag("tile_flashlight")
                    )

                    // Wi-Fi
                    ControlTile(
                        title = "Wi-Fi Panel",
                        subtitle = if (systemStatus.isWifiOn) "Wi-Fi Enabled" else "Wi-Fi Disabled",
                        icon = Icons.Default.Wifi,
                        isActive = systemStatus.isWifiOn,
                        onClick = onOpenWifiControls,
                        modifier = Modifier.weight(1f).testTag("tile_wifi")
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    // Bluetooth
                    ControlTile(
                        title = "Bluetooth",
                        subtitle = if (systemStatus.isBluetoothOn) "Active" else "Disabled",
                        icon = Icons.Default.Bluetooth,
                        isActive = systemStatus.isBluetoothOn,
                        onClick = onOpenBluetoothControls,
                        modifier = Modifier.weight(1f).testTag("tile_bluetooth")
                    )

                    // Mobile Data
                    ControlTile(
                        title = "Mobile Data",
                        subtitle = "Cellular & Roaming",
                        icon = Icons.Default.Settings,
                        isActive = !isAirplaneModeOn,
                        onClick = onOpenMobileDataSettings,
                        modifier = Modifier.weight(1f).testTag("tile_mobile_data")
                    )
                }
            }
        }

        // Sound Profiles Selector Card
        item {
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = AtikSurface),
                border = BorderStroke(1.dp, AtikBorder),
                modifier = Modifier.fillMaxWidth().testTag("card_sound_profiles")
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.VolumeUp, null, tint = AtikNeonAzure, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Audio Sound Profiles",
                                color = AtikTextPrimary,
                                fontSize = 13.5.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        Text(
                            text = "Ringer: ${systemStatus.ringerVolumePct}%",
                            color = AtikTextMuted,
                            fontSize = 11.sp
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        SoundProfile.values().forEach { profile ->
                            val isSelected = soundProfile == profile
                            Surface(
                                onClick = { onSetSoundProfile(profile) },
                                shape = RoundedCornerShape(10.dp),
                                color = if (isSelected) AtikElectricBlue.copy(alpha = 0.35f) else AtikSurfaceVariant,
                                border = BorderStroke(1.dp, if (isSelected) AtikNeonCyan else AtikBorder),
                                modifier = Modifier.weight(1f).testTag("profile_pill_${profile.name}")
                            ) {
                                Column(
                                    modifier = Modifier.padding(vertical = 10.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally
                                ) {
                                    Text(profile.emoji, fontSize = 20.sp)
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = profile.displayName,
                                        color = if (isSelected) AtikNeonCyan else AtikTextPrimary,
                                        fontSize = 11.5.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // System Settings Sub-Menus Quick Grid
        item {
            Column {
                Text(
                    text = "System Settings Deep-Links",
                    color = AtikTextPrimary,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(8.dp))
            }
        }

        items(systemSubMenus.take(6)) { menu ->
            Surface(
                onClick = { onOpenSubMenu(menu.actionIntent) },
                shape = RoundedCornerShape(10.dp),
                color = AtikSurface,
                border = BorderStroke(1.dp, AtikBorder),
                modifier = Modifier.fillMaxWidth().testTag("submenu_${menu.title.replace(" ", "_")}")
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(menu.iconEmoji, fontSize = 18.sp)
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(menu.title, color = AtikTextPrimary, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                            Text(menu.description, color = AtikTextSecondary, fontSize = 11.sp)
                        }
                    }
                    Icon(Icons.Default.OpenInNew, null, tint = AtikNeonCyan, modifier = Modifier.size(16.dp))
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

@Composable
fun ControlTile(
    title: String,
    subtitle: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    isActive: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(12.dp),
        color = if (isActive) AtikSurfaceVariant else AtikSurface,
        border = BorderStroke(1.dp, if (isActive) AtikNeonCyan.copy(alpha = 0.6f) else AtikBorder),
        modifier = modifier
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(32.dp)
                        .clip(CircleShape)
                        .background(if (isActive) AtikNeonCyan.copy(alpha = 0.15f) else AtikSurfaceHighlight),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        icon,
                        contentDescription = null,
                        tint = if (isActive) AtikNeonCyan else AtikTextMuted,
                        modifier = Modifier.size(18.dp)
                    )
                }

                Surface(
                    shape = RoundedCornerShape(4.dp),
                    color = if (isActive) AtikSuccess.copy(alpha = 0.2f) else AtikBorder.copy(alpha = 0.4f)
                ) {
                    Text(
                        text = if (isActive) "ACTIVE" else "READY",
                        color = if (isActive) AtikSuccess else AtikTextMuted,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))
            Text(title, color = AtikTextPrimary, fontSize = 13.sp, fontWeight = FontWeight.Bold)
            Text(subtitle, color = AtikTextSecondary, fontSize = 10.5.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
    }
}

/**
 * Tab 2: AI Gallery & Semantic Photo Finder
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun AiGalleryTabContent(
    photos: List<GalleryPhotoItem>,
    selectedCategory: PhotoCategory,
    searchResult: SemanticSearchResult?,
    searchQuery: String,
    isAnalyzing: Boolean,
    onSearchChange: (String) -> Unit,
    onSelectCategory: (PhotoCategory) -> Unit,
    onLaunchPhotoPicker: () -> Unit,
    onSendToChat: (String) -> Unit
) {
    val displayedPhotos = remember(photos, selectedCategory, searchResult) {
        if (searchResult != null && searchResult.query.isNotBlank()) {
            searchResult.matches
        } else if (selectedCategory == PhotoCategory.ALL) {
            photos
        } else {
            photos.filter { it.category == selectedCategory }
        }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(10.dp))
            // Search Bar & Import Action
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = onSearchChange,
                    placeholder = { Text("Search photos (e.g. 'sunglasses picture', 'documents', 'nature')...", fontSize = 11.5.sp, color = AtikTextMuted) },
                    leadingIcon = { Icon(Icons.Default.Search, null, tint = AtikNeonCyan, modifier = Modifier.size(18.dp)) },
                    trailingIcon = {
                        if (searchQuery.isNotEmpty()) {
                            IconButton(onClick = { onSearchChange("") }) {
                                Icon(Icons.Default.Close, null, tint = AtikTextMuted, modifier = Modifier.size(16.dp))
                            }
                        }
                    },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = AtikNeonCyan,
                        unfocusedBorderColor = AtikBorder
                    ),
                    modifier = Modifier.weight(1f).testTag("input_gallery_search")
                )

                Spacer(modifier = Modifier.width(8.dp))

                IconButton(
                    onClick = onLaunchPhotoPicker,
                    modifier = Modifier
                        .size(48.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(AtikElectricBlue)
                        .testTag("btn_import_device_photo")
                ) {
                    Icon(Icons.Default.AddPhotoAlternate, contentDescription = "Import Photo", tint = Color.White, modifier = Modifier.size(22.dp))
                }
            }
        }

        // Quick Category Filter Chips
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                PhotoCategory.values().forEach { cat ->
                    val isSelected = selectedCategory == cat && searchQuery.isBlank()
                    FilterChip(
                        selected = isSelected,
                        onClick = { onSelectCategory(cat) },
                        label = { Text("${cat.emoji} ${cat.displayName}", fontSize = 11.sp) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = AtikElectricBlue.copy(alpha = 0.4f),
                            selectedLabelColor = AtikNeonCyan
                        ),
                        border = BorderStroke(0.8.dp, if (isSelected) AtikNeonCyan else AtikBorder),
                        modifier = Modifier.testTag("gallery_cat_${cat.name}")
                    )
                }
            }
        }

        if (isAnalyzing) {
            item {
                Card(
                    shape = RoundedCornerShape(10.dp),
                    colors = CardDefaults.cardColors(containerColor = AtikSurfaceVariant),
                    border = BorderStroke(1.dp, AtikNeonCyan.copy(alpha = 0.5f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        CircularProgressIndicator(color = AtikNeonCyan, modifier = Modifier.size(20.dp), strokeWidth = 2.dp)
                        Spacer(modifier = Modifier.width(10.dp))
                        Text("Vision AI analyzing and extracting semantic tags...", color = AtikTextPrimary, fontSize = 12.sp)
                    }
                }
            }
        }

        // Search Metrics Banner
        if (searchResult != null && searchResult.query.isNotBlank()) {
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Found ${displayedPhotos.size} semantic matches for \"${searchResult.query}\"",
                        color = AtikNeonAzure,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "${searchResult.executionTimeMs}ms",
                        color = AtikTextMuted,
                        fontSize = 11.sp
                    )
                }
            }
        }

        // Photo Grid Cards
        items(displayedPhotos) { photo ->
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = AtikSurface),
                border = BorderStroke(1.dp, AtikBorder),
                modifier = Modifier.fillMaxWidth().testTag("gallery_item_${photo.id}")
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(38.dp)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(AtikSurfaceVariant),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(photo.visualIconEmoji, fontSize = 20.sp)
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = photo.title,
                                    color = AtikTextPrimary,
                                    fontSize = 13.5.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "${photo.category.displayName} • ${photo.timestampFormatted}",
                                    color = AtikTextMuted,
                                    fontSize = 10.5.sp
                                )
                            }
                        }

                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = AtikNeonCyan.copy(alpha = 0.15f),
                            border = BorderStroke(0.6.dp, AtikNeonCyan)
                        ) {
                            Text(
                                text = "${photo.confidencePct}% MATCH",
                                color = AtikNeonCyan,
                                fontSize = 9.5.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = photo.description,
                        color = AtikTextSecondary,
                        fontSize = 12.sp,
                        lineHeight = 17.sp
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    // Semantic Tags FlowRow
                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(4.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        photo.semanticTags.forEach { tag ->
                            Surface(
                                shape = RoundedCornerShape(4.dp),
                                color = AtikSurfaceVariant,
                                border = BorderStroke(0.5.dp, AtikBorder)
                            ) {
                                Text(
                                    text = "#$tag",
                                    color = AtikNeonAzure,
                                    fontSize = 10.sp,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End
                    ) {
                        Button(
                            onClick = {
                                onSendToChat("Let's analyze this photo from my gallery:\nTitle: ${photo.title}\nDescription: ${photo.description}\nCategory: ${photo.category.displayName}")
                            },
                            shape = RoundedCornerShape(8.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = AtikSurfaceHighlight),
                            modifier = Modifier.height(32.dp).testTag("btn_discuss_photo_${photo.id}")
                        ) {
                            Icon(Icons.Default.ChatBubbleOutline, null, tint = AtikNeonCyan, modifier = Modifier.size(13.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Discuss in Chat", color = AtikNeonCyan, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

/**
 * Tab 3: Universal App Launcher & System Deep-Links
 */
@Composable
fun UniversalLauncherTabContent(
    appShortcuts: List<AppShortcutItem>,
    systemSubMenus: List<SystemSubMenuShortcut>,
    onLaunchApp: (String) -> Unit,
    onOpenSubMenu: (String) -> Unit
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(10.dp))
            Text(
                text = "Universal App Launchpad",
                color = AtikTextPrimary,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "Launch installed apps and tools directly with one tap or voice",
                color = AtikTextSecondary,
                fontSize = 11.5.sp
            )
        }

        // App Shortcuts Grid
        item {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                appShortcuts.chunked(2).forEach { rowApps ->
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        rowApps.forEach { app ->
                            Surface(
                                onClick = { onLaunchApp(app.packageName) },
                                shape = RoundedCornerShape(12.dp),
                                color = AtikSurface,
                                border = BorderStroke(1.dp, AtikBorder),
                                modifier = Modifier.weight(1f).testTag("app_launch_${app.name}")
                            ) {
                                Row(
                                    modifier = Modifier.padding(12.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(app.iconEmoji, fontSize = 22.sp)
                                    Spacer(modifier = Modifier.width(10.dp))
                                    Column {
                                        Text(app.name, color = AtikTextPrimary, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                        Text(app.category, color = AtikTextMuted, fontSize = 10.5.sp)
                                    }
                                }
                            }
                        }
                        if (rowApps.size == 1) {
                            Spacer(modifier = Modifier.weight(1f))
                        }
                    }
                }
            }
        }

        item {
            Text(
                text = "System Sub-Menus & Diagnostic Panels",
                color = AtikTextPrimary,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold
            )
        }

        items(systemSubMenus) { sub ->
            Surface(
                onClick = { onOpenSubMenu(sub.actionIntent) },
                shape = RoundedCornerShape(10.dp),
                color = AtikSurface,
                border = BorderStroke(1.dp, AtikBorder),
                modifier = Modifier.fillMaxWidth().testTag("system_menu_${sub.title.replace(" ", "_")}")
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(sub.iconEmoji, fontSize = 18.sp)
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(sub.title, color = AtikTextPrimary, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                            Text(sub.description, color = AtikTextSecondary, fontSize = 11.sp)
                        }
                    }
                    Icon(Icons.Default.OpenInNew, null, tint = AtikNeonCyan, modifier = Modifier.size(15.dp))
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}
