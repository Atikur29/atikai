package com.example.ui.components

import android.annotation.SuppressLint
import android.os.Handler
import android.os.Looper
import android.webkit.JavascriptInterface
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.VolumeMute
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import com.example.data.GameProjectEntity
import com.example.ui.theme.AtikBorder
import com.example.ui.theme.AtikElectricBlue
import com.example.ui.theme.AtikNeonAzure
import com.example.ui.theme.AtikNeonCyan
import com.example.ui.theme.AtikSurface
import com.example.ui.theme.AtikSurfaceHighlight
import com.example.ui.theme.AtikTextMuted
import com.example.ui.theme.AtikTextPrimary
import com.example.ui.theme.AtikTextSecondary

/**
 * JavaScript Bridge exposed to the HTML5 Canvas 2D game runtime (Step 26 Requirement 1 & 4).
 */
class AndroidGameBridge(
    private val onScoreReceived: (Int) -> Unit,
    private val onGameOverReceived: (Int, String?) -> Unit,
    private val onSaveStateReceived: (String) -> Unit
) {
    private val mainHandler = Handler(Looper.getMainLooper())

    @JavascriptInterface
    fun postScore(score: Int) {
        mainHandler.post { onScoreReceived(score) }
    }

    @JavascriptInterface
    fun postGameOver(score: Int, stateJson: String?) {
        mainHandler.post { onGameOverReceived(score, stateJson) }
    }

    @JavascriptInterface
    fun postSaveState(stateJson: String) {
        mainHandler.post { onSaveStateReceived(stateJson) }
    }
}

/**
 * Interactive Game Player Canvas running HTML5/Canvas & JS logic directly inside the app (Step 26 Requirement 1, 3, 4).
 */
@SuppressLint("SetJavaScriptEnabled")
@Composable
fun GamePlayerCanvas(
    game: GameProjectEntity,
    onClose: () -> Unit,
    onScoreLogged: (score: Int, durationSeconds: Int) -> Unit,
    onSaveState: (stateJson: String) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var liveScore by remember { mutableIntStateOf(0) }
    var isGameOver by remember { mutableStateOf(false) }
    var isPaused by remember { mutableStateOf(false) }
    var isMuted by remember { mutableStateOf(false) }
    var showSaveToast by remember { mutableStateOf(false) }
    var webViewRef by remember { mutableStateOf<WebView?>(null) }
    var sessionStartTime by remember { mutableStateOf(System.currentTimeMillis()) }

    val bridge = remember(game.id) {
        AndroidGameBridge(
            onScoreReceived = { score ->
                liveScore = score
            },
            onGameOverReceived = { finalScore, stateJson ->
                liveScore = finalScore
                isGameOver = true
                val duration = ((System.currentTimeMillis() - sessionStartTime) / 1000).toInt()
                onScoreLogged(finalScore, duration)
                if (stateJson != null) {
                    onSaveState(stateJson)
                }
            },
            onSaveStateReceived = { stateJson ->
                onSaveState(stateJson)
                showSaveToast = true
            }
        )
    }

    DisposableEffect(game.id) {
        sessionStartTime = System.currentTimeMillis()
        onDispose {
            webViewRef?.destroy()
        }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFF070B14))
    ) {
        // Core HTML5 / Canvas Runtime Engine via AndroidView
        AndroidView(
            modifier = Modifier.fillMaxSize(),
            factory = { ctx ->
                WebView(ctx).apply {
                    settings.apply {
                        javaScriptEnabled = true
                        domStorageEnabled = true
                        useWideViewPort = true
                        loadWithOverviewMode = true
                        mediaPlaybackRequiresUserGesture = false
                        cacheMode = WebSettings.LOAD_NO_CACHE
                    }
                    setBackgroundColor(android.graphics.Color.parseColor("#070B14"))
                    addJavascriptInterface(bridge, "AndroidBridge")
                    webViewClient = WebViewClient()
                    loadDataWithBaseURL("https://game.internal/", game.htmlContent, "text/html", "UTF-8", null)
                    webViewRef = this
                }
            },
            update = { wv ->
                webViewRef = wv
            }
        )

        // Top Game Overlay HUD Bar
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 10.dp)
                .align(Alignment.TopCenter),
            shape = RoundedCornerShape(16.dp),
            color = AtikSurface.copy(alpha = 0.90f),
            border = BorderStroke(1.dp, AtikNeonCyan.copy(alpha = 0.6f))
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Game title badge
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(game.thumbnailEmoji, fontSize = 20.sp)
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                        Text(
                            text = game.title,
                            color = AtikTextPrimary,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = game.genre,
                            color = AtikNeonCyan,
                            fontSize = 10.5.sp
                        )
                    }
                }

                // Scores & High Score Badge
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = AtikSurfaceHighlight,
                        border = BorderStroke(1.dp, AtikBorder)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.EmojiEvents, contentDescription = null, tint = Color(0xFFFFE600), modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "BEST: ${maxOf(game.highScore, liveScore)}",
                                color = Color(0xFFFFE600),
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    // Score Display
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = AtikNeonAzure.copy(alpha = 0.2f),
                        border = BorderStroke(1.dp, AtikNeonCyan)
                    ) {
                        Text(
                            text = "PTS: $liveScore",
                            color = AtikNeonCyan,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                        )
                    }
                }

                // Action Controls (Restart, Mute, Save, Close)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(
                        onClick = {
                            isGameOver = false
                            liveScore = 0
                            sessionStartTime = System.currentTimeMillis()
                            webViewRef?.loadDataWithBaseURL("https://game.internal/", game.htmlContent, "text/html", "UTF-8", null)
                        },
                        modifier = Modifier.size(34.dp)
                    ) {
                        Icon(Icons.Default.Refresh, contentDescription = "Restart", tint = AtikTextPrimary, modifier = Modifier.size(18.dp))
                    }

                    IconButton(
                        onClick = {
                            webViewRef?.evaluateJavascript("notifySaveState({ score: $liveScore, timestamp: Date.now() });", null)
                        },
                        modifier = Modifier.size(34.dp)
                    ) {
                        Icon(Icons.Default.Save, contentDescription = "Save State", tint = AtikTextSecondary, modifier = Modifier.size(18.dp))
                    }

                    IconButton(
                        onClick = onClose,
                        modifier = Modifier.size(34.dp)
                    ) {
                        Icon(Icons.Default.Close, contentDescription = "Exit Game", tint = Color(0xFFFF2A85), modifier = Modifier.size(18.dp))
                    }
                }
            }
        }

        // Saved State Notification Toast
        AnimatedVisibility(
            visible = showSaveToast,
            enter = fadeIn(),
            exit = fadeOut(),
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(bottom = 24.dp)
        ) {
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = AtikSurface.copy(alpha = 0.95f),
                border = BorderStroke(1.dp, Color(0xFF10B981))
            ) {
                Text(
                    text = "💾 Game state saved to Room DB!",
                    color = Color(0xFF10B981),
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
                )
            }
        }

        // Game Over Overlay Card
        AnimatedVisibility(
            visible = isGameOver,
            enter = fadeIn(),
            exit = fadeOut(),
            modifier = Modifier.align(Alignment.Center)
        ) {
            Card(
                modifier = Modifier
                    .fillMaxWidth(0.85f)
                    .padding(16.dp),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = AtikSurface),
                border = BorderStroke(1.5.dp, Color(0xFFFF2A85))
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        text = "🎮 MATCH COMPLETE",
                        color = Color(0xFFFF2A85),
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold
                    )

                    Surface(
                        shape = CircleShape,
                        color = AtikSurfaceHighlight,
                        modifier = Modifier.size(80.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Text(
                                text = "$liveScore",
                                color = AtikNeonCyan,
                                fontSize = 26.sp,
                                fontWeight = FontWeight.ExtraBold
                            )
                        }
                    }

                    if (liveScore > game.highScore && game.highScore > 0) {
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = Color(0xFFFFE600).copy(alpha = 0.2f),
                            border = BorderStroke(1.dp, Color(0xFFFFE600))
                        ) {
                            Text(
                                text = "🏆 NEW HIGH SCORE RECORD!",
                                color = Color(0xFFFFE600),
                                fontSize = 11.5.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                            )
                        }
                    }

                    Text(
                        text = "Score recorded locally in Room Database.",
                        color = AtikTextMuted,
                        fontSize = 11.sp
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Button(
                            onClick = {
                                isGameOver = false
                                liveScore = 0
                                sessionStartTime = System.currentTimeMillis()
                                webViewRef?.loadDataWithBaseURL("https://game.internal/", game.htmlContent, "text/html", "UTF-8", null)
                            },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(containerColor = AtikNeonCyan, contentColor = Color.Black),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text("Play Again", fontWeight = FontWeight.Bold)
                        }

                        Button(
                            onClick = onClose,
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(containerColor = AtikSurfaceHighlight, contentColor = AtikTextPrimary),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text("Game Hub")
                        }
                    }
                }
            }
        }
    }
}
