package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.accessibility.SmartActionType
import com.example.accessibility.TargetMessagingApp
import com.example.data.SmartActionAuditEntity
import com.example.ui.theme.AtikAmber
import com.example.ui.theme.AtikBackground
import com.example.ui.theme.AtikBlack
import com.example.ui.theme.AtikBlue
import com.example.ui.theme.AtikBorder
import com.example.ui.theme.AtikCardBackground
import com.example.ui.theme.AtikDanger
import com.example.ui.theme.AtikEmerald
import com.example.ui.theme.AtikPurple
import com.example.ui.theme.AtikSurfaceHighlight
import com.example.ui.theme.AtikTextPrimary
import com.example.ui.theme.AtikTextSecondary
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Smart Actions & Accessibility Automation Management Hub (Step 24).
 * Coordinates:
 * 1. Accessibility Service State & Settings Link
 * 2. Real-Time Action Simulator & Testing Studio
 * 3. Strict Safety Guardrails & User Consent Configuration
 * 4. Room Database Audit Log & Action History
 */
@Composable
fun SmartActionsSubTabContent(
    isAccessibilityConnected: Boolean,
    smartActionEnabled: Boolean,
    requireConfirmation: Boolean,
    countdownSeconds: Long,
    whatsappEnabled: Boolean,
    imoEnabled: Boolean,
    smsEnabled: Boolean,
    phoneEnabled: Boolean,
    auditLogs: List<SmartActionAuditEntity>,
    onOpenAccessibilitySettings: () -> Unit,
    onToggleSmartAction: (Boolean) -> Unit,
    onToggleRequireConfirmation: (Boolean) -> Unit,
    onSetCountdownSeconds: (Long) -> Unit,
    onToggleWhatsapp: (Boolean) -> Unit,
    onToggleImo: (Boolean) -> Unit,
    onToggleSms: (Boolean) -> Unit,
    onTogglePhone: (Boolean) -> Unit,
    onTriggerTestAction: (TargetMessagingApp, SmartActionType, String, String?) -> Unit,
    onClearAudits: () -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedApp by remember { mutableStateOf(TargetMessagingApp.WHATSAPP) }
    var selectedActionType by remember { mutableStateOf(SmartActionType.SEND_MESSAGE) }
    var recipientInput by remember { mutableStateOf("") }
    var messageInput by remember { mutableStateOf("") }

    LazyColumn(
        modifier = modifier.padding(horizontal = 14.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // 1. Accessibility Service Status Banner
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(
                    containerColor = if (isAccessibilityConnected) Color(0xFF0F261B) else Color(0xFF281C10)
                ),
                border = BorderStroke(
                    1.dp,
                    if (isAccessibilityConnected) AtikEmerald.copy(alpha = 0.5f) else AtikAmber.copy(alpha = 0.6f)
                )
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(14.dp)
                                    .clip(CircleShape)
                                    .background(if (isAccessibilityConnected) AtikEmerald else AtikAmber)
                            )
                            Column {
                                Text(
                                    text = if (isAccessibilityConnected) "Accessibility Service Connected" else "Accessibility Service Required",
                                    color = if (isAccessibilityConnected) AtikEmerald else AtikAmber,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = if (isAccessibilityConnected) "Automated touch & typing engine active" else "Enable in Android Settings for full automation",
                                    color = AtikTextSecondary,
                                    fontSize = 12.sp
                                )
                            }
                        }

                        Button(
                            onClick = onOpenAccessibilitySettings,
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (isAccessibilityConnected) AtikEmerald.copy(alpha = 0.2f) else AtikAmber,
                                contentColor = if (isAccessibilityConnected) AtikEmerald else AtikBlack
                            ),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Text(
                                text = if (isAccessibilityConnected) "Settings" else "Enable Now",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }

        // 2. Action Simulator & Testing Studio
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = AtikCardBackground),
                border = BorderStroke(1.dp, AtikBorder)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(text = "🧪", fontSize = 18.sp)
                        Text(
                            text = "Smart Action Simulator & Tester",
                            color = AtikTextPrimary,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Text(
                        text = "Simulate automated messaging or voice calls to test touch and guardrails.",
                        color = AtikTextSecondary,
                        fontSize = 12.sp,
                        modifier = Modifier.padding(top = 2.dp, bottom = 12.dp)
                    )

                    // Target App Selector
                    Text(
                        text = "SELECT TARGET PLATFORM",
                        color = AtikBlue,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        TargetMessagingApp.values().take(4).forEach { app ->
                            FilterChip(
                                selected = selectedApp == app,
                                onClick = { selectedApp = app },
                                label = {
                                    Text(
                                        text = "${app.iconEmoji} ${app.displayName}",
                                        fontSize = 11.sp,
                                        fontWeight = if (selectedApp == app) FontWeight.Bold else FontWeight.Normal
                                    )
                                },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = AtikBlue.copy(alpha = 0.2f),
                                    selectedLabelColor = AtikBlue
                                ),
                                border = FilterChipDefaults.filterChipBorder(
                                    enabled = true,
                                    selected = selectedApp == app,
                                    borderColor = AtikBorder,
                                    selectedBorderColor = AtikBlue
                                )
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Action Type Selector
                    Text(
                        text = "ACTION TYPE",
                        color = AtikPurple,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        SmartActionType.values().forEach { type ->
                            FilterChip(
                                selected = selectedActionType == type,
                                onClick = { selectedActionType = type },
                                label = {
                                    Text(
                                        text = "${type.icon} ${type.displayName}",
                                        fontSize = 11.sp,
                                        fontWeight = if (selectedActionType == type) FontWeight.Bold else FontWeight.Normal
                                    )
                                },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = AtikPurple.copy(alpha = 0.2f),
                                    selectedLabelColor = AtikPurple
                                ),
                                border = FilterChipDefaults.filterChipBorder(
                                    enabled = true,
                                    selected = selectedActionType == type,
                                    borderColor = AtikBorder,
                                    selectedBorderColor = AtikPurple
                                )
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Recipient Input
                    OutlinedTextField(
                        value = recipientInput,
                        onValueChange = { recipientInput = it },
                        modifier = Modifier.fillMaxWidth(),
                        label = { Text("Recipient (Contact name or phone number)") },
                        placeholder = { Text("e.g. +8801712345678 or Karim") },
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = AtikBlue,
                            unfocusedBorderColor = AtikBorder,
                            focusedContainerColor = AtikSurfaceHighlight,
                            unfocusedContainerColor = AtikSurfaceHighlight
                        ),
                        shape = RoundedCornerShape(10.dp)
                    )

                    if (selectedActionType == SmartActionType.SEND_MESSAGE) {
                        Spacer(modifier = Modifier.height(8.dp))
                        OutlinedTextField(
                            value = messageInput,
                            onValueChange = { messageInput = it },
                            modifier = Modifier.fillMaxWidth(),
                            label = { Text("Message Text") },
                            placeholder = { Text("e.g. Assalamu Alaikum, I'm heading out now.") },
                            maxLines = 3,
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = AtikBlue,
                                unfocusedBorderColor = AtikBorder,
                                focusedContainerColor = AtikSurfaceHighlight,
                                unfocusedContainerColor = AtikSurfaceHighlight
                            ),
                            shape = RoundedCornerShape(10.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Button(
                        onClick = {
                            val targetRecipient = if (recipientInput.isBlank()) "Demo Contact" else recipientInput
                            val targetMsg = if (messageInput.isBlank()) "Test message from Atik AI" else messageInput
                            onTriggerTestAction(selectedApp, selectedActionType, targetRecipient, targetMsg)
                        },
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = AtikBlue,
                            contentColor = Color.White
                        ),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text(
                            text = "⚡ Execute Action Test",
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp
                        )
                    }
                }
            }
        }

        // 3. Safety Guardrails & User Consent Configuration
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = AtikCardBackground),
                border = BorderStroke(1.dp, AtikBorder)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(text = "🛡️", fontSize = 18.sp)
                        Text(
                            text = "Safety Guardrails & User Consent",
                            color = AtikTextPrimary,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Text(
                        text = "Prevent unauthorized background messaging and enforce explicit confirmation.",
                        color = AtikTextSecondary,
                        fontSize = 12.sp,
                        modifier = Modifier.padding(top = 2.dp, bottom = 12.dp)
                    )

                    // Master Toggle
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Enable Smart Actions",
                                color = AtikTextPrimary,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                            Text(
                                text = "Allow messaging and calling automation via voice and text",
                                color = AtikTextSecondary,
                                fontSize = 11.sp
                            )
                        }
                        Switch(
                            checked = smartActionEnabled,
                            onCheckedChange = onToggleSmartAction,
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = AtikEmerald,
                                checkedTrackColor = AtikEmerald.copy(alpha = 0.3f)
                            )
                        )
                    }

                    HorizontalDivider(modifier = Modifier.padding(vertical = 10.dp), color = AtikBorder)

                    // Strict Confirmation Toggle
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Require Consent Confirmation",
                                color = AtikTextPrimary,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                            Text(
                                text = "Show on-screen countdown and abort button before sending",
                                color = AtikTextSecondary,
                                fontSize = 11.sp
                            )
                        }
                        Switch(
                            checked = requireConfirmation,
                            onCheckedChange = onToggleRequireConfirmation,
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = AtikAmber,
                                checkedTrackColor = AtikAmber.copy(alpha = 0.3f)
                            )
                        )
                    }

                    if (requireConfirmation) {
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = "AUTO-SEND COUNTDOWN DELAY",
                            color = AtikTextSecondary,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Row(
                            modifier = Modifier.padding(top = 4.dp),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            listOf(3L, 5L, 10L).forEach { secs ->
                                FilterChip(
                                    selected = countdownSeconds == secs,
                                    onClick = { onSetCountdownSeconds(secs) },
                                    label = { Text("${secs}s") },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = AtikAmber.copy(alpha = 0.2f),
                                        selectedLabelColor = AtikAmber
                                    )
                                )
                            }
                        }
                    }

                    HorizontalDivider(modifier = Modifier.padding(vertical = 10.dp), color = AtikBorder)

                    // Target App Whitelist Toggles
                    Text(
                        text = "PERMITTED TARGET PLATFORMS",
                        color = AtikTextSecondary,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp
                    )
                    Spacer(modifier = Modifier.height(6.dp))

                    AppToggleRow(
                        title = "WhatsApp",
                        icon = "💬",
                        enabled = whatsappEnabled,
                        onToggle = onToggleWhatsapp
                    )
                    AppToggleRow(
                        title = "Imo Messenger",
                        icon = "📞",
                        enabled = imoEnabled,
                        onToggle = onToggleImo
                    )
                    AppToggleRow(
                        title = "SMS / Messages",
                        icon = "✉️",
                        enabled = smsEnabled,
                        onToggle = onToggleSms
                    )
                    AppToggleRow(
                        title = "Phone Dialer",
                        icon = "📱",
                        enabled = phoneEnabled,
                        onToggle = onTogglePhone
                    )
                }
            }
        }

        // 4. Execution Audit Trail & Room Database Log
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(text = "📋", fontSize = 16.sp)
                    Text(
                        text = "Execution Audit Log (${auditLogs.size})",
                        color = AtikTextPrimary,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                if (auditLogs.isNotEmpty()) {
                    OutlinedButton(
                        onClick = onClearAudits,
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = AtikDanger),
                        border = BorderStroke(1.dp, AtikDanger.copy(alpha = 0.5f)),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text(text = "Clear Log", fontSize = 11.sp)
                    }
                }
            }
        }

        if (auditLogs.isEmpty()) {
            item {
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    color = AtikCardBackground,
                    border = BorderStroke(1.dp, AtikBorder)
                ) {
                    Column(
                        modifier = Modifier.padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(text = "🛡️", fontSize = 32.sp)
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "No action audits recorded yet",
                            color = AtikTextPrimary,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Automated voice and text messaging events will appear here with full transparency.",
                            color = AtikTextSecondary,
                            fontSize = 12.sp
                        )
                    }
                }
            }
        } else {
            items(auditLogs, key = { it.id }) { audit ->
                AuditLogItemCard(audit)
            }
        }
    }
}

@Composable
private fun AppToggleRow(
    title: String,
    icon: String,
    enabled: Boolean,
    onToggle: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text(text = icon, fontSize = 15.sp)
            Text(text = title, color = AtikTextPrimary, fontSize = 13.sp)
        }
        Switch(
            checked = enabled,
            onCheckedChange = onToggle,
            colors = SwitchDefaults.colors(
                checkedThumbColor = AtikBlue,
                checkedTrackColor = AtikBlue.copy(alpha = 0.3f)
            )
        )
    }
}

@Composable
private fun AuditLogItemCard(audit: SmartActionAuditEntity) {
    val dateFormat = remember { SimpleDateFormat("MMM d, HH:mm", Locale.getDefault()) }
    val formattedDate = remember(audit.timestamp) { dateFormat.format(Date(audit.timestamp)) }

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = AtikCardBackground),
        border = BorderStroke(1.dp, AtikBorder)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    val app = TargetMessagingApp.values().firstOrNull { it.name == audit.targetApp }
                    Text(text = "${app?.iconEmoji ?: "⚡"} ${app?.displayName ?: audit.targetApp}", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = AtikTextPrimary)
                    Text(text = "• ${audit.actionType}", fontSize = 11.sp, color = AtikBlue)
                }
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = "To: ${audit.recipient}",
                    color = AtikTextPrimary,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold
                )
                if (!audit.messageSnippet.isNullOrBlank()) {
                    Text(
                        text = "\"${audit.messageSnippet}\"",
                        color = AtikTextSecondary,
                        fontSize = 11.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
                Text(
                    text = "$formattedDate • Mode: ${audit.executionMode}",
                    color = AtikTextSecondary.copy(alpha = 0.7f),
                    fontSize = 10.sp
                )
            }

            Surface(
                shape = RoundedCornerShape(8.dp),
                color = when (audit.status) {
                    "SUCCESS" -> AtikEmerald.copy(alpha = 0.15f)
                    "CANCELLED" -> AtikAmber.copy(alpha = 0.15f)
                    else -> AtikDanger.copy(alpha = 0.15f)
                },
                border = BorderStroke(
                    1.dp,
                    when (audit.status) {
                        "SUCCESS" -> AtikEmerald.copy(alpha = 0.4f)
                        "CANCELLED" -> AtikAmber.copy(alpha = 0.4f)
                        else -> AtikDanger.copy(alpha = 0.4f)
                    }
                )
            ) {
                Text(
                    text = audit.status,
                    color = when (audit.status) {
                        "SUCCESS" -> AtikEmerald
                        "CANCELLED" -> AtikAmber
                        else -> AtikDanger
                    },
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                )
            }
        }
    }
}
