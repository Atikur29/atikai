package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Alarm
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ClearAll
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.DoNotDisturbOn
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Lightbulb
import androidx.compose.material.icons.filled.Nightlight
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.NotificationsOff
import androidx.compose.material.icons.filled.OpenInNew
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.RadioButtonUnchecked
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.PushPin
import androidx.compose.material.icons.outlined.PushPin
import androidx.compose.material.icons.filled.EditNote
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.TaskAlt
import androidx.compose.material.icons.filled.Vibration
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material.icons.filled.WbSunny
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.automation.QuietHoursConfig
import com.example.automation.WorkflowActionType
import com.example.automation.WorkflowExecutionReport
import com.example.data.NoteEntity
import com.example.data.ReminderEntity
import com.example.data.RoutineEntity
import com.example.data.TaskItemEntity
import com.example.data.WorkflowEntity
import com.example.data.SmartActionAuditEntity
import com.example.accessibility.TargetMessagingApp
import com.example.accessibility.SmartActionType
import com.example.ui.theme.AtikBlack
import com.example.ui.theme.AtikBorder
import com.example.ui.theme.AtikElectricBlue
import com.example.ui.theme.AtikNeonAzure
import com.example.ui.theme.AtikNeonCyan
import com.example.ui.theme.AtikSuccess
import com.example.ui.theme.AtikSurface
import com.example.ui.theme.AtikSurfaceHighlight
import com.example.ui.theme.AtikSurfaceVariant
import com.example.ui.theme.AtikTextMuted
import com.example.ui.theme.AtikTextPrimary
import com.example.ui.theme.AtikTextSecondary
import com.example.ui.theme.AtikWarning
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

enum class TaskHubSubTab(val title: String, val iconEmoji: String) {
    WORKFLOWS("Workflow Studio", "⚡"),
    SMART_ACTIONS("Smart Actions", "🤖"),
    TASKS("To-Do & Tasks", "📌"),
    NOTES("Notes Vault", "📝"),
    REMINDERS("Task Scheduler", "⏰"),
    ROUTINES("Daily Routines", "🌅"),
    QUIET_HOURS("Quiet Hours & DND", "🌙")
}

/**
 * Smart Automation Workflows & Task Scheduler Engine for Atik AI (Step 22 & Step 23).
 * Integrates:
 * 1. Automated Task Scheduler (AlarmManager exact alarms & reminders)
 * 2. Custom Routine Workflows (Macro trigger sequences in Workflow Studio)
 * 3. Notification & Quiet Hours Manager (DND schedules & custom alerts)
 * 4. Room Offline Storage Engine: Persistent User Notes Vault & Background Sync
 * 5. Clean Professional English UI
 */
@Composable
fun TaskHubScreen(
    tasks: List<TaskItemEntity>,
    routines: List<RoutineEntity>,
    reminders: List<ReminderEntity>,
    workflows: List<WorkflowEntity> = emptyList(),
    notes: List<NoteEntity> = emptyList(),
    isExecutingWorkflow: Boolean = false,
    lastWorkflowReport: WorkflowExecutionReport? = null,
    quietHoursConfig: QuietHoursConfig = QuietHoursConfig(),
    pendingOfflineCount: Int = 0,
    isSyncingData: Boolean = false,
    onSyncNow: () -> Unit = {},
    onAddTask: (title: String, description: String, priority: String, category: String) -> Unit,
    onToggleTaskCompleted: (id: String, isCompleted: Boolean) -> Unit,
    onDeleteTask: (id: String) -> Unit,
    onClearCompletedTasks: () -> Unit,
    onToggleRoutine: (id: String, isEnabled: Boolean) -> Unit,
    onRunRoutineBriefing: (routineType: String) -> Unit,
    onAddReminder: (title: String, timeFormatted: String, isAlarm: Boolean) -> Unit,
    onDeleteReminder: (id: String) -> Unit,
    onAddWorkflow: (name: String, description: String, iconEmoji: String, scheduledTime: String, actions: List<WorkflowActionType>) -> Unit = { _, _, _, _, _ -> },
    onToggleWorkflow: (id: String, isEnabled: Boolean) -> Unit = { _, _ -> },
    onExecuteWorkflowNow: (workflow: WorkflowEntity) -> Unit = {},
    onDeleteWorkflow: (id: String) -> Unit = {},
    onAddNote: (title: String, content: String, category: String) -> Unit = { _, _, _ -> },
    onDeleteNote: (id: String) -> Unit = {},
    onTogglePinNote: (note: NoteEntity) -> Unit = {},
    onToggleQuietHours: (Boolean) -> Unit = {},
    onSetQuietHoursSchedule: (startHour: Int, startMinute: Int, endHour: Int, endMinute: Int) -> Unit = { _, _, _, _ -> },
    onSetDndAllowUrgent: (Boolean) -> Unit = {},
    onSetDndVibrateOnly: (Boolean) -> Unit = {},
    onSetDndSoundEnabled: (Boolean) -> Unit = {},
    onOpenSystemDndSettings: () -> Unit = {},
    onOpenAppNotificationSettings: () -> Unit = {},
    onTestAlertNotification: () -> Unit = {},
    isAccessibilityConnected: Boolean = false,
    smartActionEnabled: Boolean = true,
    requireConfirmation: Boolean = true,
    actionCountdownSeconds: Long = 5L,
    whatsappActionEnabled: Boolean = true,
    imoActionEnabled: Boolean = true,
    smsActionEnabled: Boolean = true,
    phoneActionEnabled: Boolean = true,
    smartAudits: List<SmartActionAuditEntity> = emptyList(),
    onOpenAccessibilitySettings: () -> Unit = {},
    onToggleSmartAction: (Boolean) -> Unit = {},
    onToggleRequireConfirmation: (Boolean) -> Unit = {},
    onSetCountdownSeconds: (Long) -> Unit = {},
    onToggleWhatsapp: (Boolean) -> Unit = {},
    onToggleImo: (Boolean) -> Unit = {},
    onToggleSms: (Boolean) -> Unit = {},
    onTogglePhone: (Boolean) -> Unit = {},
    onTriggerTestAction: (TargetMessagingApp, SmartActionType, String, String?) -> Unit = { _, _, _, _ -> },
    onClearSmartAudits: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    var selectedTab by remember { mutableStateOf(TaskHubSubTab.WORKFLOWS) }
    var taskFilter by remember { mutableStateOf("ALL") }
    var showAddTaskDialog by remember { mutableStateOf(false) }
    var showAddReminderDialog by remember { mutableStateOf(false) }
    var showAddWorkflowDialog by remember { mutableStateOf(false) }
    var showAddNoteDialog by remember { mutableStateOf(false) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(AtikBlack)
    ) {
        // Top Header Card
        Surface(
            color = AtikSurfaceVariant,
            border = BorderStroke(1.dp, AtikBorder),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("⚡", fontSize = 18.sp)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "Automation & Workflow Studio",
                                color = AtikTextPrimary,
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Text(
                            text = "Macro workflows, background task scheduler & DND quiet hours",
                            color = AtikTextMuted,
                            fontSize = 11.5.sp
                        )
                    }

                    // DND Quick Badge
                    val isDndNow = quietHoursConfig.isCurrentlyActive()
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = if (isDndNow) AtikWarning.copy(alpha = 0.15f) else AtikSurfaceHighlight,
                        border = BorderStroke(1.dp, if (isDndNow) AtikWarning else AtikBorder)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(if (isDndNow) "🌙 DND Active" else "🔔 Alerts On", fontSize = 11.sp, color = if (isDndNow) AtikWarning else AtikNeonCyan, fontWeight = FontWeight.SemiBold)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Scrollable Sub-tabs Row
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    TaskHubSubTab.values().forEach { tab ->
                        val isSelected = tab == selectedTab
                        Surface(
                            onClick = { selectedTab = tab },
                            shape = RoundedCornerShape(10.dp),
                            color = if (isSelected) AtikSurfaceHighlight else AtikSurface,
                            border = BorderStroke(1.dp, if (isSelected) AtikNeonCyan else AtikBorder),
                            modifier = Modifier.testTag("task_hub_tab_${tab.name.lowercase()}")
                        ) {
                            Row(
                                modifier = Modifier.padding(vertical = 7.dp, horizontal = 10.dp),
                                horizontalArrangement = Arrangement.Center,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(tab.iconEmoji, fontSize = 13.sp)
                                Spacer(modifier = Modifier.width(5.dp))
                                Text(
                                    text = tab.title,
                                    color = if (isSelected) AtikNeonCyan else AtikTextMuted,
                                    fontSize = 11.sp,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                                )
                            }
                        }
                    }
                }
            }
        }

        // Body Content based on selected tab
        Box(modifier = Modifier.fillMaxSize()) {
            when (selectedTab) {
                TaskHubSubTab.WORKFLOWS -> {
                    WorkflowStudioSubTabContent(
                        workflows = workflows,
                        isExecuting = isExecutingWorkflow,
                        lastReport = lastWorkflowReport,
                        onOpenAddWorkflow = { showAddWorkflowDialog = true },
                        onToggleWorkflow = onToggleWorkflow,
                        onExecuteNow = onExecuteWorkflowNow,
                        onDeleteWorkflow = onDeleteWorkflow
                    )
                }

                TaskHubSubTab.SMART_ACTIONS -> {
                    SmartActionsSubTabContent(
                        isAccessibilityConnected = isAccessibilityConnected,
                        smartActionEnabled = smartActionEnabled,
                        requireConfirmation = requireConfirmation,
                        countdownSeconds = actionCountdownSeconds,
                        whatsappEnabled = whatsappActionEnabled,
                        imoEnabled = imoActionEnabled,
                        smsEnabled = smsActionEnabled,
                        phoneEnabled = phoneActionEnabled,
                        auditLogs = smartAudits,
                        onOpenAccessibilitySettings = onOpenAccessibilitySettings,
                        onToggleSmartAction = onToggleSmartAction,
                        onToggleRequireConfirmation = onToggleRequireConfirmation,
                        onSetCountdownSeconds = onSetCountdownSeconds,
                        onToggleWhatsapp = onToggleWhatsapp,
                        onToggleImo = onToggleImo,
                        onToggleSms = onToggleSms,
                        onTogglePhone = onTogglePhone,
                        onTriggerTestAction = onTriggerTestAction,
                        onClearAudits = onClearSmartAudits
                    )
                }

                TaskHubSubTab.TASKS -> {
                    TasksSubTabContent(
                        tasks = tasks,
                        taskFilter = taskFilter,
                        onFilterChange = { taskFilter = it },
                        onToggleCompleted = onToggleTaskCompleted,
                        onDeleteTask = onDeleteTask,
                        onOpenAddTask = { showAddTaskDialog = true },
                        onClearCompleted = onClearCompletedTasks
                    )
                }

                TaskHubSubTab.REMINDERS -> {
                    RemindersSubTabContent(
                        reminders = reminders,
                        onAddReminderClick = { showAddReminderDialog = true },
                        onDeleteReminder = onDeleteReminder
                    )
                }

                TaskHubSubTab.ROUTINES -> {
                    RoutinesSubTabContent(
                        routines = routines,
                        onToggleRoutine = onToggleRoutine,
                        onRunBriefing = onRunRoutineBriefing
                    )
                }

                TaskHubSubTab.NOTES -> {
                    NotesVaultSubTabContent(
                        notes = notes,
                        pendingOfflineCount = pendingOfflineCount,
                        isSyncingData = isSyncingData,
                        onOpenAddNote = { showAddNoteDialog = true },
                        onDeleteNote = onDeleteNote,
                        onTogglePinNote = onTogglePinNote,
                        onSyncNow = onSyncNow
                    )
                }

                TaskHubSubTab.QUIET_HOURS -> {
                    QuietHoursSubTabContent(
                        config = quietHoursConfig,
                        onToggleQuietHours = onToggleQuietHours,
                        onSetSchedule = onSetQuietHoursSchedule,
                        onSetAllowUrgent = onSetDndAllowUrgent,
                        onSetVibrateOnly = onSetDndVibrateOnly,
                        onSetSoundEnabled = onSetDndSoundEnabled,
                        onOpenSystemDnd = onOpenSystemDndSettings,
                        onOpenAppNotifications = onOpenAppNotificationSettings,
                        onTestAlert = onTestAlertNotification
                    )
                }
            }

            // Floating Action Button for Adding
            if (selectedTab == TaskHubSubTab.TASKS) {
                FloatingActionButton(
                    onClick = { showAddTaskDialog = true },
                    containerColor = AtikElectricBlue,
                    contentColor = Color.White,
                    modifier = Modifier
                        .align(Alignment.BottomEnd)
                        .padding(20.dp)
                        .testTag("task_fab_add")
                ) {
                    Icon(Icons.Default.Add, contentDescription = "Add New Task")
                }
            } else if (selectedTab == TaskHubSubTab.WORKFLOWS) {
                FloatingActionButton(
                    onClick = { showAddWorkflowDialog = true },
                    containerColor = AtikElectricBlue,
                    contentColor = Color.White,
                    modifier = Modifier
                        .align(Alignment.BottomEnd)
                        .padding(20.dp)
                        .testTag("workflow_fab_add")
                ) {
                    Icon(Icons.Default.Add, contentDescription = "Create Macro Workflow")
                }
            } else if (selectedTab == TaskHubSubTab.NOTES) {
                FloatingActionButton(
                    onClick = { showAddNoteDialog = true },
                    containerColor = AtikElectricBlue,
                    contentColor = Color.White,
                    modifier = Modifier
                        .align(Alignment.BottomEnd)
                        .padding(20.dp)
                        .testTag("note_fab_add")
                ) {
                    Icon(Icons.Default.Add, contentDescription = "Add Offline Note")
                }
            }
        }
    }

    // Modal: Add Task Dialog
    if (showAddTaskDialog) {
        AddTaskDialog(
            onDismiss = { showAddTaskDialog = false },
            onConfirm = { title, desc, priority, category ->
                onAddTask(title, desc, priority, category)
                showAddTaskDialog = false
            }
        )
    }

    // Modal: Add Reminder Dialog
    if (showAddReminderDialog) {
        AddReminderDialog(
            onDismiss = { showAddReminderDialog = false },
            onConfirm = { title, time, isAlarm ->
                onAddReminder(title, time, isAlarm)
                showAddReminderDialog = false
            }
        )
    }

    // Modal: Add Custom Macro Workflow Dialog (Step 22 Requirement 2)
    if (showAddWorkflowDialog) {
        AddWorkflowDialog(
            onDismiss = { showAddWorkflowDialog = false },
            onConfirm = { name, desc, emoji, time, actions ->
                onAddWorkflow(name, desc, emoji, time, actions)
                showAddWorkflowDialog = false
            }
        )
    }

    // Modal: Add Local Offline Note Dialog (Step 23 Requirement 1)
    if (showAddNoteDialog) {
        AddNoteDialog(
            onDismiss = { showAddNoteDialog = false },
            onConfirm = { title, content, category ->
                onAddNote(title, content, category)
                showAddNoteDialog = false
            }
        )
    }
}

// =============================================================================
// 1. WORKFLOW STUDIO SUB-TAB (Step 22 Requirement 2)
// =============================================================================

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun WorkflowStudioSubTabContent(
    workflows: List<WorkflowEntity>,
    isExecuting: Boolean,
    lastReport: WorkflowExecutionReport?,
    onOpenAddWorkflow: () -> Unit,
    onToggleWorkflow: (String, Boolean) -> Unit,
    onExecuteNow: (WorkflowEntity) -> Unit,
    onDeleteWorkflow: (String) -> Unit
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Hero Overview Card
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = AtikSurfaceVariant),
                border = BorderStroke(1.dp, AtikBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text("⚡", fontSize = 20.sp)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "Custom Routine Workflows",
                                    color = AtikTextPrimary,
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            Text(
                                text = "Configurable multi-step macros with system triggers",
                                color = AtikTextMuted,
                                fontSize = 11.5.sp
                            )
                        }

                        Button(
                            onClick = onOpenAddWorkflow,
                            colors = ButtonDefaults.buttonColors(containerColor = AtikElectricBlue),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.testTag("btn_open_add_workflow")
                        ) {
                            Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("New Macro", fontSize = 11.5.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Text(
                        text = "Build combined routines like Morning Routine: read live news + check system status + turn on Wi-Fi with automated daily schedules.",
                        color = AtikTextSecondary,
                        fontSize = 12.sp,
                        lineHeight = 17.sp
                    )
                }
            }
        }

        // Active Execution Status Card
        if (isExecuting) {
            item {
                Card(
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = AtikSurfaceHighlight),
                    border = BorderStroke(1.dp, AtikNeonCyan),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        CircularProgressIndicator(
                            color = AtikNeonCyan,
                            strokeWidth = 2.5.dp,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = "Executing Macro Workflow...",
                                color = AtikNeonCyan,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "Running sequential actions and verifying device telemetry",
                                color = AtikTextMuted,
                                fontSize = 11.sp
                            )
                        }
                    }
                }
            }
        }

        // Last Workflow Execution Report Banner
        if (lastReport != null) {
            item {
                Card(
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = if (lastReport.isSuccess) AtikSurfaceVariant else AtikSurfaceHighlight
                    ),
                    border = BorderStroke(
                        1.dp,
                        if (lastReport.isSuccess) AtikSuccess.copy(alpha = 0.5f) else AtikWarning.copy(alpha = 0.5f)
                    ),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(if (lastReport.isSuccess) "✅" else "⚠️", fontSize = 16.sp)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "Last Run: ${lastReport.workflowName}",
                                    color = AtikTextPrimary,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            Text(
                                text = SimpleDateFormat("hh:mm a", Locale.US).format(Date(lastReport.timestamp)),
                                color = AtikTextMuted,
                                fontSize = 11.sp
                            )
                        }

                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = lastReport.summaryMessage,
                            color = AtikNeonAzure,
                            fontSize = 11.5.sp,
                            fontWeight = FontWeight.Medium
                        )

                        if (lastReport.executedSteps.isNotEmpty()) {
                            Spacer(modifier = Modifier.height(6.dp))
                            Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                lastReport.executedSteps.forEach { step ->
                                    Text(
                                        text = "• $step",
                                        color = AtikTextSecondary,
                                        fontSize = 10.5.sp
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // List of Workflows
        if (workflows.isEmpty()) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 36.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("⚡", fontSize = 40.sp)
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = "No Workflows Configured",
                            color = AtikTextPrimary,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Tap 'New Macro' to compose your first automated sequence.",
                            color = AtikTextMuted,
                            fontSize = 12.sp
                        )
                    }
                }
            }
        } else {
            items(workflows, key = { it.id }) { workflow ->
                WorkflowCardItem(
                    workflow = workflow,
                    isExecuting = isExecuting,
                    onToggle = { onToggleWorkflow(workflow.id, it) },
                    onRunNow = { onExecuteNow(workflow) },
                    onDelete = { onDeleteWorkflow(workflow.id) }
                )
            }
        }

        item { Spacer(modifier = Modifier.height(80.dp)) }
    }
}

/**
 * Individual Macro Workflow Card with Step Pills and Controls.
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun WorkflowCardItem(
    workflow: WorkflowEntity,
    isExecuting: Boolean,
    onToggle: (Boolean) -> Unit,
    onRunNow: () -> Unit,
    onDelete: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = AtikSurfaceVariant),
        border = BorderStroke(1.dp, if (workflow.isEnabled) AtikBorder else AtikBorder.copy(alpha = 0.4f)),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("workflow_item_${workflow.id}")
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            // Top Row: Emoji, Name, Enabled Switch
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = AtikSurfaceHighlight,
                        border = BorderStroke(1.dp, AtikBorder),
                        modifier = Modifier.size(38.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Text(workflow.iconEmoji, fontSize = 20.sp)
                        }
                    }

                    Spacer(modifier = Modifier.width(10.dp))

                    Column {
                        Text(
                            text = workflow.name,
                            color = if (workflow.isEnabled) AtikTextPrimary else AtikTextMuted,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                Icons.Default.Schedule,
                                contentDescription = null,
                                tint = AtikNeonCyan,
                                modifier = Modifier.size(12.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "Daily at ${workflow.scheduledTime}",
                                color = AtikNeonCyan,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Medium
                            )
                        }
                    }
                }

                Switch(
                    checked = workflow.isEnabled,
                    onCheckedChange = onToggle,
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = AtikNeonCyan,
                        checkedTrackColor = AtikElectricBlue
                    ),
                    modifier = Modifier.testTag("switch_workflow_${workflow.id}")
                )
            }

            if (workflow.description.isNotBlank()) {
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = workflow.description,
                    color = AtikTextSecondary,
                    fontSize = 12.sp,
                    lineHeight = 16.sp
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Action Sequence FlowRow
            val actions = workflow.actionsCsv.split(",")
                .mapNotNull { WorkflowActionType.fromId(it) }

            Text("Macro Action Sequence:", color = AtikTextMuted, fontSize = 10.5.sp, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(4.dp))

            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                actions.forEachIndexed { index, action ->
                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = AtikSurfaceHighlight,
                        border = BorderStroke(0.7.dp, AtikBorder)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("${index + 1}. ${action.iconEmoji} ${action.displayName}", color = AtikTextPrimary, fontSize = 10.5.sp)
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Footer: Last run status & Actions
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = if (workflow.lastRunTimestamp > 0) {
                        "Last: ${SimpleDateFormat("MMM d, h:mm a", Locale.US).format(Date(workflow.lastRunTimestamp))}"
                    } else {
                        "Status: ${workflow.lastRunResult}"
                    },
                    color = AtikTextMuted,
                    fontSize = 10.5.sp,
                    modifier = Modifier.weight(1f)
                )

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    IconButton(
                        onClick = onDelete,
                        modifier = Modifier
                            .size(32.dp)
                            .testTag("btn_delete_workflow_${workflow.id}")
                    ) {
                        Icon(Icons.Default.Delete, contentDescription = "Delete", tint = AtikTextMuted, modifier = Modifier.size(18.dp))
                    }

                    Button(
                        onClick = onRunNow,
                        enabled = !isExecuting,
                        shape = RoundedCornerShape(8.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = AtikSurfaceHighlight,
                            contentColor = AtikNeonCyan
                        ),
                        border = BorderStroke(1.dp, AtikNeonCyan.copy(alpha = 0.6f)),
                        modifier = Modifier.testTag("btn_run_workflow_${workflow.id}")
                    ) {
                        Icon(Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(15.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Run Now", fontSize = 11.5.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

/**
 * Modal dialog for building custom macro workflows.
 */
@Composable
private fun AddWorkflowDialog(
    onDismiss: () -> Unit,
    onConfirm: (name: String, desc: String, emoji: String, time: String, actions: List<WorkflowActionType>) -> Unit
) {
    var name by remember { mutableStateOf("") }
    var desc by remember { mutableStateOf("") }
    var selectedEmoji by remember { mutableStateOf("🌅") }
    var scheduledTime by remember { mutableStateOf("07:30 AM") }
    val selectedActions = remember {
        mutableStateListOf(
            WorkflowActionType.READ_LIVE_NEWS,
            WorkflowActionType.CHECK_SYSTEM_STATUS,
            WorkflowActionType.TURN_ON_WIFI
        )
    }

    val emojiOptions = listOf("🌅", "⚡", "🌙", "🚀", "🥋", "📊", "🔔", "💡", "🛡️")

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = AtikSurfaceVariant,
        title = {
            Text(
                text = "Create Macro Workflow",
                color = AtikTextPrimary,
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp
            )
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Workflow Name
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Workflow Name (e.g. Morning Routine) *") },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = AtikNeonCyan,
                        unfocusedBorderColor = AtikBorder
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("input_workflow_name")
                )

                // Description
                OutlinedTextField(
                    value = desc,
                    onValueChange = { desc = it },
                    label = { Text("Description (Optional)") },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = AtikNeonCyan,
                        unfocusedBorderColor = AtikBorder
                    ),
                    modifier = Modifier.fillMaxWidth()
                )

                // Emoji Picker Row
                Text("Select Workflow Icon:", color = AtikTextSecondary, fontSize = 11.5.sp)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    emojiOptions.forEach { em ->
                        val isSel = em == selectedEmoji
                        Surface(
                            onClick = { selectedEmoji = em },
                            shape = RoundedCornerShape(8.dp),
                            color = if (isSel) AtikSurfaceHighlight else AtikSurface,
                            border = BorderStroke(1.dp, if (isSel) AtikNeonCyan else AtikBorder),
                            modifier = Modifier.size(38.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Text(em, fontSize = 18.sp)
                            }
                        }
                    }
                }

                // Scheduled Time
                OutlinedTextField(
                    value = scheduledTime,
                    onValueChange = { scheduledTime = it },
                    label = { Text("Scheduled Daily Time (e.g. 07:30 AM)") },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = AtikNeonCyan,
                        unfocusedBorderColor = AtikBorder
                    ),
                    modifier = Modifier.fillMaxWidth()
                )

                // Multi-Step Action Checklist
                Text("Select Action Steps to Execute:", color = AtikTextSecondary, fontSize = 12.sp, fontWeight = FontWeight.Bold)

                WorkflowActionType.values().forEach { action ->
                    val isChecked = selectedActions.contains(action)
                    Surface(
                        onClick = {
                            if (isChecked) {
                                if (selectedActions.size > 1) selectedActions.remove(action)
                            } else {
                                selectedActions.add(action)
                            }
                        },
                        shape = RoundedCornerShape(8.dp),
                        color = if (isChecked) AtikSurfaceHighlight else AtikSurface,
                        border = BorderStroke(1.dp, if (isChecked) AtikNeonCyan else AtikBorder),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(action.iconEmoji, fontSize = 16.sp)
                            Spacer(modifier = Modifier.width(8.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = action.displayName,
                                    color = if (isChecked) AtikTextPrimary else AtikTextMuted,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.SemiBold
                                )
                                Text(
                                    text = action.description,
                                    color = AtikTextMuted,
                                    fontSize = 10.sp
                                )
                            }
                            Icon(
                                if (isChecked) Icons.Default.CheckCircle else Icons.Default.RadioButtonUnchecked,
                                contentDescription = null,
                                tint = if (isChecked) AtikNeonCyan else AtikTextMuted,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (name.isNotBlank() && selectedActions.isNotEmpty()) {
                        onConfirm(name, desc, selectedEmoji, scheduledTime, selectedActions.toList())
                    }
                },
                enabled = name.isNotBlank() && selectedActions.isNotEmpty(),
                colors = ButtonDefaults.buttonColors(containerColor = AtikElectricBlue),
                modifier = Modifier.testTag("dialog_confirm_add_workflow")
            ) {
                Text("Save Macro Workflow", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel", color = AtikTextMuted)
            }
        }
    )
}

// =============================================================================
// 2. QUIET HOURS & NOTIFICATION MANAGER SUB-TAB (Step 22 Requirement 3)
// =============================================================================

@Composable
private fun QuietHoursSubTabContent(
    config: QuietHoursConfig,
    onToggleQuietHours: (Boolean) -> Unit,
    onSetSchedule: (startHour: Int, startMinute: Int, endHour: Int, endMinute: Int) -> Unit,
    onSetAllowUrgent: (Boolean) -> Unit,
    onSetVibrateOnly: (Boolean) -> Unit,
    onSetSoundEnabled: (Boolean) -> Unit,
    onOpenSystemDnd: () -> Unit,
    onOpenAppNotifications: () -> Unit,
    onTestAlert: () -> Unit
) {
    val isDndActive = config.isCurrentlyActive()

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Hero Card
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = AtikSurfaceVariant),
                border = BorderStroke(1.dp, if (isDndActive) AtikWarning else AtikBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("🌙", fontSize = 24.sp)
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = "Scheduled Quiet Hours & DND",
                                    color = AtikTextPrimary,
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = if (isDndActive) "ACTIVE • Silencing non-urgent alerts" else "Standby (${config.formattedStartTime} - ${config.formattedEndTime})",
                                    color = if (isDndActive) AtikWarning else AtikTextMuted,
                                    fontSize = 11.5.sp,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                        }

                        Switch(
                            checked = config.isEnabled,
                            onCheckedChange = onToggleQuietHours,
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = AtikWarning,
                                checkedTrackColor = AtikWarning.copy(alpha = 0.5f)
                            ),
                            modifier = Modifier.testTag("switch_master_quiet_hours")
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = "Automatically suppress loud notifications, background voice responses, and chimes during your designated rest hours.",
                        color = AtikTextSecondary,
                        fontSize = 12.sp,
                        lineHeight = 17.sp
                    )
                }
            }
        }

        // Schedule Configuration Card
        item {
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = AtikSurfaceVariant),
                border = BorderStroke(1.dp, AtikBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Quiet Window Schedule",
                        color = AtikTextPrimary,
                        fontSize = 13.5.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Configured for daily recurring quiet hours from ${config.formattedStartTime} to ${config.formattedEndTime}",
                        color = AtikNeonCyan,
                        fontSize = 11.5.sp
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        // Start Time Selector
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = AtikSurfaceHighlight,
                            border = BorderStroke(1.dp, AtikBorder),
                            modifier = Modifier.weight(1f)
                        ) {
                            Column(modifier = Modifier.padding(12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                Text("Quiet Begins", color = AtikTextMuted, fontSize = 11.sp)
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(config.formattedStartTime, color = AtikTextPrimary, fontSize = 15.sp, fontWeight = FontWeight.Bold)

                                Spacer(modifier = Modifier.height(8.dp))
                                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    Button(
                                        onClick = {
                                            val newHour = (config.startHour - 1 + 24) % 24
                                            onSetSchedule(newHour, config.startMinute, config.endHour, config.endMinute)
                                        },
                                        colors = ButtonDefaults.buttonColors(containerColor = AtikSurface),
                                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 2.dp),
                                        modifier = Modifier.height(28.dp)
                                    ) { Text("-1h", fontSize = 10.sp) }

                                    Button(
                                        onClick = {
                                            val newHour = (config.startHour + 1) % 24
                                            onSetSchedule(newHour, config.startMinute, config.endHour, config.endMinute)
                                        },
                                        colors = ButtonDefaults.buttonColors(containerColor = AtikSurface),
                                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 2.dp),
                                        modifier = Modifier.height(28.dp)
                                    ) { Text("+1h", fontSize = 10.sp) }
                                }
                            }
                        }

                        // End Time Selector
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = AtikSurfaceHighlight,
                            border = BorderStroke(1.dp, AtikBorder),
                            modifier = Modifier.weight(1f)
                        ) {
                            Column(modifier = Modifier.padding(12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                Text("Quiet Ends", color = AtikTextMuted, fontSize = 11.sp)
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(config.formattedEndTime, color = AtikTextPrimary, fontSize = 15.sp, fontWeight = FontWeight.Bold)

                                Spacer(modifier = Modifier.height(8.dp))
                                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    Button(
                                        onClick = {
                                            val newHour = (config.endHour - 1 + 24) % 24
                                            onSetSchedule(config.startHour, config.startMinute, newHour, config.endMinute)
                                        },
                                        colors = ButtonDefaults.buttonColors(containerColor = AtikSurface),
                                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 2.dp),
                                        modifier = Modifier.height(28.dp)
                                    ) { Text("-1h", fontSize = 10.sp) }

                                    Button(
                                        onClick = {
                                            val newHour = (config.endHour + 1) % 24
                                            onSetSchedule(config.startHour, config.startMinute, newHour, config.endMinute)
                                        },
                                        colors = ButtonDefaults.buttonColors(containerColor = AtikSurface),
                                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 2.dp),
                                        modifier = Modifier.height(28.dp)
                                    ) { Text("+1h", fontSize = 10.sp) }
                                }
                            }
                        }
                    }
                }
            }
        }

        // Custom Notification & Alert Policies
        item {
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = AtikSurfaceVariant),
                border = BorderStroke(1.dp, AtikBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        text = "Alert Policies & Exceptions",
                        color = AtikTextPrimary,
                        fontSize = 13.5.sp,
                        fontWeight = FontWeight.Bold
                    )

                    // Allow Urgent
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Allow Urgent Tasks & Alarms", color = AtikTextPrimary, fontSize = 12.5.sp, fontWeight = FontWeight.SemiBold)
                            Text("Exact alarms and priority reminders bypass Quiet Hours", color = AtikTextMuted, fontSize = 11.sp)
                        }
                        Switch(
                            checked = config.allowUrgentTasks,
                            onCheckedChange = onSetAllowUrgent,
                            colors = SwitchDefaults.colors(checkedThumbColor = AtikNeonCyan, checkedTrackColor = AtikElectricBlue)
                        )
                    }

                    // Vibrate Only
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Vibrate Only Mode", color = AtikTextPrimary, fontSize = 12.5.sp, fontWeight = FontWeight.SemiBold)
                            Text("Use gentle haptic vibrations instead of sound alerts", color = AtikTextMuted, fontSize = 11.sp)
                        }
                        Switch(
                            checked = config.vibrateOnly,
                            onCheckedChange = onSetVibrateOnly,
                            colors = SwitchDefaults.colors(checkedThumbColor = AtikNeonCyan, checkedTrackColor = AtikElectricBlue)
                        )
                    }

                    // Notification Sound
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Standard Sound Alerts", color = AtikTextPrimary, fontSize = 12.5.sp, fontWeight = FontWeight.SemiBold)
                            Text("Play discrete system tone when outside Quiet Hours", color = AtikTextMuted, fontSize = 11.sp)
                        }
                        Switch(
                            checked = config.notificationSoundEnabled,
                            onCheckedChange = onSetSoundEnabled,
                            colors = SwitchDefaults.colors(checkedThumbColor = AtikNeonCyan, checkedTrackColor = AtikElectricBlue)
                        )
                    }
                }
            }
        }

        // Quick System Settings & Test Notification
        item {
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = AtikSurfaceVariant),
                border = BorderStroke(1.dp, AtikBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text(
                        text = "Android System Integration & Audition",
                        color = AtikTextPrimary,
                        fontSize = 13.5.sp,
                        fontWeight = FontWeight.Bold
                    )

                    Button(
                        onClick = onTestAlert,
                        colors = ButtonDefaults.buttonColors(containerColor = AtikElectricBlue),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("btn_test_alert_notification")
                    ) {
                        Icon(Icons.Default.NotificationsActive, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Dispatch Test Alert Notification", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = onOpenSystemDnd,
                            colors = ButtonDefaults.buttonColors(containerColor = AtikSurfaceHighlight),
                            shape = RoundedCornerShape(10.dp),
                            border = BorderStroke(1.dp, AtikBorder),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("btn_system_dnd_settings")
                        ) {
                            Text("DND Policy", color = AtikTextPrimary, fontSize = 11.5.sp)
                        }

                        Button(
                            onClick = onOpenAppNotifications,
                            colors = ButtonDefaults.buttonColors(containerColor = AtikSurfaceHighlight),
                            shape = RoundedCornerShape(10.dp),
                            border = BorderStroke(1.dp, AtikBorder),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("btn_app_notification_settings")
                        ) {
                            Text("Channels", color = AtikTextPrimary, fontSize = 11.5.sp)
                        }
                    }
                }
            }
        }

        item { Spacer(modifier = Modifier.height(80.dp)) }
    }
}

// =============================================================================
// 3. TASKS SUB-TAB
// =============================================================================

@Composable
private fun TasksSubTabContent(
    tasks: List<TaskItemEntity>,
    taskFilter: String,
    onFilterChange: (String) -> Unit,
    onToggleCompleted: (String, Boolean) -> Unit,
    onDeleteTask: (String) -> Unit,
    onOpenAddTask: () -> Unit,
    onClearCompleted: () -> Unit
) {
    val filteredTasks = when (taskFilter) {
        "PENDING" -> tasks.filter { !it.isCompleted }
        "HIGH" -> tasks.filter { it.priority == "HIGH" || it.priority == "URGENT" }
        "COMPLETED" -> tasks.filter { it.isCompleted }
        else -> tasks
    }

    Column(modifier = Modifier.fillMaxSize()) {
        // Filter Chips Row
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(horizontal = 14.dp, vertical = 10.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            val filters = listOf(
                "ALL" to "All Tasks (${tasks.size})",
                "PENDING" to "Pending (${tasks.count { !it.isCompleted }})",
                "HIGH" to "High Priority (${tasks.count { it.priority == "HIGH" || it.priority == "URGENT" }})",
                "COMPLETED" to "Completed (${tasks.count { it.isCompleted }})"
            )

            filters.forEach { (id, label) ->
                val isSelected = id == taskFilter
                Surface(
                    onClick = { onFilterChange(id) },
                    shape = RoundedCornerShape(12.dp),
                    color = if (isSelected) AtikSurfaceHighlight else AtikSurfaceVariant,
                    border = BorderStroke(1.dp, if (isSelected) AtikNeonCyan else AtikBorder),
                    modifier = Modifier.testTag("filter_chip_$id")
                ) {
                    Text(
                        text = label,
                        color = if (isSelected) AtikNeonCyan else AtikTextMuted,
                        fontSize = 11.5.sp,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                    )
                }
            }

            if (tasks.any { it.isCompleted }) {
                TextButton(
                    onClick = onClearCompleted,
                    modifier = Modifier.testTag("clear_completed_tasks_btn")
                ) {
                    Text("Clear Done", color = AtikNeonAzure, fontSize = 11.sp)
                }
            }
        }

        if (filteredTasks.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(32.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("📌", fontSize = 36.sp)
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = "No tasks found in this view",
                        color = AtikTextPrimary,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Tap + to add a prioritized task or say \"Add task: [title]\"",
                        color = AtikTextMuted,
                        fontSize = 12.sp
                    )
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(horizontal = 14.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(filteredTasks, key = { it.id }) { task ->
                    TaskCardItem(
                        task = task,
                        onToggle = { onToggleCompleted(task.id, !task.isCompleted) },
                        onDelete = { onDeleteTask(task.id) }
                    )
                }
                item { Spacer(modifier = Modifier.height(72.dp)) }
            }
        }
    }
}

@Composable
private fun TaskCardItem(
    task: TaskItemEntity,
    onToggle: () -> Unit,
    onDelete: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("task_item_${task.id}"),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (task.isCompleted) AtikSurface.copy(alpha = 0.6f) else AtikSurfaceVariant
        ),
        border = BorderStroke(
            1.dp,
            if (task.isCompleted) AtikBorder.copy(alpha = 0.5f) else AtikBorder
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = onToggle,
                modifier = Modifier
                    .size(28.dp)
                    .testTag("task_checkbox_${task.id}")
            ) {
                if (task.isCompleted) {
                    Icon(
                        Icons.Default.CheckCircle,
                        contentDescription = "Completed",
                        tint = AtikSuccess,
                        modifier = Modifier.size(22.dp)
                    )
                } else {
                    Icon(
                        Icons.Default.RadioButtonUnchecked,
                        contentDescription = "Pending",
                        tint = AtikTextMuted,
                        modifier = Modifier.size(22.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.width(10.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = task.title,
                    color = if (task.isCompleted) AtikTextMuted else AtikTextPrimary,
                    fontSize = 13.5.sp,
                    fontWeight = FontWeight.SemiBold,
                    textDecoration = if (task.isCompleted) TextDecoration.LineThrough else null,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )

                if (task.description.isNotBlank()) {
                    Text(
                        text = task.description,
                        color = AtikTextMuted,
                        fontSize = 11.5.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                Spacer(modifier = Modifier.height(6.dp))

                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    val (pColor, pBg) = when (task.priority) {
                        "URGENT" -> Color(0xFFFF5252) to Color(0x33FF5252)
                        "HIGH" -> AtikWarning to AtikWarning.copy(alpha = 0.2f)
                        "LOW" -> AtikTextMuted to AtikSurfaceHighlight
                        else -> AtikNeonCyan to AtikNeonCyan.copy(alpha = 0.15f)
                    }

                    Surface(
                        shape = RoundedCornerShape(4.dp),
                        color = pBg
                    ) {
                        Text(
                            text = task.priority,
                            color = pColor,
                            fontSize = 9.5.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }

                    Surface(
                        shape = RoundedCornerShape(4.dp),
                        color = AtikSurfaceHighlight
                    ) {
                        Text(
                            text = task.category,
                            color = AtikTextSecondary,
                            fontSize = 9.5.sp,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                }
            }

            IconButton(onClick = onDelete, modifier = Modifier.size(28.dp)) {
                Icon(
                    Icons.Default.Delete,
                    contentDescription = "Delete",
                    tint = AtikTextMuted,
                    modifier = Modifier.size(18.dp)
                )
            }
        }
    }
}

// =============================================================================
// 4. TASK SCHEDULER & EXACT ALARMS (Step 22 Requirement 1)
// =============================================================================

@Composable
private fun RemindersSubTabContent(
    reminders: List<ReminderEntity>,
    onAddReminderClick: () -> Unit,
    onDeleteReminder: (String) -> Unit
) {
    Column(modifier = Modifier.fillMaxSize()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "Scheduled Tasks & Alarms",
                    color = AtikTextPrimary,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "Android AlarmManager exact background scheduler",
                    color = AtikTextMuted,
                    fontSize = 11.sp
                )
            }

            Button(
                onClick = onAddReminderClick,
                shape = RoundedCornerShape(10.dp),
                colors = ButtonDefaults.buttonColors(containerColor = AtikElectricBlue),
                modifier = Modifier.testTag("btn_open_add_reminder")
            ) {
                Icon(Icons.Default.Add, null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("Schedule", fontSize = 11.5.sp, fontWeight = FontWeight.Bold)
            }
        }

        if (reminders.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(32.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("⏰", fontSize = 36.sp)
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = "No Scheduled Alarms or Reminders",
                        color = AtikTextPrimary,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Say \"Remind me to call client at 5 PM\" or \"Set alarm for 7:30 AM\"",
                        color = AtikTextMuted,
                        fontSize = 12.sp
                    )
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(horizontal = 14.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(reminders, key = { it.id }) { rem ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("reminder_item_${rem.id}"),
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = AtikSurfaceVariant),
                        border = BorderStroke(1.dp, AtikBorder)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                                Text(if (rem.isAlarm) "⏰" else "🔔", fontSize = 20.sp)
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Text(
                                        text = rem.title,
                                        color = AtikTextPrimary,
                                        fontSize = 13.5.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Surface(
                                            shape = RoundedCornerShape(4.dp),
                                            color = if (rem.isAlarm) AtikWarning.copy(alpha = 0.2f) else AtikSurfaceHighlight
                                        ) {
                                            Text(
                                                text = if (rem.isAlarm) "Exact Alarm" else "Reminder",
                                                color = if (rem.isAlarm) AtikWarning else AtikNeonCyan,
                                                fontSize = 9.5.sp,
                                                modifier = Modifier.padding(horizontal = 5.dp, vertical = 1.dp)
                                            )
                                        }
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(
                                            text = "Trigger at ${rem.timeFormatted}",
                                            color = AtikNeonAzure,
                                            fontSize = 11.5.sp
                                        )
                                    }
                                }
                            }

                            IconButton(onClick = { onDeleteReminder(rem.id) }) {
                                Icon(Icons.Default.Delete, "Delete", tint = AtikTextMuted, modifier = Modifier.size(18.dp))
                            }
                        }
                    }
                }
            }
        }
    }
}

// =============================================================================
// 5. DAILY ROUTINES SUB-TAB
// =============================================================================

@Composable
private fun RoutinesSubTabContent(
    routines: List<RoutineEntity>,
    onToggleRoutine: (String, Boolean) -> Unit,
    onRunBriefing: (String) -> Unit
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        items(routines, key = { it.id }) { routine ->
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = AtikSurfaceVariant),
                border = BorderStroke(1.dp, AtikBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                when (routine.type) {
                                    "MORNING_BRIEFING" -> "🌅"
                                    "EVENING_SUMMARY" -> "🌇"
                                    "WORK_FOCUS" -> "⚡"
                                    else -> "🌙"
                                },
                                fontSize = 22.sp
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = routine.title,
                                    color = AtikTextPrimary,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "Scheduled daily at ${routine.scheduledTime}",
                                    color = AtikNeonCyan,
                                    fontSize = 11.sp
                                )
                            }
                        }

                        Switch(
                            checked = routine.isEnabled,
                            onCheckedChange = { onToggleRoutine(routine.id, it) },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = AtikNeonCyan,
                                checkedTrackColor = AtikElectricBlue
                            )
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        if (routine.includeWeather) {
                            Surface(
                                shape = RoundedCornerShape(6.dp),
                                color = AtikSurfaceHighlight,
                                border = BorderStroke(0.6.dp, AtikBorder)
                            ) {
                                Text("🌤️ Weather", color = AtikTextSecondary, fontSize = 10.sp, modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp))
                            }
                        }
                        if (routine.includeTasks) {
                            Surface(
                                shape = RoundedCornerShape(6.dp),
                                color = AtikSurfaceHighlight,
                                border = BorderStroke(0.6.dp, AtikBorder)
                            ) {
                                Text("📌 Pending Tasks", color = AtikTextSecondary, fontSize = 10.sp, modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp))
                            }
                        }
                        if (routine.includeSchedule) {
                            Surface(
                                shape = RoundedCornerShape(6.dp),
                                color = AtikSurfaceHighlight,
                                border = BorderStroke(0.6.dp, AtikBorder)
                            ) {
                                Text("🗓️ Daily Agenda", color = AtikTextSecondary, fontSize = 10.sp, modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp))
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Button(
                        onClick = { onRunBriefing(routine.type) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("routine_run_btn_${routine.id}"),
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = AtikSurfaceHighlight,
                            contentColor = AtikNeonCyan
                        ),
                        border = BorderStroke(1.dp, AtikNeonCyan.copy(alpha = 0.5f))
                    ) {
                        Icon(Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Run Briefing Now", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

// =============================================================================
// 6. DIALOGS
// =============================================================================

@Composable
private fun AddTaskDialog(
    onDismiss: () -> Unit,
    onConfirm: (title: String, desc: String, priority: String, category: String) -> Unit
) {
    var title by remember { mutableStateOf("") }
    var desc by remember { mutableStateOf("") }
    var priority by remember { mutableStateOf("MEDIUM") }
    var category by remember { mutableStateOf("Work") }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = AtikSurfaceVariant,
        title = {
            Text("Add Prioritized Task", color = AtikTextPrimary, fontWeight = FontWeight.Bold, fontSize = 16.sp)
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("Task Title *") },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = AtikNeonCyan,
                        unfocusedBorderColor = AtikBorder
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("input_task_title")
                )

                OutlinedTextField(
                    value = desc,
                    onValueChange = { desc = it },
                    label = { Text("Description / Notes (Optional)") },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = AtikNeonCyan,
                        unfocusedBorderColor = AtikBorder
                    ),
                    modifier = Modifier.fillMaxWidth()
                )

                Text("Priority Level:", color = AtikTextSecondary, fontSize = 11.5.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("LOW", "MEDIUM", "HIGH", "URGENT").forEach { p ->
                        val isSel = priority == p
                        Surface(
                            onClick = { priority = p },
                            shape = RoundedCornerShape(8.dp),
                            color = if (isSel) AtikSurfaceHighlight else AtikSurface,
                            border = BorderStroke(1.dp, if (isSel) AtikNeonCyan else AtikBorder),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text(
                                text = p,
                                color = if (isSel) AtikNeonCyan else AtikTextMuted,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(vertical = 6.dp),
                                textAlign = TextAlign.Center
                            )
                        }
                    }
                }

                Text("Category:", color = AtikTextSecondary, fontSize = 11.5.sp)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    listOf("Work", "AI Development", "Learning", "Health", "Personal").forEach { c ->
                        val isSel = category == c
                        Surface(
                            onClick = { category = c },
                            shape = RoundedCornerShape(8.dp),
                            color = if (isSel) AtikSurfaceHighlight else AtikSurface,
                            border = BorderStroke(1.dp, if (isSel) AtikNeonCyan else AtikBorder)
                        ) {
                            Text(
                                text = c,
                                color = if (isSel) AtikNeonCyan else AtikTextMuted,
                                fontSize = 10.5.sp,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                            )
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (title.isNotBlank()) {
                        onConfirm(title, desc, priority, category)
                    }
                },
                enabled = title.isNotBlank(),
                colors = ButtonDefaults.buttonColors(containerColor = AtikElectricBlue),
                modifier = Modifier.testTag("dialog_confirm_add_task")
            ) {
                Text("Add Task", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel", color = AtikTextMuted)
            }
        }
    )
}

@Composable
private fun AddReminderDialog(
    onDismiss: () -> Unit,
    onConfirm: (title: String, time: String, isAlarm: Boolean) -> Unit
) {
    var title by remember { mutableStateOf("") }
    var time by remember { mutableStateOf("05:00 PM") }
    var isAlarm by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = AtikSurfaceVariant,
        title = {
            Text("Set Alarm / Reminder", color = AtikTextPrimary, fontWeight = FontWeight.Bold, fontSize = 16.sp)
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("Reminder Title / Task *") },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = AtikNeonCyan,
                        unfocusedBorderColor = AtikBorder
                    ),
                    modifier = Modifier.fillMaxWidth().testTag("input_reminder_title")
                )

                OutlinedTextField(
                    value = time,
                    onValueChange = { time = it },
                    label = { Text("Scheduled Time (e.g. 05:00 PM)") },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = AtikNeonCyan,
                        unfocusedBorderColor = AtikBorder
                    ),
                    modifier = Modifier.fillMaxWidth().testTag("input_reminder_time")
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Sound as Audible Alarm", color = AtikTextSecondary, fontSize = 12.5.sp)
                    Switch(
                        checked = isAlarm,
                        onCheckedChange = { isAlarm = it },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = AtikNeonCyan,
                            checkedTrackColor = AtikElectricBlue
                        )
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (title.isNotBlank()) {
                        onConfirm(title, time, isAlarm)
                    }
                },
                enabled = title.isNotBlank(),
                colors = ButtonDefaults.buttonColors(containerColor = AtikElectricBlue),
                modifier = Modifier.testTag("dialog_confirm_add_reminder")
            ) {
                Text("Schedule", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel", color = AtikTextMuted)
            }
        }
    )
}

// =============================================================================
// 6. NOTES VAULT SUB-TAB (Step 23 Requirement 1 & 4)
// =============================================================================

@Composable
private fun NotesVaultSubTabContent(
    notes: List<NoteEntity>,
    pendingOfflineCount: Int,
    isSyncingData: Boolean,
    onOpenAddNote: () -> Unit,
    onDeleteNote: (String) -> Unit,
    onTogglePinNote: (NoteEntity) -> Unit,
    onSyncNow: () -> Unit
) {
    var searchQuery by remember { mutableStateOf("") }
    var selectedCategory by remember { mutableStateOf("ALL") }
    val categories = listOf("ALL", "General", "Offline Notes", "Ideas", "Work", "Rules")
    val dateFormatter = remember { SimpleDateFormat("MMM d, yyyy • hh:mm a", Locale.US) }

    val filteredNotes = remember(notes, searchQuery, selectedCategory) {
        notes.filter { note ->
            val matchesCategory = selectedCategory == "ALL" || note.category.equals(selectedCategory, ignoreCase = true)
            val matchesSearch = searchQuery.isBlank() ||
                    note.title.contains(searchQuery, ignoreCase = true) ||
                    note.content.contains(searchQuery, ignoreCase = true)
            matchesCategory && matchesSearch
        }.sortedWith(compareByDescending<NoteEntity> { it.isPinned }.thenByDescending { it.updatedAt })
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 16.dp, bottom = 100.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Vault Header & Diagnostics Banner
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = AtikSurfaceVariant),
                border = BorderStroke(1.dp, AtikBorder),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("notes_vault_header_card")
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "📝 Room Offline Notes Vault",
                                color = AtikTextPrimary,
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = "Local persistent storage • Works 100% offline",
                                color = AtikTextMuted,
                                fontSize = 11.5.sp
                            )
                        }

                        Button(
                            onClick = onOpenAddNote,
                            colors = ButtonDefaults.buttonColors(containerColor = AtikElectricBlue),
                            shape = RoundedCornerShape(10.dp),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                            modifier = Modifier.testTag("btn_notes_vault_new_note")
                        ) {
                            Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("New Note", fontSize = 11.5.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Sync & Metrics Row
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = AtikSurfaceHighlight,
                            border = BorderStroke(0.8.dp, AtikBorder),
                            modifier = Modifier.weight(1f)
                        ) {
                            Column(
                                modifier = Modifier.padding(10.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Text("Total Saved", color = AtikTextMuted, fontSize = 10.sp)
                                Text("${notes.size} Notes", color = AtikNeonCyan, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                            }
                        }

                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = if (pendingOfflineCount > 0) Color(0xFF332305) else AtikSurfaceHighlight,
                            border = BorderStroke(0.8.dp, if (pendingOfflineCount > 0) Color(0xFFFFB300).copy(alpha = 0.6f) else AtikBorder),
                            modifier = Modifier.weight(1.3f)
                        ) {
                            Row(
                                modifier = Modifier
                                    .padding(horizontal = 10.dp, vertical = 8.dp)
                                    .fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text("Cloud Sync Queue", color = AtikTextMuted, fontSize = 10.sp)
                                    Text(
                                        if (pendingOfflineCount > 0) "$pendingOfflineCount Queued" else "All Synced ✅",
                                        color = if (pendingOfflineCount > 0) Color(0xFFFFB300) else AtikSuccess,
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                                if (pendingOfflineCount > 0) {
                                    Button(
                                        onClick = onSyncNow,
                                        enabled = !isSyncingData,
                                        colors = ButtonDefaults.buttonColors(containerColor = AtikSurfaceHighlight),
                                        shape = RoundedCornerShape(6.dp),
                                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                                        modifier = Modifier.height(26.dp).testTag("btn_sync_now_notes_tab")
                                    ) {
                                        Text(if (isSyncingData) "..." else "Sync", color = AtikNeonCyan, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // Search Bar
        item {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                placeholder = { Text("Search local notes by title or content...", fontSize = 12.sp, color = AtikTextMuted) },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = AtikTextMuted, modifier = Modifier.size(18.dp)) },
                trailingIcon = {
                    if (searchQuery.isNotEmpty()) {
                        IconButton(onClick = { searchQuery = "" }) {
                            Icon(Icons.Default.Close, contentDescription = "Clear search", tint = AtikTextMuted, modifier = Modifier.size(16.dp))
                        }
                    }
                },
                singleLine = true,
                shape = RoundedCornerShape(12.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = AtikNeonCyan,
                    unfocusedBorderColor = AtikBorder,
                    focusedTextColor = AtikTextPrimary,
                    unfocusedTextColor = AtikTextPrimary,
                    cursorColor = AtikNeonCyan
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("input_search_offline_notes")
            )
        }

        // Category Filter Chips
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                categories.forEach { cat ->
                    val isSelected = selectedCategory == cat
                    Surface(
                        onClick = { selectedCategory = cat },
                        shape = RoundedCornerShape(16.dp),
                        color = if (isSelected) AtikElectricBlue.copy(alpha = 0.25f) else AtikSurfaceVariant,
                        border = BorderStroke(1.dp, if (isSelected) AtikNeonCyan else AtikBorder),
                        modifier = Modifier.testTag("chip_note_cat_$cat")
                    ) {
                        Text(
                            text = cat,
                            color = if (isSelected) AtikNeonCyan else AtikTextMuted,
                            fontSize = 11.sp,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                        )
                    }
                }
            }
        }

        // Notes List
        if (filteredNotes.isEmpty()) {
            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = AtikSurfaceVariant),
                    border = BorderStroke(1.dp, AtikBorder),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(32.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Icon(Icons.Default.EditNote, contentDescription = null, tint = AtikNeonCyan, modifier = Modifier.size(44.dp))
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = if (searchQuery.isNotEmpty()) "No matching notes found" else "No persistent notes stored yet",
                            color = AtikTextPrimary,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Save ideas, project snippets, or offline reminders. Say \"Take note: [idea]\" in chat or tap + New Note.",
                            color = AtikTextMuted,
                            fontSize = 11.5.sp,
                            textAlign = TextAlign.Center
                        )
                        Spacer(modifier = Modifier.height(14.dp))
                        Button(
                            onClick = onOpenAddNote,
                            colors = ButtonDefaults.buttonColors(containerColor = AtikElectricBlue),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text("+ Create First Note", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        } else {
            items(filteredNotes, key = { it.id }) { note ->
                Card(
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = AtikSurfaceVariant),
                    border = BorderStroke(
                        if (note.isPinned) 1.2.dp else 0.8.dp,
                        if (note.isPinned) AtikNeonCyan.copy(alpha = 0.7f) else AtikBorder
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("note_card_${note.id}")
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.weight(1f)
                            ) {
                                if (note.isPinned) {
                                    Icon(
                                        Icons.Default.PushPin,
                                        contentDescription = "Pinned Note",
                                        tint = AtikNeonCyan,
                                        modifier = Modifier.size(15.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                }
                                Text(
                                    text = note.title,
                                    color = AtikTextPrimary,
                                    fontSize = 13.5.sp,
                                    fontWeight = FontWeight.Bold,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }

                            Row(verticalAlignment = Alignment.CenterVertically) {
                                // Sync indicator badge
                                Surface(
                                    shape = RoundedCornerShape(6.dp),
                                    color = if (note.isSynced) AtikSuccess.copy(alpha = 0.15f) else Color(0xFF332305),
                                    border = BorderStroke(0.6.dp, if (note.isSynced) AtikSuccess.copy(alpha = 0.4f) else Color(0xFFFFB300).copy(alpha = 0.5f))
                                ) {
                                    Text(
                                        text = if (note.isSynced) "Synced" else "Local Only",
                                        color = if (note.isSynced) AtikSuccess else Color(0xFFFFB300),
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }

                                Spacer(modifier = Modifier.width(4.dp))

                                IconButton(
                                    onClick = { onTogglePinNote(note) },
                                    modifier = Modifier.size(28.dp)
                                ) {
                                    Icon(
                                        imageVector = if (note.isPinned) Icons.Default.PushPin else Icons.Outlined.PushPin,
                                        contentDescription = "Toggle Pin",
                                        tint = if (note.isPinned) AtikNeonCyan else AtikTextMuted,
                                        modifier = Modifier.size(16.dp)
                                    )
                                }

                                IconButton(
                                    onClick = { onDeleteNote(note.id) },
                                    modifier = Modifier.size(28.dp)
                                ) {
                                    Icon(
                                        Icons.Default.Delete,
                                        contentDescription = "Delete Note",
                                        tint = AtikTextMuted,
                                        modifier = Modifier.size(16.dp)
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(6.dp))

                        Text(
                            text = note.content,
                            color = AtikTextSecondary,
                            fontSize = 12.sp,
                            lineHeight = 16.sp
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Surface(
                                shape = RoundedCornerShape(6.dp),
                                color = AtikSurfaceHighlight,
                                border = BorderStroke(0.6.dp, AtikBorder)
                            ) {
                                Text(
                                    text = "🏷️ ${note.category}",
                                    color = AtikTextMuted,
                                    fontSize = 10.sp,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }

                            Text(
                                text = dateFormatter.format(Date(note.updatedAt)),
                                color = AtikTextMuted,
                                fontSize = 10.sp
                            )
                        }
                    }
                }
            }
        }
    }
}

// =============================================================================
// ADD NOTE DIALOG (Step 23 Requirement 1)
// =============================================================================

@Composable
private fun AddNoteDialog(
    onDismiss: () -> Unit,
    onConfirm: (title: String, content: String, category: String) -> Unit
) {
    var title by remember { mutableStateOf("") }
    var content by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("General") }
    val categories = listOf("General", "Offline Notes", "Ideas", "Work", "Rules")

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = AtikSurfaceVariant,
        titleContentColor = AtikTextPrimary,
        textContentColor = AtikTextSecondary,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("📝 New Offline Note", fontWeight = FontWeight.Bold, fontSize = 16.sp)
            }
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("Note Title") },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = AtikNeonCyan,
                        unfocusedBorderColor = AtikBorder
                    ),
                    modifier = Modifier.fillMaxWidth().testTag("input_note_title")
                )

                OutlinedTextField(
                    value = content,
                    onValueChange = { content = it },
                    label = { Text("Note Content / Details") },
                    minLines = 3,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = AtikNeonCyan,
                        unfocusedBorderColor = AtikBorder
                    ),
                    modifier = Modifier.fillMaxWidth().testTag("input_note_content")
                )

                Text("Category", fontSize = 11.5.sp, color = AtikTextMuted)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    categories.forEach { cat ->
                        val isSelected = category == cat
                        Surface(
                            onClick = { category = cat },
                            shape = RoundedCornerShape(8.dp),
                            color = if (isSelected) AtikElectricBlue.copy(alpha = 0.3f) else AtikSurfaceHighlight,
                            border = BorderStroke(1.dp, if (isSelected) AtikNeonCyan else AtikBorder)
                        ) {
                            Text(
                                text = cat,
                                color = if (isSelected) AtikNeonCyan else AtikTextMuted,
                                fontSize = 11.sp,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                            )
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (title.isNotBlank()) {
                        onConfirm(title.trim(), content.trim(), category)
                    }
                },
                enabled = title.isNotBlank(),
                colors = ButtonDefaults.buttonColors(containerColor = AtikElectricBlue),
                modifier = Modifier.testTag("dialog_confirm_add_note")
            ) {
                Text("Save Note", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel", color = AtikTextMuted)
            }
        }
    )
}

