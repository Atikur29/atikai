package com.example.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.DynamicThemeState
import com.example.ui.theme.ThemePreset

/**
 * Quick Home-Screen Dynamic Theme Selector Bar (Step 25 Requirement 1 & 2).
 * Allows switching predefined themes with a single tap directly from the home screen.
 */
@Composable
fun HomeQuickThemeBar(
    themeState: DynamicThemeState,
    onSelectPreset: (ThemePreset) -> Unit,
    onOpenStudio: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 14.dp, vertical = 6.dp),
        shape = themeState.buttonStyle.getShape(),
        colors = CardDefaults.cardColors(
            containerColor = themeState.preset.defaultSurfaceVariant.copy(alpha = 0.9f)
        ),
        border = BorderStroke(1.dp, themeState.preset.defaultBorder)
    ) {
        Column(modifier = Modifier.padding(10.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(text = "🎨", fontSize = 14.sp)
                    Text(
                        text = "THEME: ${themeState.preset.displayName.uppercase()}",
                        color = themeState.accentColor,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 0.8.sp
                    )
                }

                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = themeState.accentColor.copy(alpha = 0.15f),
                    border = BorderStroke(1.dp, themeState.accentColor.copy(alpha = 0.3f)),
                    modifier = Modifier.clickable { onOpenStudio() }
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Text(text = "Customize", fontSize = 11.sp, color = themeState.accentColor, fontWeight = FontWeight.Bold)
                        Text(text = "⚙️", fontSize = 11.sp)
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Quick Theme Preset Chips
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                ThemePreset.values().forEach { preset ->
                    val isSelected = themeState.preset == preset

                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = if (isSelected) themeState.accentColor.copy(alpha = 0.25f) else themeState.preset.defaultSurfaceHighlight,
                        border = BorderStroke(
                            if (isSelected) 1.5.dp else 1.dp,
                            if (isSelected) themeState.accentColor else themeState.preset.defaultBorder
                        ),
                        modifier = Modifier.clickable { onSelectPreset(preset) }
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(12.dp)
                                    .clip(CircleShape)
                                    .background(Brush.horizontalGradient(preset.previewGradient))
                            )
                            Text(
                                text = "${preset.iconEmoji} ${preset.displayName}",
                                fontSize = 11.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                color = if (isSelected) themeState.accentColor else themeState.preset.defaultTextPrimary
                            )
                        }
                    }
                }
            }
        }
    }
}
