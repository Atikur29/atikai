package com.example.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.AtikElectricBlue
import com.example.ui.theme.AtikNeonAzure
import com.example.ui.theme.AtikNeonCyan
import kotlin.math.roundToInt

/**
 * Floating Assistant Action Widget / Overlay Bubble (Step 14 Requirement 1).
 * An adjustable, draggable floating bubble that remains accessible over the interface
 * for instantaneous one-tap voice activation, shortcut execution, and quick result peek.
 */
@Composable
fun FloatingAssistantBubble(
    isVisible: Boolean,
    isListening: Boolean,
    isGenerating: Boolean,
    bubbleSizeDp: Int = 60,
    onTap: () -> Unit,
    onLongPress: () -> Unit,
    modifier: Modifier = Modifier
) {
    if (!isVisible) return

    // Position state for dragging
    var offsetX by remember { mutableFloatStateOf(40f) }
    var offsetY by remember { mutableFloatStateOf(350f) }

    val infiniteTransition = rememberInfiniteTransition(label = "bubbleAura")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 1f,
        targetValue = if (isListening) 1.2f else 1.06f,
        animationSpec = infiniteRepeatable(
            animation = tween(if (isListening) 500 else 1400, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulseScale"
    )

    val borderColor = when {
        isListening -> Color(0xFFFF5252)
        isGenerating -> Color(0xFFFFB300)
        else -> AtikNeonCyan
    }

    Box(
        modifier = modifier
            .offset { IntOffset(offsetX.roundToInt(), offsetY.roundToInt()) }
            .pointerInput(Unit) {
                detectDragGestures { change, dragAmount ->
                    change.consume()
                    offsetX += dragAmount.x
                    offsetY += dragAmount.y
                }
            }
            .pointerInput(Unit) {
                detectTapGestures(
                    onTap = { onTap() },
                    onLongPress = { onLongPress() }
                )
            }
            .testTag("floating_assistant_bubble")
    ) {
        // Outer glowing aura pulse
        Box(
            modifier = Modifier
                .size((bubbleSizeDp + 14).dp)
                .scale(pulseScale)
                .clip(CircleShape)
                .background(borderColor.copy(alpha = 0.22f))
                .align(Alignment.Center)
        )

        // Main Bubble Surface
        Surface(
            shape = CircleShape,
            color = Color(0xFF070D14),
            border = BorderStroke(2.dp, borderColor),
            modifier = Modifier
                .size(bubbleSizeDp.dp)
                .shadow(12.dp, CircleShape, spotColor = borderColor)
                .align(Alignment.Center)
        ) {
            Box(
                modifier = Modifier
                    .size(bubbleSizeDp.dp)
                    .background(
                        Brush.radialGradient(
                            colors = listOf(
                                Color(0xFF132238),
                                Color(0xFF070D14)
                            )
                        )
                    ),
                contentAlignment = Alignment.Center
            ) {
                if (isListening) {
                    Icon(
                        imageVector = Icons.Default.GraphicEq,
                        contentDescription = "Listening",
                        tint = Color(0xFFFF5252),
                        modifier = Modifier.size((bubbleSizeDp * 0.45).dp)
                    )
                } else if (isGenerating) {
                    Text(
                        text = "⚡",
                        fontSize = (bubbleSizeDp * 0.4).sp
                    )
                } else {
                    Text(
                        text = "🥋",
                        fontSize = (bubbleSizeDp * 0.42).sp
                    )
                }
            }
        }
    }
}
