package com.example.ui

import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.animation.Crossfade
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AirplanemodeActive
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Campaign
import androidx.compose.material.icons.filled.ChatBubbleOutline
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.DriveFileRenameOutline
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.SportsEsports
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.NavigationDrawerItem
import androidx.compose.material3.NavigationDrawerItemDefaults
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import com.example.data.ChatSessionEntity
import com.example.ui.theme.AtikError
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.SmartActionFeedbackBanner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.components.AtikAvatar
import com.example.ui.components.AtikHeader
import com.example.ui.components.BiometricLockOverlay
import com.example.ui.components.FloatingAssistantBubble
import com.example.ui.components.QuickResultOverlaySheet
import com.example.ui.screens.ChatScreen
import com.example.ui.screens.FilesScreen
import com.example.ui.screens.HistoryScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.LiveAssistantScreen
import com.example.ui.screens.MemoryScreen
import com.example.ui.screens.NewsScreen
import com.example.ui.screens.IdeWorkspaceScreen
import com.example.ide.SupportedLanguage
import com.example.ui.screens.PythonLabScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.screens.SystemAutomationScreen
import com.example.ui.screens.TechGuidesScreen
import com.example.ui.screens.TerminalScreen
import com.example.ui.screens.ToolsScreen
import com.example.ui.screens.VisionScreen
import com.example.ui.screens.SocialSchedulerScreen
import com.example.ui.screens.TaskHubScreen
import com.example.ui.screens.GameStudioScreen
import com.example.ui.components.GamePlayerCanvas
import com.example.ui.theme.AtikBlack
import com.example.ui.theme.AtikBorder
import com.example.ui.theme.AtikElectricBlue
import com.example.ui.theme.AtikNeonAzure
import com.example.ui.theme.AtikNeonCyan
import com.example.ui.theme.AtikSurface
import com.example.ui.theme.AtikSurfaceHighlight
import com.example.ui.theme.AtikSurfaceVariant
import com.example.ui.theme.AtikTextMuted
import com.example.ui.theme.AtikTextPrimary
import com.example.ui.theme.AtikTextSecondary
import kotlinx.coroutines.launch

enum class AtikNavTab(
    val title: String,
    val subtitle: String,
    val icon: androidx.compose.ui.graphics.vector.ImageVector
) {
    HOME("Home", "Personal AI Assistant", Icons.Default.Home),
    CHAT("Chat", "Smart AI Conversations", Icons.Default.ChatBubbleOutline),
    VISION("Vision & Scan", "AI Object, QR/Barcode & OCR", Icons.Default.QrCodeScanner),
    SOCIAL("Social AI Hub", "Viral Content & Smart Scheduler", Icons.Default.Campaign),
    TECH_GUIDES("Tech & Guides", "Earning & Coding Tutorials", Icons.Default.School),
    TASKS_ROUTINES("Workflows & Tasks", "Workflow Studio & Task Scheduler", Icons.Default.Schedule),
    HISTORY("History", "Persistent Chat Sessions", Icons.Default.History),
    MEMORY("Memory", "AI Knowledge & Preferences", Icons.Default.Psychology),
    FILES("Files", "Document & Image Analysis", Icons.Default.FolderOpen),
    VOICE_LIVE("Voice / Live", "Real-time Live Assistant", Icons.Default.GraphicEq),
    PYTHON_LAB("IDE Studio", "Multi-Language IDE & Live Preview", Icons.Default.Code),
    TERMINAL("Terminal", "Termux & Kali Simulator", Icons.Default.Terminal),
    GAME_STUDIO("Game Studio", "2D HTML5 Games & Arcade", Icons.Default.SportsEsports),
    TOOLS("Device & Tools", "Hardware Controls & System Info", Icons.Default.Build),
    SYSTEM_AUTOMATION("System & Gallery", "Airplane Mode, Deep Controls & AI Photos", Icons.Default.AirplanemodeActive),
    NEWS("Web & News", "Live Search & Breaking Hub", Icons.Default.Public),
    SETTINGS("Settings", "API & App Configuration", Icons.Default.Settings)
}

@Composable
fun MainScreen(
    viewModel: AtikViewModel,
    modifier: Modifier = Modifier
) {
    var currentTab by remember { mutableStateOf(AtikNavTab.CHAT) }
    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
    val coroutineScope = rememberCoroutineScope()
    val context = LocalContext.current

    // States from ViewModel
    val currentMessages by viewModel.currentMessages.collectAsStateWithLifecycle()
    val allSessions by viewModel.allSessions.collectAsStateWithLifecycle()
    val memories by viewModel.memories.collectAsStateWithLifecycle()
    val files by viewModel.files.collectAsStateWithLifecycle()
    val activeSessionId by viewModel.currentSessionId.collectAsStateWithLifecycle()
    val isGenerating by viewModel.isGenerating.collectAsStateWithLifecycle()
    val languageMode by viewModel.languageMode.collectAsStateWithLifecycle()
    val selectedModel by viewModel.selectedModel.collectAsStateWithLifecycle()
    val customApiKey by viewModel.customApiKey.collectAsStateWithLifecycle()
    val autoReadTts by viewModel.autoReadTts.collectAsStateWithLifecycle()
    val speechRate by viewModel.speechRate.collectAsStateWithLifecycle()
    val attachedImage by viewModel.attachedImageBitmap.collectAsStateWithLifecycle()
    val attachedFileName by viewModel.attachedFileName.collectAsStateWithLifecycle()
    val currentlySpeakingId by viewModel.currentlySpeakingMessageId.collectAsStateWithLifecycle()
    val lastAiReply by viewModel.lastAiReply.collectAsStateWithLifecycle()

    // Voice states
    val isLiveActive by viewModel.isLiveActive.collectAsStateWithLifecycle()
    val isListening by viewModel.voiceManager.isListening.collectAsStateWithLifecycle()
    val isSpeaking by viewModel.voiceManager.isSpeaking.collectAsStateWithLifecycle()
    val spokenText by viewModel.voiceManager.spokenText.collectAsStateWithLifecycle()
    val rmsDb by viewModel.voiceManager.rmsDb.collectAsStateWithLifecycle()
    val bossActionPhrase by viewModel.bossActionPhrase.collectAsStateWithLifecycle()

    // Python Lab States
    val pythonCode by viewModel.pythonCode.collectAsStateWithLifecycle()
    val pythonExecutionResult by viewModel.pythonExecutionResult.collectAsStateWithLifecycle()
    val isPythonRunning by viewModel.isPythonRunning.collectAsStateWithLifecycle()

    // Terminal States
    val terminalLines by viewModel.terminalLines.collectAsStateWithLifecycle()
    val terminalCurrentDir by viewModel.terminalCurrentDir.collectAsStateWithLifecycle()
    val isTerminalRunning by viewModel.isTerminalRunning.collectAsStateWithLifecycle()
    val terminalBackendUrl by viewModel.terminalBackendUrl.collectAsStateWithLifecycle()

    // Vision & Scanner States
    val visionScanMode by viewModel.visionScanMode.collectAsStateWithLifecycle()
    val visionPreset by viewModel.visionPreset.collectAsStateWithLifecycle()
    val qrBarcodeResult by viewModel.qrBarcodeResult.collectAsStateWithLifecycle()
    val ocrResult by viewModel.ocrResult.collectAsStateWithLifecycle()
    val visionAiResult by viewModel.visionAiResult.collectAsStateWithLifecycle()
    val isVisionAnalyzing by viewModel.isVisionAnalyzing.collectAsStateWithLifecycle()
    val visionStatusMessage by viewModel.visionStatusMessage.collectAsStateWithLifecycle()

    // Social Media States
    val socialPosts by viewModel.socialPosts.collectAsStateWithLifecycle()
    val isGeneratingSocial by viewModel.isGeneratingSocial.collectAsStateWithLifecycle()
    val generatedSocialContent by viewModel.generatedSocialContent.collectAsStateWithLifecycle()

    // Personalization & Theme States (Step 10)
    val themeMode by viewModel.themeMode.collectAsStateWithLifecycle()
    val voiceSpeed by viewModel.voiceSpeed.collectAsStateWithLifecycle()
    val voicePitch by viewModel.voicePitch.collectAsStateWithLifecycle()
    val voiceGender by viewModel.voiceGender.collectAsStateWithLifecycle()
    val userName by viewModel.userName.collectAsStateWithLifecycle()
    val preferredTitle by viewModel.preferredTitle.collectAsStateWithLifecycle()
    val greetingStyle by viewModel.greetingStyle.collectAsStateWithLifecycle()

    // Kung-Fu Warrior Avatar States (Step 11)
    val avatarVisible by viewModel.avatarVisible.collectAsStateWithLifecycle()
    val avatarScale by viewModel.avatarScale.collectAsStateWithLifecycle()
    val avatarPosition by viewModel.avatarPosition.collectAsStateWithLifecycle()
    val avatarGestureSpeed by viewModel.avatarGestureSpeed.collectAsStateWithLifecycle()
    val avatarStance by viewModel.avatarStance.collectAsStateWithLifecycle()
    val avatarActionTrigger by viewModel.avatarActionTrigger.collectAsStateWithLifecycle()

    // Network & Offline AI States (Step 12)
    val isNetworkOnline by viewModel.isNetworkOnline.collectAsStateWithLifecycle()
    val networkConnectionType by viewModel.networkConnectionType.collectAsStateWithLifecycle()
    val isSimulationOffline by viewModel.isSimulationOffline.collectAsStateWithLifecycle()

    // Smart Automation & Routine Task States (Step 13)
    val allTasks by viewModel.allTasks.collectAsStateWithLifecycle()
    val allRoutines by viewModel.allRoutines.collectAsStateWithLifecycle()
    val allReminders by viewModel.allReminders.collectAsStateWithLifecycle()

    // Voice Shortcuts & Floating Widget States (Step 14)
    val isFloatingBubbleEnabled by viewModel.isFloatingBubbleEnabled.collectAsStateWithLifecycle()
    val isQuickOverlayVisible by viewModel.isQuickOverlayVisible.collectAsStateWithLifecycle()
    val floatingBubbleSizeDp by viewModel.floatingBubbleSizeDp.collectAsStateWithLifecycle()
    val isSystemOverlayActive by viewModel.isSystemOverlayActive.collectAsStateWithLifecycle()
    val voiceShortcuts by viewModel.voiceShortcuts.collectAsStateWithLifecycle()

    // App Performance & Resource Optimization States (Step 15)
    val powerProfile by viewModel.powerProfile.collectAsStateWithLifecycle()
    val memoryDiagnostics by viewModel.memoryDiagnostics.collectAsStateWithLifecycle()
    val storageDiagnostics by viewModel.storageDiagnostics.collectAsStateWithLifecycle()
    val isOptimizing by viewModel.isOptimizing.collectAsStateWithLifecycle()
    val lastOptimizationResult by viewModel.lastOptimizationResult.collectAsStateWithLifecycle()

    // Security, Privacy & Data Encryption States (Step 16)
    val isBiometricEnabled by viewModel.isBiometricEnabled.collectAsStateWithLifecycle()
    val hasMasterPin by viewModel.hasMasterPin.collectAsStateWithLifecycle()
    val isAppLocked by viewModel.isAppLocked.collectAsStateWithLifecycle()
    val failedAttempts by viewModel.failedAttempts.collectAsStateWithLifecycle()

    // Global Multi-Language Translation & Accent States (Step 17)
    val isTranslating by viewModel.isTranslating.collectAsStateWithLifecycle()
    val lastTranslationResult by viewModel.lastTranslationResult.collectAsStateWithLifecycle()
    val userAccent by viewModel.userAccent.collectAsStateWithLifecycle()

    // Smart Web Search & Live News Aggregator States (Step 18)
    val isSearchingWeb by viewModel.isSearchingWeb.collectAsStateWithLifecycle()
    val lastSearchAnswer by viewModel.lastSearchAnswer.collectAsStateWithLifecycle()
    val isSummarizingArticle by viewModel.isSummarizingArticle.collectAsStateWithLifecycle()
    val lastArticleSummary by viewModel.lastArticleSummary.collectAsStateWithLifecycle()
    val selectedNewsCategory by viewModel.selectedNewsCategory.collectAsStateWithLifecycle()
    val newsArticles by viewModel.newsArticles.collectAsStateWithLifecycle()
    val isRefreshingNews by viewModel.isRefreshingNews.collectAsStateWithLifecycle()

    // AI Coding Assistant & IDE Simulator States (Step 19)
    val ideSelectedLanguage by viewModel.ideSelectedLanguage.collectAsStateWithLifecycle()
    val ideCodeBuffer by viewModel.ideCodeBuffer.collectAsStateWithLifecycle()
    val isIdeRunning by viewModel.isIdeRunning.collectAsStateWithLifecycle()
    val ideExecutionResult by viewModel.ideExecutionResult.collectAsStateWithLifecycle()
    val ideDiagnosticLogs by viewModel.ideDiagnosticLogs.collectAsStateWithLifecycle()
    val isIdeAiAssisting by viewModel.isIdeAiAssisting.collectAsStateWithLifecycle()
    val currentIdeCode = ideCodeBuffer[ideSelectedLanguage].orEmpty()

    // Deep System Automation & AI Gallery States (Step 20)
    val currentSoundProfile by viewModel.currentSoundProfile.collectAsStateWithLifecycle()
    val isAirplaneModeOn by viewModel.isAirplaneModeOn.collectAsStateWithLifecycle()
    val galleryPhotos by viewModel.galleryPhotos.collectAsStateWithLifecycle()
    val selectedPhotoCategory by viewModel.selectedPhotoCategory.collectAsStateWithLifecycle()
    val semanticSearchResult by viewModel.semanticSearchResult.collectAsStateWithLifecycle()
    val isAnalyzingPhoto by viewModel.isAnalyzingPhoto.collectAsStateWithLifecycle()
    val isFlashlightOn by viewModel.isFlashlightOn.collectAsStateWithLifecycle()
    val systemStatusSummary = remember(isAirplaneModeOn, currentSoundProfile, isFlashlightOn) {
        viewModel.systemAutomationEngine.getSystemStatusSummary()
    }

    // Interactive Live Voice Assistant & Wake-Word States (Step 21)
    val isWakeWordEnabled by viewModel.isWakeWordEnabled.collectAsStateWithLifecycle()
    val wakeWordSensitivity by viewModel.wakeWordSensitivity.collectAsStateWithLifecycle()
    val isHandsFreeDuplex by viewModel.isHandsFreeDuplexEnabled.collectAsStateWithLifecycle()
    val isAudioChimeEnabled by viewModel.isAudioChimeEnabled.collectAsStateWithLifecycle()
    val isHapticFeedbackEnabled by viewModel.isHapticFeedbackEnabled.collectAsStateWithLifecycle()
    val voiceDuplexState by viewModel.voiceDuplexState.collectAsStateWithLifecycle()

    // Smart Automation Workflows & Task Scheduler States (Step 22)
    val allWorkflows by viewModel.allWorkflows.collectAsStateWithLifecycle()
    val quietHoursConfig by viewModel.quietHoursConfig.collectAsStateWithLifecycle()
    val isExecutingWorkflow by viewModel.isExecutingWorkflow.collectAsStateWithLifecycle()
    val lastWorkflowReport by viewModel.lastWorkflowReport.collectAsStateWithLifecycle()

    // Offline AI Capabilities & Room Persistence Engine (Step 23)
    val allNotes by viewModel.allNotes.collectAsStateWithLifecycle()
    val isSyncingData by viewModel.isSyncingData.collectAsStateWithLifecycle()
    val syncStatusText by viewModel.syncStatusText.collectAsStateWithLifecycle()
    val pendingOfflineCount by viewModel.pendingOfflineActionsCount.collectAsStateWithLifecycle()
    val lastSyncTimestamp by viewModel.lastSyncTimestamp.collectAsStateWithLifecycle()
    val autoSyncEnabled by viewModel.autoSyncEnabled.collectAsStateWithLifecycle()
    val offlineFallbackPersona by viewModel.offlineFallbackPersona.collectAsStateWithLifecycle()
    val syncOnlyOnWifi by viewModel.syncOnlyOnWifi.collectAsStateWithLifecycle()
    val localDatabaseMetrics by viewModel.localDatabaseMetrics.collectAsStateWithLifecycle()
    val cacheMetrics by viewModel.cacheMetrics.collectAsStateWithLifecycle()

    // Smart Actions & Accessibility Automation States (Step 24)
    val smartActionPhase by viewModel.smartActionPhase.collectAsStateWithLifecycle()
    val isAccessibilityConnected by viewModel.isAccessibilityServiceConnected.collectAsStateWithLifecycle()
    val smartAudits by viewModel.smartActionAudits.collectAsStateWithLifecycle()
    val smartActionEnabled by viewModel.smartActionEnabled.collectAsStateWithLifecycle()
    val requireConfirmation by viewModel.requireConfirmation.collectAsStateWithLifecycle()
    val actionCountdownSeconds by viewModel.actionCountdownSeconds.collectAsStateWithLifecycle()
    val whatsappActionEnabled by viewModel.whatsappActionEnabled.collectAsStateWithLifecycle()
    val imoActionEnabled by viewModel.imoActionEnabled.collectAsStateWithLifecycle()
    val smsActionEnabled by viewModel.smsActionEnabled.collectAsStateWithLifecycle()
    val phoneActionEnabled by viewModel.phoneActionEnabled.collectAsStateWithLifecycle()

    // Dynamic Theme State (Step 25)
    val dynamicThemeState by viewModel.dynamicThemeState.collectAsStateWithLifecycle()

    // Game Studio & Arcade States (Step 26)
    val games by viewModel.games.collectAsStateWithLifecycle()
    val recentGameScores by viewModel.recentGameScores.collectAsStateWithLifecycle()
    val isGeneratingGame by viewModel.isGeneratingGame.collectAsStateWithLifecycle()
    val activeGameToPlay by viewModel.activeGameToPlay.collectAsStateWithLifecycle()

    val isKeyConfigured = viewModel.geminiService.isKeyConfigured(customApiKey)

    var sessionToRename by remember { mutableStateOf<ChatSessionEntity?>(null) }
    var renameInputText by remember { mutableStateOf("") }
    var sessionToDelete by remember { mutableStateOf<ChatSessionEntity?>(null) }
    var showClearAllDialog by remember { mutableStateOf(false) }
    var drawerSectionTab by remember { mutableStateOf(0) } // 0: Chat Threads, 1: Navigation Tabs
    var drawerSearchQuery by remember { mutableStateOf("") }
    val dateFormatter = remember { SimpleDateFormat("MMM d, h:mm a", Locale.getDefault()) }

    // Handle back button: close active game first, then close drawer, or return to Chat screen
    BackHandler(enabled = activeGameToPlay != null || drawerState.isOpen || currentTab != AtikNavTab.CHAT) {
        if (activeGameToPlay != null) {
            viewModel.closeActiveGame()
        } else if (drawerState.isOpen) {
            coroutineScope.launch { drawerState.close() }
        } else {
            currentTab = AtikNavTab.CHAT
        }
    }

    // Wrap the entire app in ModalNavigationDrawer
    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            ModalDrawerSheet(
                drawerContainerColor = AtikSurfaceVariant,
                modifier = Modifier
                    .width(320.dp)
                    .fillMaxHeight()
                    .border(BorderStroke(1.dp, AtikBorder))
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .statusBarsPadding()
                        .navigationBarsPadding()
                        .verticalScroll(rememberScrollState())
                        .padding(horizontal = 14.dp, vertical = 12.dp)
                ) {
                    // Drawer Header
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            AtikAvatar(size = 40.dp, isPulsing = true)
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = "Atik AI Platform",
                                    color = AtikTextPrimary,
                                    fontSize = 16.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "Atikur Rahman's Assistant",
                                    color = AtikNeonAzure,
                                    fontSize = 11.5.sp
                                )
                            }
                        }

                        IconButton(
                            onClick = { coroutineScope.launch { drawerState.close() } },
                            modifier = Modifier.size(32.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Close,
                                contentDescription = "Close Menu",
                                tint = AtikTextMuted,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }

                    // "+ New Chat" Action Button
                    Button(
                        onClick = {
                            viewModel.startNewChat()
                            currentTab = AtikNavTab.CHAT
                            coroutineScope.launch { drawerState.close() }
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(44.dp)
                            .testTag("drawer_new_chat_button"),
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = AtikElectricBlue,
                            contentColor = Color.White
                        )
                    ) {
                        Icon(
                            imageVector = Icons.Default.Add,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "+ New Chat",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Drawer Section Switcher: [ Chat History ] | [ Sections & Tools ]
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(AtikSurface)
                            .border(BorderStroke(0.8.dp, AtikBorder), RoundedCornerShape(12.dp))
                            .padding(3.dp),
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Surface(
                            onClick = { drawerSectionTab = 0 },
                            shape = RoundedCornerShape(9.dp),
                            color = if (drawerSectionTab == 0) AtikSurfaceHighlight else Color.Transparent,
                            border = if (drawerSectionTab == 0) BorderStroke(0.8.dp, AtikNeonCyan.copy(alpha = 0.5f)) else null,
                            modifier = Modifier.weight(1f).testTag("drawer_tab_history")
                        ) {
                            Row(
                                modifier = Modifier.padding(vertical = 7.dp),
                                horizontalArrangement = Arrangement.Center,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Default.History,
                                    contentDescription = null,
                                    tint = if (drawerSectionTab == 0) AtikNeonCyan else AtikTextMuted,
                                    modifier = Modifier.size(14.dp)
                                )
                                Spacer(modifier = Modifier.width(5.dp))
                                Text(
                                    text = "History (${allSessions.size})",
                                    color = if (drawerSectionTab == 0) AtikTextPrimary else AtikTextMuted,
                                    fontSize = 11.5.sp,
                                    fontWeight = if (drawerSectionTab == 0) FontWeight.Bold else FontWeight.Medium
                                )
                            }
                        }

                        Surface(
                            onClick = { drawerSectionTab = 1 },
                            shape = RoundedCornerShape(9.dp),
                            color = if (drawerSectionTab == 1) AtikSurfaceHighlight else Color.Transparent,
                            border = if (drawerSectionTab == 1) BorderStroke(0.8.dp, AtikNeonCyan.copy(alpha = 0.5f)) else null,
                            modifier = Modifier.weight(1f).testTag("drawer_tab_navigation")
                        ) {
                            Row(
                                modifier = Modifier.padding(vertical = 7.dp),
                                horizontalArrangement = Arrangement.Center,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Build,
                                    contentDescription = null,
                                    tint = if (drawerSectionTab == 1) AtikNeonCyan else AtikTextMuted,
                                    modifier = Modifier.size(14.dp)
                                )
                                Spacer(modifier = Modifier.width(5.dp))
                                Text(
                                    text = "Sections (${AtikNavTab.values().size})",
                                    color = if (drawerSectionTab == 1) AtikTextPrimary else AtikTextMuted,
                                    fontSize = 11.5.sp,
                                    fontWeight = if (drawerSectionTab == 1) FontWeight.Bold else FontWeight.Medium
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    if (drawerSectionTab == 0) {
                        // Quick Search bar in drawer
                        OutlinedTextField(
                            value = drawerSearchQuery,
                            onValueChange = { drawerSearchQuery = it },
                            placeholder = { Text("Search previous chats...", color = AtikTextMuted, fontSize = 12.sp) },
                            leadingIcon = {
                                Icon(Icons.Default.Search, contentDescription = null, tint = AtikTextMuted, modifier = Modifier.size(16.dp))
                            },
                            trailingIcon = {
                                if (drawerSearchQuery.isNotBlank()) {
                                    IconButton(onClick = { drawerSearchQuery = "" }, modifier = Modifier.size(20.dp)) {
                                        Icon(Icons.Default.Close, contentDescription = "Clear search", tint = AtikTextMuted, modifier = Modifier.size(14.dp))
                                    }
                                }
                            },
                            singleLine = true,
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(46.dp)
                                .testTag("drawer_search_input"),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedTextColor = AtikTextPrimary,
                                unfocusedTextColor = AtikTextPrimary,
                                focusedBorderColor = AtikNeonCyan,
                                unfocusedBorderColor = AtikBorder,
                                focusedContainerColor = AtikSurface,
                                unfocusedContainerColor = AtikSurface
                            )
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        val filteredDrawerSessions = if (drawerSearchQuery.isBlank()) allSessions else allSessions.filter {
                            it.title.contains(drawerSearchQuery, ignoreCase = true)
                        }

                        // CHAT THREADS MANAGEMENT
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "RECENT CONVERSATIONS",
                                color = AtikTextMuted,
                                fontSize = 10.5.sp,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 0.8.sp
                            )

                            if (allSessions.isNotEmpty()) {
                                TextButton(
                                    onClick = { showClearAllDialog = true },
                                    contentPadding = PaddingValues(horizontal = 4.dp, vertical = 0.dp),
                                    modifier = Modifier.testTag("drawer_clear_all_chats_btn")
                                ) {
                                    Text(
                                        text = "Clear All",
                                        color = AtikError,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(4.dp))

                        if (filteredDrawerSessions.isEmpty()) {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 24.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = if (drawerSearchQuery.isNotBlank()) "No matching chats found." else "No previous chats yet.",
                                    color = AtikTextMuted,
                                    fontSize = 13.sp
                                )
                            }
                        } else {
                            filteredDrawerSessions.forEach { session ->
                                val isSelected = session.id == activeSessionId
                                Surface(
                                    onClick = {
                                        viewModel.selectSession(session.id)
                                        currentTab = AtikNavTab.CHAT
                                        coroutineScope.launch { drawerState.close() }
                                    },
                                    shape = RoundedCornerShape(12.dp),
                                    color = if (isSelected) AtikSurfaceHighlight else Color.Transparent,
                                    border = BorderStroke(
                                        0.8.dp,
                                        if (isSelected) AtikNeonCyan.copy(alpha = 0.7f) else AtikBorder.copy(alpha = 0.4f)
                                    ),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 3.dp)
                                        .testTag("drawer_session_item_${session.id}")
                                ) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(horizontal = 10.dp, vertical = 9.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Row(
                                            modifier = Modifier.weight(1f),
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.ChatBubbleOutline,
                                                contentDescription = null,
                                                tint = if (isSelected) AtikNeonCyan else AtikTextMuted,
                                                modifier = Modifier.size(16.dp)
                                            )
                                            Spacer(modifier = Modifier.width(9.dp))
                                            Column {
                                                Text(
                                                    text = session.title,
                                                    color = if (isSelected) AtikTextPrimary else AtikTextSecondary,
                                                    fontSize = 13.sp,
                                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                                    maxLines = 1
                                                )
                                                Text(
                                                    text = dateFormatter.format(Date(session.updatedAt)),
                                                    color = AtikTextMuted,
                                                    fontSize = 10.sp
                                                )
                                            }
                                        }

                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            IconButton(
                                                onClick = {
                                                    sessionToRename = session
                                                    renameInputText = session.title
                                                },
                                                modifier = Modifier.size(26.dp)
                                            ) {
                                                Icon(
                                                    imageVector = Icons.Default.DriveFileRenameOutline,
                                                    contentDescription = "Rename",
                                                    tint = AtikTextMuted,
                                                    modifier = Modifier.size(14.dp)
                                                )
                                            }

                                            IconButton(
                                                onClick = { sessionToDelete = session },
                                                modifier = Modifier.size(26.dp)
                                            ) {
                                                Icon(
                                                    imageVector = Icons.Default.DeleteOutline,
                                                    contentDescription = "Delete",
                                                    tint = AtikError.copy(alpha = 0.8f),
                                                    modifier = Modifier.size(14.dp)
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    } else {
                        // NAVIGATION SECTIONS
                        Text(
                            text = "NAVIGATION SECTIONS",
                            color = AtikTextMuted,
                            fontSize = 10.5.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 0.8.sp,
                            modifier = Modifier.padding(start = 4.dp, bottom = 4.dp)
                        )

                        AtikNavTab.values().forEach { tab ->
                            val isSelected = tab == currentTab
                            NavigationDrawerItem(
                                icon = {
                                    Icon(
                                        imageVector = tab.icon,
                                        contentDescription = tab.title,
                                        tint = if (isSelected) AtikNeonCyan else AtikTextMuted,
                                        modifier = Modifier.size(19.dp)
                                    )
                                },
                                label = {
                                    Column {
                                        Text(
                                            text = tab.title,
                                            color = if (isSelected) AtikTextPrimary else AtikTextSecondary,
                                            fontSize = 13.5.sp,
                                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                                        )
                                        Text(
                                            text = tab.subtitle,
                                            color = if (isSelected) AtikNeonAzure else AtikTextMuted,
                                            fontSize = 10.sp
                                        )
                                    }
                                },
                                selected = isSelected,
                                onClick = {
                                    currentTab = tab
                                    coroutineScope.launch { drawerState.close() }
                                },
                                colors = NavigationDrawerItemDefaults.colors(
                                    selectedContainerColor = AtikElectricBlue.copy(alpha = 0.25f),
                                    unselectedContainerColor = Color.Transparent
                                ),
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier
                                    .padding(vertical = 2.dp)
                                    .testTag("drawer_item_${tab.name.lowercase()}")
                            )
                        }
                    }

                    Spacer(modifier = Modifier.weight(1f))

                    // Bottom info card in drawer
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = AtikSurface,
                        border = BorderStroke(0.8.dp, AtikBorder),
                        modifier = Modifier.fillMaxWidth().padding(top = 16.dp)
                    ) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(modifier = Modifier.size(8.dp).clip(CircleShape).background(AtikNeonCyan))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Atik AI v2.5 Online", color = AtikNeonCyan, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                            Spacer(modifier = Modifier.height(2.dp))
                            Text("Room DB • Smart Memory Active", color = AtikTextMuted, fontSize = 10.sp)
                        }
                    }
                }
            }
        }
    ) {
        // Dialogs for Chat History management
        if (showClearAllDialog) {
            AlertDialog(
                onDismissRequest = { showClearAllDialog = false },
                title = { Text("Clear All Conversations", color = AtikTextPrimary, fontWeight = FontWeight.Bold) },
                text = {
                    Text(
                        "Are you sure you want to delete all previous chat threads? All stored messages will be permanently cleared and a fresh session will begin.",
                        color = AtikTextSecondary,
                        fontSize = 13.sp
                    )
                },
                confirmButton = {
                    Button(
                        onClick = {
                            viewModel.clearAllSessions()
                            showClearAllDialog = false
                            currentTab = AtikNavTab.CHAT
                            coroutineScope.launch { drawerState.close() }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = AtikError)
                    ) {
                        Text("Clear All", color = Color.White)
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showClearAllDialog = false }) {
                        Text("Cancel", color = AtikTextMuted)
                    }
                },
                containerColor = AtikSurfaceVariant
            )
        }

        if (sessionToRename != null) {
            AlertDialog(
                onDismissRequest = { sessionToRename = null },
                title = { Text("Rename Chat Thread", color = AtikTextPrimary, fontWeight = FontWeight.Bold) },
                text = {
                    OutlinedTextField(
                        value = renameInputText,
                        onValueChange = { renameInputText = it },
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = AtikNeonCyan,
                            unfocusedBorderColor = AtikBorder,
                            focusedTextColor = AtikTextPrimary,
                            unfocusedTextColor = AtikTextPrimary
                        ),
                        modifier = Modifier.fillMaxWidth().testTag("rename_session_input")
                    )
                },
                confirmButton = {
                    Button(
                        onClick = {
                            sessionToRename?.let { s ->
                                if (renameInputText.isNotBlank()) {
                                    viewModel.renameSession(s.id, renameInputText.trim())
                                }
                            }
                            sessionToRename = null
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = AtikElectricBlue)
                    ) {
                        Text("Save", color = Color.White)
                    }
                },
                dismissButton = {
                    TextButton(onClick = { sessionToRename = null }) {
                        Text("Cancel", color = AtikTextMuted)
                    }
                },
                containerColor = AtikSurfaceVariant
            )
        }

        if (sessionToDelete != null) {
            AlertDialog(
                onDismissRequest = { sessionToDelete = null },
                title = { Text("Delete Conversation", color = AtikTextPrimary, fontWeight = FontWeight.Bold) },
                text = {
                    Text(
                        "Delete \"${sessionToDelete?.title}\"? This conversation will be removed permanently.",
                        color = AtikTextSecondary,
                        fontSize = 13.sp
                    )
                },
                confirmButton = {
                    Button(
                        onClick = {
                            sessionToDelete?.let { s ->
                                viewModel.deleteSession(s.id)
                            }
                            sessionToDelete = null
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = AtikError)
                    ) {
                        Text("Delete", color = Color.White)
                    }
                },
                dismissButton = {
                    TextButton(onClick = { sessionToDelete = null }) {
                        Text("Cancel", color = AtikTextMuted)
                    }
                },
                containerColor = AtikSurfaceVariant
            )
        }

        Box(modifier = modifier.fillMaxSize()) {
            Scaffold(
                modifier = Modifier
                    .fillMaxSize()
                    .background(AtikBlack),
            topBar = {
                // If not in full-screen Live Assistant or Vision Scanner, show top header
                if (currentTab != AtikNavTab.VOICE_LIVE && currentTab != AtikNavTab.VISION) {
                    AtikHeader(
                        currentLanguage = languageMode,
                        isGenerating = isGenerating,
                        isSpeaking = isSpeaking,
                        onLanguageChange = { viewModel.setLanguageMode(it) },
                        onNewChatClick = {
                            viewModel.startNewChat()
                            currentTab = AtikNavTab.CHAT
                        },
                        onMenuClick = {
                            coroutineScope.launch { drawerState.open() }
                        }
                    )
                }
            },
            containerColor = MaterialTheme.colorScheme.background
        ) { innerPadding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .background(MaterialTheme.colorScheme.background)
            ) {
                SmartActionFeedbackBanner(
                    phase = smartActionPhase,
                    onConfirm = { viewModel.confirmSmartAction() },
                    onAbort = { viewModel.abortSmartAction(it) },
                    onDismiss = { viewModel.dismissSmartActionFeedback() }
                )

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                ) {
                    Crossfade(targetState = currentTab, label = "tab_fade") { tab ->
                    when (tab) {
                        AtikNavTab.HOME -> {
                            HomeScreen(
                                recentSessions = allSessions,
                                onStartChatClick = { currentTab = AtikNavTab.CHAT },
                                onVoiceClick = {
                                    viewModel.voiceManager.startListening(
                                        mode = languageMode,
                                        onResult = { text ->
                                            currentTab = AtikNavTab.CHAT
                                            viewModel.sendMessage(text)
                                        },
                                        onError = { }
                                    )
                                },
                                onLiveClick = { currentTab = AtikNavTab.VOICE_LIVE },
                                onCameraClick = { currentTab = AtikNavTab.VISION },
                                onOpenPythonLab = { currentTab = AtikNavTab.PYTHON_LAB },
                                onOpenTerminal = { currentTab = AtikNavTab.TERMINAL },
                                onOpenSocialAI = { currentTab = AtikNavTab.SOCIAL },
                                onOpenTasksHub = { currentTab = AtikNavTab.TASKS_ROUTINES },
                                onOpenGameStudio = { currentTab = AtikNavTab.GAME_STUDIO },
                                onSelectSession = { sessionId ->
                                    viewModel.selectSession(sessionId)
                                    currentTab = AtikNavTab.CHAT
                                },
                                onPromptClick = { promptText ->
                                    currentTab = AtikNavTab.CHAT
                                    viewModel.sendMessage(promptText)
                                },
                                userName = userName,
                                preferredTitle = preferredTitle,
                                greetingStyle = greetingStyle,
                                themeMode = themeMode,
                                voiceGender = voiceGender,
                                voiceSpeed = voiceSpeed,
                                onOpenSettings = { currentTab = AtikNavTab.SETTINGS },
                                onUpdatePersonalProfile = { name, title, style ->
                                    viewModel.setPersonalProfile(name, title, style)
                                },
                                onToggleTheme = { mode ->
                                    viewModel.setThemeMode(mode)
                                },
                                avatarVisible = avatarVisible,
                                avatarScale = avatarScale,
                                avatarPosition = avatarPosition,
                                avatarGestureSpeed = avatarGestureSpeed,
                                avatarStance = avatarStance,
                                isSpeaking = isSpeaking,
                                rmsDb = rmsDb,
                                actionBubbleText = avatarActionTrigger,
                                onStanceChange = { stance ->
                                    viewModel.performStanceAction(stance)
                                },
                                onSaveAvatarCustomization = { visible, scale, pos, speed, stance ->
                                    viewModel.setAvatarCustomization(visible, scale, pos, speed, stance)
                                },
                                isNetworkOnline = isNetworkOnline,
                                connectionTypeName = networkConnectionType.displayName,
                                isSimulationOffline = isSimulationOffline,
                                pendingOfflineCount = pendingOfflineCount,
                                isSyncingData = isSyncingData,
                                onSyncNow = { viewModel.syncPendingOfflineData() },
                                dynamicThemeState = dynamicThemeState,
                                onSelectThemePreset = { viewModel.setDynamicThemePreset(it) },
                                onSelectAccentColor = { viewModel.setDynamicAccentColor(it.hex) },
                                onSelectButtonStyle = { viewModel.setDynamicButtonStyle(it) },
                                onSelectFontScale = { viewModel.setDynamicFontScale(it) },
                                onSelectBackgroundWidget = { viewModel.setDynamicBackgroundWidget(it) }
                            )
                        }

                        AtikNavTab.CHAT -> {
                            ChatScreen(
                                messages = currentMessages,
                                isGenerating = isGenerating,
                                isListening = isListening,
                                spokenText = spokenText,
                                rmsDb = rmsDb,
                                currentlySpeakingId = currentlySpeakingId,
                                languageMode = languageMode,
                                attachedImage = attachedImage,
                                attachedFileName = attachedFileName,
                                bossActionPhrase = bossActionPhrase,
                                onSendMessage = { viewModel.sendMessage(it) },
                                onStartVoice = {
                                    viewModel.voiceManager.startListening(
                                        mode = languageMode,
                                        onResult = { recognizedText ->
                                            viewModel.sendMessage(recognizedText, isVoiceCommand = true)
                                        },
                                        onError = { }
                                    )
                                },
                                onStopVoice = { viewModel.voiceManager.stopListening() },
                                onToggleSpeak = { msgId, text ->
                                    viewModel.toggleSpeakMessage(msgId, text)
                                },
                                onPickImage = { uri, name ->
                                    viewModel.attachImage(uri, name)
                                },
                                onClearAttachment = { viewModel.clearAttachment() },
                                onAvatarClick = { viewModel.triggerBossVoiceConfirmation() },
                                onSaveGeneratedImage = { imageUrl, prompt, onComplete ->
                                    viewModel.saveGeneratedImage(context, imageUrl, prompt, onComplete)
                                },
                                onRunInPythonLab = { code ->
                                    viewModel.runCodeInPythonLab(code) {
                                        currentTab = AtikNavTab.PYTHON_LAB
                                    }
                                },
                                onNavigateToPythonLab = { currentTab = AtikNavTab.PYTHON_LAB },
                                onNavigateToLive = { currentTab = AtikNavTab.VOICE_LIVE },
                                onNavigateToMemory = { currentTab = AtikNavTab.MEMORY },
                                onNavigateToTools = { currentTab = AtikNavTab.TOOLS },
                                onNavigateToTechGuides = { currentTab = AtikNavTab.TECH_GUIDES },
                                onNavigateToVision = { currentTab = AtikNavTab.VISION },
                                onNavigateToSocial = { currentTab = AtikNavTab.SOCIAL },
                                onOpenDrawer = {
                                    coroutineScope.launch { drawerState.open() }
                                },
                                onCaptureImage = { bitmap ->
                                    viewModel.sendMessage(
                                        text = "আতিক, আমি ক্যামেরা দিয়ে এই ছবিটি তুলেছি। এটি বিস্তারিতভাবে বিশ্লেষণ করে সমাধান বা পরামর্শ দাও।",
                                        overrideImage = bitmap,
                                        isVoiceCommand = true
                                    )
                                },
                                isNetworkOnline = isNetworkOnline,
                                connectionTypeName = networkConnectionType.displayName,
                                isSimulationOffline = isSimulationOffline,
                                onToggleSimulationOffline = { viewModel.toggleOfflineSimulation(it) }
                            )
                        }

                        AtikNavTab.VISION -> {
                            VisionScreen(
                                scanMode = visionScanMode,
                                activePreset = visionPreset,
                                qrResult = qrBarcodeResult,
                                ocrResult = ocrResult,
                                aiResult = visionAiResult,
                                isAnalyzing = isVisionAnalyzing,
                                statusMessage = visionStatusMessage,
                                onSetMode = { viewModel.setVisionScanMode(it) },
                                onSetPreset = { viewModel.setVisionPreset(it) },
                                onQrDetected = { viewModel.onQrBarcodeDetected(it) },
                                onOcrDetected = { viewModel.onOcrDetected(it) },
                                onCaptureImage = { bitmap ->
                                    viewModel.scanImageBitmapForBarcodeOrOcr(bitmap)
                                },
                                onSelectGalleryImage = { bitmap ->
                                    viewModel.scanImageBitmapForBarcodeOrOcr(bitmap)
                                },
                                onClearResults = { viewModel.clearVisionResults() },
                                onSendToChat = { prompt ->
                                    currentTab = AtikNavTab.CHAT
                                    viewModel.sendMessage(prompt)
                                },
                                onSpeakText = { text ->
                                    viewModel.voiceManager.speak(text, viewModel.languageMode.value)
                                },
                                onClose = {
                                    currentTab = AtikNavTab.HOME
                                }
                            )
                        }

                        AtikNavTab.SOCIAL -> {
                            SocialSchedulerScreen(
                                posts = socialPosts,
                                isGenerating = isGeneratingSocial,
                                generatedContent = generatedSocialContent,
                                socialEngine = viewModel.socialEngine,
                                onGenerateContent = { topic, platform, tone, audience ->
                                    viewModel.generateSocialContent(topic, platform, tone, audience)
                                },
                                onSavePost = { post -> viewModel.saveSocialPost(post) },
                                onUpdateStatus = { id, status -> viewModel.updateSocialPostStatus(id, status) },
                                onReschedulePost = { id, newTime -> viewModel.rescheduleSocialPost(id, newTime) },
                                onDeletePost = { id -> viewModel.deleteSocialPost(id) },
                                onSendToChat = { prompt ->
                                    currentTab = AtikNavTab.CHAT
                                    viewModel.sendMessage(prompt)
                                }
                            )
                        }

                        AtikNavTab.VOICE_LIVE -> {
                            LiveAssistantScreen(
                                isLiveActive = isLiveActive,
                                isListening = isListening,
                                isSpeaking = isSpeaking,
                                isThinking = isGenerating,
                                spokenText = spokenText,
                                lastAiReply = lastAiReply,
                                rmsDb = rmsDb,
                                languageMode = languageMode,
                                isWakeWordEnabled = isWakeWordEnabled,
                                wakeWordSensitivity = wakeWordSensitivity,
                                isHandsFreeDuplex = isHandsFreeDuplex,
                                isAudioChimeEnabled = isAudioChimeEnabled,
                                isHapticEnabled = isHapticFeedbackEnabled,
                                duplexState = voiceDuplexState,
                                onToggleWakeWord = { viewModel.setWakeWordEnabled(it) },
                                onSetSensitivity = { viewModel.setWakeWordSensitivity(it) },
                                onSetSensitivityByWeight = { viewModel.setWakeWordSensitivityByWeight(it) },
                                onToggleDuplex = { viewModel.setHandsFreeDuplex(it) },
                                onToggleAudioChime = { viewModel.setAudioChimeEnabled(it) },
                                onToggleHaptic = { viewModel.setHapticFeedbackEnabled(it) },
                                onTestChime = { viewModel.testAudioChime() },
                                onTestAudioCue = { viewModel.testAudioCue(it) },
                                onStartVoice = {
                                    viewModel.startLiveConversation(speakGreetingFirst = true)
                                },
                                onStopVoice = {
                                    viewModel.stopLiveConversation()
                                },
                                onSendMessage = { viewModel.sendMessage(it) },
                                onAnalyzeFrame = { bitmap ->
                                    viewModel.analyzeCameraFrame(bitmap)
                                },
                                onClose = {
                                    viewModel.stopLiveConversation()
                                    currentTab = AtikNavTab.HOME
                                }
                            )
                        }

                        AtikNavTab.PYTHON_LAB -> {
                            IdeWorkspaceScreen(
                                currentCode = currentIdeCode,
                                selectedLanguage = ideSelectedLanguage,
                                executionResult = ideExecutionResult,
                                diagnosticLogs = ideDiagnosticLogs,
                                isRunning = isIdeRunning,
                                isAiAssisting = isIdeAiAssisting,
                                onCodeChange = { viewModel.updateIdeCode(it) },
                                onSelectLanguage = { viewModel.setIdeLanguage(it) },
                                onRunCode = { viewModel.runIdeCode() },
                                onClearOutput = { viewModel.clearIdeOutput() },
                                onAutoFormat = { viewModel.autoFormatIdeCode() },
                                onAiGenerateCode = { viewModel.aiGenerateIdeCode(it) },
                                onAiDebugAndFix = { viewModel.aiDebugAndFixIdeCode() },
                                onAiRefactor = { viewModel.aiRefactorIdeCode() },
                                onAiExplain = {
                                    currentTab = AtikNavTab.CHAT
                                    viewModel.aiExplainIdeCode()
                                },
                                onExportFile = { fileName ->
                                    val exported = viewModel.exportIdeScript(fileName)
                                    Toast.makeText(context, "Saved: ${exported.fileName} (${exported.byteCount} bytes)", Toast.LENGTH_LONG).show()
                                },
                                onBack = { currentTab = AtikNavTab.HOME }
                            )
                        }

                        AtikNavTab.TERMINAL -> {
                            TerminalScreen(
                                lines = terminalLines,
                                currentDir = terminalCurrentDir,
                                isRunning = isTerminalRunning,
                                onExecuteCommand = { viewModel.executeTerminalCommand(it) },
                                onClearTerminal = { viewModel.clearTerminal() },
                                onStopProcess = { viewModel.stopTerminalProcess() },
                                remoteBackendUrl = terminalBackendUrl,
                                onSaveRemoteBackendUrl = { viewModel.setTerminalBackendUrl(it) }
                            )
                        }

                        AtikNavTab.GAME_STUDIO -> {
                            GameStudioScreen(
                                games = games,
                                recentScores = recentGameScores,
                                isGenerating = isGeneratingGame,
                                onGenerateGame = { prompt -> viewModel.generateGame(prompt) },
                                onDeleteGame = { id -> viewModel.deleteGame(id) },
                                onScoreLogged = { gameId, score, duration ->
                                    viewModel.recordGameScore(gameId, score, duration)
                                },
                                onSaveState = { gameId, stateJson ->
                                    viewModel.saveGameState(gameId, stateJson)
                                },
                                onStartVoiceInput = {
                                    viewModel.voiceManager.startListening(
                                        mode = languageMode,
                                        onResult = { text ->
                                            viewModel.generateGame(text)
                                        },
                                        onError = { }
                                    )
                                }
                            )
                        }

                        AtikNavTab.TOOLS -> {
                            ToolsScreen(
                                onSendToChat = { prompt ->
                                    currentTab = AtikNavTab.CHAT
                                    viewModel.sendMessage(prompt)
                                },
                                onSendToPythonLab = { code ->
                                    viewModel.setPythonCode(code)
                                    currentTab = AtikNavTab.PYTHON_LAB
                                },
                                onSendToTerminal = { cmd ->
                                    currentTab = AtikNavTab.TERMINAL
                                    viewModel.executeTerminalCommand(cmd)
                                },
                                onBoostPerformance = { viewModel.runPerformanceOptimization() },
                                isTranslating = isTranslating,
                                lastTranslationResult = lastTranslationResult,
                                onTranslate = { text, src, tgt -> viewModel.translateText(text, src, tgt) },
                                onPlayTranslatedAudio = { text, locale -> viewModel.playTranslatedAudio(text, locale) },
                                onNavigateToSystemGallery = { currentTab = AtikNavTab.SYSTEM_AUTOMATION }
                            )
                        }

                        AtikNavTab.SYSTEM_AUTOMATION -> {
                            SystemAutomationScreen(
                                systemStatus = systemStatusSummary,
                                soundProfile = currentSoundProfile,
                                isFlashlightOn = isFlashlightOn,
                                isAirplaneModeOn = isAirplaneModeOn,
                                photos = galleryPhotos,
                                selectedCategory = selectedPhotoCategory,
                                searchResult = semanticSearchResult,
                                isAnalyzingPhoto = isAnalyzingPhoto,
                                appShortcuts = viewModel.appShortcuts,
                                systemSubMenus = viewModel.systemSubMenus,
                                onToggleAirplaneMode = { viewModel.toggleAirplaneMode() },
                                onOpenMobileDataSettings = { viewModel.openMobileDataSettings() },
                                onOpenWifiControls = { viewModel.openWifiControls() },
                                onOpenBluetoothControls = { viewModel.openBluetoothControls() },
                                onToggleFlashlight = { viewModel.toggleSystemFlashlight() },
                                onSetSoundProfile = { viewModel.setSystemSoundProfile(it) },
                                onOpenSubMenu = { viewModel.openSystemSubMenu(it) },
                                onLaunchApp = { viewModel.launchInstalledApp(it) },
                                onSearchPhotos = { viewModel.searchGalleryPhotos(it) },
                                onSelectPhotoCategory = { viewModel.selectGalleryPhotoCategory(it) },
                                onIndexDevicePhoto = { viewModel.indexDevicePhoto(it) },
                                onSendToChat = { prompt ->
                                    currentTab = AtikNavTab.CHAT
                                    viewModel.sendMessage(prompt)
                                },
                                onBack = { currentTab = AtikNavTab.HOME }
                            )
                        }

                        AtikNavTab.NEWS -> {
                            NewsScreen(
                                articles = newsArticles,
                                selectedCategory = selectedNewsCategory,
                                isSearching = isSearchingWeb,
                                searchAnswer = lastSearchAnswer,
                                isSummarizing = isSummarizingArticle,
                                articleSummary = lastArticleSummary,
                                isRefreshingNews = isRefreshingNews,
                                onSearch = { viewModel.searchWeb(it) },
                                onSummarizeUrl = { viewModel.summarizeWebArticle(it) },
                                onSelectCategory = { viewModel.selectNewsCategory(it) },
                                onToggleBookmark = { viewModel.toggleNewsBookmark(it) },
                                onRefreshNews = { viewModel.refreshNewsFeed() },
                                onSendToChat = { prompt ->
                                    currentTab = AtikNavTab.CHAT
                                    viewModel.sendMessage(prompt)
                                },
                                onBack = { currentTab = AtikNavTab.HOME }
                            )
                        }

                        AtikNavTab.TECH_GUIDES -> {
                            TechGuidesScreen(
                                onSendToChat = { prompt ->
                                    currentTab = AtikNavTab.CHAT
                                    viewModel.sendMessage(prompt)
                                }
                            )
                        }

                        AtikNavTab.TASKS_ROUTINES -> {
                            TaskHubScreen(
                                tasks = allTasks,
                                routines = allRoutines,
                                reminders = allReminders,
                                workflows = allWorkflows,
                                notes = allNotes,
                                isExecutingWorkflow = isExecutingWorkflow,
                                lastWorkflowReport = lastWorkflowReport,
                                quietHoursConfig = quietHoursConfig,
                                pendingOfflineCount = pendingOfflineCount,
                                isSyncingData = isSyncingData,
                                onSyncNow = { viewModel.syncPendingOfflineData() },
                                onAddTask = { title, desc, priority, category ->
                                    viewModel.addTask(title, desc, priority, category)
                                },
                                onToggleTaskCompleted = { id, completed ->
                                    viewModel.toggleTaskCompleted(id, completed)
                                },
                                onDeleteTask = { id ->
                                    viewModel.deleteTask(id)
                                },
                                onClearCompletedTasks = {
                                    viewModel.clearCompletedTasks()
                                },
                                onToggleRoutine = { id, enabled ->
                                    viewModel.toggleRoutine(id, enabled)
                                },
                                onRunRoutineBriefing = { routineType ->
                                    viewModel.runRoutineBriefing(routineType)
                                    currentTab = AtikNavTab.CHAT
                                },
                                onAddReminder = { title, time, isAlarm ->
                                    viewModel.addReminder(title, time, isAlarm)
                                },
                                onDeleteReminder = { id ->
                                    viewModel.deleteReminder(id)
                                },
                                onAddWorkflow = { name, desc, emoji, time, actions ->
                                    viewModel.addWorkflow(name, desc, emoji, time, actions)
                                },
                                onToggleWorkflow = { id, enabled ->
                                    viewModel.toggleWorkflow(id, enabled)
                                },
                                onExecuteWorkflowNow = { workflow ->
                                    viewModel.executeWorkflowNow(workflow)
                                },
                                onDeleteWorkflow = { id ->
                                    viewModel.deleteWorkflow(id)
                                },
                                onAddNote = { title, content, category ->
                                    viewModel.addNote(title, content, category)
                                },
                                onDeleteNote = { id ->
                                    viewModel.deleteNote(id)
                                },
                                onTogglePinNote = { note ->
                                    viewModel.updateNote(note.copy(isPinned = !note.isPinned))
                                },
                                onToggleQuietHours = { viewModel.setQuietHoursEnabled(it) },
                                onSetQuietHoursSchedule = { sH, sM, eH, eM ->
                                    viewModel.setQuietHoursSchedule(sH, sM, eH, eM)
                                },
                                onSetDndAllowUrgent = { viewModel.setDndAllowUrgent(it) },
                                onSetDndVibrateOnly = { viewModel.setDndVibrateOnly(it) },
                                onSetDndSoundEnabled = { viewModel.setDndSoundEnabled(it) },
                                onOpenSystemDndSettings = { viewModel.openSystemDndSettings() },
                                onOpenAppNotificationSettings = { viewModel.openAppNotificationSettings() },
                                onTestAlertNotification = { viewModel.testAlertNotification() },
                                isAccessibilityConnected = isAccessibilityConnected,
                                smartActionEnabled = smartActionEnabled,
                                requireConfirmation = requireConfirmation,
                                actionCountdownSeconds = actionCountdownSeconds,
                                whatsappActionEnabled = whatsappActionEnabled,
                                imoActionEnabled = imoActionEnabled,
                                smsActionEnabled = smsActionEnabled,
                                phoneActionEnabled = phoneActionEnabled,
                                smartAudits = smartAudits,
                                onOpenAccessibilitySettings = { viewModel.openAccessibilitySettings() },
                                onToggleSmartAction = { viewModel.setSmartActionEnabled(it) },
                                onToggleRequireConfirmation = { viewModel.setRequireConfirmation(it) },
                                onSetCountdownSeconds = { viewModel.setActionCountdownSeconds(it) },
                                onToggleWhatsapp = { viewModel.setWhatsappActionEnabled(it) },
                                onToggleImo = { viewModel.setImoActionEnabled(it) },
                                onToggleSms = { viewModel.setSmsActionEnabled(it) },
                                onTogglePhone = { viewModel.setPhoneActionEnabled(it) },
                                onTriggerTestAction = { app, type, rec, msg ->
                                    viewModel.testSmartAction(app, type, rec, msg)
                                },
                                onClearSmartAudits = { viewModel.clearSmartActionAudits() }
                            )
                        }

                        AtikNavTab.HISTORY -> {
                            HistoryScreen(
                                sessions = allSessions,
                                activeSessionId = activeSessionId,
                                onSelectSession = { sessionId ->
                                    viewModel.selectSession(sessionId)
                                    currentTab = AtikNavTab.CHAT
                                },
                                onNewChatClick = {
                                    viewModel.startNewChat()
                                    currentTab = AtikNavTab.CHAT
                                },
                                onRenameSession = { sessionId, newTitle ->
                                    viewModel.renameSession(sessionId, newTitle)
                                },
                                onDeleteSession = { sessionId ->
                                    viewModel.deleteSession(sessionId)
                                }
                            )
                        }

                        AtikNavTab.MEMORY -> {
                            MemoryScreen(
                                memories = memories,
                                onAddMemory = { key, value, category ->
                                    viewModel.addMemory(key, value, category)
                                },
                                onDeleteMemory = { id ->
                                    viewModel.deleteMemory(id)
                                }
                            )
                        }

                        AtikNavTab.FILES -> {
                            FilesScreen(
                                files = files,
                                onAddFile = { uri, name, sizeStr, mimeType ->
                                    viewModel.addFile(uri, name, sizeStr, mimeType)
                                },
                                onDeleteFile = { id ->
                                    viewModel.deleteFile(id)
                                },
                                onChatWithFile = { file ->
                                    currentTab = AtikNavTab.CHAT
                                    viewModel.sendMessage("অনুগ্রহ করে এই ফাইলটি বিশ্লেষণ করো: ${file.fileName} (${file.fileSize})")
                                }
                            )
                        }

                        AtikNavTab.SETTINGS -> {
                            SettingsScreen(
                                currentLanguage = languageMode,
                                selectedModel = selectedModel,
                                customApiKey = customApiKey,
                                isKeyConfigured = isKeyConfigured,
                                autoReadTts = autoReadTts,
                                speechRate = voiceSpeed,
                                voicePitch = voicePitch,
                                voiceGender = voiceGender,
                                themeMode = themeMode,
                                userName = userName,
                                preferredTitle = preferredTitle,
                                greetingStyle = greetingStyle,
                                onLanguageChange = { viewModel.setLanguageMode(it) },
                                onModelChange = { viewModel.setSelectedModel(it) },
                                onSaveApiKey = { viewModel.setCustomApiKey(it) },
                                onAutoReadToggle = { viewModel.setAutoReadTts(it) },
                                onSpeechRateChange = { viewModel.setSpeechRate(it) },
                                onVoicePreferencesChange = { speed, pitch, gender ->
                                    viewModel.setVoicePreferences(speed, pitch, gender)
                                },
                                onThemeModeChange = { viewModel.setThemeMode(it) },
                                onSavePersonalProfile = { name, title, style ->
                                    viewModel.setPersonalProfile(name, title, style)
                                },
                                onTestVoiceAudition = { viewModel.testAuditionVoice() },
                                avatarVisible = avatarVisible,
                                avatarScale = avatarScale,
                                avatarPosition = avatarPosition,
                                avatarGestureSpeed = avatarGestureSpeed,
                                avatarStance = avatarStance,
                                onAvatarSettingsChange = { visible, scale, pos, speed, stance ->
                                    viewModel.setAvatarCustomization(visible, scale, pos, speed, stance)
                                },
                                onPerformStanceAction = { stance ->
                                    viewModel.performStanceAction(stance)
                                },
                                isNetworkOnline = isNetworkOnline,
                                connectionTypeName = networkConnectionType.displayName,
                                isSimulationOffline = isSimulationOffline,
                                onToggleSimulationOffline = { viewModel.toggleOfflineSimulation(it) },
                                isFloatingBubbleEnabled = isFloatingBubbleEnabled,
                                floatingBubbleSizeDp = floatingBubbleSizeDp,
                                isSystemOverlayActive = isSystemOverlayActive,
                                shortcuts = voiceShortcuts,
                                onToggleFloatingBubble = { viewModel.toggleFloatingBubble(it) },
                                onSetFloatingBubbleSize = { viewModel.setFloatingBubbleSize(it) },
                                onToggleSystemOverlay = { viewModel.toggleSystemFloatingService(context, it) },
                                onAddShortcut = { title, trigger, prompt, emoji ->
                                    viewModel.addCustomShortcut(title, trigger, prompt, emoji)
                                },
                                onDeleteShortcut = { viewModel.deleteShortcut(it) },
                                memoryDiagnostics = memoryDiagnostics,
                                storageDiagnostics = storageDiagnostics,
                                powerProfile = powerProfile,
                                isOptimizing = isOptimizing,
                                lastOptimizationResult = lastOptimizationResult,
                                onRunOptimization = { viewModel.runPerformanceOptimization() },
                                onRefreshDiagnostics = { viewModel.refreshPerformanceDiagnostics() },
                                onSelectPowerProfile = { viewModel.setPowerProfile(it) },
                                onToggleAutoClean = { viewModel.setAutoCleanConfig(it, storageDiagnostics.autoCleanThresholdMb) },
                                isBiometricEnabled = isBiometricEnabled,
                                hasMasterPin = hasMasterPin,
                                onToggleBiometric = { viewModel.setBiometricEnabled(it) },
                                onSetMasterPin = { viewModel.setMasterPin(it) },
                                onLockAppNow = { viewModel.lockApp() },
                                onExportEncryptedBackup = { viewModel.exportEncryptedBackup() },
                                onRestoreEncryptedBackup = { viewModel.restoreEncryptedBackup(it) },
                                onClearAllLocalData = { viewModel.clearAllLocalData() },
                                userAccent = userAccent,
                                onSelectVoiceAccent = { viewModel.setVoiceAccent(it) },
                                isWakeWordEnabled = isWakeWordEnabled,
                                wakeWordSensitivity = wakeWordSensitivity,
                                isHandsFreeDuplex = isHandsFreeDuplex,
                                isAudioChimeEnabled = isAudioChimeEnabled,
                                isHapticEnabled = isHapticFeedbackEnabled,
                                onToggleWakeWord = { viewModel.setWakeWordEnabled(it) },
                                onSetSensitivity = { viewModel.setWakeWordSensitivity(it) },
                                onSetSensitivityByWeight = { viewModel.setWakeWordSensitivityByWeight(it) },
                                onToggleDuplex = { viewModel.setHandsFreeDuplex(it) },
                                onToggleAudioChime = { viewModel.setAudioChimeEnabled(it) },
                                onToggleHaptic = { viewModel.setHapticFeedbackEnabled(it) },
                                onTestChime = { viewModel.testAudioChime() },
                                onTestAudioCue = { viewModel.testAudioCue(it) },
                                isSyncingData = isSyncingData,
                                syncStatusText = syncStatusText,
                                pendingOfflineCount = pendingOfflineCount,
                                lastSyncTimestamp = lastSyncTimestamp,
                                autoSyncEnabled = autoSyncEnabled,
                                offlineFallbackPersona = offlineFallbackPersona,
                                syncOnlyOnWifi = syncOnlyOnWifi,
                                databaseMetrics = localDatabaseMetrics,
                                notes = allNotes,
                                onSyncNow = { viewModel.syncPendingOfflineData() },
                                onToggleAutoSync = { viewModel.setAutoSyncEnabled(it) },
                                onToggleOfflineFallback = { viewModel.setOfflineFallbackPersona(it) },
                                onToggleSyncOnlyOnWifi = { viewModel.setSyncOnlyOnWifi(it) },
                                onClearOfflineCache = { viewModel.clearOfflineCache() },
                                onAddNote = { title, content -> viewModel.addNote(title, content) },
                                onDeleteNote = { viewModel.deleteNote(it) },
                                dynamicThemeState = dynamicThemeState,
                                onSelectThemePreset = { viewModel.setDynamicThemePreset(it) },
                                onSelectAccentColor = { viewModel.setDynamicAccentColor(it.hex) },
                                onSelectButtonStyle = { viewModel.setDynamicButtonStyle(it) },
                                onSelectFontScale = { viewModel.setDynamicFontScale(it) },
                                onSelectBackgroundWidget = { viewModel.setDynamicBackgroundWidget(it) }
                            )
                        }
                    }
                }
            }
        }
    }

            // Floating Assistant Action Bubble (Step 14 Requirement 1)
            FloatingAssistantBubble(
                isVisible = isFloatingBubbleEnabled,
                isListening = isListening,
                isGenerating = isGenerating,
                bubbleSizeDp = floatingBubbleSizeDp,
                onTap = { viewModel.setQuickOverlayVisible(true) },
                onLongPress = {
                    viewModel.setQuickOverlayVisible(true)
                    viewModel.voiceManager.startListening(
                        mode = languageMode,
                        onResult = { recognizedText ->
                            viewModel.sendMessage(recognizedText, isVoiceCommand = true)
                        },
                        onError = { }
                    )
                }
            )

            // Quick Result Overlay Bottom Sheet (Step 14 Requirement 3)
            QuickResultOverlaySheet(
                isVisible = isQuickOverlayVisible,
                isListening = isListening,
                isGenerating = isGenerating,
                spokenText = spokenText,
                lastAiReply = lastAiReply,
                currentlySpeaking = currentlySpeakingId != null,
                shortcuts = voiceShortcuts,
                onStartVoice = {
                    viewModel.voiceManager.startListening(
                        mode = languageMode,
                        onResult = { recognizedText ->
                            viewModel.sendMessage(recognizedText, isVoiceCommand = true)
                        },
                        onError = { }
                    )
                },
                onStopVoice = { viewModel.voiceManager.stopListening() },
                onSendText = { viewModel.sendMessage(it) },
                onToggleSpeak = { text ->
                    viewModel.toggleSpeakMessage("quick_overlay", text)
                },
                onExecuteShortcut = { shortcut ->
                    viewModel.executeVoiceShortcut(shortcut)
                },
                onOpenFullChat = {
                    viewModel.setQuickOverlayVisible(false)
                    currentTab = AtikNavTab.CHAT
                },
                onDismiss = { viewModel.setQuickOverlayVisible(false) }
            )

            // Biometric Lock Screen Overlay (Step 16 Requirement 1)
            BiometricLockOverlay(
                isLocked = isAppLocked,
                failedAttempts = failedAttempts,
                onVerifyPin = { pin -> viewModel.verifyMasterPin(pin) },
                onTriggerBiometrics = { act, onSucc, onErr ->
                    viewModel.triggerBiometricAuth(act, onSucc, onErr)
                }
            )
        }
    }
}
