package com.example.ui

import android.app.Application
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.ai.AiModelInfo
import com.example.ai.GeminiLiveClient
import com.example.ai.GeminiService
import com.example.ai.ImageGenerationEngine
import com.example.ai.LanguageMode
import com.example.data.AppDatabase
import com.example.data.ChatMessageEntity
import com.example.data.ChatRepository
import com.example.data.ChatSessionEntity
import com.example.data.MemoryEntity
import com.example.data.SavedFileEntity
import com.example.device.DeviceHardwareManager
import com.example.python.PythonExecutionResult
import com.example.python.PythonSandboxEngine
import com.example.terminal.TerminalLine
import com.example.terminal.TerminalLineType
import com.example.terminal.TerminalSandboxEngine
import com.example.ai.VisionScannerEngine
import com.example.ai.VisionScanMode
import com.example.ai.VisionAiPreset
import com.example.ai.QrBarcodeResult
import com.example.ai.OcrResult
import com.example.ai.VisionAiAnalysisResult
import com.example.data.SocialPlatform
import com.example.data.SocialPostEntity
import com.example.social.GeneratedSocialContent
import com.example.social.SocialMediaEngine
import com.example.automation.SmartRoutineEngine
import com.example.automation.ParsedAutomationCommand
import com.example.data.TaskItemEntity
import com.example.data.RoutineEntity
import com.example.data.ReminderEntity
import com.example.widget.VoiceShortcutsEngine
import com.example.widget.VoiceShortcut
import com.example.widget.ShortcutActionType
import com.example.widget.FloatingBubbleService
import com.example.performance.ResourceOptimizationEngine
import com.example.performance.PowerProfileMode
import com.example.performance.MemoryDiagnostics
import com.example.performance.StorageDiagnostics
import com.example.performance.OptimizationResult
import android.app.Activity
import com.example.security.DataEncryptionEngine
import com.example.security.BiometricSecurityEngine
import com.example.translation.GlobalTranslationEngine
import com.example.translation.TranslationResult
import com.example.translation.VoiceAccent
import com.example.news.SmartWebSearchEngine
import com.example.news.NewsArticle
import com.example.news.NewsCategory
import com.example.news.WebSearchAnswer
import com.example.news.ArticleSummaryResult
import com.example.ide.IdeSimulatorEngine
import com.example.ide.SupportedLanguage
import com.example.ide.IdeExecutionResult
import com.example.ide.DiagnosticLog
import com.example.ide.ExportedFileResult
import com.example.device.SystemAutomationEngine
import com.example.device.SoundProfile
import com.example.device.SystemStatusSummary
import com.example.device.AppNavigationEngine
import com.example.gallery.GalleryAiEngine
import com.example.gallery.GalleryPhotoItem
import com.example.gallery.PhotoCategory
import com.example.gallery.SemanticSearchResult
import java.util.Locale
import org.json.JSONArray
import org.json.JSONObject
import android.provider.Settings
import com.example.network.NetworkConnectivityMonitor
import com.example.network.NetworkConnectionType
import com.example.ai.OfflineAiEngine
import com.example.ai.OfflineAiResult
import com.example.ui.screens.DEFAULT_PYTHON_TEMPLATES
import com.example.ui.theme.AppThemeMode
import com.example.ui.components.AvatarPosition
import com.example.ui.components.KungFuStance
import com.example.voice.VoiceGender
import com.example.voice.VoiceManager
import com.example.voice.WakeWordEngine
import com.example.voice.WakeWordSensitivity
import com.example.voice.VoiceDuplexState
import com.example.voice.AudioCueType
import com.example.data.WorkflowEntity
import com.example.data.NoteEntity
import com.example.data.OfflineActionEntity
import com.example.data.LocalDatabaseMetrics
import com.example.data.AtikDataStorePreferences
import com.example.data.LocalCacheManager
import com.example.data.CacheMetrics
import com.example.network.OfflineSyncEngine
import com.example.automation.TaskSchedulerEngine
import com.example.automation.WorkflowActionType
import com.example.automation.QuietHoursConfig
import com.example.automation.WorkflowExecutionReport
import com.example.accessibility.AtikAccessibilityActionService
import com.example.accessibility.SmartActionAutomationEngine
import com.example.accessibility.SmartActionParser
import com.example.accessibility.SmartActionPhase
import com.example.accessibility.SmartActionRequest
import com.example.accessibility.SmartActionType
import com.example.accessibility.TargetMessagingApp
import com.example.data.SmartActionAuditEntity
import com.example.data.ThemeConfigEntity
import com.example.data.GameProjectEntity
import com.example.data.GameScoreEntity
import com.example.game.GameGeneratorEngine
import com.example.game.GameTemplateType
import com.example.ui.theme.ThemePreset
import com.example.ui.theme.AppButtonStyle
import com.example.ui.theme.BackgroundWidgetType
import com.example.ui.theme.DynamicThemeState
import com.example.ui.theme.DynamicThemeVoiceParser
import com.example.ui.theme.ThemeCommandResult
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.InputStream

class AtikViewModel(application: Application) : AndroidViewModel(application) {

    private val db = AppDatabase.getDatabase(application)
    val encryptionEngine = DataEncryptionEngine(application)
    private val repository = ChatRepository(
        chatDao = db.chatDao(),
        memoryDao = db.memoryDao(),
        fileDao = db.fileDao(),
        generatedImageDao = db.generatedImageDao(),
        userSettingDao = db.userSettingDao(),
        socialPostDao = db.socialPostDao(),
        automationDao = db.automationDao(),
        noteDao = db.noteDao(),
        offlineSyncDao = db.offlineSyncDao(),
        cacheDao = db.cacheDao(),
        smartActionDao = db.smartActionDao(),
        themeDao = db.themeDao(),
        gameDao = db.gameDao()
    )
    val geminiService = GeminiService(application)
    val socialEngine = SocialMediaEngine(geminiService)
    val voiceManager = VoiceManager(application)

    // Interactive Live Voice Assistant & Wake-Word Engine (Step 21)
    val wakeWordEngine = WakeWordEngine(application)
    val isWakeWordEnabled: StateFlow<Boolean> = wakeWordEngine.isWakeWordEnabled
    val wakeWordSensitivity: StateFlow<WakeWordSensitivity> = wakeWordEngine.sensitivity
    val isHandsFreeDuplexEnabled: StateFlow<Boolean> = wakeWordEngine.isHandsFreeDuplexEnabled
    val isAudioChimeEnabled: StateFlow<Boolean> = wakeWordEngine.isAudioChimeEnabled
    val isHapticFeedbackEnabled: StateFlow<Boolean> = wakeWordEngine.isHapticFeedbackEnabled
    val voiceDuplexState: StateFlow<VoiceDuplexState> = wakeWordEngine.duplexState
    val wakeWordAmplitude: StateFlow<Float> = wakeWordEngine.rmsAmplitude

    val geminiLiveClient = GeminiLiveClient(viewModelScope) {
        geminiService.getResolvedApiKey(_customApiKey.value)
    }

    private val pythonEngine = PythonSandboxEngine()
    private val terminalEngine = TerminalSandboxEngine(pythonEngine)
    val imageEngine = ImageGenerationEngine()
    val hardwareManager = DeviceHardwareManager.getInstance(application)
    val isFlashlightOn: StateFlow<Boolean> = hardwareManager.isFlashlightOn

    // Network & Offline AI Infrastructure (Step 12)
    val networkMonitor = NetworkConnectivityMonitor(application, viewModelScope)
    val offlineAiEngine = OfflineAiEngine(application, repository, hardwareManager)

    // Smart Automation & Routine Task Engine (Step 13)
    val routineEngine = SmartRoutineEngine(application, repository)

    val isNetworkOnline: StateFlow<Boolean> = networkMonitor.isEffectiveOnline
    val isRealNetworkOnline: StateFlow<Boolean> = networkMonitor.isRealOnline
    val networkConnectionType: StateFlow<NetworkConnectionType> = networkMonitor.connectionType
    val isSimulationOffline: StateFlow<Boolean> = networkMonitor.isSimulationOffline

    // Offline AI Capabilities & Storage Persistence Engine (Step 23)
    val dataStorePreferences = AtikDataStorePreferences(application)
    val offlineSyncEngine = OfflineSyncEngine(
        context = application,
        repository = repository,
        dataStorePrefs = dataStorePreferences,
        networkMonitor = networkMonitor,
        routineEngine = routineEngine,
        scope = viewModelScope
    )
    val localCacheManager = LocalCacheManager(
        context = application,
        repository = repository,
        encryptionEngine = encryptionEngine,
        scope = viewModelScope
    )
    val cacheMetrics: StateFlow<CacheMetrics> = localCacheManager.cacheMetrics

    val allNotes: StateFlow<List<NoteEntity>> = repository.allNotes
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val isSyncingData: StateFlow<Boolean> = offlineSyncEngine.isSyncing
    val syncStatusText: StateFlow<String> = offlineSyncEngine.syncStatus
    val pendingOfflineActionsCount: StateFlow<Int> = offlineSyncEngine.pendingCount
    val lastSyncTimestamp: StateFlow<Long> = offlineSyncEngine.lastSyncTimestamp
    val autoSyncEnabled: StateFlow<Boolean> = dataStorePreferences.autoSyncEnabled
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), true)
    val offlineFallbackPersona: StateFlow<Boolean> = dataStorePreferences.offlineFallbackPersona
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), true)
    val syncOnlyOnWifi: StateFlow<Boolean> = dataStorePreferences.syncOnlyOnWifi
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), false)

    private val _localDatabaseMetrics = MutableStateFlow(LocalDatabaseMetrics())
    val localDatabaseMetrics: StateFlow<LocalDatabaseMetrics> = _localDatabaseMetrics.asStateFlow()

    // Smart Actions & Accessibility Automation Engine (Step 24)
    val smartActionEngine = SmartActionAutomationEngine(
        context = application,
        repository = repository,
        dataStorePreferences = dataStorePreferences
    )
    val smartActionPhase: StateFlow<SmartActionPhase> = smartActionEngine.livePhase
    val isAccessibilityServiceConnected: StateFlow<Boolean> = AtikAccessibilityActionService.isServiceConnected
    val pendingConsentRequest: StateFlow<SmartActionRequest?> = smartActionEngine.pendingConsentRequest
    val smartActionAudits: StateFlow<List<SmartActionAuditEntity>> = repository.allSmartAuditsFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val recentSmartAudits: StateFlow<List<SmartActionAuditEntity>> = repository.recentSmartAuditsFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val smartActionEnabled: StateFlow<Boolean> = dataStorePreferences.smartActionEnabled
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), true)
    val requireConfirmation: StateFlow<Boolean> = dataStorePreferences.requireConfirmation
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), true)
    val actionCountdownSeconds: StateFlow<Long> = dataStorePreferences.countdownSeconds
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 5L)
    val whatsappActionEnabled: StateFlow<Boolean> = dataStorePreferences.whatsappActionEnabled
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), true)
    val imoActionEnabled: StateFlow<Boolean> = dataStorePreferences.imoActionEnabled
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), true)
    val smsActionEnabled: StateFlow<Boolean> = dataStorePreferences.smsActionEnabled
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), true)
    val phoneActionEnabled: StateFlow<Boolean> = dataStorePreferences.phoneActionEnabled
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), true)

    // Tasks & Automation States (Step 13)
    val allTasks: StateFlow<List<TaskItemEntity>> = repository.allTasks
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val pendingTasks: StateFlow<List<TaskItemEntity>> = repository.pendingTasks
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allRoutines: StateFlow<List<RoutineEntity>> = repository.allRoutines
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allReminders: StateFlow<List<ReminderEntity>> = repository.allReminders
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Voice Shortcuts & Floating Assistant Widget (Step 14)
    val shortcutsEngine = VoiceShortcutsEngine(application)
    val voiceShortcuts: StateFlow<List<VoiceShortcut>> = shortcutsEngine.shortcuts

    private val prefs = application.getSharedPreferences("atik_ai_prefs", Context.MODE_PRIVATE)

    private val _isFloatingBubbleEnabled = MutableStateFlow(
        prefs.getBoolean("floating_bubble_enabled", true)
    )
    val isFloatingBubbleEnabled: StateFlow<Boolean> = _isFloatingBubbleEnabled.asStateFlow()

    private val _isQuickOverlayVisible = MutableStateFlow(false)
    val isQuickOverlayVisible: StateFlow<Boolean> = _isQuickOverlayVisible.asStateFlow()

    private val _floatingBubbleSizeDp = MutableStateFlow(
        prefs.getInt("floating_bubble_size_dp", 60)
    )
    val floatingBubbleSizeDp: StateFlow<Int> = _floatingBubbleSizeDp.asStateFlow()

    private val _isSystemOverlayActive = MutableStateFlow(FloatingBubbleService.isRunning)
    val isSystemOverlayActive: StateFlow<Boolean> = _isSystemOverlayActive.asStateFlow()

    // App Performance & Resource Optimization Engine (Step 15)
    val optimizationEngine = ResourceOptimizationEngine(application)
    val powerProfile: StateFlow<PowerProfileMode> = optimizationEngine.powerProfile
    val memoryDiagnostics: StateFlow<MemoryDiagnostics> = optimizationEngine.memoryDiagnostics
    val storageDiagnostics: StateFlow<StorageDiagnostics> = optimizationEngine.storageDiagnostics
    val isOptimizing: StateFlow<Boolean> = optimizationEngine.isOptimizing
    val lastOptimizationResult: StateFlow<OptimizationResult?> = optimizationEngine.lastOptimizationResult

    // Security, Privacy & Data Encryption Engine (Step 16)
    val biometricEngine = BiometricSecurityEngine(application)
    val isBiometricEnabled: StateFlow<Boolean> = biometricEngine.isBiometricEnabled
    val hasMasterPin: StateFlow<Boolean> = biometricEngine.hasMasterPin
    val isAppLocked: StateFlow<Boolean> = biometricEngine.isAppLocked
    val failedAttempts: StateFlow<Int> = biometricEngine.failedAttempts

    // Global Multi-Language Translation & Accent Engine (Step 17)
    val translationEngine = GlobalTranslationEngine(application, geminiService)
    val isTranslating: StateFlow<Boolean> = translationEngine.isTranslating
    val lastTranslationResult: StateFlow<TranslationResult?> = translationEngine.lastResult
    val translationHistory: StateFlow<List<TranslationResult>> = translationEngine.translationHistory

    private val _userAccent = MutableStateFlow(
        try {
            VoiceAccent.valueOf(prefs.getString("voice_accent", VoiceAccent.US_ENGLISH.name) ?: VoiceAccent.US_ENGLISH.name)
        } catch (_: Exception) {
            VoiceAccent.US_ENGLISH
        }
    )
    val userAccent: StateFlow<VoiceAccent> = _userAccent.asStateFlow()

    // Smart Web Search & Live News Aggregator Engine (Step 18)
    val webSearchEngine = SmartWebSearchEngine(application, geminiService)
    val isSearchingWeb: StateFlow<Boolean> = webSearchEngine.isSearching
    val lastSearchAnswer: StateFlow<WebSearchAnswer?> = webSearchEngine.lastSearchAnswer
    val isSummarizingArticle: StateFlow<Boolean> = webSearchEngine.isSummarizing
    val lastArticleSummary: StateFlow<ArticleSummaryResult?> = webSearchEngine.lastArticleSummary
    val selectedNewsCategory: StateFlow<NewsCategory> = webSearchEngine.selectedCategory
    val newsArticles: StateFlow<List<NewsArticle>> = webSearchEngine.newsArticles
    val isRefreshingNews: StateFlow<Boolean> = webSearchEngine.isRefreshingNews

    // AI Coding Assistant & IDE Simulator Engine (Step 19)
    val ideEngine = IdeSimulatorEngine(application, geminiService)
    val ideSelectedLanguage: StateFlow<SupportedLanguage> = ideEngine.selectedLanguage
    val ideCodeBuffer: StateFlow<Map<SupportedLanguage, String>> = ideEngine.codeBuffer
    val isIdeRunning: StateFlow<Boolean> = ideEngine.isRunning
    val ideExecutionResult: StateFlow<IdeExecutionResult?> = ideEngine.lastExecutionResult
    val ideDiagnosticLogs: StateFlow<List<DiagnosticLog>> = ideEngine.diagnosticLogs
    val isIdeAiAssisting: StateFlow<Boolean> = ideEngine.isAiAssisting

    // Deep System Automation & Airplane Mode Engine (Step 20)
    val systemAutomationEngine = SystemAutomationEngine(application, hardwareManager)
    val appNavigationEngine = AppNavigationEngine(application)
    val galleryAiEngine = GalleryAiEngine(application, geminiService)

    val currentSoundProfile: StateFlow<SoundProfile> = systemAutomationEngine.currentSoundProfile
    val isAirplaneModeOn: StateFlow<Boolean> = systemAutomationEngine.isAirplaneModeOn
    val galleryPhotos: StateFlow<List<GalleryPhotoItem>> = galleryAiEngine.photos
    val selectedPhotoCategory: StateFlow<PhotoCategory> = galleryAiEngine.selectedCategory
    val semanticSearchResult: StateFlow<SemanticSearchResult?> = galleryAiEngine.lastSearchResult
    val isAnalyzingPhoto: StateFlow<Boolean> = galleryAiEngine.isAnalyzing
    val appShortcuts = appNavigationEngine.popularAppShortcuts
    val systemSubMenus = appNavigationEngine.systemSubMenus

    // Smart Automation Workflows & Task Scheduler Engine (Step 22)
    val taskSchedulerEngine = TaskSchedulerEngine(
        context = application,
        repository = repository,
        routineEngine = routineEngine,
        systemAutomationEngine = systemAutomationEngine,
        hardwareManager = hardwareManager,
        webSearchEngine = webSearchEngine,
        voiceManager = voiceManager
    )

    val allWorkflows: StateFlow<List<WorkflowEntity>> = repository.allWorkflows
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val quietHoursConfig: StateFlow<QuietHoursConfig> = taskSchedulerEngine.quietHoursConfig
    val isExecutingWorkflow: StateFlow<Boolean> = taskSchedulerEngine.isExecutingWorkflow
    val lastWorkflowReport: StateFlow<WorkflowExecutionReport?> = taskSchedulerEngine.lastWorkflowReport

    // Live continuous conversation state
    private val _isLiveActive = MutableStateFlow(false)
    val isLiveActive: StateFlow<Boolean> = _isLiveActive.asStateFlow()

    // Current active session ID
    private val _currentSessionId = MutableStateFlow<String?>(null)
    val currentSessionId: StateFlow<String?> = _currentSessionId.asStateFlow()

    // Messages for current active session
    private val _currentMessages = MutableStateFlow<List<ChatMessageEntity>>(emptyList())
    val currentMessages: StateFlow<List<ChatMessageEntity>> = _currentMessages.asStateFlow()

    // All sessions
    val allSessions: StateFlow<List<ChatSessionEntity>> = repository.sessions
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Memories
    val memories: StateFlow<List<MemoryEntity>> = repository.memories
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Files
    val files: StateFlow<List<SavedFileEntity>> = repository.files
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Social Media Posts
    val socialPosts: StateFlow<List<SocialPostEntity>> = repository.socialPosts
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _isGeneratingSocial = MutableStateFlow(false)
    val isGeneratingSocial: StateFlow<Boolean> = _isGeneratingSocial.asStateFlow()

    private val _generatedSocialContent = MutableStateFlow<GeneratedSocialContent?>(null)
    val generatedSocialContent: StateFlow<GeneratedSocialContent?> = _generatedSocialContent.asStateFlow()

    // Generation state
    private val _isGenerating = MutableStateFlow(false)
    val isGenerating: StateFlow<Boolean> = _isGenerating.asStateFlow()

    // Language mode - default to BANGLA for native Bengali & English assistant conversations
    private val _languageMode = MutableStateFlow(
        try {
            val saved = prefs.getString("pref_language_mode", LanguageMode.BANGLA.name)
            LanguageMode.valueOf(saved ?: LanguageMode.BANGLA.name)
        } catch (_: Exception) {
            LanguageMode.BANGLA
        }
    )
    val languageMode: StateFlow<LanguageMode> = _languageMode.asStateFlow()

    // Model name - default to gemini-3.5-flash as per Gemini API guidelines
    private val _selectedModel = MutableStateFlow(
        prefs.getString("pref_model_id", "gemini-3.5-flash")?.let { id ->
            if (id == "gemini-3.8-flash" || id == "gemini-2.0-flash" || id.isBlank()) "gemini-3.5-flash" else id
        } ?: "gemini-3.5-flash"
    )
    val selectedModel: StateFlow<String> = _selectedModel.asStateFlow()

    // Custom API Key
    private val _customApiKey = MutableStateFlow(prefs.getString("pref_custom_api_key", "").orEmpty())
    val customApiKey: StateFlow<String> = _customApiKey.asStateFlow()

    // Auto-read TTS
    private val _autoReadTts = MutableStateFlow(prefs.getBoolean("pref_auto_read", false))
    val autoReadTts: StateFlow<Boolean> = _autoReadTts.asStateFlow()

    // Dynamic Theme Mode
    private val _themeMode = MutableStateFlow(
        try {
            val saved = prefs.getString("pref_theme_mode", AppThemeMode.CYBERPUNK_DARK.name)
            AppThemeMode.valueOf(saved ?: AppThemeMode.CYBERPUNK_DARK.name)
        } catch (_: Exception) {
            AppThemeMode.CYBERPUNK_DARK
        }
    )
    val themeMode: StateFlow<AppThemeMode> = _themeMode.asStateFlow()

    // Dynamic Home-Screen Theme Changer & Persistence (Step 25 Requirements 1, 2, 3, 4)
    private val _dynamicThemeState = MutableStateFlow(DynamicThemeState())
    val dynamicThemeState: StateFlow<DynamicThemeState> = _dynamicThemeState.asStateFlow()

    // In-App 2D Game Generator Engine (Step 26 Requirements 1, 2, 3, 4)
    val gameGeneratorEngine = GameGeneratorEngine(repository, geminiService)
    val games: StateFlow<List<GameProjectEntity>> = repository.games
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val recentGameScores: StateFlow<List<GameScoreEntity>> = (db.gameDao().getRecentScores(25))
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    private val _isGeneratingGame = MutableStateFlow(false)
    val isGeneratingGame: StateFlow<Boolean> = _isGeneratingGame.asStateFlow()

    private val _activeGameToPlay = MutableStateFlow<GameProjectEntity?>(null)
    val activeGameToPlay: StateFlow<GameProjectEntity?> = _activeGameToPlay.asStateFlow()

    // Voice Customization
    private val _voiceSpeed = MutableStateFlow(prefs.getFloat("pref_voice_speed", 1.0f))
    val voiceSpeed: StateFlow<Float> = _voiceSpeed.asStateFlow()

    private val _voicePitch = MutableStateFlow(prefs.getFloat("pref_voice_pitch", 1.0f))
    val voicePitch: StateFlow<Float> = _voicePitch.asStateFlow()

    private val _voiceGender = MutableStateFlow(
        try {
            val saved = prefs.getString("pref_voice_gender", VoiceGender.DYNAMIC.name)
            VoiceGender.valueOf(saved ?: VoiceGender.DYNAMIC.name)
        } catch (_: Exception) {
            VoiceGender.DYNAMIC
        }
    )
    val voiceGender: StateFlow<VoiceGender> = _voiceGender.asStateFlow()

    // Personal Profile & Welcome Customization
    private val _userName = MutableStateFlow(prefs.getString("pref_user_name", "Atikur Rahman") ?: "Atikur Rahman")
    val userName: StateFlow<String> = _userName.asStateFlow()

    private val _preferredTitle = MutableStateFlow(prefs.getString("pref_preferred_title", "Atik Bhai") ?: "Atik Bhai")
    val preferredTitle: StateFlow<String> = _preferredTitle.asStateFlow()

    private val _greetingStyle = MutableStateFlow(prefs.getString("pref_greeting_style", "Time-Aware") ?: "Time-Aware")
    val greetingStyle: StateFlow<String> = _greetingStyle.asStateFlow()

    // Kung-Fu Warrior Animated Avatar States (Step 11)
    private val _avatarVisible = MutableStateFlow(prefs.getBoolean("pref_avatar_visible", true))
    val avatarVisible: StateFlow<Boolean> = _avatarVisible.asStateFlow()

    private val _avatarScale = MutableStateFlow(prefs.getFloat("pref_avatar_scale", 1.0f))
    val avatarScale: StateFlow<Float> = _avatarScale.asStateFlow()

    private val _avatarPosition = MutableStateFlow(
        try {
            val saved = prefs.getString("pref_avatar_position", AvatarPosition.CENTER_HERO.name)
            AvatarPosition.valueOf(saved ?: AvatarPosition.CENTER_HERO.name)
        } catch (_: Exception) {
            AvatarPosition.CENTER_HERO
        }
    )
    val avatarPosition: StateFlow<AvatarPosition> = _avatarPosition.asStateFlow()

    private val _avatarGestureSpeed = MutableStateFlow(prefs.getFloat("pref_avatar_gesture_speed", 1.0f))
    val avatarGestureSpeed: StateFlow<Float> = _avatarGestureSpeed.asStateFlow()

    private val _avatarStance = MutableStateFlow(
        try {
            val saved = prefs.getString("pref_avatar_stance", KungFuStance.IDLE_GUARD.name)
            KungFuStance.valueOf(saved ?: KungFuStance.IDLE_GUARD.name)
        } catch (_: Exception) {
            KungFuStance.IDLE_GUARD
        }
    )
    val avatarStance: StateFlow<KungFuStance> = _avatarStance.asStateFlow()

    private val _avatarActionTrigger = MutableStateFlow<String?>(null)
    val avatarActionTrigger: StateFlow<String?> = _avatarActionTrigger.asStateFlow()

    // Speech rate (legacy compatibility)
    val speechRate: StateFlow<Float> = _voiceSpeed

    // Attachment
    private val _attachedImageBitmap = MutableStateFlow<Bitmap?>(null)
    val attachedImageBitmap: StateFlow<Bitmap?> = _attachedImageBitmap.asStateFlow()

    private val _attachedFileName = MutableStateFlow<String?>(null)
    val attachedFileName: StateFlow<String?> = _attachedFileName.asStateFlow()

    // Currently speaking message ID
    private val _currentlySpeakingMessageId = MutableStateFlow<String?>(null)
    val currentlySpeakingMessageId: StateFlow<String?> = _currentlySpeakingMessageId.asStateFlow()

    // Last assistant response text (for Live Assistant and UI)
    private val _lastAiReply = MutableStateFlow("আসসালামু আলাইকুম আতিক ভাই 👋 আমি Atik AI, আপনার পার্সোনাল এআই অ্যাসিস্ট্যান্ট।")
    val lastAiReply: StateFlow<String> = _lastAiReply.asStateFlow()

    // Signature phrase action state for Kung-Fu warrior response ("Okay boss, I am doing it right now!")
    private val _bossActionPhrase = MutableStateFlow<String?>(null)
    val bossActionPhrase: StateFlow<String?> = _bossActionPhrase.asStateFlow()

    // Real-time chat streaming response state
    private val _streamingText = MutableStateFlow<String?>(null)
    val streamingText: StateFlow<String?> = _streamingText.asStateFlow()

    // === Python Lab State ===
    private val _pythonCode = MutableStateFlow(DEFAULT_PYTHON_TEMPLATES[0].code)
    val pythonCode: StateFlow<String> = _pythonCode.asStateFlow()

    private val _pythonExecutionResult = MutableStateFlow<PythonExecutionResult?>(null)
    val pythonExecutionResult: StateFlow<PythonExecutionResult?> = _pythonExecutionResult.asStateFlow()

    private val _isPythonRunning = MutableStateFlow(false)
    val isPythonRunning: StateFlow<Boolean> = _isPythonRunning.asStateFlow()

    private val _pythonBackendUrl = MutableStateFlow(prefs.getString("pref_python_backend_url", "").orEmpty())
    val pythonBackendUrl: StateFlow<String> = _pythonBackendUrl.asStateFlow()

    // === Terminal / Linux Lab State ===
    private val _terminalLines = MutableStateFlow<List<TerminalLine>>(emptyList())
    val terminalLines: StateFlow<List<TerminalLine>> = _terminalLines.asStateFlow()

    private val _terminalCurrentDir = MutableStateFlow("/home/atik")
    val terminalCurrentDir: StateFlow<String> = _terminalCurrentDir.asStateFlow()

    private val _isTerminalRunning = MutableStateFlow(false)
    val isTerminalRunning: StateFlow<Boolean> = _isTerminalRunning.asStateFlow()

    private val _terminalBackendUrl = MutableStateFlow(prefs.getString("pref_terminal_backend_url", "").orEmpty())
    val terminalBackendUrl: StateFlow<String> = _terminalBackendUrl.asStateFlow()

    private var terminalJob: Job? = null

    // === Vision AI & Scanner State ===
    val visionEngine = VisionScannerEngine(application)

    private val _visionScanMode = MutableStateFlow(VisionScanMode.OBJECT_AI)
    val visionScanMode: StateFlow<VisionScanMode> = _visionScanMode.asStateFlow()

    private val _visionPreset = MutableStateFlow(VisionAiPreset.IDENTIFY_OBJECT)
    val visionPreset: StateFlow<VisionAiPreset> = _visionPreset.asStateFlow()

    private val _qrBarcodeResult = MutableStateFlow<QrBarcodeResult?>(null)
    val qrBarcodeResult: StateFlow<QrBarcodeResult?> = _qrBarcodeResult.asStateFlow()

    private val _ocrResult = MutableStateFlow<OcrResult?>(null)
    val ocrResult: StateFlow<OcrResult?> = _ocrResult.asStateFlow()

    private val _visionAiResult = MutableStateFlow<VisionAiAnalysisResult?>(null)
    val visionAiResult: StateFlow<VisionAiAnalysisResult?> = _visionAiResult.asStateFlow()

    private val _isVisionAnalyzing = MutableStateFlow(false)
    val isVisionAnalyzing: StateFlow<Boolean> = _isVisionAnalyzing.asStateFlow()

    private val _capturedVisionBitmap = MutableStateFlow<Bitmap?>(null)
    val capturedVisionBitmap: StateFlow<Bitmap?> = _capturedVisionBitmap.asStateFlow()

    private val _visionStatusMessage = MutableStateFlow<String?>(null)
    val visionStatusMessage: StateFlow<String?> = _visionStatusMessage.asStateFlow()

    init {
        // Apply user voice profile settings
        voiceManager.configureVoice(_voiceSpeed.value, _voicePitch.value, _voiceGender.value, _userAccent.value)

        // Wake-Word listener trigger callback
        wakeWordEngine.onWakeWordTriggered = { phrase ->
            triggerWakeWordActivation(phrase)
        }

        // Start background wake-word listening if enabled
        if (wakeWordEngine.isWakeWordEnabled.value) {
            wakeWordEngine.startWakeWordListening()
        }

        // Initialize local storage diagnostics (Step 23)
        refreshDatabaseMetrics()

        // Continuous live assistant & duplex loop: automatically resume listening after speaking ends
        voiceManager.onSpeakingDone = {
            _currentlySpeakingMessageId.value = null
            if (_isLiveActive.value && wakeWordEngine.isHandsFreeDuplexEnabled.value) {
                viewModelScope.launch {
                    kotlinx.coroutines.delay(350)
                    if (_isLiveActive.value && !voiceManager.isSpeaking.value) {
                        wakeWordEngine.playAudioCue(AudioCueType.SUCCESS)
                        wakeWordEngine.triggerHaptic(AudioCueType.SUCCESS)
                        wakeWordEngine.setDuplexState(VoiceDuplexState.CONTINUOUS_PROMPT)
                        startLiveListening()
                    }
                }
            } else if (_isLiveActive.value) {
                viewModelScope.launch {
                    kotlinx.coroutines.delay(250)
                    if (_isLiveActive.value && !voiceManager.isSpeaking.value) {
                        startLiveListening()
                    }
                }
            } else {
                wakeWordEngine.setDuplexState(VoiceDuplexState.STANDBY)
                if (wakeWordEngine.isWakeWordEnabled.value) {
                    wakeWordEngine.startWakeWordListening()
                }
            }
        }

        // Observe voice manager speaking state to reset indicator
        viewModelScope.launch {
            voiceManager.isSpeaking.collect { isSpeaking ->
                if (!isSpeaking) {
                    _currentlySpeakingMessageId.value = null
                }
            }
        }

        // Initialize with default session or saved session from persistent Room DB
        val savedSessionId = prefs.getString("pref_last_active_session_id", null)

        viewModelScope.launch(Dispatchers.IO) {
            val existing = repository.getAllSessionsList()
            if (existing.isEmpty()) {
                val fresh = repository.createNewSession("New Chat")
                withContext(Dispatchers.Main) {
                    _currentSessionId.value = fresh.id
                    prefs.edit().putString("pref_last_active_session_id", fresh.id).apply()
                }
            } else {
                val targetId = if (!savedSessionId.isNullOrBlank() && existing.any { it.id == savedSessionId }) {
                    savedSessionId
                } else {
                    existing.first().id
                }
                withContext(Dispatchers.Main) {
                    _currentSessionId.value = targetId
                    prefs.edit().putString("pref_last_active_session_id", targetId).apply()
                }
            }

            // Ensure baseline personal memory for Atikur Rahman is established
            val memoryCount = repository.getMemoryCount()
            if (memoryCount == 0) {
                repository.addMemory("Owner & Creator", "Atikur Rahman", "Profile")
                repository.addMemory("Role", "Senior Software Engineer & AI Architect", "Profile")
                repository.addMemory("Preferred Languages", "Bengali (বাংলা) & English", "Preference")
                repository.addMemory("Tech Focus", "Android, Kotlin, Jetpack Compose, Python, AI Automations", "Project")
                repository.addMemory("Assistant Identity", "Atik AI - Chinese Kung-Fu Warrior Persona, Loyal, calls Atikur 'Boss' or 'আতিক ভাই'", "Rule")
            }

            // Initialize Dynamic Theme Engine from Room Database (Step 25 Requirement 4)
            val savedTheme = repository.getThemeConfig()
            if (savedTheme != null) {
                withContext(Dispatchers.Main) {
                    _dynamicThemeState.value = DynamicThemeState.fromEntity(savedTheme)
                }
            } else {
                val initialTheme = DynamicThemeState()
                repository.saveThemeConfig(initialTheme.toEntity())
            }

            // Seed default 2D games into Room DB (Step 26 Requirement 2 & 4)
            gameGeneratorEngine.seedDefaultGamesIfEmpty()
        }

        // Collect messages when currentSessionId changes
        viewModelScope.launch {
            _currentSessionId.collectLatest { sessionId ->
                if (sessionId != null) {
                    repository.getMessages(sessionId).collectLatest { msgs ->
                        _currentMessages.value = msgs
                    }
                } else {
                    _currentMessages.value = emptyList()
                }
            }
        }

        // Add welcome lines to terminal
        _terminalLines.value = listOf(
            TerminalLine(TerminalLineType.SYSTEM, "Atik AI Mobile Linux & Termux Sandbox v2.5"),
            TerminalLine(TerminalLineType.OUTPUT, "Welcome back, Atikur Rahman. All security sandboxes are armed."),
            TerminalLine(TerminalLineType.OUTPUT, "Type 'help' to view available safe commands or 'python hello.py' to run script.")
        )
    }

    fun selectSession(sessionId: String) {
        _currentSessionId.value = sessionId
        prefs.edit().putString("pref_last_active_session_id", sessionId).apply()
    }

    fun startNewChat(initialTitle: String = "New Chat") {
        viewModelScope.launch {
            val session = repository.createNewSession(initialTitle)
            _currentSessionId.value = session.id
            prefs.edit().putString("pref_last_active_session_id", session.id).apply()
        }
    }

    fun renameSession(sessionId: String, newTitle: String) {
        viewModelScope.launch {
            repository.renameSession(sessionId, newTitle)
        }
    }

    fun deleteSession(sessionId: String) {
        viewModelScope.launch {
            repository.deleteSession(sessionId)
            if (_currentSessionId.value == sessionId) {
                val remaining = allSessions.value.filter { it.id != sessionId }
                if (remaining.isNotEmpty()) {
                    val nextId = remaining.first().id
                    _currentSessionId.value = nextId
                    prefs.edit().putString("pref_last_active_session_id", nextId).apply()
                } else {
                    startNewChat()
                }
            }
        }
    }

    fun clearAllSessions() {
        viewModelScope.launch {
            repository.clearAllSessions()
            val freshSession = repository.createNewSession("New Chat")
            _currentSessionId.value = freshSession.id
            prefs.edit().putString("pref_last_active_session_id", freshSession.id).apply()
        }
    }

    fun setLanguageMode(mode: LanguageMode) {
        _languageMode.value = mode
        prefs.edit().putString("pref_language_mode", mode.name).apply()
        viewModelScope.launch { repository.saveSetting("pref_language_mode", mode.name) }
    }

    fun setSelectedModel(modelId: String) {
        _selectedModel.value = modelId
        prefs.edit().putString("pref_model_id", modelId).apply()
        viewModelScope.launch { repository.saveSetting("pref_model_id", modelId) }
    }

    fun setCustomApiKey(key: String) {
        _customApiKey.value = key.trim()
        prefs.edit().putString("pref_custom_api_key", key.trim()).apply()
        viewModelScope.launch { repository.saveSetting("pref_custom_api_key", key.trim()) }
    }

    fun setAutoReadTts(enabled: Boolean) {
        _autoReadTts.value = enabled
        prefs.edit().putBoolean("pref_auto_read", enabled).apply()
        viewModelScope.launch { repository.saveSetting("pref_auto_read", enabled.toString()) }
    }

    fun setSpeechRate(rate: Float) {
        setVoicePreferences(rate, _voicePitch.value, _voiceGender.value)
    }

    fun attachImage(uri: Uri, fileName: String) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val inputStream: InputStream? = getApplication<Application>().contentResolver.openInputStream(uri)
                val bitmap = BitmapFactory.decodeStream(inputStream)
                inputStream?.close()
                _attachedImageBitmap.value = bitmap
                _attachedFileName.value = fileName
            } catch (e: Exception) {
                // handle error
            }
        }
    }

    fun clearAttachment() {
        _attachedImageBitmap.value = null
        _attachedFileName.value = null
    }

    /**
     * Identifies if a prompt constitutes a task or actionable command.
     */
    fun isTaskOrVoicePrompt(text: String): Boolean {
        val lower = text.trim().lowercase()
        val taskKeywords = listOf(
            "create", "image", "write", "edit", "search", "draw", "make", "generate", "run",
            "find", "build", "code", "analyze", "help", "solve", "do", "show", "summarize",
            "translate", "fix", "explain", "python", "terminal", "command", "task", "pic", "photo",
            "করো", "লেখো", "বানাও", "খুঁজো", "তৈরি", "হিসাব", "চালাও", "বলো", "দেখাও"
        )
        return taskKeywords.any { lower.contains(it) }
    }

    /**
     * Checks if a user prompt is requesting AI image generation.
     */
    fun isImageGenerationRequest(text: String): Boolean {
        val lower = text.trim().lowercase()
        return lower.startsWith("create an image") ||
                lower.startsWith("create image") ||
                lower.startsWith("generate an image") ||
                lower.startsWith("generate image") ||
                lower.startsWith("draw an image") ||
                lower.startsWith("draw a picture") ||
                lower.startsWith("draw ") ||
                lower.startsWith("paint ") ||
                lower.startsWith("make an image") ||
                lower.startsWith("picture of ") ||
                lower.startsWith("image of ") ||
                lower.contains("ছবি আঁকো") ||
                lower.contains("ছবি তৈরি করো") ||
                lower.contains("একটি ছবি") ||
                lower.contains("create picture") ||
                lower.contains("generate picture")
    }

    /**
     * Extracts the core visual prompt from user's image creation request.
     */
    fun extractImagePrompt(text: String): String {
        var clean = text.trim()
        val prefixes = listOf(
            "create an image of", "create an image", "create image of", "create image",
            "generate an image of", "generate an image", "generate image of", "generate image",
            "draw a picture of", "draw an image of", "draw an image", "draw a", "draw ",
            "paint an image of", "paint a picture of", "paint ",
            "make an image of", "make an image",
            "picture of", "image of",
            "ছবি আঁকো", "ছবি তৈরি করো", "একটি ছবি আঁকো", "একটি ছবি তৈরি করো"
        )
        for (prefix in prefixes) {
            if (clean.lowercase().startsWith(prefix)) {
                clean = clean.substring(prefix.length).trim()
                break
            }
        }
        clean = clean.removePrefix(":").removePrefix("-").removePrefix("for").removePrefix("about").trim()
        return clean.ifBlank { "a futuristic cybernetic warrior in neon armor, 8k resolution, cinematic lighting" }
    }

    /**
     * Generates an image using the open & unrestricted image engine (Pollinations AI / Flux).
     */
    private suspend fun generateImageInternal(prompt: String, sessionId: String) {
        val visualPrompt = prompt.trim()

        var finalPrompt = visualPrompt
        val containsBengali = visualPrompt.any { it in '\u0980'..'\u09FF' }
        if (containsBengali) {
            try {
                val translationResult = geminiService.generateReply(
                    prompt = "Translate this image generation prompt to descriptive English visual keywords only: \"$visualPrompt\"",
                    history = emptyList(),
                    languageMode = LanguageMode.ENGLISH,
                    memories = emptyList(),
                    model = _selectedModel.value,
                    customApiKey = _customApiKey.value
                )
                translationResult.onSuccess { translated ->
                    val clean = translated.lines().firstOrNull { it.isNotBlank() } ?: visualPrompt
                    finalPrompt = clean.replace("\"", "").trim()
                }
            } catch (e: Exception) {
                // fallback to original
            }
        }

        // Build unlimited high-resolution Pollinations image URL (flux model)
        val imageUrl = imageEngine.buildImageUrl(finalPrompt)

        val replyText = "Here is your generated image of **$visualPrompt**:\n\n![Generated Image]($imageUrl)"
        _lastAiReply.value = "Here is your generated image of $visualPrompt"

        val insertedMessage = repository.addMessage(
            sessionId = sessionId,
            role = "model",
            content = replyText,
            attachedFileName = imageUrl,
            attachedFileType = "generated_image"
        )

        // Save generated image metadata to Room database
        repository.addGeneratedImage(
            prompt = visualPrompt,
            imageUrl = imageUrl,
            sessionId = sessionId
        )

        _isGenerating.value = false

        if (_autoReadTts.value) {
            speakMessage(insertedMessage.id, "Here is your generated image, boss!")
        }
    }

    /**
     * Public method to generate an image from prompt.
     */
    fun generateImage(prompt: String) {
        val sessionId = _currentSessionId.value ?: return
        triggerBossVoiceConfirmation()
        viewModelScope.launch {
            repository.addMessage(
                sessionId = sessionId,
                role = "user",
                content = "Create an image of $prompt"
            )
            _isGenerating.value = true
            generateImageInternal(prompt, sessionId)
        }
    }

    /**
     * Downloads and saves a generated image to the user's Gallery / MediaStore.
     */
    fun saveGeneratedImage(
        context: Context,
        imageUrl: String,
        promptDescription: String,
        onResult: (Boolean, String) -> Unit
    ) {
        viewModelScope.launch {
            val result = imageEngine.downloadAndSaveImage(context, imageUrl, promptDescription)
            result.onSuccess {
                onResult(true, "Image saved to Gallery successfully!")
            }.onFailure { err ->
                onResult(false, err.message ?: "Failed to save image")
            }
        }
    }

    /**
     * Confidently speaks the warrior signature phrase via TTS:
     * "Okay boss, I am doing it right now!" before executing the task.
     */
    fun triggerBossVoiceConfirmation(onDone: () -> Unit = {}) {
        _bossActionPhrase.value = "Okay boss, I am doing it right now!"
        voiceManager.speakBossSignature {
            viewModelScope.launch {
                kotlinx.coroutines.delay(1200)
                _bossActionPhrase.value = null
                onDone()
            }
        }
    }

    fun sendMessage(text: String, overrideImage: Bitmap? = null, isVoiceCommand: Boolean = false) {
        val trimmed = text.trim()
        val currentAttachment = overrideImage ?: _attachedImageBitmap.value
        val attachmentName = _attachedFileName.value

        if (trimmed.isBlank() && currentAttachment == null) return

        val sessionId = _currentSessionId.value ?: return

        clearAttachment()

        // Dynamic voice response: "Okay boss, I am doing it right now!" before executing task
        val isTask = isVoiceCommand || currentAttachment != null || isTaskOrVoicePrompt(trimmed)
        if (isTask) {
            triggerBossVoiceConfirmation()
        }

        viewModelScope.launch {
            extractAndSaveMemories(trimmed)

            repository.addMessage(
                sessionId = sessionId,
                role = "user",
                content = trimmed,
                attachedFileName = attachmentName,
                attachedFileType = if (currentAttachment != null) "image" else null
            )

            // Auto-rename session title from first prompt if default title
            val currentSession = allSessions.value.find { it.id == sessionId }
            if (currentSession != null && (currentSession.title == "New Chat" || currentSession.title == "নতুন আলোচনা" || currentSession.title.isBlank())) {
                val autoTitle = if (trimmed.length > 28) trimmed.take(28) + "…" else trimmed
                repository.renameSession(sessionId, autoTitle)
            }

            // Route to Hardware Controls & Telemetry if hardware command requested
            if (currentAttachment == null && hardwareManager.isHardwareCommand(trimmed)) {
                val hwResult = hardwareManager.executeHardwareCommand(trimmed)
                if (hwResult != null) {
                    _lastAiReply.value = hwResult.feedbackMessage
                    val inserted = repository.addMessage(
                        sessionId = sessionId,
                        role = "model",
                        content = hwResult.feedbackMessage
                    )
                    if (isVoiceCommand) {
                        _currentlySpeakingMessageId.value = inserted.id.toString()
                        voiceManager.speak(hwResult.feedbackMessage, _languageMode.value)
                    }
                    return@launch
                }
            }

            // Route to Universal App & System Settings Navigation (Step 20)
            val navResult = appNavigationEngine.processNavigationCommand(trimmed)
            if (currentAttachment == null && navResult != null) {
                _lastAiReply.value = navResult
                val inserted = repository.addMessage(
                    sessionId = sessionId,
                    role = "model",
                    content = navResult
                )
                if (isVoiceCommand || _autoReadTts.value) {
                    voiceManager.speak(navResult, _languageMode.value)
                }
                return@launch
            }

            // Route to Smart Messaging & Calling Accessibility Engine (Step 24)
            val smartCmd = SmartActionParser.parseCommand(trimmed)
            if (currentAttachment == null && smartCmd != null) {
                val platformBadge = "${smartCmd.targetApp.iconEmoji} ${smartCmd.targetApp.displayName}"
                val actionText = smartCmd.actionType.displayName
                val msgSnippet = smartCmd.messageText?.let { "\n• **Message:** \"$it\"" } ?: ""

                val feedback = "⚡ **[Accessibility Smart Action Initiated]**\n\n" +
                    "• **Action:** $actionText\n" +
                    "• **Target Platform:** $platformBadge\n" +
                    "• **Recipient:** **${smartCmd.recipient}**$msgSnippet\n\n" +
                    "*(🛡️ Safety Guardrail active: Verify on screen or tap Cancel to abort)*"

                _lastAiReply.value = feedback
                val inserted = repository.addMessage(
                    sessionId = sessionId,
                    role = "model",
                    content = feedback
                )
                smartActionEngine.submitAction(smartCmd)

                if (isVoiceCommand || _autoReadTts.value) {
                    _currentlySpeakingMessageId.value = inserted.id.toString()
                    voiceManager.speak("Initiating ${smartCmd.actionType.displayName} to ${smartCmd.recipient} on ${smartCmd.targetApp.displayName}. Verification requested.", _languageMode.value)
                }
                return@launch
            }

            // Route to Dynamic Theme Engine (Step 25 Requirement 1)
            val themeCmd = DynamicThemeVoiceParser.parseThemeCommand(trimmed)
            if (currentAttachment == null && themeCmd != null) {
                when (themeCmd) {
                    is ThemeCommandResult.PresetChange -> {
                        setDynamicThemePreset(themeCmd.preset)
                    }
                    is ThemeCommandResult.AccentChange -> {
                        setDynamicAccentColor(themeCmd.colorOption.hex)
                    }
                    is ThemeCommandResult.ButtonStyleChange -> {
                        setDynamicButtonStyle(themeCmd.style)
                    }
                    is ThemeCommandResult.FontScaleChange -> {
                        setDynamicFontScale(themeCmd.scale)
                    }
                    is ThemeCommandResult.BackgroundWidgetChange -> {
                        setDynamicBackgroundWidget(themeCmd.widget)
                    }
                }

                _lastAiReply.value = themeCmd.feedbackMessage
                val inserted = repository.addMessage(
                    sessionId = sessionId,
                    role = "model",
                    content = themeCmd.feedbackMessage
                )
                if (isVoiceCommand || _autoReadTts.value) {
                    _currentlySpeakingMessageId.value = inserted.id.toString()
                    voiceManager.speak(themeCmd.feedbackMessage, _languageMode.value)
                }
                return@launch
            }

            // Route to In-App 2D Game Generator Engine (Step 26 Requirement 2)
            if (currentAttachment == null && gameGeneratorEngine.isGamePrompt(trimmed)) {
                _isGeneratingGame.value = true
                val game = gameGeneratorEngine.generateGameFromPrompt(trimmed, _customApiKey.value)
                _isGeneratingGame.value = false
                _activeGameToPlay.value = game

                val reply = "🎮 **[2D Game Synthesized: ${game.title}]**\n\nI have created the interactive 2D HTML5 Canvas game logic, touch controls, sound effects, and Room DB score tracking for you, Boss!\n\n• **Title**: ${game.thumbnailEmoji} ${game.title}\n• **Genre**: ${game.genre}\n• **Engine**: HTML5 / Canvas 60 FPS Native Runtime\n• **High Score Record**: ${game.highScore} PTS\n\n👉 Open the **Game Studio** tab in the sidebar navigation to play live on the full canvas!"
                _lastAiReply.value = reply
                val inserted = repository.addMessage(
                    sessionId = sessionId,
                    role = "model",
                    content = reply
                )
                if (isVoiceCommand || _autoReadTts.value) {
                    _currentlySpeakingMessageId.value = inserted.id.toString()
                    voiceManager.speak("I have generated ${game.title} for you, Boss! Ready to play in Game Studio.", _languageMode.value)
                }
                return@launch
            }

            // Route to Smart Automation & Routine Engine (Step 13)
            val autoCmd = routineEngine.parseAutomationCommand(trimmed)
            if (currentAttachment == null && autoCmd != null) {
                when (autoCmd) {
                    is ParsedAutomationCommand.AddTask -> {
                        val task = repository.addTask(autoCmd.title, "", autoCmd.priority, autoCmd.category)
                        val reply = "📌 **[Task Added to Queue]**\n\nI have registered this priority task for you, Boss:\n• **${task.title}**\n• Priority: **${task.priority}** • Category: **${task.category}**"
                        _lastAiReply.value = reply
                        val inserted = repository.addMessage(sessionId = sessionId, role = "model", content = reply)
                        if (isVoiceCommand || _autoReadTts.value) {
                            voiceManager.speak("Task added, Boss: ${task.title}", _languageMode.value)
                        }
                        return@launch
                    }
                    is ParsedAutomationCommand.SetReminder -> {
                        repository.addReminder(autoCmd.title, autoCmd.timeFormatted, autoCmd.timeMillis, autoCmd.isAlarm)
                        val notifId = (System.currentTimeMillis() % 10000).toInt()
                        routineEngine.postNotification(
                            notifId,
                            if (autoCmd.isAlarm) "⏰ Alarm Scheduled" else "🔔 Reminder Scheduled",
                            "${autoCmd.title} at ${autoCmd.timeFormatted}",
                            SmartRoutineEngine.CHANNEL_REMINDERS
                        )
                        val reply = "⏰ **[Scheduled Alarm / Reminder]**\n\nAlert configured for **${autoCmd.timeFormatted}**:\n> \"${autoCmd.title}\"\n\n*(Push notification and alarm registered)*"
                        _lastAiReply.value = reply
                        val inserted = repository.addMessage(sessionId = sessionId, role = "model", content = reply)
                        if (isVoiceCommand || _autoReadTts.value) {
                            voiceManager.speak("Reminder set for ${autoCmd.timeFormatted}, Boss!", _languageMode.value)
                        }
                        return@launch
                    }
                    is ParsedAutomationCommand.TriggerRoutine -> {
                        runRoutineBriefing(autoCmd.routineType)
                        return@launch
                    }
                    is ParsedAutomationCommand.ListTasks -> {
                        val tasks = repository.getPendingTasksList()
                        val reply = if (tasks.isEmpty()) {
                            "📌 **[Tasks & To-Do Queue]**\n\nNo pending tasks in your queue right now, Boss!"
                        } else {
                            val sb = StringBuilder("📌 **[Pending Tasks Queue]**\n\n")
                            tasks.forEachIndexed { i, t ->
                                sb.append("${i + 1}. [${t.priority}] **${t.title}** (${t.category})\n")
                            }
                            sb.toString()
                        }
                        _lastAiReply.value = reply
                        val inserted = repository.addMessage(sessionId = sessionId, role = "model", content = reply)
                        if (isVoiceCommand || _autoReadTts.value) {
                            voiceManager.speak(reply, _languageMode.value)
                        }
                        return@launch
                    }
                }
            }

            // Route to Unlimited AI Image Generation Engine if image creation requested
            if (currentAttachment == null && isImageGenerationRequest(trimmed)) {
                val extractedPrompt = extractImagePrompt(trimmed)
                _isGenerating.value = true
                generateImageInternal(extractedPrompt, sessionId)
                return@launch
            }

            // Route to Offline AI Engine & Local Cache if network is offline or simulation is active (Step 12 & Step 23)
            if (!networkMonitor.isEffectiveOnline.value) {
                _isGenerating.value = true

                // Check local persistent cache first (Step 23 Requirement 2)
                val cachedResponse = localCacheManager.getCachedResponse(trimmed)
                if (cachedResponse != null) {
                    _isGenerating.value = false
                    val replyWithBadge = "$cachedResponse\n\n*(⚡ Recalled from Local Room Cache • Offline Active)*"
                    _lastAiReply.value = replyWithBadge
                    val insertedMessage = repository.addMessage(
                        sessionId = sessionId,
                        role = "model",
                        content = replyWithBadge
                    )
                    refreshDatabaseMetrics()
                    if (_autoReadTts.value || voiceManager.isListening.value || isVoiceCommand) {
                        speakMessage(insertedMessage.id, cachedResponse)
                    }
                    return@launch
                }

                val offlineResult = offlineAiEngine.processQuery(trimmed, _userName.value, _preferredTitle.value)
                _isGenerating.value = false

                // Queue offline action in Room sync queue (Step 23 Requirement 3)
                offlineSyncEngine.enqueueOfflineAction(
                    actionType = "CHAT_MESSAGE",
                    payloadJson = """{"prompt":"${trimmed.replace("\"", "\\\"")}","category":"${offlineResult.category.name}"}""",
                    description = "Offline query: ${trimmed.take(30)}"
                )

                // If note or memory, also save as local persistent NoteEntity (Step 23 Requirement 1)
                if (offlineResult.category == com.example.ai.OfflineAiCategory.NOTE_MEMORY) {
                    repository.addNote(
                        title = "Note: ${trimmed.take(24)}",
                        content = trimmed,
                        category = "Offline Notes",
                        isSynced = false
                    )
                }

                val replyWithBadge = "${offlineResult.responseText}\n\n*(⚡ Stored on local device • Queued for cloud sync)*"
                _lastAiReply.value = replyWithBadge
                val insertedMessage = repository.addMessage(
                    sessionId = sessionId,
                    role = "model",
                    content = replyWithBadge
                )
                refreshDatabaseMetrics()
                if (_autoReadTts.value || voiceManager.isListening.value || isVoiceCommand) {
                    speakMessage(insertedMessage.id, offlineResult.responseText)
                }
                return@launch
            }

            _isGenerating.value = true
            _streamingText.value = ""

            val history = _currentMessages.value.map { it.role to it.content }
            val memoryStrings = memories.value.map { "${it.category} [${it.key}]: ${it.value}" }

            val result = geminiService.generateReplyStream(
                prompt = trimmed,
                history = history,
                languageMode = _languageMode.value,
                memories = memoryStrings,
                model = _selectedModel.value,
                customApiKey = _customApiKey.value,
                imageBitmap = currentAttachment,
                onChunk = { chunk ->
                    withContext(Dispatchers.Main) {
                        _streamingText.value = (_streamingText.value ?: "") + chunk
                    }
                }
            )

            _isGenerating.value = false
            _streamingText.value = null

            result.onSuccess { replyText ->
                _lastAiReply.value = replyText
                val insertedMessage = repository.addMessage(
                    sessionId = sessionId,
                    role = "model",
                    content = replyText
                )

                // Cache response locally for offline fallback & instant recall (Step 23 Requirement 2)
                if (currentAttachment == null) {
                    localCacheManager.cacheResponse(
                        prompt = trimmed,
                        response = replyText,
                        category = "AI_REPLY",
                        encrypt = false
                    )
                }

                if (_autoReadTts.value || voiceManager.isListening.value || isVoiceCommand) {
                    speakMessage(insertedMessage.id, replyText)
                }
            }.onFailure { error ->
                // Check if network error and perform automatic offline fallback (Step 12 & Step 23)
                val isNetworkError = error is java.io.IOException ||
                        error.message?.contains("Unable to resolve host", ignoreCase = true) == true ||
                        error.message?.contains("timeout", ignoreCase = true) == true ||
                        error.message?.contains("Failed to connect", ignoreCase = true) == true

                if (isNetworkError) {
                    val cachedResponse = localCacheManager.getCachedResponse(trimmed)
                    val fallbackResponseText = if (cachedResponse != null) {
                        "$cachedResponse\n\n*(⚡ Served from Local Encrypted Room Cache)*"
                    } else {
                        val offlineResult = offlineAiEngine.processQuery(trimmed, _userName.value, _preferredTitle.value)
                        offlineResult.responseText
                    }

                    val fallbackMessage = "⚡ **[Offline Fallback Active]**\n*(Cloud disconnected: ${error.message ?: "Network unreachable"})*\n\n$fallbackResponseText"
                    _lastAiReply.value = fallbackMessage
                    val insertedMessage = repository.addMessage(
                        sessionId = sessionId,
                        role = "model",
                        content = fallbackMessage
                    )
                    if (isVoiceCommand || _autoReadTts.value) {
                        speakMessage(insertedMessage.id, fallbackResponseText)
                    }
                } else {
                    val errorMsg = if (_languageMode.value == LanguageMode.ENGLISH) {
                        "Error: ${error.message}"
                    } else {
                        "ত্রুটি: ${error.message}"
                    }
                    _lastAiReply.value = errorMsg
                    val insertedMessage = repository.addMessage(
                        sessionId = sessionId,
                        role = "model",
                        content = errorMsg
                    )
                    if (isVoiceCommand) {
                        speakMessage(insertedMessage.id, errorMsg)
                    }
                }
            }
        }
    }

    fun analyzeCameraFrame(bitmap: Bitmap) {
        sendMessage(
            text = "আতিক, আমি ক্যামেরা দিয়ে এই দৃশ্যটি তুলে ধরেছি। অনুগ্রহ করে এই ফ্রেমে কী দেখা যাচ্ছে তা বিস্তারিতভাবে বিশ্লেষণ করো এবং পরামর্শ দাও।",
            overrideImage = bitmap,
            isVoiceCommand = true
        )
    }

    fun toggleSpeakMessage(messageId: String, text: String) {
        if (_currentlySpeakingMessageId.value == messageId && voiceManager.isSpeaking.value) {
            voiceManager.stopSpeaking()
            _currentlySpeakingMessageId.value = null
        } else {
            speakMessage(messageId, text)
        }
    }

    fun speakMessage(messageId: String, text: String) {
        _currentlySpeakingMessageId.value = messageId
        voiceManager.speak(
            text = text,
            mode = _languageMode.value,
            speed = _voiceSpeed.value
        )
    }

    // === Continuous Live Voice Conversation ===
    fun startLiveConversation(speakGreetingFirst: Boolean = true) {
        _isLiveActive.value = true
        geminiLiveClient.connectLiveSession(if (_selectedModel.value.contains("live")) "gemini-3.8-live" else _selectedModel.value)

        if (speakGreetingFirst) {
            val greeting = when (_languageMode.value) {
                LanguageMode.BANGLA -> "আসসালামু আলাইকুম আতিক ভাই! 👋 আমি Atik AI, আপনার পার্সোনাল এআই অ্যাসিস্ট্যান্ট। বলুন, আজ কীভাবে সাহায্য করতে পারি?"
                LanguageMode.ENGLISH -> "Assalamu Alaikum Atik Bhai! 👋 I am Atik AI, your personal AI assistant. How can I assist you today?"
                LanguageMode.BANGLISH -> "Assalamu Alaikum Atik Bhai! 👋 Ami Atik AI. Bolun, kivabe help korte pari?"
            }
            _lastAiReply.value = greeting
            voiceManager.speak(greeting, _languageMode.value, speed = _voiceSpeed.value)
            // When TTS completes, onSpeakingDone automatically triggers startLiveListening()
        } else {
            startLiveListening()
        }
    }

    fun stopLiveConversation() {
        _isLiveActive.value = false
        geminiLiveClient.disconnect()
        voiceManager.stopSpeaking()
        voiceManager.stopListening()
        wakeWordEngine.setDuplexState(VoiceDuplexState.STANDBY)
        if (wakeWordEngine.isWakeWordEnabled.value) {
            wakeWordEngine.startWakeWordListening()
        }
    }

    fun triggerWakeWordActivation(phrase: String) {
        viewModelScope.launch {
            _isLiveActive.value = true
            wakeWordEngine.setDuplexState(VoiceDuplexState.WAKE_DETECTED)
            val greeting = when (_languageMode.value) {
                LanguageMode.BANGLA -> "হ্যাঁ আতিক ভাই! শুনছি..."
                LanguageMode.ENGLISH -> "Yes Boss! I'm listening..."
                LanguageMode.BANGLISH -> "Yes Boss! Bolun..."
            }
            _lastAiReply.value = greeting
            voiceManager.speak(greeting, _languageMode.value, speed = _voiceSpeed.value)
        }
    }

    fun startLiveListening() {
        if (!_isLiveActive.value) return
        wakeWordEngine.setDuplexState(VoiceDuplexState.LISTENING)
        voiceManager.startListening(
            mode = _languageMode.value,
            onResult = { recognizedText ->
                if (_isLiveActive.value && recognizedText.isNotBlank()) {
                    sendLiveVoiceMessage(recognizedText)
                }
            },
            onError = { _ ->
                // In live mode, continuous listening shouldn't terminate on momentary pause
                if (_isLiveActive.value) {
                    viewModelScope.launch {
                        kotlinx.coroutines.delay(400)
                        if (_isLiveActive.value && !voiceManager.isSpeaking.value) {
                            startLiveListening()
                        }
                    }
                }
            }
        )
    }

    fun sendLiveVoiceMessage(text: String) {
        val trimmed = text.trim()
        if (trimmed.isBlank()) return
        val sessionId = _currentSessionId.value ?: return

        triggerBossVoiceConfirmation()

        // Audio cue & haptic for processing state
        wakeWordEngine.playAudioCue(AudioCueType.PROCESSING)
        wakeWordEngine.triggerHaptic(AudioCueType.PROCESSING)
        wakeWordEngine.setDuplexState(VoiceDuplexState.PROCESSING)

        viewModelScope.launch {
            extractAndSaveMemories(trimmed)

            repository.addMessage(
                sessionId = sessionId,
                role = "user",
                content = trimmed
            )

            _isGenerating.value = true

            val history = _currentMessages.value.map { it.role to it.content }
            val memoryStrings = memories.value.map { "${it.category} [${it.key}]: ${it.value}" }

            val result = geminiService.generateReply(
                prompt = trimmed,
                history = history,
                languageMode = _languageMode.value,
                memories = memoryStrings,
                model = if (_selectedModel.value.contains("live")) "gemini-3.8-live" else _selectedModel.value,
                customApiKey = _customApiKey.value
            )

            _isGenerating.value = false

            result.onSuccess { replyText ->
                _lastAiReply.value = replyText
                repository.addMessage(
                    sessionId = sessionId,
                    role = "model",
                    content = replyText
                )
                // Speak reply. When speaking completes, onSpeakingDone triggers next listen turn!
                if (_isLiveActive.value) {
                    wakeWordEngine.setDuplexState(VoiceDuplexState.SPEAKING)
                    voiceManager.speak(
                        text = replyText,
                        mode = _languageMode.value,
                        speed = _voiceSpeed.value
                    )
                }
            }.onFailure { error ->
                val errorMsg = "দুঃখিত আতিক ভাই, একটি সমস্যা হয়েছে: ${error.message}"
                _lastAiReply.value = errorMsg
                if (_isLiveActive.value) {
                    wakeWordEngine.setDuplexState(VoiceDuplexState.SPEAKING)
                    voiceManager.speak(
                        text = errorMsg,
                        mode = _languageMode.value,
                        speed = _voiceSpeed.value
                    )
                }
            }
        }
    }

    // === Memory Auto-Extraction ===
    fun extractAndSaveMemories(text: String) {
        val trimmed = text.trim()
        val lower = trimmed.lowercase()

        // 1. User name
        if (lower.contains("আমার নাম")) {
            val namePart = trimmed.substringAfter("আমার নাম")
                .removePrefix("হলো").removePrefix("হচ্ছে").removePrefix(":").removePrefix("=").trim()
            val name = namePart.split(" ", "।", ",", "\n").firstOrNull { it.isNotBlank() } ?: namePart
            if (name.isNotBlank()) {
                addMemory("ব্যবহারকারীর নাম", name, "Profile")
            }
        } else if (lower.contains("my name is")) {
            val idx = lower.indexOf("my name is") + "my name is".length
            val name = trimmed.substring(idx).trim().split(" ", ",", ".").firstOrNull { it.isNotBlank() }
            if (!name.isNullOrBlank()) {
                addMemory("User Name", name, "Profile")
            }
        }

        // 2. Profession & Role
        if (lower.contains("আমার পেশা") || lower.contains("আমি একজন") || lower.contains("আমি কাজ করি")) {
            val marker = when {
                lower.contains("আমার পেশা") -> "আমার পেশা"
                lower.contains("আমি একজন") -> "আমি একজন"
                else -> "আমি কাজ করি"
            }
            val rest = trimmed.substringAfter(marker).trim().removePrefix("হলো").removePrefix("হচ্ছে").removePrefix(":").trim()
            val role = rest.split("।", "\n", ",").firstOrNull { it.isNotBlank() } ?: rest
            if (role.isNotBlank()) {
                addMemory("পেশা / ভূমিকা", role, "Profile")
            }
        } else if (lower.contains("my profession is") || lower.contains("i work as") || lower.contains("i am a ")) {
            val phrase = when {
                lower.contains("my profession is") -> "my profession is"
                lower.contains("i work as") -> "i work as"
                else -> "i am a "
            }
            val idx = lower.indexOf(phrase) + phrase.length
            val role = trimmed.substring(idx).removePrefix("a").removePrefix("an").trim().split(".", "\n", ",").firstOrNull() ?: ""
            if (role.isNotBlank()) {
                addMemory("Profession / Role", role.trim(), "Profile")
            }
        }

        // 3. Location / Residence
        if (lower.contains("আমার বাসা") || lower.contains("আমি থাকি") || lower.contains("আমার শহর")) {
            val marker = when {
                lower.contains("আমার বাসা") -> "আমার বাসা"
                lower.contains("আমি থাকি") -> "আমি থাকি"
                else -> "আমার শহর"
            }
            val rest = trimmed.substringAfter(marker).trim().removePrefix("হলো").removePrefix("হচ্ছে").removePrefix(":").trim()
            val loc = rest.split("।", "\n", ",").firstOrNull { it.isNotBlank() } ?: rest
            if (loc.isNotBlank()) {
                addMemory("ঠিকানা / অবস্থান", loc, "Profile")
            }
        } else if (lower.contains("i live in") || lower.contains("i am based in") || lower.contains("my city is")) {
            val marker = when {
                lower.contains("i live in") -> "i live in"
                lower.contains("i am based in") -> "i am based in"
                else -> "my city is"
            }
            val idx = lower.indexOf(marker) + marker.length
            val loc = trimmed.substring(idx).trim().split(".", "\n", ",").firstOrNull() ?: ""
            if (loc.isNotBlank()) {
                addMemory("Location", loc.trim(), "Profile")
            }
        }

        // 4. Preferences & Favorites
        if (lower.contains("আমার পছন্দের") || lower.contains("আমার প্রিয়") || lower.contains("আমার প্রিয়")) {
            val marker = when {
                lower.contains("আমার পছন্দের") -> "আমার পছন্দের"
                lower.contains("আমার প্রিয়") -> "আমার প্রিয়"
                else -> "আমার প্রিয়"
            }
            val rest = trimmed.substringAfter(marker).trim()
            val parts = rest.split("হলো", "হচ্ছে", "হল", "হচ্ছে:", ":", "=")
            if (parts.size >= 2) {
                val key = parts[0].trim()
                val value = parts[1].trim().trimEnd('।', '.')
                if (key.isNotBlank() && value.isNotBlank()) {
                    addMemory("পছন্দ: $key", value, "Preference")
                }
            }
        } else if (lower.contains("my favorite") || lower.contains("i prefer")) {
            val phrase = if (lower.contains("my favorite")) "my favorite" else "i prefer"
            val idx = lower.indexOf(phrase) + phrase.length
            val detail = trimmed.substring(idx).removePrefix("is").trim()
            if (detail.isNotBlank()) {
                addMemory("Preference", detail, "Preference")
            }
        }

        // 5. Active Projects & Work
        if (lower.contains("আমার প্রজেক্ট") || lower.contains("আমি বানাচ্ছি") || lower.contains("আমি তৈরি করছি")) {
            val marker = when {
                lower.contains("আমার প্রজেক্ট") -> "আমার প্রজেক্ট"
                lower.contains("আমি বানাচ্ছি") -> "আমি বানাচ্ছি"
                else -> "আমি তৈরি করছি"
            }
            val rest = trimmed.substringAfter(marker).trim().removePrefix("হলো").removePrefix("হচ্ছে").removePrefix(":").trim()
            val proj = rest.split("।", "\n").firstOrNull { it.isNotBlank() } ?: rest
            if (proj.isNotBlank()) {
                addMemory("চলমান প্রজেক্ট", proj, "Project")
            }
        } else if (lower.contains("my project is") || lower.contains("i am building") || lower.contains("i am working on")) {
            val marker = when {
                lower.contains("my project is") -> "my project is"
                lower.contains("i am building") -> "i am building"
                else -> "i am working on"
            }
            val idx = lower.indexOf(marker) + marker.length
            val proj = trimmed.substring(idx).trim().split(".", "\n").firstOrNull() ?: ""
            if (proj.isNotBlank()) {
                addMemory("Active Project", proj.trim(), "Project")
            }
        }

        // 6. Explicit memory and note directives
        if (lower.contains("মনে রাখো") || lower.contains("মনে রাখবে") || lower.contains("মনে রেখো") || lower.contains("নোট করো") || lower.contains("মনে রাখুন")) {
            val content = trimmed.substringAfter("মনে রাখো").substringAfter("মনে রাখবে")
                .substringAfter("মনে রেখো").substringAfter("নোট করো").substringAfter("মনে রাখুন")
                .removePrefix("যে").removePrefix(":").trim()
            if (content.isNotBlank()) {
                addMemory("স্মৃতি / নোট", content, "Rule")
            }
        } else if (lower.contains("remember that") || lower.contains("remember:") || lower.contains("note that") || lower.contains("keep in mind")) {
            val content = trimmed.substringAfter("remember that").substringAfter("remember:")
                .substringAfter("note that").substringAfter("keep in mind")
                .removePrefix(":").trim()
            if (content.isNotBlank()) {
                addMemory("Note / Memory", content, "Rule")
            }
        }
    }

    fun runCodeInPythonLab(code: String, onNavigate: () -> Unit) {
        setPythonCode(code)
        runPythonCode()
        onNavigate()
    }

    // === Python Lab Methods ===
    fun setPythonCode(code: String) {
        _pythonCode.value = code
    }

    fun runPythonCode() {
        triggerBossVoiceConfirmation()
        viewModelScope.launch {
            _isPythonRunning.value = true
            val result = pythonEngine.execute(
                code = _pythonCode.value,
                remoteBackendUrl = _pythonBackendUrl.value.ifBlank { null }
            )
            _pythonExecutionResult.value = result
            _isPythonRunning.value = false
        }
    }

    fun clearPythonOutput() {
        _pythonExecutionResult.value = null
    }

    // === AI Coding Assistant & IDE Simulator Methods (Step 19) ===
    fun setIdeLanguage(language: SupportedLanguage) {
        ideEngine.selectLanguage(language)
    }

    fun updateIdeCode(code: String) {
        ideEngine.updateCode(code)
    }

    fun runIdeCode() {
        triggerBossVoiceConfirmation()
        viewModelScope.launch {
            ideEngine.executeCode()
        }
    }

    fun clearIdeOutput() {
        viewModelScope.launch {
            ideEngine.executeCode(code = "", language = ideEngine.selectedLanguage.value)
        }
    }

    fun autoFormatIdeCode() {
        ideEngine.autoFormatCode(ideEngine.getCurrentCode(), ideEngine.selectedLanguage.value)
    }

    fun aiGenerateIdeCode(prompt: String) {
        viewModelScope.launch {
            ideEngine.generateCode(prompt, ideEngine.selectedLanguage.value)
        }
    }

    fun aiDebugAndFixIdeCode() {
        viewModelScope.launch {
            val err = ideEngine.lastExecutionResult.value?.error
            ideEngine.debugAndFixCode(ideEngine.getCurrentCode(), err, ideEngine.selectedLanguage.value)
        }
    }

    fun aiRefactorIdeCode() {
        viewModelScope.launch {
            ideEngine.refactorCode(ideEngine.getCurrentCode(), ideEngine.selectedLanguage.value)
        }
    }

    fun aiExplainIdeCode() {
        val code = ideEngine.getCurrentCode()
        val lang = ideEngine.selectedLanguage.value.displayName
        sendMessage("Please analyze, explain line-by-line, and break down the logic of this $lang code:\n\n```${ideEngine.selectedLanguage.value.identifier}\n$code\n```")
    }

    fun exportIdeScript(fileName: String): ExportedFileResult {
        return ideEngine.exportScriptToFile(fileNameWithoutExt = fileName)
    }

    // === Terminal Methods ===
    fun executeTerminalCommand(command: String) {
        val trimmed = command.trim()
        if (trimmed.isEmpty()) return

        triggerBossVoiceConfirmation()

        val currentLines = _terminalLines.value.toMutableList()
        currentLines.add(TerminalLine(TerminalLineType.INPUT, trimmed))
        _terminalLines.value = currentLines

        _isTerminalRunning.value = true

        terminalJob = viewModelScope.launch {
            val responseLines = terminalEngine.executeCommand(
                commandLine = trimmed,
                onGeminiQuery = { prompt ->
                    val history = _currentMessages.value.map { it.role to it.content }
                    val memoryStrings = memories.value.map { "${it.category} [${it.key}]: ${it.value}" }
                    val reply = geminiService.generateReply(
                        prompt = prompt,
                        history = history,
                        languageMode = _languageMode.value,
                        memories = memoryStrings,
                        model = _selectedModel.value,
                        customApiKey = _customApiKey.value
                    )
                    reply.getOrDefault("Gemini assistant response unavailable.")
                },
                onMemoryAction = { action, arg ->
                    if (action == "list") {
                        memories.value.joinToString("\n") { "[${it.category}] ${it.key}: ${it.value}" }
                            .ifEmpty { "No memories found." }
                    } else if (action == "add") {
                        val parts = arg.split(":", limit = 2)
                        if (parts.size == 2) {
                            addMemory(parts[0].trim(), parts[1].trim(), "Terminal")
                            "Saved to memory: ${parts[0].trim()} = ${parts[1].trim()}"
                        } else {
                            "Format: memory add <key: value>"
                        }
                    } else ""
                },
                onHardwareAction = { action, arg ->
                    when (action) {
                        "flashlight" -> {
                            val target = if (arg == "on") true else if (arg == "off") false else null
                            val res = hardwareManager.toggleFlashlight(target)
                            if (res.isSuccess) {
                                val on = res.getOrDefault(false)
                                "Flashlight is now ${if (on) "ON" else "OFF"}"
                            } else {
                                "Flashlight error: ${res.exceptionOrNull()?.message}"
                            }
                        }
                        "wifi" -> hardwareManager.openWifiControls()
                        "bluetooth" -> hardwareManager.openBluetoothControls()
                        "battery" -> {
                            val b = hardwareManager.getBatteryInfo()
                            "Battery: ${b.levelPct}% (${b.statusStr}, ${b.temperatureC}°C, Health: ${b.healthStr})"
                        }
                        else -> "Action completed."
                    }
                },
                remoteBackendUrl = _terminalBackendUrl.value.ifBlank { null }
            )

            _terminalCurrentDir.value = terminalEngine.getCurrentDir()
            _isTerminalRunning.value = false

            val updated = _terminalLines.value.toMutableList()
            if (responseLines.any { it.text == "__CLEAR__" }) {
                _terminalLines.value = emptyList()
            } else {
                updated.addAll(responseLines)
                _terminalLines.value = updated
            }
        }
    }

    fun clearTerminal() {
        _terminalLines.value = emptyList()
    }

    fun stopTerminalProcess() {
        terminalJob?.cancel()
        _isTerminalRunning.value = false
        val currentLines = _terminalLines.value.toMutableList()
        currentLines.add(TerminalLine(TerminalLineType.ERROR, "^C Process stopped."))
        _terminalLines.value = currentLines
    }

    fun setTerminalBackendUrl(url: String) {
        _terminalBackendUrl.value = url.trim()
        prefs.edit().putString("pref_terminal_backend_url", url.trim()).apply()
    }

    // Memories management
    fun addMemory(key: String, value: String, category: String) {
        viewModelScope.launch {
            repository.addMemory(key, value, category)
        }
    }

    fun updateMemory(memory: MemoryEntity) {
        viewModelScope.launch {
            repository.updateMemory(memory)
        }
    }

    fun deleteMemory(id: Long) {
        viewModelScope.launch {
            repository.deleteMemory(id)
        }
    }

    // Files management
    fun addFile(uri: Uri, displayName: String, sizeStr: String, mimeType: String) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.addFile(
                fileName = displayName,
                fileUri = uri.toString(),
                fileSize = sizeStr,
                mimeType = mimeType
            )
        }
    }

    fun deleteFile(id: Long) {
        viewModelScope.launch {
            repository.deleteFile(id)
        }
    }

    // === Vision & Scanner Engine Actions ===
    fun setVisionScanMode(mode: VisionScanMode) {
        _visionScanMode.value = mode
        clearVisionResults()
    }

    fun setVisionPreset(preset: VisionAiPreset) {
        _visionPreset.value = preset
    }

    fun onQrBarcodeDetected(result: QrBarcodeResult) {
        _qrBarcodeResult.value = result
    }

    fun onOcrDetected(result: OcrResult) {
        _ocrResult.value = result
    }

    fun clearVisionResults() {
        _qrBarcodeResult.value = null
        _ocrResult.value = null
        _visionAiResult.value = null
        _capturedVisionBitmap.value = null
        _visionStatusMessage.value = null
    }

    fun analyzeCapturedBitmap(bitmap: Bitmap, customPrompt: String? = null) {
        _capturedVisionBitmap.value = bitmap
        _isVisionAnalyzing.value = true
        _visionStatusMessage.value = "Analyzing with Atik AI Vision..."

        viewModelScope.launch {
            val result = visionEngine.analyzeImageWithAi(
                bitmap = bitmap,
                preset = _visionPreset.value,
                customPrompt = customPrompt,
                apiKey = _customApiKey.value
            )
            _isVisionAnalyzing.value = false
            if (result.isSuccess) {
                val parsed = result.getOrNull()
                _visionAiResult.value = parsed
                _visionStatusMessage.value = null
                if (_autoReadTts.value && parsed != null) {
                    voiceManager.speak(
                        text = "${parsed.title}. ${parsed.summary}",
                        mode = _languageMode.value,
                        pitch = 1.0f,
                        speed = _voiceSpeed.value
                    )
                }
            } else {
                _visionStatusMessage.value = "Vision Analysis failed: ${result.exceptionOrNull()?.message}"
            }
        }
    }

    fun scanImageBitmapForBarcodeOrOcr(bitmap: Bitmap) {
        _capturedVisionBitmap.value = bitmap
        when (_visionScanMode.value) {
            VisionScanMode.QR_BARCODE -> {
                visionEngine.scanBarcodeFromBitmap(
                    bitmap = bitmap,
                    onSuccess = { res ->
                        if (res != null) {
                            _qrBarcodeResult.value = res
                            _visionStatusMessage.value = null
                        } else {
                            _visionStatusMessage.value = "No QR Code or Barcode found in this image."
                        }
                    },
                    onFailure = { e ->
                        _visionStatusMessage.value = "Scan error: ${e.message}"
                    }
                )
            }
            VisionScanMode.OCR_TEXT -> {
                visionEngine.recognizeTextFromBitmap(
                    bitmap = bitmap,
                    onSuccess = { res ->
                        if (res.fullText.isNotBlank()) {
                            _ocrResult.value = res
                            _visionStatusMessage.value = null
                        } else {
                            _visionStatusMessage.value = "No readable text detected in this image."
                        }
                    },
                    onFailure = { e ->
                        _visionStatusMessage.value = "OCR error: ${e.message}"
                    }
                )
            }
            VisionScanMode.OBJECT_AI -> {
                analyzeCapturedBitmap(bitmap)
            }
        }
    }

    // === Social Media Automation & Scheduler Actions ===
    fun generateSocialContent(
        topic: String,
        platform: SocialPlatform,
        tone: String,
        audience: String
    ) {
        viewModelScope.launch {
            _isGeneratingSocial.value = true
            val result = socialEngine.generateSocialContent(
                topic = topic,
                platform = platform,
                tone = tone,
                targetAudience = audience,
                apiKey = _customApiKey.value
            )
            _isGeneratingSocial.value = false
            _generatedSocialContent.value = result.getOrNull()
        }
    }

    fun saveSocialPost(post: SocialPostEntity) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.saveSocialPost(post)
        }
    }

    fun updateSocialPostStatus(id: Long, status: String) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.updateSocialPostStatus(id, status)
        }
    }

    fun rescheduleSocialPost(id: Long, newTime: Long) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.rescheduleSocialPost(id, newTime)
        }
    }

    fun deleteSocialPost(id: Long) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.deleteSocialPost(id)
        }
    }

    fun clearPublishedSocialPosts() {
        viewModelScope.launch(Dispatchers.IO) {
            repository.clearPublishedSocialPosts()
        }
    }

    // === Custom Theme & Personalization Actions ===
    fun setThemeMode(mode: AppThemeMode) {
        _themeMode.value = mode
        prefs.edit().putString("pref_theme_mode", mode.name).apply()
        viewModelScope.launch(Dispatchers.IO) {
            repository.saveSetting("theme_mode", mode.name)
        }
    }

    fun setVoicePreferences(speed: Float, pitch: Float, gender: VoiceGender) {
        val safeSpeed = speed.coerceIn(0.6f, 2.0f)
        val safePitch = pitch.coerceIn(0.6f, 1.5f)
        _voiceSpeed.value = safeSpeed
        _voicePitch.value = safePitch
        _voiceGender.value = gender
        voiceManager.configureVoice(safeSpeed, safePitch, gender, _userAccent.value)
        prefs.edit()
            .putFloat("pref_voice_speed", safeSpeed)
            .putFloat("pref_voice_pitch", safePitch)
            .putString("pref_voice_gender", gender.name)
            .apply()
        viewModelScope.launch(Dispatchers.IO) {
            repository.saveSetting("voice_speed", safeSpeed.toString())
            repository.saveSetting("voice_pitch", safePitch.toString())
            repository.saveSetting("voice_gender", gender.name)
        }
    }

    fun setVoiceAccent(accent: VoiceAccent) {
        _userAccent.value = accent
        prefs.edit().putString("voice_accent", accent.name).apply()
        voiceManager.configureVoice(_voiceSpeed.value, _voicePitch.value, _voiceGender.value, accent)
    }

    fun translateText(text: String, sourceCode: String = "auto", targetCode: String = "en") {
        viewModelScope.launch {
            translationEngine.translate(text, sourceCode, targetCode)
        }
    }

    fun playTranslatedAudio(text: String, locale: Locale) {
        voiceManager.speakInLocale(text, locale)
    }

    fun setPersonalProfile(name: String, title: String, greetingStyle: String) {
        val safeName = name.trim().ifBlank { "Atikur Rahman" }
        val safeTitle = title.trim().ifBlank { "Atik Bhai" }
        val safeStyle = greetingStyle.trim().ifBlank { "Time-Aware" }
        _userName.value = safeName
        _preferredTitle.value = safeTitle
        _greetingStyle.value = safeStyle
        prefs.edit()
            .putString("pref_user_name", safeName)
            .putString("pref_preferred_title", safeTitle)
            .putString("pref_greeting_style", safeStyle)
            .apply()
        viewModelScope.launch(Dispatchers.IO) {
            repository.saveSetting("user_name", safeName)
            repository.saveSetting("preferred_title", safeTitle)
            repository.saveSetting("greeting_style", safeStyle)
            repository.addMemory("User Name", safeName, "Profile")
            repository.addMemory("Preferred Title", safeTitle, "Preference")
        }
    }

    fun testAuditionVoice() {
        voiceManager.testAuditionVoice(_languageMode.value)
    }

    // === Kung-Fu Avatar Actions & Customization (Step 11) ===
    fun setAvatarVisible(visible: Boolean) {
        _avatarVisible.value = visible
        prefs.edit().putBoolean("pref_avatar_visible", visible).apply()
        viewModelScope.launch(Dispatchers.IO) { repository.saveSetting("avatar_visible", visible.toString()) }
    }

    fun setAvatarScale(scale: Float) {
        val safeScale = scale.coerceIn(0.7f, 1.4f)
        _avatarScale.value = safeScale
        prefs.edit().putFloat("pref_avatar_scale", safeScale).apply()
        viewModelScope.launch(Dispatchers.IO) { repository.saveSetting("avatar_scale", safeScale.toString()) }
    }

    fun setAvatarPosition(position: AvatarPosition) {
        _avatarPosition.value = position
        prefs.edit().putString("pref_avatar_position", position.name).apply()
        viewModelScope.launch(Dispatchers.IO) { repository.saveSetting("avatar_position", position.name) }
    }

    fun setAvatarGestureSpeed(speed: Float) {
        val safeSpeed = speed.coerceIn(0.5f, 2.0f)
        _avatarGestureSpeed.value = safeSpeed
        prefs.edit().putFloat("pref_avatar_gesture_speed", safeSpeed).apply()
        viewModelScope.launch(Dispatchers.IO) { repository.saveSetting("avatar_gesture_speed", safeSpeed.toString()) }
    }

    fun setAvatarStance(stance: KungFuStance) {
        _avatarStance.value = stance
        prefs.edit().putString("pref_avatar_stance", stance.name).apply()
        viewModelScope.launch(Dispatchers.IO) { repository.saveSetting("avatar_stance", stance.name) }
    }

    fun performStanceAction(stance: KungFuStance) {
        _avatarStance.value = stance
        _avatarActionTrigger.value = stance.actionQuote
        _bossActionPhrase.value = stance.actionQuote
        voiceManager.speak(stance.actionQuote, _languageMode.value)
    }

    fun setAvatarCustomization(
        visible: Boolean,
        scale: Float,
        position: AvatarPosition,
        speed: Float,
        stance: KungFuStance
    ) {
        setAvatarVisible(visible)
        setAvatarScale(scale)
        setAvatarPosition(position)
        setAvatarGestureSpeed(speed)
        setAvatarStance(stance)
    }

    // === Network & Offline AI Controls (Step 12) ===
    fun toggleOfflineSimulation(enabled: Boolean) {
        networkMonitor.toggleOfflineSimulation(enabled)
    }

    // === Smart Automation & Routine Task Actions (Step 13) ===
    fun addTask(title: String, description: String = "", priority: String = "MEDIUM", category: String = "Work") {
        viewModelScope.launch(Dispatchers.IO) {
            repository.addTask(title, description, priority, category)
        }
    }

    fun toggleTaskCompleted(id: String, isCompleted: Boolean) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.setTaskCompleted(id, isCompleted)
        }
    }

    fun deleteTask(id: String) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.deleteTask(id)
        }
    }

    fun clearCompletedTasks() {
        viewModelScope.launch(Dispatchers.IO) {
            repository.clearCompletedTasks()
        }
    }

    fun toggleRoutine(id: String, isEnabled: Boolean) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.setRoutineEnabled(id, isEnabled)
        }
    }

    fun runRoutineBriefing(routineType: String) {
        viewModelScope.launch {
            val content = routineEngine.generateBriefingContent(
                routineType = routineType,
                userName = _userName.value,
                preferredTitle = _preferredTitle.value
            )
            _lastAiReply.value = content

            // Deliver push notification
            val notifId = (System.currentTimeMillis() % 10000).toInt()
            val notifTitle = when (routineType) {
                "MORNING_BRIEFING" -> "🌅 Morning Executive Briefing"
                "EVENING_SUMMARY" -> "🌇 Evening Summary"
                "WORK_FOCUS" -> "⚡ Deep Work Focus Sprint"
                else -> "🌙 Night Reflection"
            }
            routineEngine.postNotification(
                notifId,
                notifTitle,
                content.lines().firstOrNull { it.isNotBlank() } ?: "Briefing Ready",
                SmartRoutineEngine.CHANNEL_ROUTINES
            )

            // Save to chat session if exists
            val sessionId = _currentSessionId.value
            if (sessionId != null) {
                val inserted = repository.addMessage(
                    sessionId = sessionId,
                    role = "model",
                    content = content
                )
                if (_autoReadTts.value) {
                    speakMessage(inserted.id, content)
                }
            } else {
                voiceManager.speak(content, _languageMode.value)
            }
        }
    }

    fun addReminder(title: String, timeFormatted: String, isAlarm: Boolean = false) {
        viewModelScope.launch(Dispatchers.IO) {
            val timeMillis = System.currentTimeMillis() + 3600000L
            val reminder = repository.addReminder(title, timeFormatted, timeMillis, isAlarm)
            taskSchedulerEngine.scheduleExactReminder(reminder)
            val notifId = (System.currentTimeMillis() % 10000).toInt()
            routineEngine.postNotification(
                notifId,
                if (isAlarm) "⏰ Alarm Scheduled" else "🔔 Reminder Scheduled",
                "$title at $timeFormatted",
                SmartRoutineEngine.CHANNEL_REMINDERS
            )
        }
    }

    fun deleteReminder(id: String) {
        viewModelScope.launch(Dispatchers.IO) {
            taskSchedulerEngine.cancelReminder(id)
            repository.deleteReminder(id)
        }
    }

    // === Voice Shortcuts & Floating Widget Controls (Step 14) ===
    fun toggleFloatingBubble(enabled: Boolean) {
        _isFloatingBubbleEnabled.value = enabled
        prefs.edit().putBoolean("floating_bubble_enabled", enabled).apply()
    }

    fun setQuickOverlayVisible(visible: Boolean) {
        _isQuickOverlayVisible.value = visible
    }

    fun setFloatingBubbleSize(sizeDp: Int) {
        _floatingBubbleSizeDp.value = sizeDp
        prefs.edit().putInt("floating_bubble_size_dp", sizeDp).apply()
    }

    fun executeVoiceShortcut(shortcut: VoiceShortcut) {
        when (shortcut.actionType) {
            ShortcutActionType.MORNING_BRIEFING -> runRoutineBriefing("MORNING_BRIEFING")
            ShortcutActionType.EVENING_SUMMARY -> runRoutineBriefing("EVENING_SUMMARY")
            ShortcutActionType.DEEP_WORK_FOCUS -> runRoutineBriefing("WORK_FOCUS")
            ShortcutActionType.FLASHLIGHT_TOGGLE -> {
                val hw = hardwareManager.executeHardwareCommand("flashlight toggle")
                if (hw != null) {
                    _lastAiReply.value = hw.feedbackMessage
                    voiceManager.speak(hw.feedbackMessage, _languageMode.value)
                }
            }
            ShortcutActionType.BATTERY_CHECK -> {
                val hw = hardwareManager.executeHardwareCommand("battery")
                if (hw != null) {
                    _lastAiReply.value = hw.feedbackMessage
                    voiceManager.speak(hw.feedbackMessage, _languageMode.value)
                }
            }
            ShortcutActionType.QUICK_NOTE -> {
                _isQuickOverlayVisible.value = true
                voiceManager.speak("Note mode activated. Please speak your note, Boss.", _languageMode.value)
            }
            ShortcutActionType.TRANSLATE_BANGLA -> {
                _isQuickOverlayVisible.value = true
                voiceManager.speak("Speak or enter the English text to translate, Boss.", _languageMode.value)
            }
            ShortcutActionType.CUSTOM_PROMPT -> {
                if (shortcut.customPrompt.isNotBlank()) {
                    sendMessage(shortcut.customPrompt, isVoiceCommand = true)
                }
            }
        }
    }

    fun addCustomShortcut(title: String, triggerPhrase: String, customPrompt: String, emoji: String = "⚡") {
        shortcutsEngine.addCustomShortcut(title, triggerPhrase, customPrompt, emoji)
    }

    fun deleteShortcut(id: String) {
        shortcutsEngine.deleteShortcut(id)
    }

    fun toggleSystemFloatingService(context: Context, enable: Boolean) {
        if (enable) {
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M && !Settings.canDrawOverlays(context)) {
                _isSystemOverlayActive.value = false
                return
            }
            FloatingBubbleService.startService(context)
            _isSystemOverlayActive.value = true
        } else {
            FloatingBubbleService.stopService(context)
            _isSystemOverlayActive.value = false
        }
    }

    // === App Performance & Resource Optimization Controls (Step 15) ===
    fun runPerformanceOptimization() {
        viewModelScope.launch {
            val result = optimizationEngine.runOptimizationSweep()
            voiceManager.speak(
                "Optimization complete. Freed ${result.freedMemoryMb} megabytes of RAM and cleared ${result.clearedStorageFormatted} cache.",
                _languageMode.value
            )
        }
    }

    fun refreshPerformanceDiagnostics() {
        optimizationEngine.refreshDiagnostics()
    }

    fun setPowerProfile(mode: PowerProfileMode) {
        optimizationEngine.setPowerProfile(mode)
    }

    fun setAutoCleanConfig(enabled: Boolean, thresholdMb: Int) {
        optimizationEngine.setAutoCleanConfig(enabled, thresholdMb)
    }

    // === Security, Privacy & Data Encryption Controls (Step 16) ===
    fun setBiometricEnabled(enabled: Boolean) {
        biometricEngine.setBiometricEnabled(enabled)
    }

    fun setMasterPin(pin: String) {
        biometricEngine.setMasterPin(pin)
    }

    fun verifyMasterPin(pin: String): Boolean {
        return biometricEngine.verifyMasterPin(pin)
    }

    fun triggerBiometricAuth(activity: Activity, onSuccess: () -> Unit, onError: (String) -> Unit) {
        biometricEngine.triggerNativeBiometricAuth(activity, onSuccess, onError)
    }

    fun lockApp() {
        biometricEngine.lockApp()
    }

    fun unlockAppDirectly() {
        biometricEngine.unlockAppDirectly()
    }

    fun exportEncryptedBackup(): String {
        return try {
            val root = JSONObject()
            val sessionsList = JSONArray()
            allSessions.value.forEach { s ->
                val sObj = JSONObject().apply {
                    put("id", s.id)
                    put("title", s.title)
                    put("createdAt", s.createdAt)
                    put("updatedAt", s.updatedAt)
                }
                sessionsList.put(sObj)
            }
            root.put("sessions", sessionsList)

            val memoriesList = JSONArray()
            memories.value.forEach { m ->
                val mObj = JSONObject().apply {
                    put("key", m.key)
                    put("value", m.value)
                    put("category", m.category)
                    put("timestamp", m.timestamp)
                }
                memoriesList.put(mObj)
            }
            root.put("memories", memoriesList)
            root.put("exportedAt", System.currentTimeMillis())
            root.put("appVersion", "1.0.0-step16")

            encryptionEngine.createEncryptedBackupPackage(root.toString())
        } catch (_: Exception) {
            "ERROR_GENERATING_BACKUP"
        }
    }

    fun restoreEncryptedBackup(vaultPayload: String): Boolean {
        val decryptedJson = encryptionEngine.decryptBackupPackage(vaultPayload.trim()) ?: return false
        return try {
            val root = JSONObject(decryptedJson)
            val memoriesArray = root.optJSONArray("memories")
            if (memoriesArray != null) {
                viewModelScope.launch {
                    for (i in 0 until memoriesArray.length()) {
                        val m = memoriesArray.getJSONObject(i)
                        repository.addMemory(
                            key = m.optString("key", ""),
                            value = m.optString("value", ""),
                            category = m.optString("category", "General")
                        )
                    }
                }
            }
            true
        } catch (_: Exception) {
            false
        }
    }

    fun clearAllLocalData() {
        viewModelScope.launch {
            repository.clearAllDatabaseData()
            _currentSessionId.value = null
            _currentMessages.value = emptyList()
            prefs.edit().clear().apply()
            optimizationEngine.runOptimizationSweep()
        }
    }

    // === Smart Web Search & Live News Aggregator Controls (Step 18) ===
    fun searchWeb(query: String) {
        viewModelScope.launch {
            webSearchEngine.searchLiveWeb(query)
        }
    }

    fun summarizeWebArticle(url: String) {
        viewModelScope.launch {
            webSearchEngine.summarizeArticle(url)
        }
    }

    fun selectNewsCategory(category: NewsCategory) {
        webSearchEngine.setCategory(category)
    }

    fun toggleNewsBookmark(articleId: String) {
        webSearchEngine.toggleBookmark(articleId)
    }

    fun refreshNewsFeed() {
        viewModelScope.launch {
            webSearchEngine.refreshNewsFeed()
        }
    }

    // === Deep System Automation, Airplane Mode & Gallery AI Controls (Step 20) ===
    fun toggleAirplaneMode() {
        val result = systemAutomationEngine.openAirplaneModeSettings()
        voiceManager.speak(result, _languageMode.value)
    }

    fun openMobileDataSettings() {
        systemAutomationEngine.openMobileDataSettings()
    }

    fun openWifiControls() {
        systemAutomationEngine.openWifiControls()
    }

    fun openBluetoothControls() {
        systemAutomationEngine.openBluetoothControls()
    }

    fun toggleSystemFlashlight() {
        systemAutomationEngine.toggleFlashlight()
    }

    fun setSystemSoundProfile(profile: SoundProfile) {
        val result = systemAutomationEngine.setSoundProfile(profile)
        voiceManager.speak(result, _languageMode.value)
    }

    fun openSystemSubMenu(actionIntent: String) {
        appNavigationEngine.openSystemSetting(actionIntent)
    }

    fun launchInstalledApp(packageName: String) {
        appNavigationEngine.launchAppByPackage(packageName)
    }

    fun searchGalleryPhotos(query: String) {
        galleryAiEngine.searchPhotos(query)
    }

    fun selectGalleryPhotoCategory(category: PhotoCategory) {
        galleryAiEngine.selectCategory(category)
    }

    fun indexDevicePhoto(uri: Uri) {
        viewModelScope.launch {
            galleryAiEngine.indexImportedPhoto(uri)
        }
    }

    // === Interactive Live Voice & Wake-Word Controls (Step 21) ===
    fun setWakeWordEnabled(enabled: Boolean) {
        wakeWordEngine.setWakeWordEnabled(enabled)
    }

    fun setWakeWordSensitivity(sens: WakeWordSensitivity) {
        wakeWordEngine.setSensitivity(sens)
    }

    fun setWakeWordSensitivityByWeight(weight: Float) {
        wakeWordEngine.setSensitivityByWeight(weight)
    }

    fun setHandsFreeDuplex(enabled: Boolean) {
        wakeWordEngine.setHandsFreeDuplexEnabled(enabled)
    }

    fun setAudioChimeEnabled(enabled: Boolean) {
        wakeWordEngine.setAudioChimeEnabled(enabled)
    }

    fun setHapticFeedbackEnabled(enabled: Boolean) {
        wakeWordEngine.setHapticFeedbackEnabled(enabled)
    }

    fun testAudioChime() {
        wakeWordEngine.playAudioCue(AudioCueType.WAKE)
        wakeWordEngine.triggerHaptic(AudioCueType.WAKE)
    }

    fun testAudioCue(type: AudioCueType) {
        wakeWordEngine.playAudioCue(type)
        wakeWordEngine.triggerHaptic(type)
    }

    // === Smart Automation Workflows & Task Scheduler Methods (Step 22) ===
    fun addWorkflow(
        name: String,
        description: String,
        iconEmoji: String,
        scheduledTime: String,
        actions: List<WorkflowActionType>
    ) {
        val actionsCsv = actions.joinToString(",") { it.id }
        val workflow = WorkflowEntity(
            name = name.trim(),
            description = description.trim(),
            iconEmoji = iconEmoji.ifBlank { "⚡" },
            scheduledTime = scheduledTime,
            actionsCsv = actionsCsv
        )
        viewModelScope.launch(Dispatchers.IO) {
            repository.insertWorkflow(workflow)
            taskSchedulerEngine.scheduleWorkflowAlarm(workflow)
        }
    }

    fun toggleWorkflow(id: String, isEnabled: Boolean) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.setWorkflowEnabled(id, isEnabled)
            val wf = allWorkflows.value.firstOrNull { it.id == id }
            if (wf != null) {
                if (isEnabled) {
                    taskSchedulerEngine.scheduleWorkflowAlarm(wf.copy(isEnabled = true))
                } else {
                    taskSchedulerEngine.cancelWorkflowAlarm(id)
                }
            }
        }
    }

    fun executeWorkflowNow(workflow: WorkflowEntity) {
        triggerBossVoiceConfirmation()
        viewModelScope.launch {
            taskSchedulerEngine.executeWorkflow(workflow)
        }
    }

    fun deleteWorkflow(id: String) {
        viewModelScope.launch(Dispatchers.IO) {
            taskSchedulerEngine.cancelWorkflowAlarm(id)
            repository.deleteWorkflow(id)
        }
    }

    fun setQuietHoursEnabled(enabled: Boolean) {
        taskSchedulerEngine.setQuietHoursEnabled(enabled)
    }

    fun setQuietHoursSchedule(startHour: Int, startMinute: Int, endHour: Int, endMinute: Int) {
        taskSchedulerEngine.setQuietHoursSchedule(startHour, startMinute, endHour, endMinute)
    }

    fun setDndAllowUrgent(allow: Boolean) {
        taskSchedulerEngine.setAllowUrgentTasks(allow)
    }

    fun setDndVibrateOnly(vibrate: Boolean) {
        taskSchedulerEngine.setVibrateOnly(vibrate)
    }

    fun setDndSoundEnabled(sound: Boolean) {
        taskSchedulerEngine.setNotificationSoundEnabled(sound)
    }

    fun openSystemDndSettings() {
        taskSchedulerEngine.openSystemDndSettings()
    }

    fun openAppNotificationSettings() {
        taskSchedulerEngine.openAppNotificationSettings()
    }

    fun testAlertNotification() {
        triggerBossVoiceConfirmation()
        val isQuiet = taskSchedulerEngine.isQuietHoursActive()
        val notifId = (System.currentTimeMillis() % 10000).toInt()
        routineEngine.postNotification(
            id = notifId,
            title = if (isQuiet) "🌙 DND Alert (Quiet Mode)" else "⚡ Atik AI Task Scheduler Alert",
            content = if (isQuiet) "Quiet Hours / DND is active. Delivered as low-priority discreet notification." else "Automated task scheduler triggered. Background workers operational.",
            channelId = SmartRoutineEngine.CHANNEL_REMINDERS
        )
    }

    // === Offline AI Capabilities & Storage Persistence (Step 23) ===
    fun addNote(title: String, content: String, category: String = "General", isPinned: Boolean = false) {
        viewModelScope.launch(Dispatchers.IO) {
            val isOnline = networkMonitor.isEffectiveOnline.value
            repository.addNote(title, content, category, isPinned, isSynced = isOnline)
            if (!isOnline) {
                offlineSyncEngine.enqueueOfflineAction(
                    actionType = "CREATE_NOTE",
                    payloadJson = """{"title":"${title.replace("\"", "\\\"")}","content":"${content.replace("\"", "\\\"")}"}""",
                    description = "Offline Note: $title"
                )
            }
            refreshDatabaseMetrics()
        }
    }

    fun updateNote(note: NoteEntity) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.updateNote(note)
            refreshDatabaseMetrics()
        }
    }

    fun deleteNote(id: String) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.deleteNote(id)
            refreshDatabaseMetrics()
        }
    }

    fun syncPendingOfflineData() {
        triggerBossVoiceConfirmation()
        viewModelScope.launch {
            offlineSyncEngine.syncPendingData(isAutomatic = false)
            refreshDatabaseMetrics()
        }
    }

    fun setAutoSyncEnabled(enabled: Boolean) {
        viewModelScope.launch {
            dataStorePreferences.setAutoSyncEnabled(enabled)
        }
    }

    fun setOfflineFallbackPersona(enabled: Boolean) {
        viewModelScope.launch {
            dataStorePreferences.setOfflineFallbackPersona(enabled)
        }
    }

    fun setSyncOnlyOnWifi(onlyWifi: Boolean) {
        viewModelScope.launch {
            dataStorePreferences.setSyncOnlyOnWifi(onlyWifi)
        }
    }

    fun refreshDatabaseMetrics() {
        viewModelScope.launch(Dispatchers.IO) {
            val metrics = repository.getStorageMetrics()
            _localDatabaseMetrics.value = metrics
        }
    }

    fun clearOfflineCache() {
        triggerBossVoiceConfirmation()
        viewModelScope.launch(Dispatchers.IO) {
            repository.clearCompletedOfflineActions()
            localCacheManager.pruneExpiredCache()
            repository.clearCompletedTasks()
            refreshDatabaseMetrics()
        }
    }

    fun purgeAllLocalCache() {
        triggerBossVoiceConfirmation()
        viewModelScope.launch(Dispatchers.IO) {
            localCacheManager.clearAllCache()
            repository.clearCompletedOfflineActions()
            refreshDatabaseMetrics()
        }
    }

    // Smart Action & Accessibility Automation Controls (Step 24)
    fun confirmSmartAction() {
        triggerBossVoiceConfirmation()
        smartActionEngine.confirmAndExecuteNow()
    }

    fun abortSmartAction(reason: String = "Action aborted by user") {
        smartActionEngine.abortAction(reason)
    }

    fun dismissSmartActionFeedback() {
        smartActionEngine.dismissFeedback()
    }

    fun openAccessibilitySettings() {
        AtikAccessibilityActionService.openAccessibilitySettings(getApplication())
    }

    fun isAccessibilityServiceEnabled(): Boolean {
        return AtikAccessibilityActionService.isAccessibilityEnabled(getApplication())
    }

    fun setSmartActionEnabled(enabled: Boolean) {
        viewModelScope.launch {
            dataStorePreferences.setSmartActionEnabled(enabled)
        }
    }

    fun setRequireConfirmation(required: Boolean) {
        viewModelScope.launch {
            dataStorePreferences.setRequireConfirmation(required)
        }
    }

    fun setActionCountdownSeconds(seconds: Long) {
        viewModelScope.launch {
            dataStorePreferences.setCountdownSeconds(seconds)
        }
    }

    fun setWhatsappActionEnabled(enabled: Boolean) {
        viewModelScope.launch {
            dataStorePreferences.setWhatsappActionEnabled(enabled)
        }
    }

    fun setImoActionEnabled(enabled: Boolean) {
        viewModelScope.launch {
            dataStorePreferences.setImoActionEnabled(enabled)
        }
    }

    fun setSmsActionEnabled(enabled: Boolean) {
        viewModelScope.launch {
            dataStorePreferences.setSmsActionEnabled(enabled)
        }
    }

    fun setPhoneActionEnabled(enabled: Boolean) {
        viewModelScope.launch {
            dataStorePreferences.setPhoneActionEnabled(enabled)
        }
    }

    fun clearSmartActionAudits() {
        viewModelScope.launch(Dispatchers.IO) {
            repository.clearSmartActionAudits()
            refreshDatabaseMetrics()
        }
    }

    fun testSmartAction(
        targetApp: TargetMessagingApp,
        actionType: SmartActionType,
        recipient: String,
        messageText: String?
    ) {
        val request = SmartActionRequest(
            targetApp = targetApp,
            actionType = actionType,
            recipient = recipient,
            messageText = messageText,
            requireConfirmation = true
        )
        smartActionEngine.submitAction(request)
    }

    // Dynamic Theme Engine Controls & Room DB Persistence (Step 25 Requirements 1, 2, 3, 4)
    fun setDynamicThemePreset(preset: ThemePreset) {
        val updated = _dynamicThemeState.value.copy(
            preset = preset,
            accentColorHex = String.format("#%06X", (0xFFFFFF and preset.defaultAccentCyan.value.toInt()))
        )
        _dynamicThemeState.value = updated
        viewModelScope.launch(Dispatchers.IO) {
            repository.saveThemeConfig(updated.toEntity())
        }
    }

    fun setDynamicAccentColor(hex: String) {
        val updated = _dynamicThemeState.value.copy(accentColorHex = hex)
        _dynamicThemeState.value = updated
        viewModelScope.launch(Dispatchers.IO) {
            repository.saveThemeConfig(updated.toEntity())
        }
    }

    fun setDynamicButtonStyle(style: AppButtonStyle) {
        val updated = _dynamicThemeState.value.copy(buttonStyle = style)
        _dynamicThemeState.value = updated
        viewModelScope.launch(Dispatchers.IO) {
            repository.saveThemeConfig(updated.toEntity())
        }
    }

    fun setDynamicFontScale(scale: Float) {
        val updated = _dynamicThemeState.value.copy(fontScale = scale.coerceIn(0.85f, 1.30f))
        _dynamicThemeState.value = updated
        viewModelScope.launch(Dispatchers.IO) {
            repository.saveThemeConfig(updated.toEntity())
        }
    }

    fun setDynamicBackgroundWidget(widget: BackgroundWidgetType) {
        val updated = _dynamicThemeState.value.copy(backgroundWidget = widget)
        _dynamicThemeState.value = updated
        viewModelScope.launch(Dispatchers.IO) {
            repository.saveThemeConfig(updated.toEntity())
        }
    }

    // In-App 2D Game Generator & Player Controls (Step 26 Requirements 1, 2, 3, 4)
    fun generateGame(prompt: String, onComplete: ((GameProjectEntity) -> Unit)? = null) {
        viewModelScope.launch {
            _isGeneratingGame.value = true
            try {
                val game = gameGeneratorEngine.generateGameFromPrompt(prompt, _customApiKey.value)
                _activeGameToPlay.value = game
                onComplete?.invoke(game)
            } finally {
                _isGeneratingGame.value = false
            }
        }
    }

    fun launchGame(game: GameProjectEntity) {
        _activeGameToPlay.value = game
    }

    fun launchGameByTitleOrId(query: String) {
        viewModelScope.launch(Dispatchers.IO) {
            val game = repository.getGameById(query) ?: games.value.firstOrNull {
                it.title.contains(query, ignoreCase = true) || it.genre.contains(query, ignoreCase = true)
            }
            if (game != null) {
                _activeGameToPlay.value = game
            }
        }
    }

    fun closeActiveGame() {
        _activeGameToPlay.value = null
    }

    fun deleteGame(id: String) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.deleteGame(id)
        }
    }

    fun recordGameScore(gameId: String, score: Int, durationSeconds: Int = 0) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.recordGameScore(gameId, score, _userName.value, durationSeconds)
        }
    }

    fun saveGameState(gameId: String, stateJson: String) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.saveGameState(gameId, stateJson)
        }
    }

    override fun onCleared() {
        super.onCleared()
        networkMonitor.destroy()
        geminiLiveClient.disconnect()
        voiceManager.destroy()
        wakeWordEngine.destroy()
    }
}
