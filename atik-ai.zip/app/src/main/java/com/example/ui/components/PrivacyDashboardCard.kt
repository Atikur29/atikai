package com.example.ui.components

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Fingerprint
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.OpenInNew
import androidx.compose.material.icons.filled.Restore
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.AtikBorder
import com.example.ui.theme.AtikElectricBlue
import com.example.ui.theme.AtikNeonAzure
import com.example.ui.theme.AtikNeonCyan
import com.example.ui.theme.AtikSuccess
import com.example.ui.theme.AtikSurface
import com.example.ui.theme.AtikSurfaceHighlight
import com.example.ui.theme.AtikSurfaceVariant
import com.example.ui.theme.AtikTextMuted
import com.example.ui.theme.AtikTextPrimary
import com.example.ui.theme.AtikTextSecondary

/**
 * Privacy & Security Control Center Card (Step 16 Requirement 3).
 * Manages biometric app lock, AES-256 local data encryption,
 * encrypted backup export/restore, permissions oversight, and data wipe actions.
 */
@Composable
fun PrivacyDashboardCard(
    isBiometricEnabled: Boolean,
    hasMasterPin: Boolean,
    onToggleBiometric: (Boolean) -> Unit,
    onSetMasterPin: (String) -> Unit,
    onLockAppNow: () -> Unit,
    onExportEncryptedBackup: () -> String,
    onRestoreEncryptedBackup: (String) -> Boolean,
    onClearAllLocalData: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var showSetPinDialog by remember { mutableStateOf(false) }
    var showExportDialog by remember { mutableStateOf(false) }
    var exportedVaultText by remember { mutableStateOf("") }
    var showRestoreDialog by remember { mutableStateOf(false) }
    var restoreInputText by remember { mutableStateOf("") }
    var showWipeConfirmDialog by remember { mutableStateOf(false) }

    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("card_privacy_dashboard"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = AtikSurface),
        border = BorderStroke(1.dp, AtikBorder)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(
                                Brush.linearGradient(
                                    colors = listOf(AtikElectricBlue, AtikNeonCyan)
                                )
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            Icons.Default.Security,
                            contentDescription = "Security Engine",
                            tint = Color.White,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = "Security & Privacy Center",
                            color = AtikTextPrimary,
                            fontSize = 14.5.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Biometric lock, AES encryption & data control",
                            color = AtikTextMuted,
                            fontSize = 11.sp
                        )
                    }
                }

                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = AtikSuccess.copy(alpha = 0.15f),
                    border = BorderStroke(1.dp, AtikSuccess)
                ) {
                    Text(
                        text = "Encrypted",
                        color = AtikSuccess,
                        fontSize = 10.5.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Encryption Telemetry Banner
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = AtikSurfaceVariant,
                border = BorderStroke(0.8.dp, AtikBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        Icons.Default.Shield,
                        contentDescription = null,
                        tint = AtikNeonCyan,
                        modifier = Modifier.size(22.dp)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "AES-256 GCM Local Encryption",
                            color = AtikTextPrimary,
                            fontSize = 12.5.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Chat history, memory vectors, and API keys are encrypted at rest with device-bound cryptographic keys.",
                            color = AtikTextMuted,
                            fontSize = 10.5.sp,
                            lineHeight = 14.sp
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Biometric & PIN Lock Section
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = AtikSurfaceVariant,
                border = BorderStroke(0.8.dp, AtikBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                Icons.Default.Fingerprint,
                                contentDescription = null,
                                tint = AtikNeonAzure,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text(
                                    text = "Biometric & Master PIN Lock",
                                    color = AtikTextPrimary,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.SemiBold
                                )
                                Text(
                                    text = if (hasMasterPin) "PIN configured and active" else "Setup 4-digit PIN to enable",
                                    color = if (hasMasterPin) AtikNeonCyan else AtikTextMuted,
                                    fontSize = 11.sp
                                )
                            }
                        }

                        Switch(
                            checked = isBiometricEnabled && hasMasterPin,
                            onCheckedChange = { enable ->
                                if (enable && !hasMasterPin) {
                                    showSetPinDialog = true
                                } else {
                                    onToggleBiometric(enable)
                                }
                            },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = AtikNeonCyan,
                                checkedTrackColor = AtikElectricBlue
                            ),
                            modifier = Modifier.testTag("switch_biometric_lock")
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedButton(
                            onClick = { showSetPinDialog = true },
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier
                                .weight(1f)
                                .height(38.dp)
                                .testTag("btn_configure_pin")
                        ) {
                            Icon(Icons.Default.Key, null, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(if (hasMasterPin) "Change PIN" else "Set Master PIN", fontSize = 11.sp)
                        }

                        if (isBiometricEnabled && hasMasterPin) {
                            Button(
                                onClick = onLockAppNow,
                                shape = RoundedCornerShape(8.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = AtikSurfaceHighlight),
                                modifier = Modifier
                                    .weight(1f)
                                    .height(38.dp)
                                    .testTag("btn_lock_app_now")
                            ) {
                                Icon(Icons.Default.Lock, null, tint = AtikNeonCyan, modifier = Modifier.size(14.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Lock Now", color = AtikNeonCyan, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Encrypted Data Backup & Vault Snapshot
            Text(
                text = "Encrypted Vault Snapshots",
                color = AtikTextSecondary,
                fontSize = 12.sp,
                fontWeight = FontWeight.SemiBold
            )
            Spacer(modifier = Modifier.height(6.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Surface(
                    onClick = {
                        exportedVaultText = onExportEncryptedBackup()
                        showExportDialog = true
                    },
                    shape = RoundedCornerShape(10.dp),
                    color = AtikSurfaceVariant,
                    border = BorderStroke(1.dp, AtikBorder),
                    modifier = Modifier
                        .weight(1f)
                        .testTag("btn_export_vault")
                ) {
                    Row(
                        modifier = Modifier.padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center
                    ) {
                        Icon(Icons.Default.Download, null, tint = AtikNeonCyan, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Export Backup", color = AtikTextPrimary, fontSize = 11.5.sp, fontWeight = FontWeight.Medium)
                    }
                }

                Surface(
                    onClick = { showRestoreDialog = true },
                    shape = RoundedCornerShape(10.dp),
                    color = AtikSurfaceVariant,
                    border = BorderStroke(1.dp, AtikBorder),
                    modifier = Modifier
                        .weight(1f)
                        .testTag("btn_restore_vault")
                ) {
                    Row(
                        modifier = Modifier.padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center
                    ) {
                        Icon(Icons.Default.Restore, null, tint = AtikNeonAzure, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Restore Vault", color = AtikTextPrimary, fontSize = 11.5.sp, fontWeight = FontWeight.Medium)
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Permission Access Manager
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = AtikSurfaceVariant,
                border = BorderStroke(0.8.dp, AtikBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "System Permission Oversight",
                            color = AtikTextPrimary,
                            fontSize = 12.5.sp,
                            fontWeight = FontWeight.SemiBold
                        )

                        TextButton(
                            onClick = {
                                val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                                    data = Uri.fromParts("package", context.packageName, null)
                                }
                                context.startActivity(intent)
                            },
                            modifier = Modifier.testTag("btn_open_app_permissions")
                        ) {
                            Text("Manage in OS", color = AtikNeonCyan, fontSize = 11.sp)
                            Spacer(modifier = Modifier.width(4.dp))
                            Icon(Icons.Default.OpenInNew, null, tint = AtikNeonCyan, modifier = Modifier.size(13.dp))
                        }
                    }

                    Text(
                        text = "Microphone • Camera • Overlay Window • Notifications • Bluetooth",
                        color = AtikTextMuted,
                        fontSize = 10.5.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Clear All Local Data (Privacy Factory Reset)
            Button(
                onClick = { showWipeConfirmDialog = true },
                shape = RoundedCornerShape(10.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color(0xFF3B1515),
                    contentColor = Color(0xFFFF5252)
                ),
                border = BorderStroke(1.dp, Color(0xFFFF5252).copy(alpha = 0.4f)),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(44.dp)
                    .testTag("btn_clear_all_data")
            ) {
                Icon(Icons.Default.Warning, null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("Clear All Local Data & Reset Vault", fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }
        }
    }

    // Set Master PIN Dialog
    if (showSetPinDialog) {
        var pinInput by remember { mutableStateOf("") }
        var confirmPinInput by remember { mutableStateOf("") }
        var pinMatchError by remember { mutableStateOf(false) }

        AlertDialog(
            onDismissRequest = { showSetPinDialog = false },
            containerColor = AtikSurfaceVariant,
            title = {
                Text(
                    text = "Configure 4-Digit Master PIN",
                    color = AtikTextPrimary,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = "This PIN is used to unlock the app and authenticate sensitive actions if biometrics fail.",
                        color = AtikTextMuted,
                        fontSize = 11.5.sp
                    )

                    OutlinedTextField(
                        value = pinInput,
                        onValueChange = { if (it.length <= 4 && it.all { c -> c.isDigit() }) pinInput = it },
                        label = { Text("Enter 4-Digit PIN") },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = AtikNeonCyan,
                            unfocusedBorderColor = AtikBorder
                        ),
                        modifier = Modifier.fillMaxWidth().testTag("input_set_pin")
                    )

                    OutlinedTextField(
                        value = confirmPinInput,
                        onValueChange = { if (it.length <= 4 && it.all { c -> c.isDigit() }) confirmPinInput = it },
                        label = { Text("Confirm 4-Digit PIN") },
                        isError = pinMatchError,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = AtikNeonCyan,
                            unfocusedBorderColor = AtikBorder
                        ),
                        modifier = Modifier.fillMaxWidth().testTag("input_confirm_pin")
                    )

                    if (pinMatchError) {
                        Text("PINs do not match", color = Color(0xFFFF5252), fontSize = 11.sp)
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (pinInput.length == 4 && pinInput == confirmPinInput) {
                            onSetMasterPin(pinInput)
                            showSetPinDialog = false
                            Toast.makeText(context, "Master Security PIN Saved", Toast.LENGTH_SHORT).show()
                        } else {
                            pinMatchError = true
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = AtikElectricBlue),
                    modifier = Modifier.testTag("btn_confirm_pin_save")
                ) {
                    Text("Save PIN", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showSetPinDialog = false }) {
                    Text("Cancel", color = AtikTextMuted)
                }
            }
        )
    }

    // Export Backup Dialog
    if (showExportDialog) {
        AlertDialog(
            onDismissRequest = { showExportDialog = false },
            containerColor = AtikSurfaceVariant,
            title = {
                Text(
                    text = "Encrypted Vault Snapshot",
                    color = AtikTextPrimary,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = "Your data has been encrypted with AES-256 and signed with a SHA-256 integrity hash.",
                        color = AtikTextMuted,
                        fontSize = 11.5.sp
                    )

                    OutlinedTextField(
                        value = exportedVaultText,
                        onValueChange = {},
                        readOnly = true,
                        maxLines = 4,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = AtikNeonCyan,
                            unfocusedBorderColor = AtikBorder
                        ),
                        modifier = Modifier.fillMaxWidth().testTag("field_exported_vault")
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                        val clip = ClipData.newPlainText("Atik AI Encrypted Vault", exportedVaultText)
                        clipboard.setPrimaryClip(clip)
                        Toast.makeText(context, "Encrypted backup copied to clipboard", Toast.LENGTH_SHORT).show()
                        showExportDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = AtikElectricBlue),
                    modifier = Modifier.testTag("btn_copy_vault_payload")
                ) {
                    Text("Copy Vault Payload", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showExportDialog = false }) {
                    Text("Close", color = AtikTextMuted)
                }
            }
        )
    }

    // Restore Backup Dialog
    if (showRestoreDialog) {
        var restoreStatus by remember { mutableStateOf<String?>(null) }

        AlertDialog(
            onDismissRequest = { showRestoreDialog = false },
            containerColor = AtikSurfaceVariant,
            title = {
                Text(
                    text = "Restore Encrypted Vault",
                    color = AtikTextPrimary,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = "Paste your ATIK_VAULT_V1 encrypted package below to restore chats, memories, and routines.",
                        color = AtikTextMuted,
                        fontSize = 11.5.sp
                    )

                    OutlinedTextField(
                        value = restoreInputText,
                        onValueChange = { restoreInputText = it },
                        placeholder = { Text("Paste encrypted package...", fontSize = 11.sp, color = AtikTextMuted) },
                        maxLines = 4,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = AtikNeonCyan,
                            unfocusedBorderColor = AtikBorder
                        ),
                        modifier = Modifier.fillMaxWidth().testTag("field_restore_vault_input")
                    )

                    if (restoreStatus != null) {
                        Text(restoreStatus.orEmpty(), color = Color(0xFFFF5252), fontSize = 11.sp)
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val success = onRestoreEncryptedBackup(restoreInputText)
                        if (success) {
                            Toast.makeText(context, "Vault successfully restored!", Toast.LENGTH_SHORT).show()
                            showRestoreDialog = false
                        } else {
                            restoreStatus = "Invalid or corrupted vault signature."
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = AtikElectricBlue),
                    modifier = Modifier.testTag("btn_confirm_restore_vault")
                ) {
                    Text("Decrypt & Restore", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showRestoreDialog = false }) {
                    Text("Cancel", color = AtikTextMuted)
                }
            }
        )
    }

    // Wipe Confirmation Dialog
    if (showWipeConfirmDialog) {
        AlertDialog(
            onDismissRequest = { showWipeConfirmDialog = false },
            containerColor = AtikSurfaceVariant,
            title = {
                Text(
                    text = "Confirm Data Wipe",
                    color = Color(0xFFFF5252),
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold
                )
            },
            text = {
                Text(
                    text = "Are you sure you want to permanently erase all chat history, memory vectors, routines, and restore the application to fresh privacy state? This cannot be undone.",
                    color = AtikTextPrimary,
                    fontSize = 12.sp,
                    lineHeight = 16.sp
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        onClearAllLocalData()
                        showWipeConfirmDialog = false
                        Toast.makeText(context, "All local data has been securely cleared.", Toast.LENGTH_LONG).show()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFF5252)),
                    modifier = Modifier.testTag("btn_confirm_wipe_data")
                ) {
                    Text("Erase Everything", color = Color.White, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showWipeConfirmDialog = false }) {
                    Text("Cancel", color = AtikTextMuted)
                }
            }
        )
    }
}
