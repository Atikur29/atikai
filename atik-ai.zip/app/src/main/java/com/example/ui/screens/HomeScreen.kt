package com.example.ui.screens

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Campaign
import androidx.compose.material.icons.filled.ChatBubbleOutline
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.SportsEsports
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material.icons.filled.Translate
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material.icons.filled.CenterFocusStrong
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material.icons.filled.RecordVoiceOver
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.Sync
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.TextButton
import com.example.ui.theme.AppThemeMode
import com.example.ui.theme.DynamicThemeState
import com.example.ui.theme.ThemePreset
import com.example.ui.theme.AccentColorOption
import com.example.ui.theme.AppButtonStyle
import com.example.ui.theme.BackgroundWidgetType
import com.example.ui.components.DynamicBackgroundWidget
import com.example.ui.components.DynamicThemeStudioSheet
import com.example.ui.components.HomeQuickThemeBar
import com.example.ui.components.KungFuWarriorAvatar
import com.example.ui.components.KungFuStance
import com.example.ui.components.AvatarPosition
import com.example.ui.components.AvatarCustomizationDialog
import com.example.voice.VoiceGender
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import com.example.knowledge.TechKnowledgeEngine
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.example.data.ChatSessionEntity
import com.example.ui.components.AtikAvatar
import com.example.ui.theme.AtikBlack
import com.example.ui.theme.AtikBorder
import com.example.ui.theme.AtikElectricBlue
import com.example.ui.theme.AtikNeonAzure
import com.example.ui.theme.AtikNeonCyan
import com.example.ui.theme.AtikSurface
import com.example.ui.theme.AtikSurfaceHighlight
import com.example.ui.theme.AtikSurfaceVariant
import com.example.ui.theme.AtikTextMuted
import com.example.ui.theme.AtikTextPrimary
import com.example.ui.theme.AtikTextSecondary
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.cos
import kotlin.math.sin

data class AssistantCommand(
    val text: String,
    val description: String,
    val icon: androidx.compose.ui.graphics.vector.ImageVector,
    val prompt: String
)

@Composable
fun HomeScreen(
    recentSessions: List<ChatSessionEntity>,
    onStartChatClick: () -> Unit,
    onVoiceClick: () -> Unit,
    onLiveClick: () -> Unit,
    onCameraClick: () -> Unit,
    onOpenPythonLab: () -> Unit,
    onOpenTerminal: () -> Unit,
    onOpenSocialAI: (() -> Unit)? = null,
    onOpenTasksHub: (() -> Unit)? = null,
    onOpenGameStudio: (() -> Unit)? = null,
    onSelectSession: (String) -> Unit,
    onPromptClick: (String) -> Unit,
    userName: String = "Atikur Rahman",
    preferredTitle: String = "Atik Bhai",
    greetingStyle: String = "Time-Aware",
    themeMode: AppThemeMode = AppThemeMode.CYBERPUNK_DARK,
    voiceGender: VoiceGender = VoiceGender.DYNAMIC,
    voiceSpeed: Float = 1.0f,
    onOpenSettings: (() -> Unit)? = null,
    onUpdatePersonalProfile: ((name: String, title: String, style: String) -> Unit)? = null,
    onToggleTheme: ((AppThemeMode) -> Unit)? = null,
    avatarVisible: Boolean = true,
    avatarScale: Float = 1.0f,
    avatarPosition: AvatarPosition = AvatarPosition.CENTER_HERO,
    avatarGestureSpeed: Float = 1.0f,
    avatarStance: KungFuStance = KungFuStance.IDLE_GUARD,
    isSpeaking: Boolean = false,
    rmsDb: Float = 0f,
    actionBubbleText: String? = null,
    onStanceChange: ((KungFuStance) -> Unit)? = null,
    onSaveAvatarCustomization: ((visible: Boolean, scale: Float, position: AvatarPosition, speed: Float, stance: KungFuStance) -> Unit)? = null,
    isNetworkOnline: Boolean = true,
    connectionTypeName: String = "Wi-Fi Network",
    isSimulationOffline: Boolean = false,
    pendingOfflineCount: Int = 0,
    isSyncingData: Boolean = false,
    onSyncNow: (() -> Unit)? = null,
    dynamicThemeState: DynamicThemeState = DynamicThemeState(),
    onSelectThemePreset: ((ThemePreset) -> Unit)? = null,
    onSelectAccentColor: ((AccentColorOption) -> Unit)? = null,
    onSelectButtonStyle: ((AppButtonStyle) -> Unit)? = null,
    onSelectFontScale: ((Float) -> Unit)? = null,
    onSelectBackgroundWidget: ((BackgroundWidgetType) -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var showEditProfileDialog by remember { mutableStateOf(false) }
    var showAvatarCustomizationDialog by remember { mutableStateOf(false) }
    var showThemeStudioSheet by remember { mutableStateOf(false) }

    val cameraPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        onCameraClick()
    }

    val audioPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            onVoiceClick()
        }
    }

    val assistantCommands = listOf(
        AssistantCommand(
            text = "“আতিক, আমার জন্য একটা পরিকল্পনা তৈরি করো।”",
            description = "কাজের সময়সূচি ও লক্ষ্য নির্ধারণ",
            icon = Icons.Default.Speed,
            prompt = "আতিক, আমার জন্য একটি সময়োপযোগী পরিকল্পনা ও কাজের তালিকা তৈরি করো।"
        ),
        AssistantCommand(
            text = "“আতিক, এই ফাইলটা বিশ্লেষণ করো।”",
            description = "ডকুমেন্ট বা কোড ফাইল পরীক্ষা",
            icon = Icons.Default.AutoAwesome,
            prompt = "আতিক, আমার সংযুক্ত ফাইলটি বিস্তারিতভাবে বিশ্লেষণ করে গুরুত্বপূর্ণ তথ্যগুলো তুলে ধরো।"
        ),
        AssistantCommand(
            text = "“আতিক, Python code লিখে রান করো।”",
            description = "পাইথন স্ক্রিপ্ট তৈরি ও এক্সিকিউশন",
            icon = Icons.Default.Code,
            prompt = "আতিক, একটি কার্যকর পাইথন স্ক্রিপ্ট লেখো এবং স্যান্ডবক্সে রান করে আউটপুট বুঝিয়ে দাও।"
        ),
        AssistantCommand(
            text = "“আতিক, এই code-এর error ঠিক করো।”",
            description = "বাগ ফিক্সিং ও কোড অপ্টিমাইজেশন",
            icon = Icons.Default.Code,
            prompt = "আতিক, কোডের সিনট্যাক্স বা লজিক্যাল ভুলগুলো চিহ্নিত করে সম্পূর্ণ নির্ভুল সমাধান দাও।"
        ),
        AssistantCommand(
            text = "“আতিক, Terminal-এ এই command চালাও।”",
            description = "লিনাক্স/টার্মাক্স স্যান্ডবক্স কমান্ড",
            icon = Icons.Default.Terminal,
            prompt = "আতিক, লিনাক্স টার্মিনালের জন্য প্রয়োজনীয় কমান্ড ও এর ফলাফল বুঝিয়ে দাও।"
        ),
        AssistantCommand(
            text = "“আতিক, আমার আগের কথোপকথন থেকে এই বিষয়টা খুঁজে বের করো।”",
            description = "হিস্ট্রি ও মেমরি থেকে রিকল",
            icon = Icons.Default.Psychology,
            prompt = "আতিক, আমাদের পূর্ববর্তী আলোচনা এবং সংরক্ষিত মেমরি থেকে প্রাসঙ্গিক তথ্য খুঁজে বের করো।"
        ),
        AssistantCommand(
            text = "“আতিক, বাংলা থেকে প্রাতিষ্ঠানিক ইংরেজিতে অনুবাদ করো।”",
            description = "পেশাদার ও স্বাভাবিক দ্বিভাষিক অনুবাদ",
            icon = Icons.Default.Translate,
            prompt = "আতিক, নিচের বক্তব্যটি প্রাতিষ্ঠানিক, সাবলীল এবং আন্তর্জাতিক মানের ইংরেজিতে অনুবাদ করে দাও:"
        ),
        AssistantCommand(
            text = "“আতিক, জটিল বিষয় একদম সহজ ভাষায় বুঝিয়ে দাও।”",
            description = "ধারণাগত ব্যাখ্যা ও বাস্তব উদাহরণ",
            icon = Icons.Default.AutoAwesome,
            prompt = "আতিক, যেকোনো জটিল প্রযুক্তিগত বা বৈজ্ঞানিক বিষয় একদম সহজ ভাষায় বাস্তব উদাহরণের সাহায্যে বুঝিয়ে দাও।"
        )
    )

    Box(modifier = modifier.fillMaxSize()) {
        // Dynamic Ambient Background Widget (Step 25 Requirement 3)
        DynamicBackgroundWidget(themeState = dynamicThemeState)

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            contentPadding = PaddingValues(top = 12.dp, bottom = 96.dp)
        ) {
            // QUICK THEME CHANGER BAR (Step 25 Requirement 1 & 2)
            item {
                HomeQuickThemeBar(
                    themeState = dynamicThemeState,
                    onSelectPreset = { onSelectThemePreset?.invoke(it) },
                    onOpenStudio = { showThemeStudioSheet = true }
                )
            }

            // MAIN PERSONAL AI ASSISTANT EXPERIENCE CARD
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(
                        BorderStroke(
                            1.dp,
                            Brush.linearGradient(
                                listOf(AtikNeonCyan.copy(alpha = 0.6f), AtikElectricBlue.copy(alpha = 0.3f))
                            )
                        ),
                        RoundedCornerShape(24.dp)
                    )
                    .shadow(14.dp, RoundedCornerShape(24.dp), spotColor = AtikNeonCyan),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = AtikSurfaceVariant)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    // Top identity badge
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        AtikAvatar(size = 48.dp, isPulsing = true)

                        Row(
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            if (pendingOfflineCount > 0) {
                                Surface(
                                    onClick = { onSyncNow?.invoke() },
                                    shape = RoundedCornerShape(12.dp),
                                    color = Color(0xFF332305),
                                    border = BorderStroke(1.dp, Color(0xFFFFB300).copy(alpha = 0.6f)),
                                    modifier = Modifier.testTag("home_pending_sync_pill")
                                ) {
                                    Row(
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Icon(
                                            Icons.Default.Sync,
                                            contentDescription = "Pending Sync",
                                            tint = if (isSyncingData) AtikNeonCyan else Color(0xFFFFB300),
                                            modifier = Modifier.size(12.dp)
                                        )
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text(
                                            text = if (isSyncingData) "Syncing..." else "$pendingOfflineCount Queued",
                                            color = Color(0xFFFFE082),
                                            fontSize = 10.5.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }
                            }

                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = if (isNetworkOnline) AtikSurfaceHighlight else Color(0xFF261C02),
                                border = BorderStroke(1.dp, if (isNetworkOnline) AtikBorder else Color(0xFFFFB300).copy(alpha = 0.5f)),
                                modifier = Modifier.testTag("home_network_status_badge")
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(8.dp)
                                            .clip(CircleShape)
                                            .background(if (isNetworkOnline) AtikNeonCyan else Color(0xFFFFB300))
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = if (isNetworkOnline) "Online • $connectionTypeName" else if (isSimulationOffline) "Offline (Simulated)" else "Local AI (Offline)",
                                        color = if (isNetworkOnline) AtikNeonCyan else Color(0xFFFFE082),
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Dynamic Personal Welcome Greeting based on time of day and honorific
                    val (dynamicGreeting, dynamicSubtitle) = remember(preferredTitle, greetingStyle) {
                        val hour = java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY)
                        val (timeGreeting, timeEmoji) = when (hour) {
                            in 5..11 -> Pair("Good Morning", "☀️")
                            in 12..16 -> Pair("Good Afternoon", "🌤️")
                            in 17..20 -> Pair("Good Evening", "🌇")
                            else -> Pair("Late Night Focus", "🌙")
                        }

                        val greeting = when (greetingStyle) {
                            "Traditional Respectful" -> "Assalamu Alaikum, $preferredTitle 👋"
                            "Energetic High-Tech" -> "System Active, $preferredTitle ⚡"
                            else -> "$timeGreeting, $preferredTitle $timeEmoji"
                        }
                        Pair(greeting, "I am Atik AI, your Personal AI Assistant.")
                    }

                    Text(
                        text = dynamicGreeting,
                        color = AtikTextPrimary,
                        fontSize = 22.sp,
                        fontWeight = FontWeight.Bold,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.testTag("home_dynamic_greeting")
                    )

                    Spacer(modifier = Modifier.height(4.dp))

                    Text(
                        text = dynamicSubtitle,
                        color = AtikNeonAzure,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Medium,
                        textAlign = TextAlign.Center
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    // Quick Profile Controls (Step 10 Requirement 3)
                    Surface(
                        onClick = { showEditProfileDialog = true },
                        shape = RoundedCornerShape(20.dp),
                        color = AtikSurfaceHighlight,
                        border = BorderStroke(1.dp, AtikNeonCyan.copy(alpha = 0.5f)),
                        modifier = Modifier.testTag("home_quick_profile_chip")
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 14.dp, vertical = 7.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                Icons.Default.Person,
                                contentDescription = null,
                                tint = AtikNeonCyan,
                                modifier = Modifier.size(15.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "$userName • $preferredTitle",
                                color = AtikTextPrimary,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Icon(
                                Icons.Default.Tune,
                                contentDescription = "Edit Profile",
                                tint = AtikNeonAzure,
                                modifier = Modifier.size(13.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Quick Theme Mode Switcher (Step 10 Requirement 1)
                    if (onToggleTheme != null) {
                        Row(
                            modifier = Modifier.padding(horizontal = 4.dp),
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            AppThemeMode.values().forEach { mode ->
                                val isSelected = mode == themeMode
                                Surface(
                                    onClick = { onToggleTheme(mode) },
                                    shape = RoundedCornerShape(12.dp),
                                    color = if (isSelected) AtikSurfaceHighlight else AtikSurface,
                                    border = BorderStroke(
                                        1.dp,
                                        if (isSelected) AtikNeonCyan else AtikBorder
                                    ),
                                    modifier = Modifier.testTag("quick_theme_${mode.name}")
                                ) {
                                    Text(
                                        text = when (mode) {
                                            AppThemeMode.CYBERPUNK_DARK -> "Neon Dark"
                                            AppThemeMode.FUTURISTIC_LIGHT -> "Light Mode"
                                            AppThemeMode.SYSTEM_DEFAULT -> "System"
                                        },
                                        color = if (isSelected) AtikNeonCyan else AtikTextMuted,
                                        fontSize = 11.sp,
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                                    )
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Kung-Fu Warrior Animated Character Avatar (Step 11 Requirement 1 & 2)
                    if (avatarVisible && avatarPosition == AvatarPosition.CENTER_HERO) {
                        KungFuWarriorAvatar(
                            isSpeaking = isSpeaking,
                            rmsDb = rmsDb,
                            currentStance = avatarStance,
                            scaleFactor = avatarScale,
                            gestureSpeed = avatarGestureSpeed,
                            actionBubbleText = actionBubbleText,
                            onAvatarClick = {
                                onLiveClick()
                            },
                            onStanceChange = { stance ->
                                onStanceChange?.invoke(stance)
                            },
                            onOpenCustomization = {
                                showAvatarCustomizationDialog = true
                            }
                        )
                    } else if (avatarVisible && avatarPosition == AvatarPosition.FLOATING_OVERLAY) {
                        // Floating Buddy Mode active: compact notification badge on Home
                        Card(
                            onClick = { onLiveClick() },
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = AtikSurface),
                            border = BorderStroke(1.dp, AtikNeonCyan.copy(alpha = 0.5f)),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp)
                                .testTag("avatar_docked_buddy_card")
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Box(
                                        modifier = Modifier
                                            .size(42.dp)
                                            .clip(CircleShape)
                                            .border(1.5.dp, AtikNeonCyan, CircleShape),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(avatarStance.iconEmoji, fontSize = 20.sp)
                                    }
                                    Spacer(modifier = Modifier.width(10.dp))
                                    Column {
                                        Text(
                                            text = "Kung-Fu Warrior Buddy (Docked)",
                                            color = AtikTextPrimary,
                                            fontSize = 13.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                        Text(
                                            text = "Stance: ${avatarStance.displayName} • Tap to Activate Live",
                                            color = AtikNeonAzure,
                                            fontSize = 11.sp
                                        )
                                    }
                                }

                                IconButton(onClick = { showAvatarCustomizationDialog = true }) {
                                    Icon(Icons.Default.Tune, "Customize Avatar", tint = AtikNeonCyan)
                                }
                            }
                        }
                    } else {
                        // Minimized or hidden avatar fallback core
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 8.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            CentralAssistantCore(
                                onCoreClick = onLiveClick
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(20.dp))

                    // The 4 Main Interaction Buttons:
                    // 1. Text Chat Button
                    // 2. Microphone/Voice Button
                    // 3. Live Conversation Button
                    // 4. Camera/Video Button
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        // Text Chat Button
                        Button(
                            onClick = onStartChatClick,
                            modifier = Modifier
                                .weight(1f)
                                .height(50.dp)
                                .testTag("home_text_chat_button"),
                            shape = RoundedCornerShape(14.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = AtikElectricBlue,
                                contentColor = Color.White
                            )
                        ) {
                            Icon(Icons.Default.ChatBubbleOutline, null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Chat", fontSize = 14.sp, fontWeight = FontWeight.Bold)
                        }

                        // Microphone / Voice Button
                        Button(
                            onClick = {
                                val hasAudio = ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO)
                                if (hasAudio == PackageManager.PERMISSION_GRANTED) {
                                    onVoiceClick()
                                } else {
                                    audioPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                                }
                            },
                            modifier = Modifier
                                .weight(1f)
                                .height(50.dp)
                                .testTag("home_voice_button"),
                            shape = RoundedCornerShape(14.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = AtikSurfaceHighlight,
                                contentColor = AtikNeonCyan
                            ),
                            border = BorderStroke(1.dp, AtikBorder)
                        ) {
                            Icon(Icons.Default.Mic, null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Voice", fontSize = 14.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        // Live Conversation Button
                        Button(
                            onClick = onLiveClick,
                            modifier = Modifier
                                .weight(1.2f)
                                .height(50.dp)
                                .shadow(8.dp, RoundedCornerShape(14.dp), spotColor = AtikNeonCyan)
                                .testTag("home_live_button"),
                            shape = RoundedCornerShape(14.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = Color(0xFF0077C2),
                                contentColor = Color.White
                            )
                        ) {
                            Icon(Icons.Default.GraphicEq, null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Live Session", fontSize = 14.sp, fontWeight = FontWeight.Bold)
                        }

                        // Camera / Video Button
                        Button(
                            onClick = {
                                val hasCamera = ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA)
                                if (hasCamera == PackageManager.PERMISSION_GRANTED) {
                                    onCameraClick()
                                } else {
                                    cameraPermissionLauncher.launch(Manifest.permission.CAMERA)
                                }
                            },
                            modifier = Modifier
                                .weight(1f)
                                .height(50.dp)
                                .testTag("home_camera_button"),
                            shape = RoundedCornerShape(14.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = AtikSurfaceHighlight,
                                contentColor = Color(0xFF80D8FF)
                            ),
                            border = BorderStroke(1.dp, AtikBorder)
                        ) {
                            Icon(Icons.Default.CenterFocusStrong, null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Vision AI", fontSize = 14.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        // Quick Navigation Row: Python Lab, Terminal & Social AI Hub
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // Python Lab Card
                Card(
                    onClick = onOpenPythonLab,
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = AtikSurface),
                    border = BorderStroke(1.dp, AtikBorder)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(32.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(AtikSurfaceHighlight),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.Code, null, tint = AtikNeonCyan, modifier = Modifier.size(16.dp))
                        }
                        Spacer(modifier = Modifier.width(6.dp))
                        Column {
                            Text("Python", color = AtikTextPrimary, fontSize = 12.5.sp, fontWeight = FontWeight.Bold)
                            Text("Sandbox", color = AtikTextMuted, fontSize = 10.sp)
                        }
                    }
                }

                // Linux Terminal Card
                Card(
                    onClick = onOpenTerminal,
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = AtikSurface),
                    border = BorderStroke(1.dp, AtikBorder)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(32.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(Color(0xFF071B1E)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.Terminal, null, tint = Color(0xFF00E676), modifier = Modifier.size(16.dp))
                        }
                        Spacer(modifier = Modifier.width(6.dp))
                        Column {
                            Text("Terminal", color = AtikTextPrimary, fontSize = 12.5.sp, fontWeight = FontWeight.Bold)
                            Text("Termux", color = AtikTextMuted, fontSize = 10.sp)
                        }
                    }
                }

                // Social AI Hub Card
                if (onOpenSocialAI != null) {
                    Card(
                        onClick = onOpenSocialAI,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("home_social_ai_btn"),
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(containerColor = AtikSurface),
                        border = BorderStroke(1.dp, AtikBorder)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(32.dp)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(AtikElectricBlue.copy(alpha = 0.25f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(Icons.Default.Campaign, null, tint = AtikNeonCyan, modifier = Modifier.size(16.dp))
                            }
                            Spacer(modifier = Modifier.width(6.dp))
                            Column {
                                Text("Social AI", color = AtikTextPrimary, fontSize = 12.5.sp, fontWeight = FontWeight.Bold)
                                Text("Viral Hub", color = AtikTextMuted, fontSize = 10.sp)
                            }
                        }
                    }
                }
            }
        }

        // Smart Automations, Routines & Task Hub Card (Step 13)
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = AtikSurface),
                border = BorderStroke(1.dp, AtikNeonCyan.copy(alpha = 0.5f)),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("home_automation_hub_card")
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("⏰", fontSize = 20.sp)
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text(
                                    text = "Smart Automations & Routines",
                                    color = AtikTextPrimary,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "Daily executive briefings & prioritized task management",
                                    color = AtikTextMuted,
                                    fontSize = 11.sp
                                )
                            }
                        }

                        if (onOpenTasksHub != null) {
                            Button(
                                onClick = onOpenTasksHub,
                                shape = RoundedCornerShape(10.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = AtikElectricBlue),
                                modifier = Modifier.testTag("btn_open_tasks_hub")
                            ) {
                                Text("Open Hub", fontSize = 11.5.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Surface(
                            onClick = { onPromptClick("Run morning briefing") },
                            shape = RoundedCornerShape(10.dp),
                            color = AtikSurfaceHighlight,
                            border = BorderStroke(1.dp, AtikBorder),
                            modifier = Modifier.weight(1f)
                        ) {
                            Row(
                                modifier = Modifier.padding(8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("🌅", fontSize = 14.sp)
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Morning Briefing", color = AtikTextPrimary, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                            }
                        }

                        Surface(
                            onClick = { onPromptClick("Run evening summary") },
                            shape = RoundedCornerShape(10.dp),
                            color = AtikSurfaceHighlight,
                            border = BorderStroke(1.dp, AtikBorder),
                            modifier = Modifier.weight(1f)
                        ) {
                            Row(
                                modifier = Modifier.padding(8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("🌇", fontSize = 14.sp)
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Evening Summary", color = AtikTextPrimary, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                            }
                        }
                    }
                }
            }
        }

        // Personalized Action Recommendations (Step 10 Requirement 3)
        item {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            Icons.Default.AutoAwesome,
                            contentDescription = null,
                            tint = AtikNeonCyan,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Recommended Actions for $preferredTitle",
                            color = AtikTextPrimary,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    // Recommendation 1: Social Media Hub
                    if (onOpenSocialAI != null) {
                        PersonalizedActionCard(
                            title = "Smart Social Post",
                            subtitle = "Viral captions & timing",
                            icon = Icons.Default.Campaign,
                            badge = "Social AI",
                            accentColor = AtikNeonCyan,
                            onClick = onOpenSocialAI,
                            testTag = "recommendation_social_ai"
                        )
                    }

                    // Recommendation 2: Live Voice Session
                    PersonalizedActionCard(
                        title = "Kung-Fu Live Voice",
                        subtitle = "Real-time conversation",
                        icon = Icons.Default.GraphicEq,
                        badge = "Live AI",
                        accentColor = AtikElectricBlue,
                        onClick = onLiveClick,
                        testTag = "recommendation_live_voice"
                    )

                    // Recommendation 3: Vision Scanner
                    PersonalizedActionCard(
                        title = "Vision AI & OCR",
                        subtitle = "Object, QR & text scan",
                        icon = Icons.Default.CenterFocusStrong,
                        badge = "Scanner",
                        accentColor = Color(0xFF00E676),
                        onClick = onCameraClick,
                        testTag = "recommendation_vision"
                    )

                    // Recommendation 4: Python Lab
                    PersonalizedActionCard(
                        title = "Python Sandbox",
                        subtitle = "Run scripts offline",
                        icon = Icons.Default.Code,
                        badge = "Coding",
                        accentColor = Color(0xFFFFD54F),
                        onClick = onOpenPythonLab,
                        testTag = "recommendation_python"
                    )

                    // Recommendation 5: Linux Terminal
                    PersonalizedActionCard(
                        title = "Linux / Termux Lab",
                        subtitle = "Run terminal commands",
                        icon = Icons.Default.Terminal,
                        badge = "CLI Sandbox",
                        accentColor = Color(0xFFFF5252),
                        onClick = onOpenTerminal,
                        testTag = "recommendation_terminal"
                    )

                    // Recommendation 6: Game Studio & 2D Arcade (Step 26)
                    if (onOpenGameStudio != null) {
                        PersonalizedActionCard(
                            title = "AI 2D Games",
                            subtitle = "Ludo, Racer & Flappy",
                            icon = Icons.Default.SportsEsports,
                            badge = "HTML5 Canvas",
                            accentColor = Color(0xFFFF2A85),
                            onClick = onOpenGameStudio,
                            testTag = "recommendation_game_studio"
                        )
                    }
                }
            }
        }

        // Earning & Tech Academy Section with Quick Suggestion Chips
        item {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.School, contentDescription = null, tint = AtikNeonCyan, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "আর্নিং ও টেক একাডেমি (Guides Hub)",
                            color = AtikTextPrimary,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    TechKnowledgeEngine.QUICK_SUGGESTION_CHIPS.forEach { chip ->
                        Surface(
                            onClick = { onPromptClick(chip.prompt) },
                            shape = RoundedCornerShape(16.dp),
                            color = AtikSurfaceVariant,
                            border = BorderStroke(1.dp, AtikBorder),
                            modifier = Modifier.testTag("home_chip_${chip.id}")
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 13.dp, vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Text(chip.label, color = AtikTextPrimary, fontSize = 12.5.sp, fontWeight = FontWeight.SemiBold)
                                Icon(
                                    imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                                    contentDescription = null,
                                    tint = AtikNeonCyan,
                                    modifier = Modifier.size(12.dp)
                                )
                            }
                        }
                    }
                }
            }
        }

        // Assistant Commands Section Header
        item {
            Text(
                text = "ব্যক্তিগত কমান্ডসমূহ (Personal Commands)",
                color = AtikTextSecondary,
                fontSize = 14.sp,
                fontWeight = FontWeight.SemiBold,
                modifier = Modifier.padding(start = 4.dp, top = 4.dp)
            )
        }

        // Specific Required Assistant Commands
        items(assistantCommands) { cmd ->
            Card(
                onClick = { onPromptClick(cmd.prompt) },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("assistant_command_${cmd.text}"),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = AtikSurface),
                border = BorderStroke(1.dp, AtikBorder)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(38.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(AtikSurfaceHighlight),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = cmd.icon,
                            contentDescription = null,
                            tint = AtikNeonCyan,
                            modifier = Modifier.size(18.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(12.dp))

                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = cmd.text,
                            color = AtikTextPrimary,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = cmd.description,
                            color = AtikTextMuted,
                            fontSize = 11.sp
                        )
                    }

                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                        contentDescription = null,
                        tint = AtikTextMuted,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }
        }

        // Recent Sessions Section
        if (recentSessions.isNotEmpty()) {
            item {
                Text(
                    text = "সাম্প্রতিক চ্যাট (Recent Chats)",
                    color = AtikTextSecondary,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.padding(top = 8.dp, start = 4.dp)
                )
            }

            items(recentSessions.take(3)) { session ->
                val dateStr = SimpleDateFormat("dd MMM, hh:mm a", Locale.getDefault())
                    .format(Date(session.updatedAt))

                Card(
                    onClick = { onSelectSession(session.id) },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = AtikSurface),
                    border = BorderStroke(0.8.dp, AtikBorder)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.ChatBubbleOutline,
                            contentDescription = null,
                            tint = AtikNeonAzure,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = session.title,
                                color = AtikTextPrimary,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Medium,
                                maxLines = 1
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = dateStr,
                                color = AtikTextMuted,
                                fontSize = 11.sp
                            )
                        }
                    }
                }
            }
        }
    }

    // Quick Edit Profile Dialog (Step 10 Requirement 3)
    if (showEditProfileDialog) {
        var tempName by remember { mutableStateOf(userName) }
        var tempTitle by remember { mutableStateOf(preferredTitle) }
        var tempStyle by remember { mutableStateOf(greetingStyle) }

        AlertDialog(
            onDismissRequest = { showEditProfileDialog = false },
            containerColor = AtikSurfaceVariant,
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Person, null, tint = AtikNeonCyan, modifier = Modifier.size(22.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Personalize Profile", color = AtikTextPrimary, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                }
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Full Name", color = AtikTextSecondary, fontSize = 12.sp)
                    OutlinedTextField(
                        value = tempName,
                        onValueChange = { tempName = it },
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("dialog_profile_name"),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = AtikTextPrimary,
                            unfocusedTextColor = AtikTextPrimary,
                            focusedBorderColor = AtikNeonCyan,
                            unfocusedBorderColor = AtikBorder
                        )
                    )

                    Text("Calling Title / Honorific", color = AtikTextSecondary, fontSize = 12.sp)
                    OutlinedTextField(
                        value = tempTitle,
                        onValueChange = { tempTitle = it },
                        singleLine = true,
                        placeholder = { Text("e.g. Atik Bhai, Boss") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("dialog_profile_title"),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = AtikTextPrimary,
                            unfocusedTextColor = AtikTextPrimary,
                            focusedBorderColor = AtikNeonCyan,
                            unfocusedBorderColor = AtikBorder
                        )
                    )

                    Text("Dynamic Greeting Style", color = AtikTextSecondary, fontSize = 12.sp)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        listOf("Time-Aware", "Traditional Respectful", "Energetic High-Tech").forEach { style ->
                            val isSel = tempStyle == style
                            Surface(
                                onClick = { tempStyle = style },
                                shape = RoundedCornerShape(8.dp),
                                color = if (isSel) AtikSurfaceHighlight else AtikSurface,
                                border = BorderStroke(1.dp, if (isSel) AtikNeonCyan else AtikBorder),
                                modifier = Modifier.weight(1f)
                            ) {
                                Text(
                                    text = style,
                                    color = if (isSel) AtikNeonCyan else AtikTextMuted,
                                    fontSize = 10.5.sp,
                                    fontWeight = if (isSel) FontWeight.Bold else FontWeight.Normal,
                                    modifier = Modifier.padding(vertical = 6.dp, horizontal = 4.dp),
                                    textAlign = androidx.compose.ui.text.style.TextAlign.Center
                                )
                            }
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        onUpdatePersonalProfile?.invoke(tempName, tempTitle, tempStyle)
                        showEditProfileDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = AtikElectricBlue),
                    modifier = Modifier.testTag("dialog_profile_save_btn")
                ) {
                    Text("Save", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(
                    onClick = { showEditProfileDialog = false },
                    modifier = Modifier.testTag("dialog_profile_cancel_btn")
                ) {
                    Text("Cancel", color = AtikTextMuted)
                }
            }
        )
    }

    // Avatar Customization Dialog (Step 11 Requirement 3)
    if (showAvatarCustomizationDialog) {
        AvatarCustomizationDialog(
            isVisible = avatarVisible,
            scale = avatarScale,
            position = avatarPosition,
            gestureSpeed = avatarGestureSpeed,
            currentStance = avatarStance,
            onDismiss = { showAvatarCustomizationDialog = false },
            onSaveSettings = { visible, scale, position, speed, stance ->
                onSaveAvatarCustomization?.invoke(visible, scale, position, speed, stance)
            }
        )
    }

    // Dynamic Theme Studio Sheet (Step 25 Requirements 1, 2, 3)
    if (showThemeStudioSheet) {
        DynamicThemeStudioSheet(
            isVisible = showThemeStudioSheet,
            themeState = dynamicThemeState,
            onSelectPreset = { onSelectThemePreset?.invoke(it) },
            onSelectAccent = { onSelectAccentColor?.invoke(it) },
            onSelectButtonStyle = { onSelectButtonStyle?.invoke(it) },
            onSelectFontScale = { onSelectFontScale?.invoke(it) },
            onSelectBackgroundWidget = { onSelectBackgroundWidget?.invoke(it) },
            onDismiss = { showThemeStudioSheet = false }
        )
    }
}
}

/**
 * Large Central Animated AI Assistant Core Area.
 */
@Composable
fun CentralAssistantCore(
    onCoreClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "core_anim")
    val rotation by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 10000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "core_rotation"
    )

    val scale by infiniteTransition.animateFloat(
        initialValue = 0.96f,
        targetValue = 1.05f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 2000),
            repeatMode = RepeatMode.Reverse
        ),
        label = "core_scale"
    )

    Box(
        modifier = modifier
            .size(150.dp)
            .clickable { onCoreClick() },
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val center = Offset(size.width / 2f, size.height / 2f)
            val radius = (size.minDimension / 2.3f) * scale

            // Ambient background glow
            drawCircle(
                brush = Brush.radialGradient(
                    listOf(AtikNeonCyan.copy(alpha = 0.25f), Color.Transparent),
                    center = center,
                    radius = radius * 1.4f
                ),
                radius = radius * 1.4f,
                center = center
            )

            // Outer orbit ring
            drawArc(
                brush = Brush.sweepGradient(
                    listOf(AtikNeonCyan, AtikElectricBlue, AtikNeonAzure, AtikNeonCyan),
                    center = center
                ),
                startAngle = rotation,
                sweepAngle = 280f,
                useCenter = false,
                topLeft = Offset(center.x - radius, center.y - radius),
                size = androidx.compose.ui.geometry.Size(radius * 2, radius * 2),
                style = Stroke(width = 2.dp.toPx())
            )

            // Inner glowing sphere
            drawCircle(
                brush = Brush.radialGradient(
                    listOf(Color.White.copy(alpha = 0.8f), AtikElectricBlue, AtikBlack),
                    center = center,
                    radius = radius * 0.75f
                ),
                radius = radius * 0.75f,
                center = center
            )
        }

        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Icon(
                imageVector = Icons.Default.GraphicEq,
                contentDescription = null,
                tint = Color.White,
                modifier = Modifier.size(28.dp)
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = "Tap for Live",
                color = AtikNeonCyan,
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold
            )
        }
    }
}

/**
 * Personalized Action Recommendation Card for Home Dashboard.
 */
@Composable
fun PersonalizedActionCard(
    title: String,
    subtitle: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    badge: String,
    accentColor: Color,
    onClick: () -> Unit,
    testTag: String,
    modifier: Modifier = Modifier
) {
    Card(
        onClick = onClick,
        modifier = modifier
            .width(165.dp)
            .testTag(testTag),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = AtikSurface),
        border = BorderStroke(1.dp, AtikBorder)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(34.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(accentColor.copy(alpha = 0.2f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(icon, contentDescription = null, tint = accentColor, modifier = Modifier.size(18.dp))
                }

                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = AtikSurfaceHighlight
                ) {
                    Text(
                        text = badge,
                        color = accentColor,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            Text(
                text = title,
                color = AtikTextPrimary,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                maxLines = 1
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = subtitle,
                color = AtikTextMuted,
                fontSize = 10.5.sp,
                maxLines = 1
            )
        }
    }
}
