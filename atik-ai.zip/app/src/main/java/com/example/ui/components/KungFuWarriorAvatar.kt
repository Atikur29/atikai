package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.ui.theme.AtikBlack
import com.example.ui.theme.AtikBorder
import com.example.ui.theme.AtikElectricBlue
import com.example.ui.theme.AtikNeonAzure
import com.example.ui.theme.AtikNeonCyan
import com.example.ui.theme.AtikSuccess
import com.example.ui.theme.AtikSurface
import com.example.ui.theme.AtikSurfaceHighlight
import com.example.ui.theme.AtikSurfaceVariant
import com.example.ui.theme.AtikTextMuted
import com.example.ui.theme.AtikTextPrimary
import com.example.ui.theme.AtikTextSecondary
import kotlinx.coroutines.launch
import kotlin.math.cos
import kotlin.math.sin

/**
 * Martial Arts Kung-Fu Stance Enum for Atik AI Avatar.
 */
enum class KungFuStance(
    val id: String,
    val displayName: String,
    val description: String,
    val iconEmoji: String,
    val actionQuote: String
) {
    IDLE_GUARD(
        "idle_guard",
        "Idle Guard",
        "Steady breathing and vigilant defensive martial stance",
        "🥋",
        "Ready and vigilant, Boss! All systems active."
    ),
    DRAGON_STRIKE(
        "dragon_strike",
        "Dragon Strike",
        "Kinetic offensive surge with lightning ki energy",
        "⚡",
        "Dragon strike unleashed! Let's conquer this challenge!"
    ),
    DUAL_DAGGER_BATTLE(
        "dual_dagger",
        "Dual Daggers",
        "Unsheathed twin waist daggers with swift cutting arcs",
        "⚔️",
        "Twin waist churi drawn. Ready for surgical execution!"
    ),
    MEDITATION_FOCUS(
        "meditation",
        "Zen Focus",
        "Deep mental levitation and neural knowledge synthesis",
        "🧘",
        "Inner peace and razor focus. Generating high-precision results."
    ),
    MARTIAL_BOW(
        "martial_bow",
        "Kung-Fu Bow",
        "Traditional Chinese martial salute with folded palm and fist",
        "🙇",
        "Assalamu Alaikum Boss! At your service with full loyalty."
    )
}

/**
 * Avatar Position / Overlay Layout Options.
 */
enum class AvatarPosition(
    val id: String,
    val displayName: String,
    val description: String
) {
    CENTER_HERO("center_hero", "Center Stage", "Primary animated centerpiece on the Home dashboard"),
    FLOATING_OVERLAY("floating_overlay", "Floating Buddy", "Compact interactive overlay docked at bottom"),
    COMPACT_HEADER("compact_header", "Compact Top Header", "Minimalist badge in the top navigation bar")
}

/**
 * Interactive 2D/3D Kung-Fu Warrior Animated Character Module (Step 11).
 * Features:
 * - Breathing and dynamic posture sway.
 * - Martial energy aura canvas with rotating trigram geometry and ki particles.
 * - Dual waist churi (twin daggers) with gold & cyan metallic glints.
 * - Synchronized speech lip-sync & acoustic waveform resonance matching AI voice outputs.
 * - Interactive action poses (Idle Guard, Dragon Strike, Dual Dagger Battle, Zen Focus, Kung-Fu Bow).
 * - Full customization controls (Scale, Position, Gesture Speed, Visibility).
 */
@Composable
fun KungFuWarriorAvatar(
    modifier: Modifier = Modifier,
    isSpeaking: Boolean = false,
    rmsDb: Float = 0f,
    currentStance: KungFuStance = KungFuStance.IDLE_GUARD,
    scaleFactor: Float = 1.0f,
    gestureSpeed: Float = 1.0f,
    actionBubbleText: String? = null,
    onAvatarClick: () -> Unit = {},
    onStanceChange: (KungFuStance) -> Unit = {},
    onOpenCustomization: () -> Unit = {}
) {
    val coroutineScope = rememberCoroutineScope()
    val baseDuration = (1400 / gestureSpeed.coerceIn(0.5f, 2.0f)).toInt()

    // 1. Natural Breathing & Kinetic Sway Animation
    val infiniteTransition = rememberInfiniteTransition(label = "kungfu_warrior_anim")
    val breathingSway by infiniteTransition.animateFloat(
        initialValue = -3f,
        targetValue = 3f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = baseDuration, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "breathing_sway"
    )

    val breathingScale by infiniteTransition.animateFloat(
        initialValue = 0.97f,
        targetValue = 1.04f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = baseDuration, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "breathing_scale"
    )

    // 2. Ki Aura Rotation
    val auraRotation by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = (10000 / gestureSpeed.coerceIn(0.5f, 2.0f)).toInt(), easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "aura_rotation"
    )

    // 3. Stance-Specific Impact Burst
    val strikeOffset = remember { Animatable(0f) }
    LaunchedEffect(currentStance) {
        if (currentStance == KungFuStance.DRAGON_STRIKE) {
            strikeOffset.animateTo(-16f, tween(120, easing = FastOutSlowInEasing))
            strikeOffset.animateTo(0f, tween(260, easing = FastOutSlowInEasing))
        } else if (currentStance == KungFuStance.DUAL_DAGGER_BATTLE) {
            strikeOffset.animateTo(8f, tween(100))
            strikeOffset.animateTo(0f, tween(200))
        }
    }

    // 4. Audio-Synchronized Lip-Sync & Waveform Resonance
    // When isSpeaking is true, synthesize phonetic cadence between 8Hz and 14Hz modulated by rmsDb
    val speechPulse = remember { Animatable(1.0f) }
    LaunchedEffect(isSpeaking, rmsDb) {
        if (isSpeaking) {
            val targetPulse = 1.05f + (rmsDb.coerceIn(0f, 15f) / 50f)
            speechPulse.animateTo(targetPulse, tween(80))
            speechPulse.animateTo(0.98f, tween(90))
        } else {
            speechPulse.snapTo(1.0f)
        }
    }

    // Dynamic Sizing
    val baseAvatarSize: Dp = (140.dp * scaleFactor.coerceIn(0.7f, 1.4f))

    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = modifier
            .fillMaxWidth()
            .testTag("kungfu_warrior_avatar_container")
    ) {
        // Speech / Action Dialogue Bubble
        AnimatedVisibility(
            visible = actionBubbleText != null || isSpeaking,
            enter = fadeIn(),
            exit = fadeOut()
        ) {
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = AtikSurfaceHighlight,
                border = BorderStroke(1.dp, if (isSpeaking) AtikNeonCyan else AtikBorder),
                modifier = Modifier
                    .padding(bottom = 10.dp)
                    .testTag("avatar_action_bubble")
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (isSpeaking) {
                        Icon(
                            Icons.Default.GraphicEq,
                            contentDescription = "Voice Active",
                            tint = AtikNeonCyan,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                    } else {
                        Text(
                            text = currentStance.iconEmoji,
                            fontSize = 13.sp,
                            modifier = Modifier.padding(end = 6.dp)
                        )
                    }

                    Text(
                        text = actionBubbleText ?: "Atik AI Speaking…",
                        color = AtikTextPrimary,
                        fontSize = 12.5.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }
        }

        // Avatar Core with Canvas Aura & Dual Daggers
        Box(
            modifier = Modifier
                .size(baseAvatarSize * 1.35f)
                .clickable {
                    onAvatarClick()
                }
                .testTag("interactive_avatar_core"),
            contentAlignment = Alignment.Center
        ) {
            // Multi-Layered Martial Canvas Aura
            Canvas(modifier = Modifier.fillMaxSize()) {
                val center = Offset(size.width / 2f, size.height / 2f)
                val radius = (size.minDimension / 2.3f) * breathingScale

                // 1. Radial ambient Ki field
                val kiColor = when (currentStance) {
                    KungFuStance.IDLE_GUARD -> AtikNeonCyan
                    KungFuStance.DRAGON_STRIKE -> Color(0xFF00E5FF)
                    KungFuStance.DUAL_DAGGER_BATTLE -> Color(0xFFFFD700)
                    KungFuStance.MEDITATION_FOCUS -> Color(0xFF80D8FF)
                    KungFuStance.MARTIAL_BOW -> Color(0xFF69F0AE)
                }

                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(
                            kiColor.copy(alpha = if (isSpeaking) 0.50f else 0.28f),
                            AtikElectricBlue.copy(alpha = 0.15f),
                            Color.Transparent
                        ),
                        center = center,
                        radius = radius * 1.45f
                    ),
                    center = center,
                    radius = radius * 1.45f
                )

                // 2. Rotating Martial Bagua Orbit Ring
                drawArc(
                    brush = Brush.sweepGradient(
                        listOf(kiColor, AtikElectricBlue, Color(0xFFFFD700), kiColor),
                        center = center
                    ),
                    startAngle = auraRotation,
                    sweepAngle = 270f,
                    useCenter = false,
                    topLeft = Offset(center.x - radius, center.y - radius),
                    size = Size(radius * 2, radius * 2),
                    style = Stroke(width = (2.2.dp * scaleFactor).toPx())
                )

                // 3. Counter-rotating inner energy accents
                drawArc(
                    color = kiColor.copy(alpha = 0.4f),
                    startAngle = -auraRotation * 1.5f,
                    sweepAngle = 140f,
                    useCenter = false,
                    topLeft = Offset(center.x - radius * 0.85f, center.y - radius * 0.85f),
                    size = Size(radius * 1.7f, radius * 1.7f),
                    style = Stroke(width = 1.2.dp.toPx())
                )

                // 4. Synchronized Lip-Sync Resonance Rings when Speaking
                if (isSpeaking) {
                    val resonantRadius = radius * speechPulse.value
                    drawCircle(
                        color = AtikNeonCyan.copy(alpha = 0.6f),
                        center = center,
                        radius = resonantRadius,
                        style = Stroke(width = 2.dp.toPx())
                    )
                }
            }

            // Central Warrior Avatar Image with Martial Arts Sway
            Box(
                modifier = Modifier
                    .size(baseAvatarSize)
                    .offset(y = strikeOffset.value.dp)
                    .rotate(breathingSway)
                    .scale(breathingScale * speechPulse.value)
                    .shadow(16.dp, CircleShape, spotColor = AtikNeonCyan)
                    .clip(CircleShape)
                    .background(AtikBlack)
                    .border(
                        width = 3.dp,
                        brush = Brush.linearGradient(
                            listOf(
                                AtikNeonCyan,
                                AtikElectricBlue,
                                Color(0xFFFFD700),
                                AtikNeonCyan
                            )
                        ),
                        shape = CircleShape
                    ),
                contentAlignment = Alignment.Center
            ) {
                Image(
                    painter = painterResource(id = R.drawable.img_kungfu_warrior_avatar),
                    contentDescription = "Atik AI Kung-Fu Warrior Character",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )

                // Dual Daggers (Twin Waist Churi) Overlay Badges
                // Left Waist Dagger
                Box(
                    modifier = Modifier
                        .align(Alignment.BottomStart)
                        .padding(start = 12.dp, bottom = 8.dp)
                        .size(24.dp)
                        .clip(CircleShape)
                        .background(Color(0xFF0F172A).copy(alpha = 0.85f))
                        .border(1.dp, Color(0xFFFFD700), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Text("🗡️", fontSize = 11.sp)
                }

                // Right Waist Dagger
                Box(
                    modifier = Modifier
                        .align(Alignment.BottomEnd)
                        .padding(end = 12.dp, bottom = 8.dp)
                        .size(24.dp)
                        .clip(CircleShape)
                        .background(Color(0xFF0F172A).copy(alpha = 0.85f))
                        .border(1.dp, AtikNeonCyan, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Text("🗡️", fontSize = 11.sp)
                }
            }

            // Quick Customization Button docked at top-right
            IconButton(
                onClick = onOpenCustomization,
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .size(34.dp)
                    .clip(CircleShape)
                    .background(AtikSurfaceHighlight)
                    .border(1.dp, AtikBorder, CircleShape)
                    .testTag("avatar_customize_btn")
            ) {
                Icon(
                    Icons.Default.Tune,
                    contentDescription = "Avatar Customization",
                    tint = AtikNeonCyan,
                    modifier = Modifier.size(16.dp)
                )
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Martial Stance Selector Bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(horizontal = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            KungFuStance.values().forEach { stance ->
                val isSelected = stance == currentStance
                Surface(
                    onClick = { onStanceChange(stance) },
                    shape = RoundedCornerShape(12.dp),
                    color = if (isSelected) AtikSurfaceHighlight else AtikSurfaceVariant,
                    border = BorderStroke(1.dp, if (isSelected) AtikNeonCyan else AtikBorder),
                    modifier = Modifier.testTag("stance_chip_${stance.id}")
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = stance.iconEmoji,
                            fontSize = 13.sp,
                            modifier = Modifier.padding(end = 5.dp)
                        )
                        Text(
                            text = stance.displayName,
                            color = if (isSelected) AtikNeonCyan else AtikTextPrimary,
                            fontSize = 11.5.sp,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                        )
                    }
                }
            }
        }
    }
}

/**
 * Avatar Customization Modal Dialog (Step 11 Requirement 3).
 * Allows the user to toggle visibility, scale, position overlay, and gesture speed.
 */
@Composable
fun AvatarCustomizationDialog(
    isVisible: Boolean,
    scale: Float,
    position: AvatarPosition,
    gestureSpeed: Float,
    currentStance: KungFuStance,
    onDismiss: () -> Unit,
    onSaveSettings: (visible: Boolean, scale: Float, position: AvatarPosition, speed: Float, stance: KungFuStance) -> Unit
) {
    var editVisible by remember(isVisible) { mutableStateOf(isVisible) }
    var editScale by remember(scale) { mutableFloatStateOf(scale) }
    var editPosition by remember(position) { mutableStateOf(position) }
    var editSpeed by remember(gestureSpeed) { mutableFloatStateOf(gestureSpeed) }
    var editStance by remember(currentStance) { mutableStateOf(currentStance) }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = AtikSurfaceVariant,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("🥋", fontSize = 20.sp)
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    "Kung-Fu Avatar Engine",
                    color = AtikTextPrimary,
                    fontSize = 17.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // 1. Visibility Toggle
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Avatar Visibility", color = AtikTextPrimary, fontSize = 13.5.sp, fontWeight = FontWeight.SemiBold)
                        Text("Show warrior character on dashboard", color = AtikTextMuted, fontSize = 11.sp)
                    }
                    Switch(
                        checked = editVisible,
                        onCheckedChange = { editVisible = it },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = AtikNeonCyan,
                            checkedTrackColor = AtikElectricBlue
                        ),
                        modifier = Modifier.testTag("avatar_visibility_switch")
                    )
                }

                // 2. Avatar Scale Slider
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Avatar Scale", color = AtikTextSecondary, fontSize = 12.5.sp)
                        Text(
                            String.format(java.util.Locale.US, "%.1fx", editScale),
                            color = AtikNeonAzure,
                            fontSize = 12.5.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Slider(
                        value = editScale,
                        onValueChange = { editScale = it },
                        valueRange = 0.7f..1.4f,
                        colors = SliderDefaults.colors(
                            thumbColor = AtikNeonCyan,
                            activeTrackColor = AtikElectricBlue,
                            inactiveTrackColor = AtikBorder
                        ),
                        modifier = Modifier.testTag("avatar_scale_slider")
                    )
                }

                // 3. Gesture & Animation Speed Slider
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Martial Gesture Speed", color = AtikTextSecondary, fontSize = 12.5.sp)
                        Text(
                            String.format(java.util.Locale.US, "%.2fx", editSpeed),
                            color = AtikNeonAzure,
                            fontSize = 12.5.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Slider(
                        value = editSpeed,
                        onValueChange = { editSpeed = it },
                        valueRange = 0.5f..2.0f,
                        colors = SliderDefaults.colors(
                            thumbColor = AtikNeonCyan,
                            activeTrackColor = AtikElectricBlue,
                            inactiveTrackColor = AtikBorder
                        ),
                        modifier = Modifier.testTag("avatar_speed_slider")
                    )
                }

                // 4. Position & Layout Mode
                Column {
                    Text("Position & Docking Mode", color = AtikTextSecondary, fontSize = 12.sp)
                    Spacer(modifier = Modifier.height(6.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        AvatarPosition.values().forEach { pos ->
                            val isSel = editPosition == pos
                            Surface(
                                onClick = { editPosition = pos },
                                shape = RoundedCornerShape(10.dp),
                                color = if (isSel) AtikSurfaceHighlight else AtikSurface,
                                border = BorderStroke(1.dp, if (isSel) AtikNeonCyan else AtikBorder),
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("avatar_pos_${pos.id}")
                            ) {
                                Text(
                                    text = pos.displayName,
                                    color = if (isSel) AtikNeonCyan else AtikTextMuted,
                                    fontSize = 10.5.sp,
                                    fontWeight = if (isSel) FontWeight.Bold else FontWeight.Normal,
                                    modifier = Modifier.padding(vertical = 7.dp, horizontal = 4.dp),
                                    textAlign = TextAlign.Center
                                )
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    onSaveSettings(editVisible, editScale, editPosition, editSpeed, editStance)
                    onDismiss()
                },
                colors = ButtonDefaults.buttonColors(containerColor = AtikElectricBlue),
                modifier = Modifier.testTag("avatar_save_settings_btn")
            ) {
                Text("Save Settings", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(
                onClick = onDismiss,
                modifier = Modifier.testTag("avatar_cancel_settings_btn")
            ) {
                Text("Cancel", color = AtikTextMuted)
            }
        }
    )
}
