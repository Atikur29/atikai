package com.example.ui.screens

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.ImageProxy
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import com.example.voice.AudioCueType
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MicOff
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material.icons.filled.VideocamOff
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.Hearing
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Vibration
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.TextButton
import com.example.voice.WakeWordSensitivity
import com.example.voice.VoiceDuplexState
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import com.example.ai.LanguageMode
import com.example.ui.theme.AtikBlack
import com.example.ui.theme.AtikBorder
import com.example.ui.theme.AtikElectricBlue
import com.example.ui.theme.AtikNeonAzure
import com.example.ui.theme.AtikNeonCyan
import com.example.ui.theme.AtikSurface
import com.example.ui.theme.AtikSurfaceHighlight
import com.example.ui.theme.AtikSurfaceVariant
import com.example.ui.theme.AtikTextMuted
import com.example.ui.theme.AtikTextPrimary
import com.example.ui.theme.AtikTextSecondary
import java.nio.ByteBuffer
import kotlin.math.cos
import kotlin.math.sin

enum class LiveState {
    IDLE,
    LISTENING,
    THINKING,
    SPEAKING
}

@Composable
fun LiveAssistantScreen(
    isLiveActive: Boolean = false,
    isListening: Boolean,
    isSpeaking: Boolean,
    isThinking: Boolean,
    spokenText: String,
    lastAiReply: String,
    rmsDb: Float,
    languageMode: LanguageMode,
    onStartVoice: () -> Unit,
    onStopVoice: () -> Unit,
    onSendMessage: (String) -> Unit,
    onAnalyzeFrame: (Bitmap) -> Unit,
    onClose: () -> Unit,
    isWakeWordEnabled: Boolean = true,
    wakeWordSensitivity: WakeWordSensitivity = WakeWordSensitivity.MEDIUM,
    isHandsFreeDuplex: Boolean = true,
    isAudioChimeEnabled: Boolean = true,
    isHapticEnabled: Boolean = true,
    duplexState: VoiceDuplexState = VoiceDuplexState.STANDBY,
    onToggleWakeWord: ((Boolean) -> Unit)? = null,
    onSetSensitivity: ((WakeWordSensitivity) -> Unit)? = null,
    onToggleDuplex: ((Boolean) -> Unit)? = null,
    onToggleAudioChime: ((Boolean) -> Unit)? = null,
    onToggleHaptic: ((Boolean) -> Unit)? = null,
    onTestChime: (() -> Unit)? = null,
    onTestAudioCue: ((AudioCueType) -> Unit)? = null,
    onSetSensitivityByWeight: ((Float) -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current

    // Live state calculation
    val liveState = remember(isLiveActive, isListening, isThinking, isSpeaking) {
        when {
            isSpeaking -> LiveState.SPEAKING
            isThinking -> LiveState.THINKING
            isListening -> LiveState.LISTENING
            isLiveActive -> LiveState.LISTENING
            else -> LiveState.IDLE
        }
    }

    // Camera state
    var isCameraActive by remember { mutableStateOf(false) }
    var hasCameraPermission by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
        )
    }

    var showWakeWordDialog by remember { mutableStateOf(false) }
    var hasAudioPermission by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        )
    }

    var imageCapture: ImageCapture? by remember { mutableStateOf(null) }

    val cameraPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        hasCameraPermission = granted
        if (granted) {
            isCameraActive = true
        }
    }

    val audioPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        hasAudioPermission = granted
        if (granted) {
            onStartVoice()
        }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(AtikBlack)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 20.dp, vertical = 16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // Header Bar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .clip(CircleShape)
                            .background(
                                when (liveState) {
                                    LiveState.LISTENING -> AtikNeonCyan
                                    LiveState.THINKING -> Color(0xFFB388FF)
                                    LiveState.SPEAKING -> AtikElectricBlue
                                    LiveState.IDLE -> AtikTextMuted
                                }
                            )
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "LIVE ASSISTANT",
                        color = AtikTextPrimary,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    // Wake-Word & Duplex Settings
                    IconButton(
                        onClick = { showWakeWordDialog = true },
                        modifier = Modifier
                            .size(40.dp)
                            .clip(CircleShape)
                            .background(if (isWakeWordEnabled) AtikElectricBlue.copy(alpha = 0.35f) else AtikSurface)
                            .border(1.dp, if (isWakeWordEnabled) AtikNeonCyan else AtikBorder, CircleShape)
                            .testTag("btn_wake_word_settings")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Tune,
                            contentDescription = "Wake-Word & Duplex Settings",
                            tint = if (isWakeWordEnabled) AtikNeonCyan else AtikTextMuted,
                            modifier = Modifier.size(20.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(8.dp))

                    // Camera Toggle
                    IconButton(
                        onClick = {
                            if (!hasCameraPermission) {
                                cameraPermissionLauncher.launch(Manifest.permission.CAMERA)
                            } else {
                                isCameraActive = !isCameraActive
                            }
                        },
                        modifier = Modifier
                            .size(40.dp)
                            .clip(CircleShape)
                            .background(if (isCameraActive) AtikElectricBlue.copy(alpha = 0.3f) else AtikSurface)
                            .border(1.dp, if (isCameraActive) AtikNeonCyan else AtikBorder, CircleShape)
                    ) {
                        Icon(
                            imageVector = if (isCameraActive) Icons.Default.Videocam else Icons.Default.VideocamOff,
                            contentDescription = "Camera Toggle",
                            tint = if (isCameraActive) AtikNeonCyan else AtikTextMuted,
                            modifier = Modifier.size(20.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(8.dp))

                    // Close Button
                    IconButton(
                        onClick = onClose,
                        modifier = Modifier
                            .size(40.dp)
                            .clip(CircleShape)
                            .background(AtikSurface)
                            .border(1.dp, AtikBorder, CircleShape)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Close Live Assistant",
                            tint = AtikTextPrimary,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Microphone Permission Card or Wake-Word Active Pill
            if (!hasAudioPermission) {
                Card(
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = AtikSurfaceVariant),
                    border = BorderStroke(1.dp, Color(0xFFEF5350).copy(alpha = 0.6f)),
                    modifier = Modifier.fillMaxWidth().testTag("card_mic_permission_rationale")
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.MicOff, null, tint = Color(0xFFEF5350), modifier = Modifier.size(24.dp))
                        Spacer(modifier = Modifier.width(10.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Microphone Access Required",
                                color = AtikTextPrimary,
                                fontSize = 12.5.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "Hands-free 'Hey Atik' wake-word and duplex audio require microphone access.",
                                color = AtikTextSecondary,
                                fontSize = 11.sp
                            )
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Button(
                            onClick = { audioPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO) },
                            colors = ButtonDefaults.buttonColors(containerColor = AtikElectricBlue),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.height(32.dp).testTag("btn_grant_mic_permission")
                        ) {
                            Text("Grant", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            } else if (isWakeWordEnabled) {
                Surface(
                    shape = RoundedCornerShape(20.dp),
                    color = AtikSurfaceVariant.copy(alpha = 0.85f),
                    border = BorderStroke(0.8.dp, AtikNeonCyan.copy(alpha = 0.4f)),
                    modifier = Modifier.clickable { showWakeWordDialog = true }.testTag("pill_wake_word_status")
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(8.dp)
                                .clip(CircleShape)
                                .background(if (duplexState == VoiceDuplexState.WAKE_DETECTED) Color(0xFFFFD600) else AtikNeonCyan)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (duplexState == VoiceDuplexState.WAKE_DETECTED) {
                                "✨ Wake-Word Detected!"
                            } else {
                                "🎙️ Hands-Free: Say \"Hey Atik\" or \"Atik AI\""
                            },
                            color = if (duplexState == VoiceDuplexState.WAKE_DETECTED) Color(0xFFFFD600) else AtikNeonCyan,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
            }

            // Central Area: Camera Feed or Futuristic Animated AI Orb
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                contentAlignment = Alignment.Center
            ) {
                if (isCameraActive && hasCameraPermission) {
                    // Real CameraX Preview with viewfinder overlay
                    Column(
                        modifier = Modifier.fillMaxSize(),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth(0.9f)
                                .height(280.dp)
                                .clip(RoundedCornerShape(24.dp))
                                .border(1.5.dp, AtikNeonCyan, RoundedCornerShape(24.dp))
                                .shadow(16.dp, RoundedCornerShape(24.dp), spotColor = AtikNeonCyan)
                        ) {
                            AndroidView(
                                factory = { ctx ->
                                    val previewView = PreviewView(ctx)
                                    val cameraProviderFuture = ProcessCameraProvider.getInstance(ctx)
                                    cameraProviderFuture.addListener({
                                        val cameraProvider = cameraProviderFuture.get()
                                        val preview = Preview.Builder().build().also {
                                            it.setSurfaceProvider(previewView.surfaceProvider)
                                        }
                                        imageCapture = ImageCapture.Builder()
                                            .setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY)
                                            .build()

                                        val cameraSelector = CameraSelector.DEFAULT_BACK_CAMERA
                                        try {
                                            cameraProvider.unbindAll()
                                            cameraProvider.bindToLifecycle(
                                                lifecycleOwner,
                                                cameraSelector,
                                                preview,
                                                imageCapture
                                            )
                                        } catch (e: Exception) {
                                            // Handle camera binding error
                                        }
                                    }, ContextCompat.getMainExecutor(ctx))
                                    previewView
                                },
                                modifier = Modifier.fillMaxSize()
                            )

                            // Futuristic HUD Overlay
                            Box(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .padding(12.dp)
                            ) {
                                Text(
                                    text = "ATIK VISION 2.5",
                                    color = AtikNeonCyan,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.align(Alignment.TopStart)
                                )

                                Surface(
                                    color = AtikBlack.copy(alpha = 0.7f),
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier
                                        .align(Alignment.BottomCenter)
                                        .clickable {
                                            // Capture frame and send to Gemini Vision
                                            imageCapture?.let { cap ->
                                                cap.takePicture(
                                                    ContextCompat.getMainExecutor(context),
                                                    object : ImageCapture.OnImageCapturedCallback() {
                                                        override fun onCaptureSuccess(image: ImageProxy) {
                                                            val bitmap = imageProxyToBitmap(image)
                                                            image.close()
                                                            if (bitmap != null) {
                                                                onAnalyzeFrame(bitmap)
                                                            }
                                                        }
                                                        override fun onError(exception: ImageCaptureException) {
                                                            // error
                                                        }
                                                    }
                                                )
                                            }
                                        }
                                ) {
                                    Row(
                                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.AutoAwesome,
                                            contentDescription = null,
                                            tint = AtikNeonCyan,
                                            modifier = Modifier.size(16.dp)
                                        )
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(
                                            text = "Analyze Scene with Vision AI",
                                            color = Color.White,
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }
                            }
                        }
                    }
                } else {
                    // Original Futuristic Atik AI Animated Cybernetic Orb
                    AtikCyberneticOrb(
                        liveState = liveState,
                        rmsDb = rmsDb
                    )
                }
            }

            // Live State Indicator & Transcript Area
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 16.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // State Badge
                Surface(
                    color = when (liveState) {
                        LiveState.LISTENING -> AtikNeonCyan.copy(alpha = 0.15f)
                        LiveState.THINKING -> Color(0xFFB388FF).copy(alpha = 0.15f)
                        LiveState.SPEAKING -> AtikElectricBlue.copy(alpha = 0.2f)
                        LiveState.IDLE -> AtikSurfaceHighlight
                    },
                    shape = RoundedCornerShape(16.dp),
                    border = androidx.compose.foundation.BorderStroke(
                        1.dp,
                        when (liveState) {
                            LiveState.LISTENING -> AtikNeonCyan
                            LiveState.THINKING -> Color(0xFFB388FF)
                            LiveState.SPEAKING -> AtikElectricBlue
                            LiveState.IDLE -> AtikBorder
                        }
                    )
                ) {
                    Text(
                        text = when {
                            duplexState == VoiceDuplexState.WAKE_DETECTED -> "✨ Wake-Word Detected (\"Hey Atik\")"
                            duplexState == VoiceDuplexState.PROCESSING -> "⚡ Processing Audio Query..."
                            duplexState == VoiceDuplexState.CONTINUOUS_PROMPT -> "🔄 Continuous Duplex: Listening..."
                            liveState == LiveState.LISTENING -> "🎙️ Listening to your voice..."
                            liveState == LiveState.THINKING -> "🧠 Atik AI is thinking..."
                            liveState == LiveState.SPEAKING -> "🔊 Speaking response..."
                            isWakeWordEnabled -> "🎙️ Standby: Say \"Hey Atik\" or tap mic"
                            else -> "Tap microphone below to start speaking"
                        },
                        color = when (liveState) {
                            LiveState.LISTENING -> AtikNeonCyan
                            LiveState.THINKING -> Color(0xFFB388FF)
                            LiveState.SPEAKING -> AtikNeonAzure
                            LiveState.IDLE -> AtikTextMuted
                        },
                        fontSize = 12.5.sp,
                        fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
                    )
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Transcript Card
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = AtikSurface),
                    border = androidx.compose.foundation.BorderStroke(1.dp, AtikBorder)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp)
                    ) {
                        if (spokenText.isNotBlank()) {
                            Text(
                                text = "You:",
                                color = AtikNeonAzure,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = spokenText,
                                color = AtikTextPrimary,
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Medium
                            )
                        } else if (lastAiReply.isNotBlank()) {
                            Text(
                                text = "Atik AI:",
                                color = AtikNeonCyan,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = lastAiReply.take(160) + if (lastAiReply.length > 160) "..." else "",
                                color = AtikTextSecondary,
                                fontSize = 14.sp
                            )
                        } else {
                            Text(
                                text = "Say \"Hey Atik, what are my priority routines today?\" or tap the microphone button...",
                                color = AtikTextMuted,
                                fontSize = 12.5.sp,
                                textAlign = TextAlign.Center,
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                    }
                }
            }

            // Bottom Action Controls
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .navigationBarsPadding()
                    .padding(bottom = 12.dp),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Live Conversation Toggle Button
                val isLiveSessionActive = isLiveActive || isListening || isSpeaking || isThinking

                Button(
                    onClick = {
                        val recordPermission = ContextCompat.checkSelfPermission(
                            context,
                            Manifest.permission.RECORD_AUDIO
                        )
                        if (recordPermission != PackageManager.PERMISSION_GRANTED) {
                            audioPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                        } else {
                            if (isLiveSessionActive) {
                                onStopVoice()
                            } else {
                                onStartVoice()
                            }
                        }
                    },
                    modifier = Modifier
                        .height(60.dp)
                        .weight(1f)
                        .shadow(12.dp, RoundedCornerShape(20.dp), spotColor = if (isLiveSessionActive) Color.Red else AtikNeonCyan)
                        .testTag("live_mic_toggle_button"),
                    shape = RoundedCornerShape(20.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (isLiveSessionActive) Color(0xFFD32F2F) else AtikElectricBlue,
                        contentColor = Color.White
                    )
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = if (isLiveSessionActive) Icons.Default.Stop else Icons.Default.Mic,
                            contentDescription = null,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = if (isLiveSessionActive) "Stop Live" else "Start Live Conversation",
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }

        if (showWakeWordDialog) {
            WakeWordSettingsDialog(
                isWakeWordEnabled = isWakeWordEnabled,
                sensitivity = wakeWordSensitivity,
                isHandsFreeDuplex = isHandsFreeDuplex,
                isAudioChimeEnabled = isAudioChimeEnabled,
                isHapticEnabled = isHapticEnabled,
                rmsDb = rmsDb,
                onToggleWakeWord = { onToggleWakeWord?.invoke(it) },
                onSetSensitivity = { onSetSensitivity?.invoke(it) },
                onSetSensitivityByWeight = { onSetSensitivityByWeight?.invoke(it) },
                onToggleDuplex = { onToggleDuplex?.invoke(it) },
                onToggleAudioChime = { onToggleAudioChime?.invoke(it) },
                onToggleHaptic = { onToggleHaptic?.invoke(it) },
                onTestChime = { onTestChime?.invoke() },
                onTestAudioCue = { onTestAudioCue?.invoke(it) },
                onDismiss = { showWakeWordDialog = false }
            )
        }
    }
}

/**
 * High-tech animated cybernetic AI Orb for Atik AI.
 * Renders multiple glowing concentric particle rings, rotating orbs,
 * and audio-reactive waveforms.
 */
@Composable
fun AtikCyberneticOrb(
    liveState: LiveState,
    rmsDb: Float,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "orb_anim")

    val rotation by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 8000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "rotation"
    )

    val counterRotation by infiniteTransition.animateFloat(
        initialValue = 360f,
        targetValue = 0f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 6000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "counter_rotation"
    )

    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 0.95f,
        targetValue = 1.08f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1500),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse"
    )

    // Dynamic reactive scale based on live microphone dB
    val dynamicAudioPulse = remember(rmsDb, liveState) {
        if (liveState == LiveState.LISTENING) {
            1.0f + (rmsDb.coerceIn(0f, 15f) / 40f)
        } else if (liveState == LiveState.SPEAKING) {
            1.12f
        } else {
            1.0f
        }
    }

    Box(
        modifier = modifier
            .size(260.dp),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val center = Offset(size.width / 2f, size.height / 2f)
            val baseRadius = (size.minDimension / 2.6f) * pulseScale * dynamicAudioPulse

            // 1. Deep outer ambient glow
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        when (liveState) {
                            LiveState.LISTENING -> AtikNeonCyan.copy(alpha = 0.35f)
                            LiveState.THINKING -> Color(0xFFB388FF).copy(alpha = 0.35f)
                            LiveState.SPEAKING -> AtikElectricBlue.copy(alpha = 0.45f)
                            LiveState.IDLE -> AtikNeonCyan.copy(alpha = 0.15f)
                        },
                        Color.Transparent
                    ),
                    center = center,
                    radius = baseRadius * 1.5f
                ),
                radius = baseRadius * 1.5f,
                center = center
            )

            // 2. Outer Rotating Particle Ring
            val ringCount = 12
            for (idx in 0 until ringCount) {
                val angleRad = Math.toRadians((rotation + (idx * (360f / ringCount))).toDouble())
                val px = center.x + (baseRadius * 1.25f * cos(angleRad)).toFloat()
                val py = center.y + (baseRadius * 1.25f * sin(angleRad)).toFloat()

                drawCircle(
                    color = if (idx % 2 == 0) AtikNeonCyan else AtikNeonAzure,
                    radius = if (liveState == LiveState.LISTENING) 4.5f else 3f,
                    center = Offset(px, py)
                )
            }

            // 3. Counter-rotating segmented arc ring
            val sweepRad = Math.toRadians(counterRotation.toDouble())
            drawArc(
                brush = Brush.sweepGradient(
                    listOf(
                        AtikNeonCyan.copy(alpha = 0.1f),
                        AtikNeonAzure,
                        AtikElectricBlue,
                        AtikNeonCyan.copy(alpha = 0.1f)
                    ),
                    center = center
                ),
                startAngle = counterRotation,
                sweepAngle = 270f,
                useCenter = false,
                topLeft = Offset(center.x - baseRadius * 1.05f, center.y - baseRadius * 1.05f),
                size = androidx.compose.ui.geometry.Size(baseRadius * 2.1f, baseRadius * 2.1f),
                style = Stroke(width = 3.dp.toPx(), cap = StrokeCap.Round)
            )

            // 4. Inner Cybernetic Core Sphere
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        Color.White.copy(alpha = 0.9f),
                        when (liveState) {
                            LiveState.LISTENING -> AtikNeonCyan
                            LiveState.THINKING -> Color(0xFF7C4DFF)
                            LiveState.SPEAKING -> AtikElectricBlue
                            LiveState.IDLE -> AtikNeonAzure
                        },
                        AtikBlack
                    ),
                    center = center,
                    radius = baseRadius * 0.85f
                ),
                radius = baseRadius * 0.85f,
                center = center
            )

            // 5. Central Atik AI Crest Glow
            drawCircle(
                color = Color.White.copy(alpha = 0.35f),
                radius = baseRadius * 0.3f,
                center = center
            )
        }

        // Central Monogram in Core
        Text(
            text = "AI",
            color = Color.White,
            fontSize = 24.sp,
            fontWeight = FontWeight.ExtraBold,
            letterSpacing = 2.sp
        )
    }
}

private fun imageProxyToBitmap(image: ImageProxy): Bitmap? {
    val planeProxy = image.planes[0]
    val buffer: ByteBuffer = planeProxy.buffer
    val bytes = ByteArray(buffer.remaining())
    buffer.get(bytes)
    val bitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.size) ?: return null

    // Rotate if necessary
    val rotation = image.imageInfo.rotationDegrees
    return if (rotation != 0) {
        val matrix = Matrix().apply { postRotate(rotation.toFloat()) }
        Bitmap.createBitmap(bitmap, 0, 0, bitmap.width, bitmap.height, matrix, true)
    } else {
        bitmap
    }
}

@Composable
fun WakeWordSettingsDialog(
    isWakeWordEnabled: Boolean,
    sensitivity: WakeWordSensitivity,
    isHandsFreeDuplex: Boolean,
    isAudioChimeEnabled: Boolean,
    isHapticEnabled: Boolean,
    rmsDb: Float = 0f,
    onToggleWakeWord: (Boolean) -> Unit,
    onSetSensitivity: (WakeWordSensitivity) -> Unit,
    onSetSensitivityByWeight: ((Float) -> Unit)? = null,
    onToggleDuplex: (Boolean) -> Unit,
    onToggleAudioChime: (Boolean) -> Unit,
    onToggleHaptic: (Boolean) -> Unit,
    onTestChime: () -> Unit,
    onTestAudioCue: ((AudioCueType) -> Unit)? = null,
    onDismiss: () -> Unit
) {
    var sliderWeight by remember(sensitivity) { mutableStateOf(sensitivity.weight) }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = AtikSurfaceVariant,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Hearing, null, tint = AtikNeonCyan, modifier = Modifier.size(22.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Column {
                    Text(
                        text = "Voice Assistant & Wake-Word",
                        color = AtikTextPrimary,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Hands-free voice detection & duplex engine",
                        color = AtikTextSecondary,
                        fontSize = 11.sp
                    )
                }
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // Wake-word toggle row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Hands-Free Wake-Word", color = AtikTextPrimary, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                        Text("Listen for \"Hey Atik\" or \"Atik AI\"", color = AtikTextSecondary, fontSize = 11.sp)
                    }
                    Switch(
                        checked = isWakeWordEnabled,
                        onCheckedChange = onToggleWakeWord,
                        colors = SwitchDefaults.colors(checkedThumbColor = AtikNeonCyan, checkedTrackColor = AtikElectricBlue),
                        modifier = Modifier.testTag("switch_wake_word")
                    )
                }

                // Supported Phrases display
                Column {
                    Text("Trigger Phrases", color = AtikTextSecondary, fontSize = 11.sp, fontWeight = FontWeight.Medium)
                    Spacer(modifier = Modifier.height(4.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        listOf("Hey Atik", "Atik AI", "Hello Atik", "Ok Atik").forEach { phrase ->
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = AtikSurfaceHighlight,
                                border = BorderStroke(0.8.dp, AtikBorder)
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(Icons.Default.CheckCircle, null, tint = AtikNeonCyan, modifier = Modifier.size(11.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(phrase, color = AtikTextPrimary, fontSize = 10.5.sp, fontWeight = FontWeight.SemiBold)
                                }
                            }
                        }
                    }
                }

                // Real-Time Audio Level (RMS dB) Visualizer
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Microphone Audio Level", color = AtikTextPrimary, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        Text(
                            text = String.format(java.util.Locale.US, "%.1f dB", rmsDb.coerceAtLeast(0f)),
                            color = if (rmsDb > 5f) AtikNeonCyan else AtikTextMuted,
                            fontSize = 11.5.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(10.dp)
                            .clip(RoundedCornerShape(5.dp))
                            .background(AtikSurface)
                            .border(0.8.dp, AtikBorder, RoundedCornerShape(5.dp))
                    ) {
                        val progress = (rmsDb.coerceIn(0f, 15f) / 15f)
                        Box(
                            modifier = Modifier
                                .fillMaxWidth(progress)
                                .height(10.dp)
                                .clip(RoundedCornerShape(5.dp))
                                .background(
                                    Brush.horizontalGradient(
                                        listOf(AtikElectricBlue, AtikNeonAzure, AtikNeonCyan)
                                    )
                                )
                        )
                    }
                }

                // Sensitivity selector & Slider
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Wake Sensitivity", color = AtikTextPrimary, fontSize = 12.5.sp, fontWeight = FontWeight.Bold)
                        Text(
                            text = String.format(java.util.Locale.US, "%.2f (%s)", sliderWeight, sensitivity.displayName.split(" ").first()),
                            color = AtikNeonCyan,
                            fontSize = 11.5.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Spacer(modifier = Modifier.height(4.dp))

                    Slider(
                        value = sliderWeight,
                        onValueChange = { weight ->
                            sliderWeight = weight
                            onSetSensitivityByWeight?.invoke(weight)
                        },
                        valueRange = 0.15f..0.95f,
                        colors = SliderDefaults.colors(
                            thumbColor = AtikNeonCyan,
                            activeTrackColor = AtikElectricBlue,
                            inactiveTrackColor = AtikBorder
                        ),
                        modifier = Modifier.testTag("slider_wake_sensitivity")
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        WakeWordSensitivity.values().forEach { sens ->
                            val isSelected = sensitivity == sens
                            FilterChip(
                                selected = isSelected,
                                onClick = {
                                    sliderWeight = sens.weight
                                    onSetSensitivity(sens)
                                },
                                label = { Text(sens.name, fontSize = 10.5.sp) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = AtikElectricBlue.copy(alpha = 0.4f),
                                    selectedLabelColor = AtikNeonCyan
                                ),
                                border = BorderStroke(0.8.dp, if (isSelected) AtikNeonCyan else AtikBorder),
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                    Text(sensitivity.description, color = AtikTextMuted, fontSize = 10.5.sp, modifier = Modifier.padding(top = 4.dp))
                }

                // Continuous Duplex conversation toggle
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Continuous Duplex Conversation", color = AtikTextPrimary, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                        Text("Automatically re-opens mic after AI response completes for hands-free dialogue", color = AtikTextSecondary, fontSize = 11.sp)
                    }
                    Switch(
                        checked = isHandsFreeDuplex,
                        onCheckedChange = onToggleDuplex,
                        colors = SwitchDefaults.colors(checkedThumbColor = AtikNeonCyan, checkedTrackColor = AtikElectricBlue),
                        modifier = Modifier.testTag("switch_duplex_mode")
                    )
                }

                // Audio Chime & Cues toggle
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Discrete Audio Chimes", color = AtikTextPrimary, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                        Text("Tone sound cues for wake, processing, and success", color = AtikTextSecondary, fontSize = 11.sp)
                    }
                    Switch(
                        checked = isAudioChimeEnabled,
                        onCheckedChange = onToggleAudioChime,
                        colors = SwitchDefaults.colors(checkedThumbColor = AtikNeonCyan, checkedTrackColor = AtikElectricBlue),
                        modifier = Modifier.testTag("switch_audio_chimes")
                    )
                }

                // Haptic Feedback toggle
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Haptic Vibrations", color = AtikTextPrimary, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                        Text("Subtle tactile pulses on voice recognition & completion", color = AtikTextSecondary, fontSize = 11.sp)
                    }
                    Switch(
                        checked = isHapticEnabled,
                        onCheckedChange = onToggleHaptic,
                        colors = SwitchDefaults.colors(checkedThumbColor = AtikNeonCyan, checkedTrackColor = AtikElectricBlue),
                        modifier = Modifier.testTag("switch_haptic_feedback")
                    )
                }

                // Audio Cue Auditioning Palette
                Column {
                    Text("Audition Sound Chimes & Haptics", color = AtikTextPrimary, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Surface(
                            onClick = { onTestAudioCue?.invoke(AudioCueType.WAKE) ?: onTestChime() },
                            shape = RoundedCornerShape(8.dp),
                            color = AtikSurface,
                            border = BorderStroke(0.8.dp, AtikBorder),
                            modifier = Modifier.weight(1f).testTag("btn_test_cue_wake")
                        ) {
                            Text(
                                "Wake 🔔",
                                color = AtikNeonCyan,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                textAlign = TextAlign.Center,
                                modifier = Modifier.padding(vertical = 8.dp)
                            )
                        }
                        Surface(
                            onClick = { onTestAudioCue?.invoke(AudioCueType.PROCESSING) ?: onTestChime() },
                            shape = RoundedCornerShape(8.dp),
                            color = AtikSurface,
                            border = BorderStroke(0.8.dp, AtikBorder),
                            modifier = Modifier.weight(1f).testTag("btn_test_cue_processing")
                        ) {
                            Text(
                                "Process ⚡",
                                color = Color(0xFFB388FF),
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                textAlign = TextAlign.Center,
                                modifier = Modifier.padding(vertical = 8.dp)
                            )
                        }
                        Surface(
                            onClick = { onTestAudioCue?.invoke(AudioCueType.SUCCESS) ?: onTestChime() },
                            shape = RoundedCornerShape(8.dp),
                            color = AtikSurface,
                            border = BorderStroke(0.8.dp, AtikBorder),
                            modifier = Modifier.weight(1f).testTag("btn_test_cue_success")
                        ) {
                            Text(
                                "Success ✨",
                                color = Color(0xFF00E676),
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                textAlign = TextAlign.Center,
                                modifier = Modifier.padding(vertical = 8.dp)
                            )
                        }
                        Surface(
                            onClick = { onTestAudioCue?.invoke(AudioCueType.ERROR) ?: onTestChime() },
                            shape = RoundedCornerShape(8.dp),
                            color = AtikSurface,
                            border = BorderStroke(0.8.dp, AtikBorder),
                            modifier = Modifier.weight(1f).testTag("btn_test_cue_error")
                        ) {
                            Text(
                                "Alert ⚠️",
                                color = Color(0xFFFF5252),
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                textAlign = TextAlign.Center,
                                modifier = Modifier.padding(vertical = 8.dp)
                            )
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = onDismiss,
                colors = ButtonDefaults.buttonColors(containerColor = AtikElectricBlue)
            ) {
                Text("Done", fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }
        }
    )
}
