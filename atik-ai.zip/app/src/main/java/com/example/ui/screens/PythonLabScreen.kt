package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.python.PythonExecutionResult
import com.example.ui.theme.AtikBlack
import com.example.ui.theme.AtikBorder
import com.example.ui.theme.AtikElectricBlue
import com.example.ui.theme.AtikNeonAzure
import com.example.ui.theme.AtikNeonCyan
import com.example.ui.theme.AtikSurface
import com.example.ui.theme.AtikSurfaceHighlight
import com.example.ui.theme.AtikSurfaceVariant
import com.example.ui.theme.AtikTextMuted
import com.example.ui.theme.AtikTextPrimary
import com.example.ui.theme.AtikTextSecondary

data class PythonTemplate(
    val name: String,
    val description: String,
    val code: String
)

val DEFAULT_PYTHON_TEMPLATES = listOf(
    PythonTemplate(
        name = "Hello Atik AI",
        description = "Basic output & loops",
        code = """
# Welcome to Atik AI Python Lab
user_name = "Atikur Rahman"
print(f"Assalamu Alaikum {user_name} 👋")
print("Atik AI Secure Sandbox Engine is active!")

total = 0
for i in range(1, 6):
    total = total + i
    print(f"Step {i}: running sum = {total}")

print("Final calculated sum:", total)
        """.trimIndent()
    ),
    PythonTemplate(
        name = "Math & Calculations",
        description = "Formulas & numbers",
        code = """
# Mathematical operations in Atik Sandbox
import_pi = 3.14159265
radius = 7.5
area = import_pi * (radius * radius)
circumference = 2 * import_pi * radius

print("Circle Calculations:")
print("Radius:", radius)
print("Area:", round(area, 2))
print("Circumference:", round(circumference, 2))
        """.trimIndent()
    ),
    PythonTemplate(
        name = "Data Filter & List",
        description = "List operations",
        code = """
# Data Processing
scores = [85, 92, 78, 95, 88, 60, 99]
print("Scores:", scores)
print("Total tests:", len(scores))
print("Highest score:", max(scores))
print("Lowest score:", min(scores))
print("Average:", round(sum(scores) / len(scores), 2))
        """.trimIndent()
    ),
    PythonTemplate(
        name = "String Analysis",
        description = "Text processing",
        code = """
# Text analysis
text = "Atikur Rahman is building Atik AI personal platform"
words = text.split(" ")
print("Original Text:", text)
print("Word count:", len(words))
for w in words:
    print(f"- {w} ({len(w)} chars)")
        """.trimIndent()
    )
)

@Composable
fun PythonLabScreen(
    currentCode: String,
    executionResult: PythonExecutionResult?,
    isRunning: Boolean,
    onCodeChange: (String) -> Unit,
    onRunCode: () -> Unit,
    onClearOutput: () -> Unit,
    onAskAiToExplain: (String) -> Unit,
    onAskAiToFix: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val clipboardManager = LocalClipboardManager.current
    var showTemplatesDialog by remember { mutableStateOf(false) }
    var showSaveDialog by remember { mutableStateOf(false) }
    var scriptTitleToSave by remember { mutableStateOf("") }
    var savedScripts by remember {
        mutableStateOf(
            listOf(
                "Welcome Script" to DEFAULT_PYTHON_TEMPLATES[0].code,
                "Math Calculations" to DEFAULT_PYTHON_TEMPLATES[1].code
            )
        )
    }
    var copiedToClipboard by remember { mutableStateOf(false) }

    val scrollState = rememberScrollState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(AtikBlack)
            .verticalScroll(scrollState)
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Header with Sandbox Status Badge
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Code,
                        contentDescription = null,
                        tint = AtikNeonCyan,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "PYTHON LAB",
                        color = AtikTextPrimary,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 0.5.sp
                    )
                }
                Text(
                    text = "Secure Sandboxed Python 3.12 Engine",
                    color = AtikTextMuted,
                    fontSize = 12.sp
                )
            }

            Surface(
                color = AtikNeonCyan.copy(alpha = 0.12f),
                shape = RoundedCornerShape(10.dp),
                border = BorderStroke(1.dp, AtikNeonCyan.copy(alpha = 0.4f))
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Security,
                        contentDescription = null,
                        tint = AtikNeonCyan,
                        modifier = Modifier.size(13.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "Sandbox Isolated",
                        color = AtikNeonCyan,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }
        }

        // Toolbar: Templates, Save, Ask AI
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Load Template Button
            Surface(
                onClick = { showTemplatesDialog = true },
                shape = RoundedCornerShape(10.dp),
                color = AtikSurface,
                border = BorderStroke(1.dp, AtikBorder)
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.FolderOpen,
                        contentDescription = null,
                        tint = AtikNeonAzure,
                        modifier = Modifier.size(15.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Templates",
                        color = AtikTextPrimary,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium
                    )
                }
            }

            // Save Script Button
            Surface(
                onClick = { showSaveDialog = true },
                shape = RoundedCornerShape(10.dp),
                color = AtikSurface,
                border = BorderStroke(1.dp, AtikBorder)
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Save,
                        contentDescription = null,
                        tint = AtikNeonAzure,
                        modifier = Modifier.size(15.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Save Code",
                        color = AtikTextPrimary,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium
                    )
                }
            }

            // AI Coding Assistant: Fix Error
            Surface(
                onClick = { onAskAiToFix(currentCode) },
                shape = RoundedCornerShape(10.dp),
                color = AtikSurfaceHighlight,
                border = BorderStroke(1.dp, AtikElectricBlue)
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.AutoAwesome,
                        contentDescription = null,
                        tint = AtikNeonCyan,
                        modifier = Modifier.size(15.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "AI: Fix / Improve",
                        color = AtikNeonCyan,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }

            // AI Coding Assistant: Explain Code
            Surface(
                onClick = { onAskAiToExplain(currentCode) },
                shape = RoundedCornerShape(10.dp),
                color = AtikSurface,
                border = BorderStroke(1.dp, AtikBorder)
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "AI: Explain",
                        color = AtikTextSecondary,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium
                    )
                }
            }
        }

        // Code Editor Box
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = AtikSurface),
            border = BorderStroke(1.dp, AtikBorder)
        ) {
            Column(modifier = Modifier.fillMaxWidth()) {
                // Editor header bar
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(AtikSurfaceHighlight)
                        .padding(horizontal = 14.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(modifier = Modifier.size(8.dp).clip(CircleShape).background(Color(0xFFFF5F56)))
                        Spacer(modifier = Modifier.width(6.dp))
                        Box(modifier = Modifier.size(8.dp).clip(CircleShape).background(Color(0xFFFFBD2E)))
                        Spacer(modifier = Modifier.width(6.dp))
                        Box(modifier = Modifier.size(8.dp).clip(CircleShape).background(Color(0xFF27C93F)))
                        Spacer(modifier = Modifier.width(12.dp))
                        Text(
                            text = "main.py",
                            color = AtikTextSecondary,
                            fontFamily = FontFamily.Monospace,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }

                    Row {
                        IconButton(
                            onClick = {
                                clipboardManager.setText(AnnotatedString(currentCode))
                                copiedToClipboard = true
                            },
                            modifier = Modifier.size(28.dp)
                        ) {
                            Icon(
                                imageVector = if (copiedToClipboard) Icons.Default.Check else Icons.Default.ContentCopy,
                                contentDescription = "Copy code",
                                tint = if (copiedToClipboard) AtikNeonCyan else AtikTextMuted,
                                modifier = Modifier.size(15.dp)
                            )
                        }
                    }
                }

                // Code Input Area
                BasicTextField(
                    value = currentCode,
                    onValueChange = onCodeChange,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(240.dp)
                        .padding(14.dp)
                        .testTag("python_code_input"),
                    textStyle = TextStyle(
                        color = Color(0xFF80D8FF),
                        fontFamily = FontFamily.Monospace,
                        fontSize = 13.sp,
                        lineHeight = 20.sp
                    )
                )
            }
        }

        // Action Buttons: Run Code / Clear Output
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Button(
                onClick = onRunCode,
                enabled = !isRunning && currentCode.isNotBlank(),
                modifier = Modifier
                    .weight(1f)
                    .height(48.dp)
                    .shadow(8.dp, RoundedCornerShape(12.dp), spotColor = AtikNeonCyan)
                    .testTag("run_python_button"),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = AtikElectricBlue,
                    contentColor = Color.White
                )
            ) {
                if (isRunning) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(18.dp),
                        color = Color.White,
                        strokeWidth = 2.dp
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Running...", fontSize = 14.sp, fontWeight = FontWeight.Bold)
                } else {
                    Icon(
                        imageVector = Icons.Default.PlayArrow,
                        contentDescription = null,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Run Python", fontSize = 14.sp, fontWeight = FontWeight.Bold)
                }
            }

            if (executionResult != null) {
                Surface(
                    onClick = onClearOutput,
                    shape = RoundedCornerShape(12.dp),
                    color = AtikSurface,
                    border = BorderStroke(1.dp, AtikBorder),
                    modifier = Modifier.height(48.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Clear,
                            contentDescription = "Clear output",
                            tint = AtikTextMuted,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Clear",
                            color = AtikTextSecondary,
                            fontSize = 13.sp
                        )
                    }
                }
            }
        }

        // Output Console Section
        if (executionResult != null) {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("python_output_card"),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(
                    containerColor = if (executionResult.success) AtikSurfaceVariant else Color(0xFF261215)
                ),
                border = BorderStroke(
                    1.dp,
                    if (executionResult.success) AtikNeonCyan.copy(alpha = 0.5f) else Color(0xFFFF5252)
                )
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = if (executionResult.success) "OUTPUT (Console)" else "EXECUTION ERROR",
                            color = if (executionResult.success) AtikNeonCyan else Color(0xFFFF5252),
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )

                        Text(
                            text = "${executionResult.executionTimeMs}ms",
                            color = AtikTextMuted,
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    if (executionResult.success) {
                        Text(
                            text = executionResult.output,
                            color = Color(0xFFE0E0E0),
                            fontSize = 13.sp,
                            fontFamily = FontFamily.Monospace,
                            lineHeight = 19.sp
                        )
                    } else {
                        Text(
                            text = executionResult.error ?: "Unknown execution error",
                            color = Color(0xFFFF8A80),
                            fontSize = 13.sp,
                            fontFamily = FontFamily.Monospace,
                            lineHeight = 19.sp
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(30.dp))
    }

    // Templates Dialog
    if (showTemplatesDialog) {
        AlertDialog(
            onDismissRequest = { showTemplatesDialog = false },
            title = {
                Text(
                    text = "Load Python Template",
                    color = AtikTextPrimary,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold
                )
            },
            text = {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    DEFAULT_PYTHON_TEMPLATES.forEach { tpl ->
                        Card(
                            onClick = {
                                onCodeChange(tpl.code)
                                showTemplatesDialog = false
                            },
                            colors = CardDefaults.cardColors(containerColor = AtikSurface),
                            border = BorderStroke(1.dp, AtikBorder),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(10.dp)
                            ) {
                                Text(
                                    text = tpl.name,
                                    color = AtikNeonCyan,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = tpl.description,
                                    color = AtikTextMuted,
                                    fontSize = 11.sp
                                )
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showTemplatesDialog = false }) {
                    Text("Close", color = AtikNeonAzure)
                }
            },
            containerColor = AtikSurfaceVariant,
            shape = RoundedCornerShape(18.dp)
        )
    }

    // Save Dialog
    if (showSaveDialog) {
        AlertDialog(
            onDismissRequest = { showSaveDialog = false },
            title = {
                Text(
                    text = "Save Script",
                    color = AtikTextPrimary,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold
                )
            },
            text = {
                OutlinedTextField(
                    value = scriptTitleToSave,
                    onValueChange = { scriptTitleToSave = it },
                    placeholder = { Text("Script name (e.g. Data Analysis)") },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = AtikTextPrimary,
                        unfocusedTextColor = AtikTextPrimary,
                        focusedBorderColor = AtikNeonCyan,
                        unfocusedBorderColor = AtikBorder
                    ),
                    modifier = Modifier.fillMaxWidth()
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (scriptTitleToSave.isNotBlank()) {
                            savedScripts = savedScripts + (scriptTitleToSave to currentCode)
                            showSaveDialog = false
                            scriptTitleToSave = ""
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = AtikElectricBlue)
                ) {
                    Text("Save")
                }
            },
            dismissButton = {
                TextButton(onClick = { showSaveDialog = false }) {
                    Text("Cancel", color = AtikTextMuted)
                }
            },
            containerColor = AtikSurfaceVariant,
            shape = RoundedCornerShape(18.dp)
        )
    }
}
