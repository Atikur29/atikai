package com.example.ui.theme

/**
 * Result of parsing a theme modification voice or text command (Step 25 Requirement 1).
 */
sealed class ThemeCommandResult {
    abstract val feedbackMessage: String

    data class PresetChange(val preset: ThemePreset, override val feedbackMessage: String) : ThemeCommandResult()
    data class AccentChange(val colorOption: AccentColorOption, override val feedbackMessage: String) : ThemeCommandResult()
    data class ButtonStyleChange(val style: AppButtonStyle, override val feedbackMessage: String) : ThemeCommandResult()
    data class FontScaleChange(val scale: Float, override val feedbackMessage: String) : ThemeCommandResult()
    data class BackgroundWidgetChange(val widget: BackgroundWidgetType, override val feedbackMessage: String) : ThemeCommandResult()
}

/**
 * Voice & Natural Language Parser for Dynamic Theme Engine.
 */
object DynamicThemeVoiceParser {

    fun parseThemeCommand(input: String): ThemeCommandResult? {
        val trimmed = input.trim()
        val lower = trimmed.lowercase()

        // 1. Theme Presets Detection
        if (lower.contains("vintage") || lower.contains("80s") || lower.contains("synthwave") || lower.contains("ভিন্টেজ") || lower.contains("আশির দশক")) {
            return ThemeCommandResult.PresetChange(
                preset = ThemePreset.VINTAGE_80S,
                feedbackMessage = "🎨 Applied Vintage 80s Synthwave theme with retro neon magenta and sunset amber tones, Boss!"
            )
        }

        if (lower.contains("cyberpunk") || lower.contains("matrix") || lower.contains("সাইবারপাঙ্ক")) {
            return ThemeCommandResult.PresetChange(
                preset = ThemePreset.CYBERPUNK,
                feedbackMessage = "🦾 Activated Cyberpunk High-Contrast theme with electric yellow and radioactive teal highlights!"
            )
        }

        if (lower.contains("amoled") || lower.contains("pitch black") || lower.contains("pure dark") || lower.contains("অ্যামোলেড") || lower.contains("কালো থিম")) {
            return ThemeCommandResult.PresetChange(
                preset = ThemePreset.AMOLED_DARK,
                feedbackMessage = "🖤 Switched to pure AMOLED Pitch Black mode for maximum power savings and razor-sharp contrast!"
            )
        }

        if (lower.contains("futuristic") || lower.contains("neon") || lower.contains("নিয়ন") || lower.contains("ফিউচারিস্টিক")) {
            return ThemeCommandResult.PresetChange(
                preset = ThemePreset.FUTURISTIC_NEON,
                feedbackMessage = "⚡ Activated Futuristic Neon theme with deep cosmic navy and vibrant laser cyan radiance!"
            )
        }

        if (lower.contains("minimal light") || lower.contains("light theme") || lower.contains("day mode") || lower.contains("লাইট থিম") || lower.contains("সাদা থিম")) {
            return ThemeCommandResult.PresetChange(
                preset = ThemePreset.MINIMAL_LIGHT,
                feedbackMessage = "☀️ Switched to Minimal Light daylight mode with crisp porcelain surfaces and royal blue accents!"
            )
        }

        // 2. Accent Color Customization
        if (lower.contains("accent") || lower.contains("color") || lower.contains("কালার") || lower.contains("রং")) {
            PRESET_ACCENT_COLORS.forEach { option ->
                val optName = option.name.lowercase()
                val simpleName = optName.split(" ").last() // e.g. "cyan", "pink", "yellow", "green"
                if (lower.contains(simpleName) || (simpleName == "pink" && lower.contains("গোলাপী")) ||
                    (simpleName == "green" && lower.contains("সবুজ")) || (simpleName == "yellow" && lower.contains("হলুদ")) ||
                    (simpleName == "blue" && lower.contains("নীল")) || (simpleName == "white" && lower.contains("সাদা"))) {
                    return ThemeCommandResult.AccentChange(
                        colorOption = option,
                        feedbackMessage = "🎨 Accent color updated to ${option.name}, Boss!"
                    )
                }
            }
        }

        // 3. Button Style Customization
        if (lower.contains("button") || lower.contains("বাটন") || lower.contains("style") || lower.contains("স্টাইল")) {
            when {
                lower.contains("pill") || lower.contains("capsule") || lower.contains("পিল") -> {
                    return ThemeCommandResult.ButtonStyleChange(
                        style = AppButtonStyle.PILL_MODERN,
                        feedbackMessage = "🔘 Modern Pill button contours applied across all controls!"
                    )
                }
                lower.contains("neon") || lower.contains("glow") || lower.contains("rounded") || lower.contains("নিয়ন") -> {
                    return ThemeCommandResult.ButtonStyleChange(
                        style = AppButtonStyle.ROUNDED_NEON,
                        feedbackMessage = "✨ Rounded Neon button contours with glow borders activated!"
                    )
                }
                lower.contains("angular") || lower.contains("sharp") || lower.contains("cyber") || lower.contains("কোণা") -> {
                    return ThemeCommandResult.ButtonStyleChange(
                        style = AppButtonStyle.ANGULAR_TECH,
                        feedbackMessage = "📐 Cyber Angular technical button cutouts activated!"
                    )
                }
                lower.contains("glass") || lower.contains("outline") || lower.contains("কাঁচ") -> {
                    return ThemeCommandResult.ButtonStyleChange(
                        style = AppButtonStyle.OUTLINED_GLASS,
                        feedbackMessage = "🪟 Translucent Outlined Glass button styling activated!"
                    )
                }
            }
        }

        // 4. Font Scale Customization
        if (lower.contains("font") || lower.contains("text size") || lower.contains("ফন্ট") || lower.contains("লেখা")) {
            when {
                lower.contains("large") || lower.contains("big") || lower.contains("bigger") || lower.contains("বড়") || lower.contains("বড় করো") -> {
                    return ThemeCommandResult.FontScaleChange(
                        scale = 1.15f,
                        feedbackMessage = "🔍 Font scale increased to Large (1.15x) for enhanced legibility, Boss!"
                    )
                }
                lower.contains("extra large") || lower.contains("huge") || lower.contains("সবচেয়ে বড়") -> {
                    return ThemeCommandResult.FontScaleChange(
                        scale = 1.30f,
                        feedbackMessage = "🔍 Font scale increased to Extra Large (1.3x), Boss!"
                    )
                }
                lower.contains("small") || lower.contains("compact") || lower.contains("ছোট") -> {
                    return ThemeCommandResult.FontScaleChange(
                        scale = 0.85f,
                        feedbackMessage = "🔍 Font scale adjusted to Compact (0.85x), Boss!"
                    )
                }
                lower.contains("normal") || lower.contains("standard") || lower.contains("default") || lower.contains("স্বাভাবিক") -> {
                    return ThemeCommandResult.FontScaleChange(
                        scale = 1.0f,
                        feedbackMessage = "🔍 Font scale reset to Standard (1.0x), Boss!"
                    )
                }
            }
        }

        return null
    }
}
