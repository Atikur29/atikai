package com.example.ui.screens

import android.content.Context
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.BatteryChargingFull
import androidx.compose.material.icons.filled.Bluetooth
import androidx.compose.material.icons.filled.BugReport
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.FlashlightOff
import androidx.compose.material.icons.filled.FlashlightOn
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.OpenInNew
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.RocketLaunch
import androidx.compose.material.icons.filled.SdCard
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.device.BatteryInfo
import com.example.device.DeviceHardwareManager
import com.example.device.RamInfo
import com.example.device.StorageInfo
import com.example.device.SystemSpecs
import com.example.ui.theme.AtikBlack
import com.example.ui.theme.AtikBorder
import com.example.ui.theme.AtikElectricBlue
import com.example.ui.theme.AtikNeonAzure
import com.example.ui.theme.AtikNeonCyan
import com.example.ui.theme.AtikSurface
import com.example.ui.theme.AtikSurfaceHighlight
import com.example.ui.theme.AtikTextMuted
import com.example.ui.theme.AtikTextPrimary
import com.example.ui.theme.AtikTextSecondary
import com.example.translation.TranslationResult
import com.example.ui.components.TranslationStudioCard
import java.util.Locale

val SUPPORTED_LANGUAGES = listOf("Python", "Kotlin", "Java", "JavaScript", "HTML/CSS", "Bash/Linux")

@Composable
fun ToolsScreen(
    onSendToChat: (String) -> Unit,
    onSendToPythonLab: (String) -> Unit,
    onSendToTerminal: (String) -> Unit,
    onBoostPerformance: (() -> Unit)? = null,
    isTranslating: Boolean = false,
    lastTranslationResult: TranslationResult? = null,
    onTranslate: ((String, String, String) -> Unit)? = null,
    onPlayTranslatedAudio: ((String, Locale) -> Unit)? = null,
    onNavigateToSystemGallery: (() -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val hardwareManager = remember { DeviceHardwareManager.getInstance(context) }
    val isFlashlightOn by hardwareManager.isFlashlightOn.collectAsStateWithLifecycle()

    var refreshTrigger by remember { mutableIntStateOf(0) }
    var hardwareFeedback by remember { mutableStateOf<String?>(null) }

    // Live Telemetry
    val batteryInfo = remember(refreshTrigger) { hardwareManager.getBatteryInfo() }
    val storageInfo = remember(refreshTrigger) { hardwareManager.getStorageInfo() }
    val ramInfo = remember(refreshTrigger) { hardwareManager.getRamInfo() }
    val specs = remember(refreshTrigger) { hardwareManager.getSystemSpecs() }
    val isWifiOn = remember(refreshTrigger) { hardwareManager.isWifiEnabled() }
    val isBtOn = remember(refreshTrigger) { hardwareManager.isBluetoothEnabled() }

    var selectedLang by remember { mutableStateOf("Python") }
    var codeOrQueryInput by remember { mutableStateOf("") }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(AtikBlack)
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        contentPadding = PaddingValues(top = 16.dp, bottom = 96.dp)
    ) {
        // 1. Hardware Automation Controls & System Dashboard
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = AtikSurface),
                border = BorderStroke(1.2.dp, AtikNeonCyan.copy(alpha = 0.5f))
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    // Header
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Speed,
                                contentDescription = null,
                                tint = AtikNeonCyan,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Device Utility & Automation",
                                color = AtikTextPrimary,
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        IconButton(
                            onClick = {
                                refreshTrigger++
                                hardwareFeedback = "Diagnostics refreshed"
                            },
                            modifier = Modifier.size(32.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Refresh,
                                contentDescription = "Refresh Telemetry",
                                tint = AtikNeonAzure,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }

                    // Quick Hardware Action Toggles: Flashlight, WiFi, Bluetooth
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        // Flashlight Toggle
                        Surface(
                            onClick = {
                                hardwareManager.toggleFlashlight()
                                hardwareFeedback = if (!isFlashlightOn) "Flashlight turned ON" else "Flashlight turned OFF"
                            },
                            shape = RoundedCornerShape(12.dp),
                            color = if (isFlashlightOn) Color(0xFFFFD600).copy(alpha = 0.2f) else AtikSurfaceHighlight,
                            border = BorderStroke(1.2.dp, if (isFlashlightOn) Color(0xFFFFD600) else AtikBorder),
                            modifier = Modifier
                                .weight(1f)
                                .height(52.dp)
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 10.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.Center
                            ) {
                                Icon(
                                    imageVector = if (isFlashlightOn) Icons.Default.FlashlightOn else Icons.Default.FlashlightOff,
                                    contentDescription = "Flashlight",
                                    tint = if (isFlashlightOn) Color(0xFFFFD600) else AtikTextMuted,
                                    modifier = Modifier.size(20.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Column {
                                    Text("Flashlight", color = AtikTextPrimary, fontSize = 11.5.sp, fontWeight = FontWeight.Bold)
                                    Text(if (isFlashlightOn) "ON" else "OFF", color = if (isFlashlightOn) Color(0xFFFFD600) else AtikTextMuted, fontSize = 9.5.sp)
                                }
                            }
                        }

                        // Wi-Fi Quick Launcher
                        Surface(
                            onClick = {
                                val msg = hardwareManager.openWifiControls()
                                hardwareFeedback = msg
                            },
                            shape = RoundedCornerShape(12.dp),
                            color = AtikSurfaceHighlight,
                            border = BorderStroke(1.dp, if (isWifiOn) AtikNeonCyan else AtikBorder),
                            modifier = Modifier
                                .weight(1f)
                                .height(52.dp)
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 10.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Wifi,
                                    contentDescription = "Wi-Fi",
                                    tint = if (isWifiOn) AtikNeonCyan else AtikTextMuted,
                                    modifier = Modifier.size(20.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Column {
                                    Text("Wi-Fi", color = AtikTextPrimary, fontSize = 11.5.sp, fontWeight = FontWeight.Bold)
                                    Text(if (isWifiOn) "Active" else "Manage", color = if (isWifiOn) AtikNeonCyan else AtikTextMuted, fontSize = 9.5.sp)
                                }
                            }
                        }

                        // Bluetooth Quick Launcher
                        Surface(
                            onClick = {
                                val msg = hardwareManager.openBluetoothControls()
                                hardwareFeedback = msg
                            },
                            shape = RoundedCornerShape(12.dp),
                            color = AtikSurfaceHighlight,
                            border = BorderStroke(1.dp, if (isBtOn) Color(0xFF2979FF) else AtikBorder),
                            modifier = Modifier
                                .weight(1f)
                                .height(52.dp)
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 10.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Bluetooth,
                                    contentDescription = "Bluetooth",
                                    tint = if (isBtOn) Color(0xFF2979FF) else AtikTextMuted,
                                    modifier = Modifier.size(20.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Column {
                                    Text("Bluetooth", color = AtikTextPrimary, fontSize = 11.5.sp, fontWeight = FontWeight.Bold)
                                    Text(if (isBtOn) "Active" else "Manage", color = if (isBtOn) Color(0xFF2979FF) else AtikTextMuted, fontSize = 9.5.sp)
                                }
                            }
                        }
                    }

                    if (onNavigateToSystemGallery != null) {
                        Surface(
                            onClick = onNavigateToSystemGallery,
                            shape = RoundedCornerShape(10.dp),
                            color = AtikElectricBlue.copy(alpha = 0.2f),
                            border = BorderStroke(1.dp, AtikNeonCyan.copy(alpha = 0.6f)),
                            modifier = Modifier.fillMaxWidth().height(42.dp)
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 12.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text("✈️", fontSize = 16.sp)
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("Airplane Mode & AI Gallery Hub", color = AtikNeonCyan, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                }
                                Icon(Icons.Default.OpenInNew, null, tint = AtikNeonCyan, modifier = Modifier.size(15.dp))
                            }
                        }
                    }

                    if (hardwareFeedback != null) {
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = AtikNeonCyan.copy(alpha = 0.12f),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = hardwareFeedback.orEmpty(),
                                color = AtikNeonCyan,
                                fontSize = 11.sp,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                            )
                        }
                    }

                    // Telemetry Row: Battery, Storage, RAM
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        // Battery Tile
                        TelemetryCard(
                            title = "Battery",
                            value = "${batteryInfo.levelPct}%",
                            subtitle = batteryInfo.statusStr,
                            icon = Icons.Default.BatteryChargingFull,
                            color = if (batteryInfo.levelPct > 25) Color(0xFF00E676) else Color(0xFFFF5252),
                            fraction = batteryInfo.levelPct / 100f,
                            modifier = Modifier.weight(1f)
                        )

                        // RAM Memory Tile
                        TelemetryCard(
                            title = "RAM",
                            value = "${ramInfo.usedGb} GB",
                            subtitle = "of ${ramInfo.totalGb} GB",
                            icon = Icons.Default.Memory,
                            color = AtikNeonAzure,
                            fraction = ramInfo.usedPct / 100f,
                            modifier = Modifier.weight(1f)
                        )

                        // Storage Tile
                        TelemetryCard(
                            title = "Storage",
                            value = "${storageInfo.usedGb} GB",
                            subtitle = "${storageInfo.freeGb} GB free",
                            icon = Icons.Default.SdCard,
                            color = Color(0xFFFF9100),
                            fraction = storageInfo.usedPct / 100f,
                            modifier = Modifier.weight(1f)
                        )
                    }

                    // CPU & Device Specs
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = AtikSurfaceHighlight,
                        border = BorderStroke(0.8.dp, AtikBorder),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 12.dp, vertical = 8.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "${specs.manufacturer} ${specs.deviceModel} • ${specs.osVersion}",
                                color = AtikTextSecondary,
                                fontSize = 11.sp,
                                fontFamily = FontFamily.Monospace
                            )
                            Text(
                                text = "${specs.cpuCores} Cores (${specs.abi})",
                                color = AtikNeonCyan,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }

                    if (onBoostPerformance != null) {
                        Spacer(modifier = Modifier.height(10.dp))
                        Button(
                            onClick = { onBoostPerformance.invoke() },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(44.dp)
                                .testTag("btn_tools_boost_ram"),
                            shape = RoundedCornerShape(10.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = AtikElectricBlue,
                                contentColor = androidx.compose.ui.graphics.Color.White
                            )
                        ) {
                            Icon(Icons.Default.RocketLaunch, null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Boost RAM & Purge Cache", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        // Global Multi-Language Translation Studio (Step 17)
        item {
            TranslationStudioCard(
                isTranslating = isTranslating,
                lastResult = lastTranslationResult,
                onTranslate = { text, src, tgt -> onTranslate?.invoke(text, src, tgt) },
                onPlayAudio = { text, locale -> onPlayTranslatedAudio?.invoke(text, locale) },
                onSendToChat = onSendToChat
            )
        }

        // 2. AI Programming & Code Generation Studio
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = AtikSurface),
                border = BorderStroke(1.dp, AtikBorder)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Code,
                            contentDescription = null,
                            tint = AtikNeonAzure,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "AI Coding & Engineering Console",
                            color = AtikTextPrimary,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Language Selector Chips
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        SUPPORTED_LANGUAGES.forEach { lang ->
                            val isSelected = selectedLang == lang
                            FilterChip(
                                selected = isSelected,
                                onClick = { selectedLang = lang },
                                label = { Text(lang, fontSize = 12.sp) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = AtikElectricBlue,
                                    selectedLabelColor = Color.White,
                                    containerColor = AtikSurfaceHighlight,
                                    labelColor = AtikTextSecondary
                                ),
                                border = FilterChipDefaults.filterChipBorder(
                                    enabled = true,
                                    selected = isSelected,
                                    borderColor = AtikBorder,
                                    selectedBorderColor = AtikNeonCyan
                                )
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Code / Query Input
                    OutlinedTextField(
                        value = codeOrQueryInput,
                        onValueChange = { codeOrQueryInput = it },
                        placeholder = {
                            Text(
                                text = "Enter code requirement, bug trace, or snippet (e.g. 'Write a FastAPI async JWT authenticator')...",
                                color = AtikTextMuted,
                                fontSize = 12.5.sp
                            )
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(130.dp)
                            .testTag("tools_code_input"),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = AtikTextPrimary,
                            unfocusedTextColor = AtikTextPrimary,
                            focusedBorderColor = AtikNeonCyan,
                            unfocusedBorderColor = AtikBorder,
                            focusedContainerColor = AtikSurface,
                            unfocusedContainerColor = AtikSurface
                        ),
                        textStyle = androidx.compose.ui.text.TextStyle(
                            fontFamily = FontFamily.Monospace,
                            fontSize = 13.sp
                        )
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    // Quick AI Coding Actions
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = {
                                val prompt = "Please write clean, production-ready $selectedLang code for the following requirement with comprehensive line-by-line comments:\n\n$codeOrQueryInput"
                                onSendToChat(prompt)
                            },
                            enabled = codeOrQueryInput.isNotBlank(),
                            shape = RoundedCornerShape(10.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = AtikElectricBlue)
                        ) {
                            Icon(Icons.Default.AutoAwesome, null, modifier = Modifier.size(15.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Generate Code", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }

                        Button(
                            onClick = {
                                val prompt = "Analyze and fix all errors, performance bottlenecks, and security vulnerabilities in this $selectedLang code:\n\n```$selectedLang\n$codeOrQueryInput\n```"
                                onSendToChat(prompt)
                            },
                            enabled = codeOrQueryInput.isNotBlank(),
                            shape = RoundedCornerShape(10.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFC2185B))
                        ) {
                            Icon(Icons.Default.BugReport, null, modifier = Modifier.size(15.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Fix Bugs", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }

                        Surface(
                            onClick = {
                                val prompt = "Explain how this $selectedLang code works step-by-step with architecture flow:\n\n```$selectedLang\n$codeOrQueryInput\n```"
                                onSendToChat(prompt)
                            },
                            enabled = codeOrQueryInput.isNotBlank(),
                            shape = RoundedCornerShape(10.dp),
                            color = AtikSurfaceHighlight,
                            border = BorderStroke(1.dp, AtikBorder),
                            modifier = Modifier.height(38.dp)
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("Explain Code", color = AtikTextPrimary, fontSize = 12.sp)
                            }
                        }

                        Surface(
                            onClick = { onSendToPythonLab(codeOrQueryInput) },
                            enabled = codeOrQueryInput.isNotBlank(),
                            shape = RoundedCornerShape(10.dp),
                            color = AtikSurface,
                            border = BorderStroke(1.dp, AtikNeonCyan),
                            modifier = Modifier.height(38.dp)
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(Icons.Default.PlayArrow, null, tint = AtikNeonCyan, modifier = Modifier.size(15.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Open in IDE Studio", color = AtikNeonCyan, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }
                        }

                        if (selectedLang == "Bash/Linux") {
                            Surface(
                                onClick = { onSendToTerminal(codeOrQueryInput) },
                                enabled = codeOrQueryInput.isNotBlank(),
                                shape = RoundedCornerShape(10.dp),
                                color = AtikSurface,
                                border = BorderStroke(1.dp, Color(0xFF00E676)),
                                modifier = Modifier.height(38.dp)
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 12.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(Icons.Default.Terminal, null, tint = Color(0xFF00E676), modifier = Modifier.size(15.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Run in Terminal", color = Color(0xFF00E676), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            }
        }

        // 3. Quick Developer Blueprints & Prompts
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = AtikSurface),
                border = BorderStroke(1.dp, AtikBorder)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text(
                        text = "Engineering Prompts & Blueprints",
                        color = AtikTextPrimary,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold
                    )

                    val quickPrompts = listOf(
                        "Design an automated asynchronous Python web scraper with error retries",
                        "Build a scalable microservices architecture blueprint for mobile apps",
                        "Analyze device hardware status and suggest performance optimizations",
                        "Write a Kali Linux network security audit cheat sheet with Nmap commands",
                        "Show how to toggle flashlight and device connectivity via voice automation",
                        "Recall all past project decisions and technology stacks from memory"
                    )

                    quickPrompts.forEach { p ->
                        Surface(
                            onClick = { onSendToChat(p) },
                            shape = RoundedCornerShape(10.dp),
                            color = AtikSurfaceHighlight,
                            border = BorderStroke(0.8.dp, AtikBorder),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = "⚡ $p",
                                color = AtikNeonAzure,
                                fontSize = 12.5.sp,
                                fontWeight = FontWeight.Medium,
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun TelemetryCard(
    title: String,
    value: String,
    subtitle: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    color: Color,
    fraction: Float,
    modifier: Modifier = Modifier
) {
    Surface(
        shape = RoundedCornerShape(12.dp),
        color = AtikSurfaceHighlight,
        border = BorderStroke(1.dp, AtikBorder),
        modifier = modifier
    ) {
        Column(
            modifier = Modifier.padding(10.dp),
            verticalArrangement = Arrangement.Center
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = color,
                    modifier = Modifier.size(16.dp)
                )
                Text(
                    text = "${(fraction * 100).toInt()}%",
                    color = color,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            Spacer(modifier = Modifier.height(4.dp))
            Text(text = title, color = AtikTextMuted, fontSize = 10.sp)
            Text(text = value, color = AtikTextPrimary, fontSize = 12.sp, fontWeight = FontWeight.Bold, maxLines = 1)
            Text(text = subtitle, color = AtikTextMuted, fontSize = 9.sp, maxLines = 1)

            Spacer(modifier = Modifier.height(6.dp))
            LinearProgressIndicator(
                progress = { fraction.coerceIn(0f, 1f) },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(4.dp)
                    .clip(RoundedCornerShape(2.dp)),
                color = color,
                trackColor = color.copy(alpha = 0.2f),
                strokeCap = StrokeCap.Round
            )
        }
    }
}
