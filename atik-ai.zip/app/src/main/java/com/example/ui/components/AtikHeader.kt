package com.example.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ai.LanguageMode
import com.example.ui.theme.AtikBlack
import com.example.ui.theme.AtikBorder
import com.example.ui.theme.AtikElectricBlue
import com.example.ui.theme.AtikNeonAzure
import com.example.ui.theme.AtikNeonCyan
import com.example.ui.theme.AtikSuccess
import com.example.ui.theme.AtikSurface
import com.example.ui.theme.AtikSurfaceVariant
import com.example.ui.theme.AtikTextMuted
import com.example.ui.theme.AtikTextPrimary
import com.example.ui.theme.AtikTextSecondary

@Composable
fun AtikHeader(
    currentLanguage: LanguageMode = LanguageMode.ENGLISH,
    isGenerating: Boolean = false,
    isSpeaking: Boolean = false,
    onLanguageChange: ((LanguageMode) -> Unit)? = null,
    onNewChatClick: () -> Unit,
    onMenuClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier
            .fillMaxWidth()
            .border(
                BorderStroke(
                    0.6.dp,
                    Brush.verticalGradient(
                        listOf(Color.Transparent, AtikBorder.copy(alpha = 0.6f))
                    )
                )
            ),
        color = AtikBlack
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 10.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Left: Hamburger Menu Button + Title ("Atik AI - Personal Assistant")
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f)
            ) {
                IconButton(
                    onClick = onMenuClick,
                    modifier = Modifier
                        .size(38.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(AtikSurfaceVariant)
                        .border(BorderStroke(0.8.dp, AtikBorder), RoundedCornerShape(10.dp))
                        .testTag("nav_menu_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Menu,
                        contentDescription = "Open Navigation Menu",
                        tint = AtikNeonCyan,
                        modifier = Modifier.size(20.dp)
                    )
                }

                Spacer(modifier = Modifier.width(12.dp))

                Column {
                    // Header title: "Atik AI - Personal Assistant"
                    Text(
                        text = "Atik AI - Personal Assistant",
                        color = AtikTextPrimary,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.SemiBold,
                        letterSpacing = 0.2.sp,
                        maxLines = 1
                    )

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(top = 1.dp)
                    ) {
                        // Online glowing indicator dot
                        val statusDotColor by animateColorAsState(
                            targetValue = when {
                                isGenerating -> AtikNeonCyan
                                isSpeaking -> AtikNeonAzure
                                else -> AtikSuccess
                            },
                            animationSpec = tween(durationMillis = 300),
                            label = "status_dot_color"
                        )

                        Box(
                            modifier = Modifier
                                .size(6.dp)
                                .clip(CircleShape)
                                .background(statusDotColor)
                        )

                        Spacer(modifier = Modifier.width(5.dp))

                        val statusText = when {
                            isGenerating -> "Thinking..."
                            isSpeaking -> "Speaking..."
                            else -> "Smart Memory • Online"
                        }

                        Text(
                            text = statusText,
                            color = if (isGenerating || isSpeaking) AtikNeonAzure else AtikTextMuted,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Normal
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.width(8.dp))

            // Right: New Chat Button (Language toggle switch completely removed as requested)
            IconButton(
                onClick = onNewChatClick,
                modifier = Modifier
                    .size(36.dp)
                    .clip(CircleShape)
                    .background(
                        Brush.linearGradient(
                            listOf(AtikElectricBlue, Color(0xFF1D4ED8))
                        )
                    )
                    .testTag("header_new_chat_button")
            ) {
                Icon(
                    imageVector = Icons.Default.Add,
                    contentDescription = "New Chat",
                    tint = Color.White,
                    modifier = Modifier.size(18.dp)
                )
            }
        }
    }
}

/**
 * Modern segmented toggle button for "English" and "বাংলা"
 */
@Composable
fun LanguageSwitcherToggle(
    currentLanguage: LanguageMode,
    onLanguageChange: (LanguageMode) -> Unit,
    modifier: Modifier = Modifier
) {
    val isBangla = currentLanguage == LanguageMode.BANGLA

    Surface(
        shape = RoundedCornerShape(20.dp),
        color = AtikSurfaceVariant,
        border = BorderStroke(0.8.dp, AtikBorder),
        modifier = modifier.testTag("language_switcher_toggle")
    ) {
        Row(
            modifier = Modifier.padding(2.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // English Option
            val enBgColor by animateColorAsState(
                targetValue = if (!isBangla) AtikElectricBlue.copy(alpha = 0.9f) else Color.Transparent,
                animationSpec = tween(durationMillis = 200),
                label = "en_bg"
            )
            val enTextColor by animateColorAsState(
                targetValue = if (!isBangla) Color.White else AtikTextMuted,
                animationSpec = tween(durationMillis = 200),
                label = "en_text"
            )

            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(16.dp))
                    .background(enBgColor)
                    .clickable { onLanguageChange(LanguageMode.ENGLISH) }
                    .padding(horizontal = 9.dp, vertical = 5.dp)
                    .testTag("toggle_lang_english"),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "English",
                    color = enTextColor,
                    fontSize = 11.5.sp,
                    fontWeight = if (!isBangla) FontWeight.Bold else FontWeight.Medium
                )
            }

            // Bengali ("বাংলা") Option
            val bnBgColor by animateColorAsState(
                targetValue = if (isBangla) AtikElectricBlue.copy(alpha = 0.9f) else Color.Transparent,
                animationSpec = tween(durationMillis = 200),
                label = "bn_bg"
            )
            val bnTextColor by animateColorAsState(
                targetValue = if (isBangla) Color.White else AtikTextMuted,
                animationSpec = tween(durationMillis = 200),
                label = "bn_text"
            )

            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(16.dp))
                    .background(bnBgColor)
                    .clickable { onLanguageChange(LanguageMode.BANGLA) }
                    .padding(horizontal = 9.dp, vertical = 5.dp)
                    .testTag("toggle_lang_bangla"),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "বাংলা",
                    color = bnTextColor,
                    fontSize = 11.5.sp,
                    fontWeight = if (isBangla) FontWeight.Bold else FontWeight.Medium
                )
            }
        }
    }
}
