package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color

enum class AppThemeMode(val displayName: String, val description: String) {
  CYBERPUNK_DARK("Cyberpunk Neon Dark", "Deep obsidian blacks with electric cyan & neon blue accents"),
  FUTURISTIC_LIGHT("Futuristic Light", "Clean minimalist slate with vibrant high-tech blue highlights"),
  SYSTEM_DEFAULT("System Default", "Automatically match your device's display setting")
}

data class AtikCustomColors(
  val isDark: Boolean,
  val background: Color,
  val surface: Color,
  val surfaceVariant: Color,
  val surfaceHighlight: Color,
  val border: Color,
  val textPrimary: Color,
  val textSecondary: Color,
  val textMuted: Color,
  val accentCyan: Color,
  val accentBlue: Color
)

val LocalThemeColors = staticCompositionLocalOf {
  AtikCustomColors(
    isDark = true,
    background = AtikBlack,
    surface = AtikSurface,
    surfaceVariant = AtikSurfaceVariant,
    surfaceHighlight = AtikSurfaceHighlight,
    border = AtikBorder,
    textPrimary = AtikTextPrimary,
    textSecondary = AtikTextSecondary,
    textMuted = AtikTextMuted,
    accentCyan = AtikNeonCyan,
    accentBlue = AtikElectricBlue
  )
}

private val AtikDarkColorScheme = darkColorScheme(
  primary = AtikNeonAzure,
  onPrimary = AtikBlack,
  primaryContainer = AtikElectricBlue,
  onPrimaryContainer = AtikTextPrimary,
  secondary = AtikNeonCyan,
  onSecondary = AtikBlack,
  secondaryContainer = AtikSurfaceVariant,
  onSecondaryContainer = AtikNeonCyan,
  tertiary = AtikNeonCyan,
  onTertiary = AtikBlack,
  background = AtikBlack,
  onBackground = AtikTextPrimary,
  surface = AtikSurface,
  onSurface = AtikTextPrimary,
  surfaceVariant = AtikSurfaceVariant,
  onSurfaceVariant = AtikTextSecondary,
  outline = AtikBorder,
  error = AtikError
)

private val AtikLightColorScheme = lightColorScheme(
  primary = AtikLightElectricBlue,
  onPrimary = Color.White,
  primaryContainer = Color(0xFFBAE6FD),
  onPrimaryContainer = AtikLightTextPrimary,
  secondary = AtikLightNeonCyan,
  onSecondary = Color.White,
  secondaryContainer = AtikLightSurfaceVariant,
  onSecondaryContainer = AtikLightElectricBlue,
  tertiary = AtikLightNeonCyan,
  onTertiary = Color.White,
  background = AtikLightBackground,
  onBackground = AtikLightTextPrimary,
  surface = AtikLightSurface,
  onSurface = AtikLightTextPrimary,
  surfaceVariant = AtikLightSurfaceVariant,
  onSurfaceVariant = AtikLightTextSecondary,
  outline = AtikLightBorder,
  error = AtikError
)

@Composable
fun AtikAiTheme(
  dynamicThemeState: DynamicThemeState = DynamicThemeState(),
  themeMode: AppThemeMode = AppThemeMode.CYBERPUNK_DARK,
  content: @Composable () -> Unit
) {
  val customColors = dynamicThemeState.toCustomColors()
  val m3ColorScheme = dynamicThemeState.toM3ColorScheme()

  CompositionLocalProvider(LocalThemeColors provides customColors) {
    MaterialTheme(
      colorScheme = m3ColorScheme,
      typography = Typography,
      content = content
    )
  }
}
