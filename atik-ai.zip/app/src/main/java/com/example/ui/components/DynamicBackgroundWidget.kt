package com.example.ui.components

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import com.example.ui.theme.BackgroundWidgetType
import com.example.ui.theme.DynamicThemeState

/**
 * Dynamic Home-Screen Background Widget Engine (Step 25 Requirement 3).
 * Renders atmospheric reactive backgrounds according to the active theme preset.
 */
@Composable
fun DynamicBackgroundWidget(
    themeState: DynamicThemeState,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "theme_bg_anim")
    val pulse by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(4000, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse_anim"
    )

    val accent = themeState.accentColor
    val bg = themeState.preset.defaultBackground

    Box(modifier = modifier.fillMaxSize()) {
        when (themeState.backgroundWidget) {
            BackgroundWidgetType.NEON_MATRIX_GRID -> {
                Canvas(modifier = Modifier.fillMaxSize()) {
                    val w = size.width
                    val h = size.height
                    val horizonY = h * 0.45f

                    // Subtle top-down cyber gradient
                    drawRect(
                        brush = Brush.verticalGradient(
                            colors = listOf(
                                bg,
                                accent.copy(alpha = 0.08f),
                                bg
                            )
                        )
                    )

                    // Vertical grid perspective lines
                    val lineCount = 12
                    val gridColor = accent.copy(alpha = 0.12f + pulse * 0.06f)
                    for (i in 0..lineCount) {
                        val startX = (w / lineCount) * i
                        val bottomX = w * 0.5f + (startX - w * 0.5f) * 1.8f
                        drawLine(
                            color = gridColor,
                            start = Offset(startX, horizonY),
                            end = Offset(bottomX, h),
                            strokeWidth = 1.2f
                        )
                    }

                    // Horizontal perspective lines
                    var currentY = horizonY
                    var step = 8f
                    while (currentY < h) {
                        drawLine(
                            color = gridColor,
                            start = Offset(0f, currentY),
                            end = Offset(w, currentY),
                            strokeWidth = 1f
                        )
                        step *= 1.25f
                        currentY += step
                    }
                }
            }

            BackgroundWidgetType.SYNTHWAVE_SUNSET -> {
                Canvas(modifier = Modifier.fillMaxSize()) {
                    val w = size.width
                    val h = size.height
                    val sunCenter = Offset(w * 0.5f, h * 0.38f)
                    val sunRadius = w * 0.28f

                    // Dusk ambient radial glow
                    drawCircle(
                        brush = Brush.radialGradient(
                            colors = listOf(
                                Color(0xFFFF2A85).copy(alpha = 0.25f),
                                Color(0xFFFF8C00).copy(alpha = 0.12f),
                                Color.Transparent
                            ),
                            center = sunCenter,
                            radius = sunRadius * 1.6f
                        ),
                        center = sunCenter,
                        radius = sunRadius * 1.6f
                    )

                    // Retro Sun
                    drawCircle(
                        brush = Brush.verticalGradient(
                            colors = listOf(
                                Color(0xFFFFE600),
                                Color(0xFFFF2A85)
                            ),
                            startY = sunCenter.y - sunRadius,
                            endY = sunCenter.y + sunRadius
                        ),
                        center = sunCenter,
                        radius = sunRadius
                    )

                    // Horizon line
                    val horizonY = h * 0.42f
                    drawLine(
                        color = Color(0xFFFF2A85).copy(alpha = 0.5f),
                        start = Offset(0f, horizonY),
                        end = Offset(w, horizonY),
                        strokeWidth = 2.5f
                    )
                }
            }

            BackgroundWidgetType.CYBER_PULSE_ORB -> {
                Canvas(modifier = Modifier.fillMaxSize()) {
                    val w = size.width
                    val h = size.height
                    val orbCenter = Offset(w * 0.5f, h * 0.35f)
                    val radius = (w * 0.32f) * (0.92f + pulse * 0.12f)

                    drawCircle(
                        brush = Brush.radialGradient(
                            colors = listOf(
                                accent.copy(alpha = 0.35f),
                                themeState.preset.defaultAccentBlue.copy(alpha = 0.15f),
                                Color.Transparent
                            ),
                            center = orbCenter,
                            radius = radius * 1.5f
                        ),
                        center = orbCenter,
                        radius = radius * 1.5f
                    )
                }
            }

            BackgroundWidgetType.STARFIELD_CONSTELLATION -> {
                val starPositions = remember {
                    List(24) { i ->
                        Pair((i * 37 % 100) / 100f, (i * 53 % 100) / 100f)
                    }
                }
                Canvas(modifier = Modifier.fillMaxSize()) {
                    val w = size.width
                    val h = size.height

                    starPositions.forEachIndexed { idx, (normX, normY) ->
                        val alpha = ((pulse + idx * 0.1f) % 1f).coerceIn(0.2f, 0.9f)
                        drawCircle(
                            color = accent.copy(alpha = alpha),
                            radius = if (idx % 3 == 0) 2.5f else 1.5f,
                            center = Offset(normX * w, normY * h)
                        )
                    }
                }
            }

            BackgroundWidgetType.CLEAN_MINIMAL -> {
                Canvas(modifier = Modifier.fillMaxSize()) {
                    drawRect(
                        brush = Brush.verticalGradient(
                            colors = listOf(
                                bg,
                                accent.copy(alpha = 0.04f),
                                bg
                            )
                        )
                    )
                }
            }
        }
    }
}
