package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowLeft
import androidx.compose.material.icons.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlin.math.abs
import kotlin.random.Random

enum class SnakeDirection {
    UP, DOWN, LEFT, RIGHT
}

enum class TokenType(val symbol: String, val points: Int, val color: Color) {
    BUG("🐛", 10, Color(0xFF00E676)),
    TURBO("⚡", 20, Color(0xFFFFD600)),
    GEM("💎", 50, Color(0xFF00E5FF))
}

data class SnakePoint(val x: Int, val y: Int)

data class FoodToken(val point: SnakePoint, val type: TokenType)

@Composable
fun TerminalSnakeGame(
    modifier: Modifier = Modifier,
    onClose: (() -> Unit)? = null
) {
    val gridSize = 18

    var snake by remember {
        mutableStateOf(
            listOf(
                SnakePoint(gridSize / 2, gridSize / 2),
                SnakePoint(gridSize / 2, gridSize / 2 + 1),
                SnakePoint(gridSize / 2, gridSize / 2 + 2)
            )
        )
    }

    var direction by remember { mutableStateOf(SnakeDirection.UP) }
    var nextDirection by remember { mutableStateOf(SnakeDirection.UP) }

    fun generateFood(currentSnake: List<SnakePoint>): FoodToken {
        var pt: SnakePoint
        do {
            pt = SnakePoint(Random.nextInt(gridSize), Random.nextInt(gridSize))
        } while (currentSnake.contains(pt))

        val randomType = when (Random.nextInt(10)) {
            in 0..6 -> TokenType.BUG
            in 7..8 -> TokenType.TURBO
            else -> TokenType.GEM
        }
        return FoodToken(pt, randomType)
    }

    var food by remember { mutableStateOf(generateFood(snake)) }
    var score by remember { mutableIntStateOf(0) }
    var highScore by remember { mutableIntStateOf(0) }
    var isGameOver by remember { mutableStateOf(false) }
    var isPaused by remember { mutableStateOf(false) }

    fun resetGame() {
        snake = listOf(
            SnakePoint(gridSize / 2, gridSize / 2),
            SnakePoint(gridSize / 2, gridSize / 2 + 1),
            SnakePoint(gridSize / 2, gridSize / 2 + 2)
        )
        direction = SnakeDirection.UP
        nextDirection = SnakeDirection.UP
        food = generateFood(snake)
        score = 0
        isGameOver = false
        isPaused = false
    }

    // Game Loop
    LaunchedEffect(isGameOver, isPaused) {
        while (!isGameOver && !isPaused) {
            val speedDelay = (140 - (score / 30) * 10).coerceAtLeast(60).toLong()
            delay(speedDelay)

            direction = nextDirection
            val head = snake.first()
            val newHead = when (direction) {
                SnakeDirection.UP -> SnakePoint(head.x, head.y - 1)
                SnakeDirection.DOWN -> SnakePoint(head.x, head.y + 1)
                SnakeDirection.LEFT -> SnakePoint(head.x - 1, head.y)
                SnakeDirection.RIGHT -> SnakePoint(head.x + 1, head.y)
            }

            // Wall or self-collision
            if (newHead.x < 0 || newHead.x >= gridSize ||
                newHead.y < 0 || newHead.y >= gridSize ||
                snake.contains(newHead)
            ) {
                isGameOver = true
                if (score > highScore) {
                    highScore = score
                }
            } else {
                val newSnake = mutableListOf(newHead)
                if (newHead == food.point) {
                    score += food.type.points
                    if (score > highScore) {
                        highScore = score
                    }
                    newSnake.addAll(snake)
                    food = generateFood(newSnake)
                } else {
                    newSnake.addAll(snake.dropLast(1))
                }
                snake = newSnake
            }
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFF03070E))
            .padding(12.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Arcade Top Bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = "🐍 DEV SNAKE V2.0",
                    color = Color(0xFF00E676),
                    fontFamily = FontFamily.Monospace,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = Color(0xFF0D1424),
                    border = BorderStroke(0.8.dp, Color(0xFF1E2D4A))
                ) {
                    Text(
                        text = "SCORE: $score",
                        color = Color(0xFF80D8FF),
                        fontFamily = FontFamily.Monospace,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }

                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = Color(0xFF0D1424),
                    border = BorderStroke(0.8.dp, Color(0xFF1E2D4A))
                ) {
                    Text(
                        text = "BEST: $highScore",
                        color = Color(0xFFFFD600),
                        fontFamily = FontFamily.Monospace,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }

                IconButton(
                    onClick = { isPaused = !isPaused },
                    modifier = Modifier.size(32.dp)
                ) {
                    Icon(
                        imageVector = if (isPaused) Icons.Default.PlayArrow else Icons.Default.Pause,
                        contentDescription = "Pause",
                        tint = Color(0xFF00E5FF),
                        modifier = Modifier.size(18.dp)
                    )
                }

                IconButton(
                    onClick = { resetGame() },
                    modifier = Modifier.size(32.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Refresh,
                        contentDescription = "Reset Game",
                        tint = Color(0xFFFF5252),
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
        }

        // Game Board Card
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .aspectRatio(1f)
                .testTag("terminal_snake_canvas_card"),
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF050B16)),
            border = BorderStroke(1.2.dp, Color(0xFF00E676).copy(alpha = 0.4f))
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(8.dp)
                    .pointerInput(Unit) {
                        detectDragGestures { change, dragAmount ->
                            change.consume()
                            val (x, y) = dragAmount
                            if (abs(x) > abs(y)) {
                                if (x > 15 && direction != SnakeDirection.LEFT) nextDirection = SnakeDirection.RIGHT
                                else if (x < -15 && direction != SnakeDirection.RIGHT) nextDirection = SnakeDirection.LEFT
                            } else {
                                if (y > 15 && direction != SnakeDirection.UP) nextDirection = SnakeDirection.DOWN
                                else if (y < -15 && direction != SnakeDirection.DOWN) nextDirection = SnakeDirection.UP
                            }
                        }
                    },
                contentAlignment = Alignment.Center
            ) {
                Canvas(modifier = Modifier.fillMaxSize()) {
                    val cellWidth = size.width / gridSize
                    val cellHeight = size.height / gridSize

                    // Grid lines (retro CRT scan lines)
                    for (i in 0..gridSize) {
                        drawLine(
                            color = Color(0xFF0A1828),
                            start = Offset(i * cellWidth, 0f),
                            end = Offset(i * cellWidth, size.height),
                            strokeWidth = 0.5f
                        )
                        drawLine(
                            color = Color(0xFF0A1828),
                            start = Offset(0f, i * cellHeight),
                            end = Offset(size.width, i * cellHeight),
                            strokeWidth = 0.5f
                        )
                    }

                    // Food Token
                    val foodX = food.point.x * cellWidth
                    val foodY = food.point.y * cellHeight
                    drawRoundRect(
                        color = food.type.color,
                        topLeft = Offset(foodX + 2f, foodY + 2f),
                        size = Size(cellWidth - 4f, cellHeight - 4f),
                        cornerRadius = CornerRadius(4f, 4f)
                    )

                    // Snake Body
                    snake.forEachIndexed { index, point ->
                        val sx = point.x * cellWidth
                        val sy = point.y * cellHeight
                        val bodyColor = if (index == 0) {
                            Color(0xFF00E676) // Head neon green
                        } else {
                            Color(0xFF00B0FF).copy(alpha = (1f - (index.toFloat() / snake.size) * 0.4f).coerceAtLeast(0.5f))
                        }

                        drawRoundRect(
                            color = bodyColor,
                            topLeft = Offset(sx + 1.5f, sy + 1.5f),
                            size = Size(cellWidth - 3f, cellHeight - 3f),
                            cornerRadius = CornerRadius(if (index == 0) 6f else 3f, if (index == 0) 6f else 3f)
                        )
                    }
                }

                // Overlay for Game Over
                if (isGameOver) {
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = Color(0xEE03070E),
                        border = BorderStroke(1.5.dp, Color(0xFFFF5252)),
                        modifier = Modifier.padding(16.dp)
                    ) {
                        Column(
                            modifier = Modifier.padding(20.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Text(
                                text = "💥 RUNTIME EXCEPTION",
                                color = Color(0xFFFF5252),
                                fontFamily = FontFamily.Monospace,
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "Snake crashed! Final Score: $score",
                                color = Color.White,
                                fontFamily = FontFamily.Monospace,
                                fontSize = 13.sp
                            )
                            Button(
                                onClick = { resetGame() },
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF00E676)),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Text(
                                    text = "RESTART REPL",
                                    color = Color.Black,
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }

                if (isPaused && !isGameOver) {
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = Color(0xDD0D1424),
                        border = BorderStroke(1.dp, Color(0xFF00E5FF)),
                        modifier = Modifier.padding(12.dp)
                    ) {
                        Text(
                            text = "⏸️ PROCESS PAUSED",
                            color = Color(0xFF00E5FF),
                            fontFamily = FontFamily.Monospace,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // D-Pad Controller for tactile touch input
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.padding(bottom = 6.dp)
        ) {
            // UP
            Surface(
                onClick = { if (direction != SnakeDirection.DOWN) nextDirection = SnakeDirection.UP },
                shape = CircleShape,
                color = Color(0xFF0E1A30),
                border = BorderStroke(1.dp, Color(0xFF1E2D4A)),
                modifier = Modifier.size(46.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(Icons.Default.KeyboardArrowUp, null, tint = Color(0xFF80D8FF), modifier = Modifier.size(28.dp))
                }
            }

            Row(
                horizontalArrangement = Arrangement.spacedBy(36.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // LEFT
                Surface(
                    onClick = { if (direction != SnakeDirection.RIGHT) nextDirection = SnakeDirection.LEFT },
                    shape = CircleShape,
                    color = Color(0xFF0E1A30),
                    border = BorderStroke(1.dp, Color(0xFF1E2D4A)),
                    modifier = Modifier.size(46.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(Icons.Default.KeyboardArrowLeft, null, tint = Color(0xFF80D8FF), modifier = Modifier.size(28.dp))
                    }
                }

                // DOWN
                Surface(
                    onClick = { if (direction != SnakeDirection.UP) nextDirection = SnakeDirection.DOWN },
                    shape = CircleShape,
                    color = Color(0xFF0E1A30),
                    border = BorderStroke(1.dp, Color(0xFF1E2D4A)),
                    modifier = Modifier.size(46.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(Icons.Default.KeyboardArrowDown, null, tint = Color(0xFF80D8FF), modifier = Modifier.size(28.dp))
                    }
                }

                // RIGHT
                Surface(
                    onClick = { if (direction != SnakeDirection.LEFT) nextDirection = SnakeDirection.RIGHT },
                    shape = CircleShape,
                    color = Color(0xFF0E1A30),
                    border = BorderStroke(1.dp, Color(0xFF1E2D4A)),
                    modifier = Modifier.size(46.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(Icons.Default.KeyboardArrowRight, null, tint = Color(0xFF80D8FF), modifier = Modifier.size(28.dp))
                    }
                }
            }
        }
    }
}
