package com.example.ui.screens

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AttachFile
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Campaign
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.EditNote
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.PhotoCamera
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.VolumeUp
import com.example.knowledge.TechKnowledgeEngine
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.example.ai.LanguageMode
import com.example.data.ChatMessageEntity
import com.example.ui.components.AtikAvatar
import com.example.ui.components.AudioRecorderBar
import com.example.ui.components.GeneratedImageInlineCard
import com.example.ui.components.KungFuAvatarIdentity
import com.example.ui.components.MarkdownContent
import com.example.ui.theme.AtikAiBubble
import com.example.ui.theme.AtikBlack
import com.example.ui.theme.AtikBorder
import com.example.ui.theme.AtikElectricBlue
import com.example.ui.theme.AtikError
import com.example.ui.theme.AtikNeonAzure
import com.example.ui.theme.AtikNeonCyan
import com.example.ui.theme.AtikSuccess
import com.example.ui.theme.AtikSurface
import com.example.ui.theme.AtikSurfaceHighlight
import com.example.ui.theme.AtikSurfaceVariant
import com.example.ui.theme.AtikTextMuted
import com.example.ui.theme.AtikTextPrimary
import com.example.ui.theme.AtikTextSecondary
import com.example.ui.theme.AtikUserBubble
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun ChatScreen(
    messages: List<ChatMessageEntity>,
    isGenerating: Boolean,
    isListening: Boolean,
    spokenText: String,
    rmsDb: Float,
    currentlySpeakingId: String?,
    languageMode: LanguageMode,
    attachedImage: Bitmap?,
    attachedFileName: String?,
    bossActionPhrase: String? = null,
    streamingText: String? = null,
    onSendMessage: (String) -> Unit,
    onStartVoice: () -> Unit,
    onStopVoice: () -> Unit,
    onToggleSpeak: (String, String) -> Unit,
    onPickImage: (Uri, String) -> Unit,
    onClearAttachment: () -> Unit,
    onAvatarClick: (() -> Unit)? = null,
    onSaveGeneratedImage: ((imageUrl: String, prompt: String, onComplete: (Boolean, String) -> Unit) -> Unit)? = null,
    onRunInPythonLab: ((String) -> Unit)? = null,
    onNavigateToPythonLab: (() -> Unit)? = null,
    onNavigateToLive: (() -> Unit)? = null,
    onNavigateToMemory: (() -> Unit)? = null,
    onNavigateToTools: (() -> Unit)? = null,
    onNavigateToTechGuides: (() -> Unit)? = null,
    onNavigateToVision: (() -> Unit)? = null,
    onNavigateToSocial: (() -> Unit)? = null,
    onNavigateToGameStudio: (() -> Unit)? = null,
    onPlayGame: ((String) -> Unit)? = null,
    onOpenDrawer: (() -> Unit)? = null,
    onCaptureImage: ((Bitmap) -> Unit)? = null,
    isNetworkOnline: Boolean = true,
    connectionTypeName: String = "Wi-Fi Network",
    isSimulationOffline: Boolean = false,
    onToggleSimulationOffline: ((Boolean) -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var inputText by remember { mutableStateOf("") }
    var showActionSheet by remember { mutableStateOf(false) }
    val listState = rememberLazyListState()
    val isEnglish = languageMode == LanguageMode.ENGLISH

    // Smooth auto-scroll to bottom on new messages or as response streams in without lag
    LaunchedEffect(messages.size, isGenerating, streamingText?.length) {
        val count = messages.size + if (isGenerating) 1 else 0
        if (count > 0) {
            if (isGenerating && !streamingText.isNullOrBlank()) {
                listState.scrollToItem(count - 1)
            } else {
                listState.animateScrollToItem(count - 1)
            }
        }
    }

    // Microphone permission launcher
    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (isGranted) {
            onStartVoice()
        } else {
            Toast.makeText(
                context,
                if (isEnglish) "Microphone permission required." else "মাইক্রোফোন অনুমতি প্রয়োজন।",
                Toast.LENGTH_SHORT
            ).show()
        }
    }

    // Photo picker launcher
    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            val fileName = "img_${System.currentTimeMillis()}.jpg"
            onPickImage(uri, fileName)
            showActionSheet = false
        }
    }

    // Camera launcher
    val cameraLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.TakePicturePreview()
    ) { bitmap ->
        if (bitmap != null) {
            onCaptureImage?.invoke(bitmap)
            showActionSheet = false
        }
    }

    val cameraPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            cameraLauncher.launch(null)
        } else {
            Toast.makeText(
                context,
                if (isEnglish) "Camera permission required." else "ক্যামেরা অনুমতি প্রয়োজন।",
                Toast.LENGTH_SHORT
            ).show()
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(AtikBlack)
            .imePadding()
    ) {
        // Network Connectivity & Offline Fallback Status Indicator Banner (Step 12 Requirement 3)
        NetworkStatusBanner(
            isOnline = isNetworkOnline,
            connectionTypeName = connectionTypeName,
            isSimulation = isSimulationOffline,
            onToggleSimulation = onToggleSimulationOffline
        )

        // Message scroll area or Empty State
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
        ) {
            if (messages.isEmpty() && !isGenerating) {
                // Top center of the clean chat screen: Chinese Kung-Fu warrior avatar graphic as Atik AI's identity
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 24.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center,
                        modifier = Modifier.padding(bottom = 20.dp)
                    ) {
                        KungFuAvatarIdentity(
                            size = 104.dp,
                            isPulsing = isListening,
                            onAvatarClick = onAvatarClick
                        )

                        Spacer(modifier = Modifier.height(18.dp))

                        Text(
                            text = "What's on your mind today?",
                            color = AtikTextSecondary,
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Normal,
                            textAlign = TextAlign.Center,
                            letterSpacing = 0.2.sp
                        )

                        Spacer(modifier = Modifier.height(20.dp))

                        // Quick Suggestion Chips in empty state
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.CenterHorizontally),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            TechKnowledgeEngine.QUICK_SUGGESTION_CHIPS.take(4).forEach { chip ->
                                Surface(
                                    onClick = { onSendMessage(chip.prompt) },
                                    shape = RoundedCornerShape(20.dp),
                                    color = AtikSurfaceVariant,
                                    border = BorderStroke(1.dp, AtikBorder),
                                    modifier = Modifier.testTag("empty_chip_${chip.id}")
                                ) {
                                    Row(
                                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        Text(
                                            text = chip.label,
                                            color = AtikTextPrimary,
                                            fontSize = 12.5.sp,
                                            fontWeight = FontWeight.Medium
                                        )
                                    }
                                }
                            }
                        }

                        if (onOpenDrawer != null) {
                            Spacer(modifier = Modifier.height(16.dp))
                            Surface(
                                onClick = onOpenDrawer,
                                shape = RoundedCornerShape(16.dp),
                                color = AtikSurfaceVariant,
                                border = BorderStroke(1.dp, AtikBorder),
                                modifier = Modifier.testTag("empty_open_history_btn")
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 7.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.History,
                                        contentDescription = "Chat History",
                                        tint = AtikNeonCyan,
                                        modifier = Modifier.size(15.dp)
                                    )
                                    Text(
                                        text = "View Chat History",
                                        color = AtikTextPrimary,
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Medium
                                    )
                                }
                            }
                        }
                    }
                }
            } else {
                LazyColumn(
                    state = listState,
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 14.dp),
                    contentPadding = PaddingValues(top = 12.dp, bottom = 12.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    items(messages, key = { it.id }) { message ->
                        ChatMessageItem(
                            message = message,
                            isSpeaking = currentlySpeakingId == message.id,
                            onToggleSpeak = { onToggleSpeak(message.id, message.content) },
                            onRunInPythonLab = onRunInPythonLab,
                            onSaveGeneratedImage = onSaveGeneratedImage,
                            onPlayGame = onPlayGame
                        )
                    }

                    if (isGenerating && !streamingText.isNullOrBlank()) {
                        item(key = "active_streaming_item") {
                            StreamingMessageItem(content = streamingText)
                        }
                    } else if (isGenerating) {
                        item(key = "active_thinking_item") {
                            ThinkingIndicator(isEnglish = isEnglish)
                        }
                    }
                }
            }
        }

        // Active Voice Recording Visualizer
        if (isListening) {
            AudioRecorderBar(
                spokenText = spokenText,
                rmsDb = rmsDb,
                onStopListening = {
                    onStopVoice()
                    if (spokenText.isNotBlank()) {
                        inputText = spokenText
                    }
                },
                modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp)
            )
        }

        // Attached image preview chip
        if (attachedImage != null) {
            Row(
                modifier = Modifier
                    .padding(horizontal = 16.dp, vertical = 4.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(AtikSurfaceVariant)
                    .border(1.dp, AtikBorder, RoundedCornerShape(12.dp))
                    .padding(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Image(
                    bitmap = attachedImage.asImageBitmap(),
                    contentDescription = "Attached preview",
                    modifier = Modifier
                        .size(42.dp)
                        .clip(RoundedCornerShape(8.dp)),
                    contentScale = ContentScale.Crop
                )
                Spacer(modifier = Modifier.width(10.dp))
                Text(
                    text = attachedFileName ?: (if (isEnglish) "Attached image" else "সংযুক্ত ছবি"),
                    color = AtikTextPrimary,
                    fontSize = 12.sp,
                    modifier = Modifier.weight(1f),
                    maxLines = 1
                )
                IconButton(
                    onClick = onClearAttachment,
                    modifier = Modifier.size(24.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "Remove attachment",
                        tint = AtikTextMuted,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }
        }

        // Expandable Quick Action Sheet (+)
        AnimatedVisibility(
            visible = showActionSheet,
            enter = fadeIn() + expandVertically(),
            exit = fadeOut() + shrinkVertically()
        ) {
            QuickActionSheet(
                isEnglish = isEnglish,
                onClose = { showActionSheet = false },
                onCamera = {
                    showActionSheet = false
                    if (onNavigateToVision != null) {
                        onNavigateToVision()
                    } else {
                        val permission = Manifest.permission.CAMERA
                        if (ContextCompat.checkSelfPermission(context, permission) == PackageManager.PERMISSION_GRANTED) {
                            cameraLauncher.launch(null)
                        } else {
                            cameraPermissionLauncher.launch(permission)
                        }
                    }
                },
                onUpload = {
                    photoPickerLauncher.launch("image/*")
                    showActionSheet = false
                },
                onSocialAI = {
                    onNavigateToSocial?.invoke()
                    showActionSheet = false
                },
                onPythonLab = {
                    onNavigateToPythonLab?.invoke()
                    showActionSheet = false
                },
                onLiveVoice = {
                    onNavigateToLive?.invoke()
                    showActionSheet = false
                },
                onMemory = {
                    onNavigateToMemory?.invoke()
                    showActionSheet = false
                },
                onTools = {
                    onNavigateToTools?.invoke()
                    showActionSheet = false
                },
                onTechGuides = {
                    onNavigateToTechGuides?.invoke()
                    showActionSheet = false
                },
                onHistory = {
                    onOpenDrawer?.invoke()
                    showActionSheet = false
                },
                onGameStudio = {
                    onNavigateToGameStudio?.invoke()
                    showActionSheet = false
                },
                onPromptSelected = { prompt ->
                    onSendMessage(prompt)
                    showActionSheet = false
                }
            )
        }

        // Dynamic Voice Action Response Banner: "Okay boss, I am doing it right now!"
        AnimatedVisibility(
            visible = bossActionPhrase != null,
            enter = fadeIn() + expandVertically(),
            exit = fadeOut() + shrinkVertically()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.Center
            ) {
                Surface(
                    shape = RoundedCornerShape(20.dp),
                    color = Color(0xFF0F172A),
                    border = BorderStroke(1.2.dp, AtikNeonCyan),
                    modifier = Modifier.testTag("boss_action_banner")
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 7.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text("🥋", fontSize = 16.sp)
                        Text(
                            text = bossActionPhrase ?: "Okay boss, I am doing it right now!",
                            color = AtikNeonCyan,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.SemiBold,
                            letterSpacing = 0.3.sp
                        )
                    }
                }
            }
        }

        // Interactive Quick Suggestion Chips directly above the bottom input box
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 10.dp, vertical = 4.dp)
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.Start),
            verticalAlignment = Alignment.CenterVertically
        ) {
            TechKnowledgeEngine.QUICK_SUGGESTION_CHIPS.forEach { chip ->
                Surface(
                    onClick = { onSendMessage(chip.prompt) },
                    shape = RoundedCornerShape(18.dp),
                    color = AtikSurfaceVariant,
                    border = BorderStroke(0.8.dp, AtikBorder),
                    modifier = Modifier.testTag("suggestion_pill_${chip.id}")
                ) {
                    Text(
                        text = chip.label,
                        color = AtikTextSecondary,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium,
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                    )
                }
            }

            Surface(
                onClick = { inputText = "Create an image of " },
                shape = RoundedCornerShape(18.dp),
                color = AtikSurfaceVariant,
                border = BorderStroke(0.8.dp, AtikBorder),
                modifier = Modifier.testTag("suggestion_pill_create_image")
            ) {
                Text(
                    text = "🎨 Create an image",
                    color = AtikTextSecondary,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Medium,
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                )
            }

            if (onNavigateToTechGuides != null) {
                Surface(
                    onClick = onNavigateToTechGuides,
                    shape = RoundedCornerShape(18.dp),
                    color = AtikSurfaceHighlight,
                    border = BorderStroke(0.8.dp, AtikNeonCyan.copy(alpha = 0.5f)),
                    modifier = Modifier.testTag("suggestion_pill_all_guides")
                ) {
                    Text(
                        text = "📚 All Guides Hub",
                        color = AtikNeonCyan,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                    )
                }
            }
        }

        // Stylish Bottom Composer Box (ChatGPT & Gemini style)
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 10.dp, vertical = 8.dp),
            shape = RoundedCornerShape(26.dp),
            color = AtikSurfaceVariant,
            border = BorderStroke(1.dp, AtikBorder)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 6.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Plus (+) Button for extra tools and upload
                IconButton(
                    onClick = { showActionSheet = !showActionSheet },
                    modifier = Modifier
                        .size(38.dp)
                        .testTag("plus_action_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Add,
                        contentDescription = "Add tools & attachments",
                        tint = if (showActionSheet) AtikNeonCyan else AtikTextSecondary,
                        modifier = Modifier.size(22.dp)
                    )
                }

                // Clean multi-line prompt field with "Ask Atik AI..." placeholder
                OutlinedTextField(
                    value = inputText,
                    onValueChange = { inputText = it },
                    placeholder = {
                        Text(
                            text = "Ask Atik AI...",
                            color = AtikTextMuted,
                            fontSize = 14.sp
                        )
                    },
                    modifier = Modifier
                        .weight(1f)
                        .padding(horizontal = 2.dp)
                        .testTag("chat_input_field"),
                    maxLines = 5,
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                    keyboardActions = KeyboardActions(
                        onSend = {
                            if ((inputText.isNotBlank() || attachedImage != null) && !isGenerating) {
                                val textToSend = inputText
                                inputText = ""
                                onSendMessage(textToSend)
                            }
                        }
                    ),
                    shape = RoundedCornerShape(20.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = AtikTextPrimary,
                        unfocusedTextColor = AtikTextPrimary,
                        focusedBorderColor = Color.Transparent,
                        unfocusedBorderColor = Color.Transparent,
                        focusedContainerColor = Color.Transparent,
                        unfocusedContainerColor = Color.Transparent
                    )
                )

                // Live Voice Button (shortcut)
                if (inputText.isBlank() && attachedImage == null) {
                    IconButton(
                        onClick = { onNavigateToLive?.invoke() },
                        modifier = Modifier
                            .size(38.dp)
                            .testTag("live_voice_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.GraphicEq,
                            contentDescription = "Live voice",
                            tint = AtikNeonAzure,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }

                // Microphone / Voice button
                IconButton(
                    onClick = {
                        val permission = Manifest.permission.RECORD_AUDIO
                        if (ContextCompat.checkSelfPermission(context, permission) == PackageManager.PERMISSION_GRANTED) {
                            if (isListening) onStopVoice() else onStartVoice()
                        } else {
                            permissionLauncher.launch(permission)
                        }
                    },
                    modifier = Modifier
                        .size(38.dp)
                        .clip(CircleShape)
                        .background(if (isListening) AtikError else Color.Transparent)
                        .testTag("mic_button")
                ) {
                    Icon(
                        imageVector = if (isListening) Icons.Default.Stop else Icons.Default.Mic,
                        contentDescription = "Voice input",
                        tint = if (isListening) Color.White else AtikTextSecondary,
                        modifier = Modifier.size(20.dp)
                    )
                }

                // Send Button
                val canSend = (inputText.isNotBlank() || attachedImage != null) && !isGenerating
                IconButton(
                    onClick = {
                        if (canSend) {
                            val textToSend = inputText
                            inputText = ""
                            onSendMessage(textToSend)
                        }
                    },
                    enabled = canSend,
                    modifier = Modifier
                        .size(40.dp)
                        .clip(CircleShape)
                        .background(
                            if (canSend) {
                                Brush.linearGradient(listOf(AtikElectricBlue, AtikNeonAzure))
                            } else {
                                Brush.linearGradient(listOf(AtikSurfaceHighlight, AtikSurfaceHighlight))
                            }
                        )
                        .testTag("send_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Send,
                        contentDescription = "Send message",
                        tint = if (canSend) Color.White else AtikTextMuted,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
        }
    }
}

/**
 * Real-time streaming response message item with pulsing Kung-Fu avatar and cyber cursor.
 */
@Composable
private fun StreamingMessageItem(content: String) {
    val infiniteTransition = rememberInfiniteTransition(label = "cursor_blink")
    val cursorAlpha by infiniteTransition.animateFloat(
        initialValue = 1f,
        targetValue = 0f,
        animationSpec = infiniteRepeatable(
            animation = tween(450, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "cursor_alpha"
    )

    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.Start,
        verticalAlignment = Alignment.Top
    ) {
        AtikAvatar(size = 32.dp, isPulsing = true)
        Spacer(modifier = Modifier.width(8.dp))

        Column(
            modifier = Modifier.fillMaxWidth(0.86f),
            horizontalAlignment = Alignment.Start
        ) {
            Box(
                modifier = Modifier
                    .clip(
                        RoundedCornerShape(
                            topStart = 18.dp,
                            topEnd = 18.dp,
                            bottomStart = 4.dp,
                            bottomEnd = 18.dp
                        )
                    )
                    .background(AtikAiBubble)
                    .border(
                        BorderStroke(1.dp, AtikBorder),
                        RoundedCornerShape(
                            topStart = 18.dp,
                            topEnd = 18.dp,
                            bottomStart = 4.dp,
                            bottomEnd = 18.dp
                        )
                    )
                    .padding(horizontal = 14.dp, vertical = 11.dp)
            ) {
                Column {
                    MarkdownContent(markdown = content)
                    Text(
                        text = " ▍",
                        color = AtikNeonCyan.copy(alpha = cursorAlpha),
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

/**
 * Thinking indicator showing animated pulse and message
 */
@Composable
private fun ThinkingIndicator(isEnglish: Boolean) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.padding(start = 4.dp, top = 4.dp)
    ) {
        AtikAvatar(size = 28.dp, isPulsing = true)
        Spacer(modifier = Modifier.width(10.dp))
        Box(
            modifier = Modifier
                .clip(RoundedCornerShape(16.dp))
                .background(AtikAiBubble)
                .border(1.dp, AtikBorder, RoundedCornerShape(16.dp))
                .padding(horizontal = 14.dp, vertical = 10.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                CircularProgressIndicator(
                    modifier = Modifier.size(16.dp),
                    color = AtikNeonCyan,
                    strokeWidth = 2.dp
                )
                Spacer(modifier = Modifier.width(10.dp))
                Text(
                    text = if (isEnglish) "Atik AI is thinking…" else "Atik AI চিন্তা করছে…",
                    color = AtikTextSecondary,
                    fontSize = 13.sp
                )
            }
        }
    }
}

/**
 * Expandable action sheet for (+) button
 */
@Composable
private fun QuickActionSheet(
    isEnglish: Boolean,
    onClose: () -> Unit,
    onCamera: () -> Unit,
    onUpload: () -> Unit,
    onSocialAI: () -> Unit,
    onPythonLab: () -> Unit,
    onLiveVoice: () -> Unit,
    onMemory: () -> Unit,
    onTools: () -> Unit,
    onTechGuides: () -> Unit,
    onHistory: () -> Unit,
    onGameStudio: () -> Unit,
    onPromptSelected: (String) -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 6.dp),
        colors = CardDefaults.cardColors(containerColor = AtikSurfaceVariant),
        border = BorderStroke(1.dp, AtikBorder),
        shape = RoundedCornerShape(18.dp)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = if (isEnglish) "ATTACH & TOOLS" else "টুলস ও সংযুক্তি",
                    color = AtikNeonAzure,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp
                )
                IconButton(
                    onClick = onClose,
                    modifier = Modifier.size(24.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "Close",
                        tint = AtikTextMuted,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                ActionChipItem(Icons.Default.PhotoCamera, if (isEnglish) "Camera" else "ক্যামেরা", onCamera)
                ActionChipItem(Icons.Default.AttachFile, if (isEnglish) "Photos" else "ছবি আপলোড", onUpload)
                ActionChipItem(Icons.Default.Campaign, "Social AI", onSocialAI)
                ActionChipItem(Icons.Default.Code, "Python", onPythonLab)
            }

            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                ActionChipItem(Icons.Default.GraphicEq, "Live Voice", onLiveVoice)
                ActionChipItem(Icons.Default.School, if (isEnglish) "Guides" else "আর্নিং গাইড", onTechGuides)
                ActionChipItem(Icons.Default.Psychology, "Memory", onMemory)
                ActionChipItem(Icons.Default.Build, "Tools", onTools)
            }

            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.Start
            ) {
                ActionChipItem(Icons.Default.SportsEsports, if (isEnglish) "2D Games" else "গেম স্টুডিও", onGameStudio)
            }
        }
    }
}

@Composable
private fun ActionChipItem(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    onClick: () -> Unit
) {
    Surface(
        color = AtikSurface,
        shape = RoundedCornerShape(12.dp),
        border = BorderStroke(0.8.dp, AtikBorder),
        modifier = Modifier
            .width(72.dp)
            .clickable(onClick = onClick)
    ) {
        Column(
            modifier = Modifier.padding(vertical = 8.dp, horizontal = 4.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = label,
                tint = AtikNeonCyan,
                modifier = Modifier.size(20.dp)
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = label,
                color = AtikTextPrimary,
                fontSize = 10.sp,
                fontWeight = FontWeight.Medium,
                textAlign = TextAlign.Center,
                maxLines = 1
            )
        }
    }
}

@Composable
private fun ChatMessageItem(
    message: ChatMessageEntity,
    isSpeaking: Boolean,
    onToggleSpeak: () -> Unit,
    onRunInPythonLab: ((String) -> Unit)? = null,
    onSaveGeneratedImage: ((imageUrl: String, prompt: String, onComplete: (Boolean, String) -> Unit) -> Unit)? = null,
    onPlayGame: ((String) -> Unit)? = null
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var isCopied by remember { mutableStateOf(false) }

    val isUser = message.role == "user"
    val timeStr = remember(message.timestamp) {
        SimpleDateFormat("hh:mm a", Locale.getDefault()).format(Date(message.timestamp))
    }

    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = if (isUser) Arrangement.End else Arrangement.Start,
        verticalAlignment = Alignment.Top
    ) {
        if (!isUser) {
            AtikAvatar(size = 32.dp, isPulsing = isSpeaking)
            Spacer(modifier = Modifier.width(8.dp))
        }

        Column(
            modifier = Modifier.fillMaxWidth(0.86f),
            horizontalAlignment = if (isUser) Alignment.End else Alignment.Start
        ) {
            Box(
                modifier = Modifier
                    .clip(
                        RoundedCornerShape(
                            topStart = 18.dp,
                            topEnd = 18.dp,
                            bottomStart = if (isUser) 18.dp else 4.dp,
                            bottomEnd = if (isUser) 4.dp else 18.dp
                        )
                    )
                    .background(if (isUser) AtikUserBubble else AtikAiBubble)
                    .border(
                        BorderStroke(
                            1.dp,
                            if (isUser) AtikElectricBlue.copy(alpha = 0.5f) else AtikBorder
                        ),
                        RoundedCornerShape(
                            topStart = 18.dp,
                            topEnd = 18.dp,
                            bottomStart = if (isUser) 18.dp else 4.dp,
                            bottomEnd = if (isUser) 4.dp else 18.dp
                        )
                    )
                    .padding(horizontal = 14.dp, vertical = 11.dp)
            ) {
                Column {
                    if (message.attachedFileName != null && message.attachedFileType != "generated_image") {
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = AtikSurfaceHighlight,
                            modifier = Modifier.padding(bottom = 6.dp)
                        ) {
                            Text(
                                text = "📎 ${message.attachedFileName}",
                                color = AtikNeonAzure,
                                fontSize = 11.sp,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                            )
                        }
                    }

                    if (isUser) {
                        Text(
                            text = message.content,
                            color = AtikTextPrimary,
                            fontSize = 15.sp,
                            lineHeight = 22.sp
                        )
                    } else {
                        val isGeneratedImage = message.attachedFileType == "generated_image" ||
                                (message.attachedFileName?.startsWith("http") == true &&
                                 message.attachedFileName.contains("pollinations.ai")) ||
                                (message.content.contains("![Generated Image](") && message.content.contains("http"))

                        if (isGeneratedImage) {
                            val imageUrl = if (message.attachedFileName?.startsWith("http") == true) {
                                message.attachedFileName
                            } else {
                                extractImageUrlFromMarkdown(message.content)
                            }
                            val prompt = extractPromptFromMessage(message.content)

                            GeneratedImageInlineCard(
                                imageUrl = imageUrl,
                                prompt = prompt,
                                onSaveToGallery = { onComplete ->
                                    onSaveGeneratedImage?.invoke(imageUrl, prompt, onComplete)
                                }
                            )
                        } else {
                            MarkdownContent(
                                markdown = message.content,
                                onRunInPythonLab = onRunInPythonLab
                            )

                            // Step 26 Requirement 3: Interactive Play Button for Synthesized Games
                            if (message.content.contains("🎮 **[2D Game Synthesized:")) {
                                val titleMatch = Regex("\\[2D Game Synthesized:\\s*([^\\]]+)\\]").find(message.content)
                                val gameTitle = titleMatch?.groupValues?.get(1)?.trim() ?: "2D Game"

                                Spacer(modifier = Modifier.height(10.dp))
                                Surface(
                                    shape = RoundedCornerShape(12.dp),
                                    color = AtikSurfaceHighlight,
                                    border = BorderStroke(1.dp, AtikNeonCyan.copy(alpha = 0.6f)),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(horizontal = 12.dp, vertical = 8.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            modifier = Modifier.weight(1f)
                                        ) {
                                            Text("🕹️", fontSize = 22.sp)
                                            Spacer(modifier = Modifier.width(8.dp))
                                            Column {
                                                Text(
                                                    text = gameTitle,
                                                    color = AtikTextPrimary,
                                                    fontSize = 13.sp,
                                                    fontWeight = FontWeight.Bold
                                                )
                                                Text(
                                                    text = "60 FPS HTML5 Canvas Runtime",
                                                    color = AtikNeonCyan,
                                                    fontSize = 10.5.sp
                                                )
                                            }
                                        }

                                        Button(
                                            onClick = { onPlayGame?.invoke(gameTitle) },
                                            colors = ButtonDefaults.buttonColors(
                                                containerColor = AtikNeonCyan,
                                                contentColor = Color.Black
                                            ),
                                            shape = RoundedCornerShape(10.dp),
                                            modifier = Modifier.testTag("btn_play_synthesized_game")
                                        ) {
                                            Icon(
                                                Icons.Default.PlayArrow,
                                                contentDescription = null,
                                                modifier = Modifier.size(16.dp)
                                            )
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text("Play Now", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Timestamp and actions for AI message
            Row(
                modifier = Modifier.padding(horizontal = 4.dp, vertical = 3.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = timeStr,
                    color = AtikTextMuted,
                    fontSize = 11.sp
                )

                if (!isUser) {
                    Spacer(modifier = Modifier.width(10.dp))

                    // Copy action
                    IconButton(
                        onClick = {
                            val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                            clipboard.setPrimaryClip(ClipData.newPlainText("Atik AI", message.content))
                            isCopied = true
                            Toast.makeText(context, "Copied!", Toast.LENGTH_SHORT).show()
                            scope.launch {
                                delay(2000)
                                isCopied = false
                            }
                        },
                        modifier = Modifier.size(26.dp)
                    ) {
                        Icon(
                            imageVector = if (isCopied) Icons.Default.Check else Icons.Default.ContentCopy,
                            contentDescription = "Copy message",
                            tint = if (isCopied) AtikSuccess else AtikTextMuted,
                            modifier = Modifier.size(14.dp)
                        )
                    }

                    // TTS Voice action
                    IconButton(
                        onClick = onToggleSpeak,
                        modifier = Modifier.size(26.dp)
                    ) {
                        Icon(
                            imageVector = if (isSpeaking) Icons.Default.Stop else Icons.Default.VolumeUp,
                            contentDescription = if (isSpeaking) "Stop speaking" else "Read aloud",
                            tint = if (isSpeaking) AtikNeonCyan else AtikTextMuted,
                            modifier = Modifier.size(15.dp)
                        )
                    }
                }
            }
        }
    }
}

private fun extractImageUrlFromMarkdown(content: String): String {
    val regex = Regex("!\\[.*?\\]\\((https?://[^)]+)\\)")
    val match = regex.find(content)
    if (match != null) {
        return match.groupValues[1]
    }
    val urlRegex = Regex("(https?://image\\.pollinations\\.ai/[^\\s)\"]+)")
    val urlMatch = urlRegex.find(content)
    return urlMatch?.groupValues?.get(1) ?: ""
}

private fun extractPromptFromMessage(content: String): String {
    val match = Regex("\\*\\*(.*?)\\*\\*").find(content)
    return match?.groupValues?.get(1) ?: "AI Generated Image"
}

/**
 * Sleek Network Status Indicator Banner on top of Chat View (Step 12 Requirement 3).
 * Seamlessly toggles visual appearance between Cloud Online AI and Local Offline AI.
 */
@Composable
fun NetworkStatusBanner(
    isOnline: Boolean,
    connectionTypeName: String,
    isSimulation: Boolean,
    onToggleSimulation: ((Boolean) -> Unit)?,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "beacon_anim")
    val beaconAlpha by infiniteTransition.animateFloat(
        initialValue = 0.35f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 800, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "beacon_alpha"
    )

    Surface(
        color = if (isOnline) AtikSurface.copy(alpha = 0.90f) else Color(0xFF271B04),
        border = BorderStroke(
            1.dp,
            if (isOnline) AtikBorder else Color(0xFFFFB300).copy(alpha = 0.5f)
        ),
        modifier = modifier
            .fillMaxWidth()
            .testTag("network_status_banner")
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 7.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f)
            ) {
                // Pulsing indicator beacon
                Box(
                    modifier = Modifier
                        .size(8.dp)
                        .clip(CircleShape)
                        .background(
                            if (isOnline) {
                                AtikSuccess.copy(alpha = beaconAlpha)
                            } else {
                                Color(0xFFFFB300).copy(alpha = beaconAlpha)
                            }
                        )
                )

                Spacer(modifier = Modifier.width(8.dp))

                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = if (isOnline) {
                                "Online Mode • Cloud AI Connected"
                            } else {
                                if (isSimulation) "Offline Mode (Simulated)" else "Offline Mode Active"
                            },
                            color = if (isOnline) AtikTextPrimary else Color(0xFFFFE082),
                            fontSize = 11.5.sp,
                            fontWeight = FontWeight.Bold
                        )
                        if (isOnline) {
                            Text(
                                text = " ($connectionTypeName)",
                                color = AtikTextMuted,
                                fontSize = 10.5.sp
                            )
                        }
                    }

                    if (!isOnline) {
                        Text(
                            text = "Local Engine Active: Math, Notes, Hardware & Tech Guides",
                            color = Color(0xFFFFCA28).copy(alpha = 0.9f),
                            fontSize = 9.5.sp
                        )
                    }
                }
            }

            // Quick toggle button to test offline fallback
            if (onToggleSimulation != null) {
                Surface(
                    onClick = {
                        onToggleSimulation(!isSimulation)
                    },
                    shape = RoundedCornerShape(8.dp),
                    color = if (isSimulation) Color(0xFFFFB300) else AtikSurfaceHighlight,
                    border = BorderStroke(0.8.dp, if (isSimulation) Color(0xFFFFB300) else AtikBorder),
                    modifier = Modifier.testTag("simulate_offline_toggle_btn")
                ) {
                    Text(
                        text = if (isSimulation) "Resume Cloud" else "Simulate Offline",
                        color = if (isSimulation) Color.Black else AtikNeonCyan,
                        fontSize = 9.5.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 7.dp, vertical = 3.dp)
                    )
                }
            }
        }
    }
}

