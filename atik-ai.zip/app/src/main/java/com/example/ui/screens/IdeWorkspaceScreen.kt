package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.BugReport
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.FormatAlignLeft
import androidx.compose.material.icons.filled.Laptop
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import com.example.ide.AiCodeAction
import com.example.ide.CodeTemplate
import com.example.ide.DEFAULT_IDE_TEMPLATES
import com.example.ide.DiagnosticLog
import com.example.ide.DiagnosticSeverity
import com.example.ide.IdeExecutionResult
import com.example.ide.SupportedLanguage
import com.example.ide.SyntaxHighlighter
import com.example.ui.theme.AtikBlack
import com.example.ui.theme.AtikBorder
import com.example.ui.theme.AtikElectricBlue
import com.example.ui.theme.AtikError
import com.example.ui.theme.AtikNeonAzure
import com.example.ui.theme.AtikNeonCyan
import com.example.ui.theme.AtikSuccess
import com.example.ui.theme.AtikSurface
import com.example.ui.theme.AtikSurfaceHighlight
import com.example.ui.theme.AtikSurfaceVariant
import com.example.ui.theme.AtikTextMuted
import com.example.ui.theme.AtikTextPrimary
import com.example.ui.theme.AtikTextSecondary

enum class IdeWorkspaceTab(val label: String, val icon: androidx.compose.ui.graphics.vector.ImageVector) {
    EDITOR("Code Editor", Icons.Default.Code),
    PREVIEW("Live Canvas & Console", Icons.Default.Visibility),
    DIAGNOSTICS("AI Diagnostics", Icons.Default.BugReport)
}

/**
 * AI Coding Assistant & IDE Simulator Screen (Step 19).
 * Features multi-language syntax generation & debugging, live web preview canvas,
 * code formatting, diagnostic logs, and export hub.
 */
@Composable
fun IdeWorkspaceScreen(
    currentCode: String,
    selectedLanguage: SupportedLanguage,
    executionResult: IdeExecutionResult?,
    diagnosticLogs: List<DiagnosticLog>,
    isRunning: Boolean,
    isAiAssisting: Boolean,
    onCodeChange: (String) -> Unit,
    onSelectLanguage: (SupportedLanguage) -> Unit,
    onRunCode: () -> Unit,
    onClearOutput: () -> Unit,
    onAutoFormat: () -> Unit,
    onAiGenerateCode: (prompt: String) -> Unit,
    onAiDebugAndFix: () -> Unit,
    onAiRefactor: () -> Unit,
    onAiExplain: () -> Unit,
    onExportFile: (fileName: String) -> Unit,
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    BackHandler { onBack() }
    val context = LocalContext.current

    var activeTab by remember { mutableStateOf(IdeWorkspaceTab.EDITOR) }
    var isMobileViewport by remember { mutableStateOf(true) }
    var webViewKey by remember { mutableStateOf(0) }

    // Dialog States
    var showAiAssistDialog by remember { mutableStateOf(false) }
    var aiPromptText by remember { mutableStateOf("") }
    var selectedAiAction by remember { mutableStateOf(AiCodeAction.GENERATE) }
    var showExportDialog by remember { mutableStateOf(false) }
    var exportFileName by remember { mutableStateOf("atik_script") }
    var showTemplatesDialog by remember { mutableStateOf(false) }

    // Automatically switch to Preview tab when running code
    LaunchedEffect(executionResult) {
        if (executionResult != null) {
            activeTab = IdeWorkspaceTab.PREVIEW
            webViewKey++
        }
    }

    val lineCount = remember(currentCode) {
        currentCode.lines().size.coerceAtLeast(1)
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(AtikBlack)
    ) {
        // Top Toolbar
        Surface(
            color = AtikSurface,
            border = BorderStroke(1.dp, AtikBorder),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(
                            onClick = onBack,
                            modifier = Modifier.size(36.dp).testTag("btn_ide_back")
                        ) {
                            Icon(
                                Icons.AutoMirrored.Filled.ArrowBack,
                                contentDescription = "Back",
                                tint = AtikTextPrimary,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(4.dp))
                        Box(
                            modifier = Modifier
                                .size(32.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(
                                    Brush.linearGradient(
                                        colors = listOf(AtikElectricBlue, AtikNeonCyan)
                                    )
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                Icons.Default.Code,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Text(
                                text = "AI Coding Assistant & IDE",
                                color = AtikTextPrimary,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "${selectedLanguage.emoji} ${selectedLanguage.displayName} • ${lineCount} lines",
                                color = AtikNeonCyan,
                                fontSize = 10.5.sp
                            )
                        }
                    }

                    // Action buttons: Run, AI, Format, Export
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // AI Assistant Button
                        IconButton(
                            onClick = { showAiAssistDialog = true },
                            enabled = !isAiAssisting,
                            modifier = Modifier.size(36.dp).testTag("btn_ide_ai_assistant")
                        ) {
                            if (isAiAssisting) {
                                CircularProgressIndicator(modifier = Modifier.size(18.dp), color = AtikNeonCyan, strokeWidth = 2.dp)
                            } else {
                                Icon(Icons.Default.AutoAwesome, contentDescription = "AI Assistant", tint = AtikNeonAzure, modifier = Modifier.size(20.dp))
                            }
                        }

                        // Auto Format Button
                        IconButton(
                            onClick = {
                                onAutoFormat()
                                Toast.makeText(context, "Code auto-formatted", Toast.LENGTH_SHORT).show()
                            },
                            modifier = Modifier.size(36.dp).testTag("btn_ide_auto_format")
                        ) {
                            Icon(Icons.Default.FormatAlignLeft, contentDescription = "Format & Indent", tint = AtikTextSecondary, modifier = Modifier.size(18.dp))
                        }

                        // Templates Button
                        IconButton(
                            onClick = { showTemplatesDialog = true },
                            modifier = Modifier.size(36.dp).testTag("btn_ide_templates")
                        ) {
                            Icon(Icons.Default.Tune, contentDescription = "Templates", tint = AtikTextSecondary, modifier = Modifier.size(18.dp))
                        }

                        // Export & Share Button
                        IconButton(
                            onClick = { showExportDialog = true },
                            modifier = Modifier.size(36.dp).testTag("btn_ide_export_dialog")
                        ) {
                            Icon(Icons.Default.Download, contentDescription = "Export File", tint = AtikTextSecondary, modifier = Modifier.size(18.dp))
                        }

                        // Execute / Run Button
                        Button(
                            onClick = onRunCode,
                            enabled = !isRunning && currentCode.isNotBlank(),
                            shape = RoundedCornerShape(8.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (selectedLanguage.isWebVisual) AtikNeonCyan else AtikElectricBlue,
                                contentColor = if (selectedLanguage.isWebVisual) Color.Black else Color.White
                            ),
                            modifier = Modifier.height(34.dp).testTag("btn_ide_run_code")
                        ) {
                            if (isRunning) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(14.dp),
                                    color = if (selectedLanguage.isWebVisual) Color.Black else Color.White,
                                    strokeWidth = 2.dp
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Running", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            } else {
                                Icon(
                                    imageVector = if (selectedLanguage.isWebVisual) Icons.Default.Visibility else Icons.Default.PlayArrow,
                                    contentDescription = null,
                                    modifier = Modifier.size(14.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = if (selectedLanguage.isWebVisual) "Render" else "Run",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))

                // Multi-Language Selection Bar (Python, JS, HTML/CSS, Kotlin, C++)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    SupportedLanguage.values().forEach { lang ->
                        val isSelected = selectedLanguage == lang
                        FilterChip(
                            selected = isSelected,
                            onClick = { onSelectLanguage(lang) },
                            label = { Text("${lang.emoji} ${lang.displayName}", fontSize = 11.sp) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = AtikElectricBlue.copy(alpha = 0.35f),
                                selectedLabelColor = AtikNeonCyan
                            ),
                            border = BorderStroke(0.8.dp, if (isSelected) AtikNeonCyan else AtikBorder),
                            modifier = Modifier.testTag("lang_tab_${lang.identifier}")
                        )
                    }
                }
            }
        }

        // View Tabs (Editor | Preview & Console | Diagnostics)
        ScrollableTabRow(
            selectedTabIndex = activeTab.ordinal,
            containerColor = AtikSurfaceVariant,
            contentColor = AtikNeonCyan,
            edgePadding = 12.dp,
            modifier = Modifier.fillMaxWidth().height(40.dp)
        ) {
            IdeWorkspaceTab.values().forEach { tab ->
                Tab(
                    selected = activeTab == tab,
                    onClick = { activeTab = tab },
                    text = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(tab.icon, contentDescription = null, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(tab.label, fontSize = 11.5.sp, fontWeight = FontWeight.SemiBold)
                        }
                    },
                    modifier = Modifier.testTag("tab_workspace_${tab.name}")
                )
            }
        }

        // Main Tab Content Area
        Box(modifier = Modifier.fillMaxSize().weight(1f)) {
            when (activeTab) {
                IdeWorkspaceTab.EDITOR -> {
                    EditorWorkspace(
                        currentCode = currentCode,
                        selectedLanguage = selectedLanguage,
                        onCodeChange = onCodeChange
                    )
                }

                IdeWorkspaceTab.PREVIEW -> {
                    LivePreviewAndConsole(
                        selectedLanguage = selectedLanguage,
                        executionResult = executionResult,
                        isRunning = isRunning,
                        isMobileViewport = isMobileViewport,
                        onToggleViewport = { isMobileViewport = !isMobileViewport },
                        onClearOutput = onClearOutput,
                        onRunCode = onRunCode,
                        onDebugWithAi = onAiDebugAndFix,
                        webViewKey = webViewKey
                    )
                }

                IdeWorkspaceTab.DIAGNOSTICS -> {
                    DiagnosticsTabContent(
                        logs = diagnosticLogs,
                        onApplyAiFix = onAiDebugAndFix,
                        onRefactor = onAiRefactor
                    )
                }
            }
        }
    }

    // AI Coding Assistant Bottom Sheet / Dialog
    if (showAiAssistDialog) {
        AlertDialog(
            onDismissRequest = { showAiAssistDialog = false },
            containerColor = AtikSurfaceVariant,
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.AutoAwesome, null, tint = AtikNeonCyan, modifier = Modifier.size(20.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "AI Coding Assistant",
                        color = AtikTextPrimary,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            },
            text = {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text(
                        text = "Select an AI operation for ${selectedLanguage.displayName}:",
                        color = AtikTextSecondary,
                        fontSize = 11.5.sp
                    )

                    // Action Selector Chips
                    Row(
                        modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        AiCodeAction.values().forEach { action ->
                            val isActionSelected = selectedAiAction == action
                            FilterChip(
                                selected = isActionSelected,
                                onClick = { selectedAiAction = action },
                                label = { Text(action.title, fontSize = 10.5.sp) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = AtikElectricBlue.copy(alpha = 0.4f),
                                    selectedLabelColor = AtikNeonCyan
                                ),
                                border = BorderStroke(0.8.dp, if (isActionSelected) AtikNeonCyan else AtikBorder)
                            )
                        }
                    }

                    if (selectedAiAction == AiCodeAction.GENERATE) {
                        OutlinedTextField(
                            value = aiPromptText,
                            onValueChange = { aiPromptText = it },
                            placeholder = { Text("e.g. Build an interactive pricing table with flexbox and neon hover effects...", fontSize = 11.sp, color = AtikTextMuted) },
                            maxLines = 4,
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = AtikNeonCyan,
                                unfocusedBorderColor = AtikBorder
                            ),
                            modifier = Modifier.fillMaxWidth().testTag("input_ai_code_prompt")
                        )

                        // Quick prompt inspiration
                        val prompts = listOf(
                            "Binary search algorithm with edge cases",
                            "Interactive animated counter with sound",
                            "REST API client with error handling",
                            "Data cleanup and deduplication script"
                        )

                        Text("Quick Ideas:", color = AtikTextMuted, fontSize = 10.5.sp)
                        prompts.forEach { p ->
                            Surface(
                                onClick = { aiPromptText = p },
                                shape = RoundedCornerShape(6.dp),
                                color = AtikSurface,
                                border = BorderStroke(0.5.dp, AtikBorder),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text(
                                    text = "💡 $p",
                                    color = AtikTextSecondary,
                                    fontSize = 10.sp,
                                    modifier = Modifier.padding(6.dp)
                                )
                            }
                        }
                    } else {
                        Text(
                            text = selectedAiAction.description,
                            color = AtikTextSecondary,
                            fontSize = 12.sp,
                            lineHeight = 16.sp
                        )
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        showAiAssistDialog = false
                        when (selectedAiAction) {
                            AiCodeAction.GENERATE -> {
                                if (aiPromptText.isNotBlank()) onAiGenerateCode(aiPromptText)
                            }
                            AiCodeAction.DEBUG_FIX -> onAiDebugAndFix()
                            AiCodeAction.REFACTOR -> onAiRefactor()
                            AiCodeAction.EXPLAIN -> onAiExplain()
                            AiCodeAction.UNIT_TESTS -> onAiGenerateCode("Write comprehensive unit tests for this code:\n\n$currentCode")
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = AtikElectricBlue),
                    modifier = Modifier.testTag("btn_confirm_ai_action")
                ) {
                    Text("Execute Action", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showAiAssistDialog = false }) {
                    Text("Cancel", color = AtikTextMuted)
                }
            }
        )
    }

    // Export & Save File Dialog
    if (showExportDialog) {
        AlertDialog(
            onDismissRequest = { showExportDialog = false },
            containerColor = AtikSurfaceVariant,
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Download, null, tint = AtikNeonCyan, modifier = Modifier.size(20.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Export Script",
                        color = AtikTextPrimary,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = "Save script to local application storage and generate shareable bundle:",
                        color = AtikTextSecondary,
                        fontSize = 12.sp
                    )

                    OutlinedTextField(
                        value = exportFileName,
                        onValueChange = { exportFileName = it },
                        label = { Text("File Name (without extension)") },
                        trailingIcon = {
                            Text(
                                text = selectedLanguage.fileExtension,
                                color = AtikNeonCyan,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(end = 12.dp)
                            )
                        },
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = AtikNeonCyan,
                            unfocusedBorderColor = AtikBorder
                        ),
                        modifier = Modifier.fillMaxWidth().testTag("input_export_filename")
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = {
                                val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                clipboard.setPrimaryClip(ClipData.newPlainText("Script", currentCode))
                                Toast.makeText(context, "Code copied to clipboard", Toast.LENGTH_SHORT).show()
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = AtikSurface),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(Icons.Default.ContentCopy, null, tint = AtikNeonCyan, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Copy", color = AtikTextPrimary, fontSize = 11.5.sp)
                        }

                        Button(
                            onClick = {
                                try {
                                    val sendIntent = Intent().apply {
                                        action = Intent.ACTION_SEND
                                        putExtra(Intent.EXTRA_TEXT, currentCode)
                                        type = "text/plain"
                                    }
                                    context.startActivity(Intent.createChooser(sendIntent, "Share ${selectedLanguage.displayName} Code"))
                                } catch (_: Exception) {
                                    Toast.makeText(context, "Cannot launch share", Toast.LENGTH_SHORT).show()
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = AtikSurface),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(Icons.Default.Share, null, tint = AtikNeonAzure, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Share", color = AtikTextPrimary, fontSize = 11.5.sp)
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        showExportDialog = false
                        onExportFile(exportFileName)
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = AtikElectricBlue),
                    modifier = Modifier.testTag("btn_confirm_export_file")
                ) {
                    Text("Save Local File", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showExportDialog = false }) {
                    Text("Close", color = AtikTextMuted)
                }
            }
        )
    }

    // Code Templates Picker Dialog
    if (showTemplatesDialog) {
        val languageTemplates = remember(selectedLanguage) {
            DEFAULT_IDE_TEMPLATES.filter { it.language == selectedLanguage }
        }

        AlertDialog(
            onDismissRequest = { showTemplatesDialog = false },
            containerColor = AtikSurfaceVariant,
            title = {
                Text(
                    text = "${selectedLanguage.displayName} Starter Templates",
                    color = AtikTextPrimary,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold
                )
            },
            text = {
                LazyColumn(
                    modifier = Modifier.fillMaxWidth().heightIn(max = 350.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(languageTemplates) { tpl ->
                        Surface(
                            onClick = {
                                onCodeChange(tpl.code)
                                showTemplatesDialog = false
                                Toast.makeText(context, "Loaded ${tpl.name}", Toast.LENGTH_SHORT).show()
                            },
                            shape = RoundedCornerShape(10.dp),
                            color = AtikSurface,
                            border = BorderStroke(1.dp, AtikBorder),
                            modifier = Modifier.fillMaxWidth().testTag("tpl_item_${tpl.id}")
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Text(
                                    text = tpl.name,
                                    color = AtikNeonCyan,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = tpl.description,
                                    color = AtikTextSecondary,
                                    fontSize = 11.sp
                                )
                            }
                        }
                    }
                }
            },
            confirmButton = {},
            dismissButton = {
                TextButton(onClick = { showTemplatesDialog = false }) {
                    Text("Dismiss", color = AtikTextMuted)
                }
            }
        )
    }
}

/**
 * Editor workspace with synchronized line numbers and monospaced code text area.
 */
@Composable
fun EditorWorkspace(
    currentCode: String,
    selectedLanguage: SupportedLanguage,
    onCodeChange: (String) -> Unit
) {
    val scrollState = rememberScrollState()
    val horizontalScroll = rememberScrollState()

    val lines = currentCode.lines()
    val lineCount = lines.size.coerceAtLeast(1)

    Row(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF070B12))
    ) {
        // Line Numbers Gutter
        Column(
            modifier = Modifier
                .width(42.dp)
                .fillMaxHeight()
                .background(Color(0xFF04060A))
                .verticalScroll(scrollState)
                .padding(vertical = 12.dp),
            horizontalAlignment = Alignment.End
        ) {
            for (i in 1..lineCount) {
                Text(
                    text = "$i ",
                    color = AtikTextMuted.copy(alpha = 0.6f),
                    fontFamily = FontFamily.Monospace,
                    fontSize = 12.sp,
                    lineHeight = 20.sp,
                    modifier = Modifier.padding(end = 6.dp)
                )
            }
        }

        // Divider
        Box(
            modifier = Modifier
                .width(1.dp)
                .fillMaxHeight()
                .background(AtikBorder)
        )

        // Code Editor Input Area
        Box(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(scrollState)
                .horizontalScroll(horizontalScroll)
                .padding(12.dp)
        ) {
            BasicTextField(
                value = currentCode,
                onValueChange = onCodeChange,
                textStyle = TextStyle(
                    color = AtikTextPrimary,
                    fontFamily = FontFamily.Monospace,
                    fontSize = 12.5.sp,
                    lineHeight = 20.sp
                ),
                cursorBrush = SolidColor(AtikNeonCyan),
                modifier = Modifier
                    .fillMaxSize()
                    .testTag("ide_code_input_field")
            )
        }
    }
}

/**
 * Live Output Preview & Console tab.
 * Renders embedded WebView for HTML/CSS/Web-JS, or simulated terminal console for Python/Kotlin/C++.
 */
@Composable
fun LivePreviewAndConsole(
    selectedLanguage: SupportedLanguage,
    executionResult: IdeExecutionResult?,
    isRunning: Boolean,
    isMobileViewport: Boolean,
    onToggleViewport: () -> Unit,
    onClearOutput: () -> Unit,
    onRunCode: () -> Unit,
    onDebugWithAi: () -> Unit,
    webViewKey: Int
) {
    val isWeb = selectedLanguage.isWebVisual && executionResult?.isWebPreview == true

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF070B12))
            .padding(12.dp)
    ) {
        // Canvas Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = if (isWeb) Icons.Default.Visibility else Icons.Default.Terminal,
                    contentDescription = null,
                    tint = AtikNeonCyan,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = if (isWeb) "Live Web Preview Canvas" else "Terminal Console Output",
                    color = AtikTextPrimary,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold
                )

                if (executionResult != null) {
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "• ${executionResult.executionTimeMs}ms",
                        color = AtikTextMuted,
                        fontSize = 11.sp
                    )
                }
            }

            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                if (isWeb) {
                    IconButton(
                        onClick = onToggleViewport,
                        modifier = Modifier.size(30.dp).testTag("btn_toggle_viewport")
                    ) {
                        Icon(
                            imageVector = if (isMobileViewport) Icons.Default.PhoneAndroid else Icons.Default.Laptop,
                            contentDescription = "Toggle Viewport",
                            tint = AtikNeonCyan,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }

                IconButton(
                    onClick = onRunCode,
                    modifier = Modifier.size(30.dp).testTag("btn_reload_preview")
                ) {
                    Icon(Icons.Default.Refresh, contentDescription = "Reload", tint = AtikTextSecondary, modifier = Modifier.size(16.dp))
                }

                IconButton(
                    onClick = onClearOutput,
                    modifier = Modifier.size(30.dp).testTag("btn_clear_console_output")
                ) {
                    Icon(Icons.Default.Clear, contentDescription = "Clear", tint = AtikTextMuted, modifier = Modifier.size(16.dp))
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        if (isRunning) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    CircularProgressIndicator(color = AtikNeonCyan, modifier = Modifier.size(36.dp))
                    Spacer(modifier = Modifier.height(10.dp))
                    Text("Compiling and executing code...", color = AtikTextSecondary, fontSize = 12.sp)
                }
            }
        } else if (isWeb && executionResult?.htmlPayload != null) {
            // Render interactive HTML/CSS WebView Canvas
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .clip(RoundedCornerShape(12.dp))
                    .border(1.dp, AtikBorder, RoundedCornerShape(12.dp))
                    .background(Color.White),
                contentAlignment = Alignment.Center
            ) {
                val viewportModifier = if (isMobileViewport) {
                    Modifier.fillMaxHeight().width(380.dp)
                } else {
                    Modifier.fillMaxSize()
                }

                AndroidView(
                    factory = { ctx ->
                        WebView(ctx).apply {
                            settings.javaScriptEnabled = true
                            settings.domStorageEnabled = true
                            settings.loadWithOverviewMode = true
                            settings.useWideViewPort = true
                            settings.cacheMode = WebSettings.LOAD_NO_CACHE
                            webViewClient = WebViewClient()
                            loadDataWithBaseURL(null, executionResult.htmlPayload, "text/html", "UTF-8", null)
                        }
                    },
                    update = { view ->
                        view.loadDataWithBaseURL(null, executionResult.htmlPayload, "text/html", "UTF-8", null)
                    },
                    modifier = viewportModifier.testTag("webview_canvas_preview")
                )
            }
        } else {
            // Standard Terminal / Console Output View
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = Color(0xFF030509),
                border = BorderStroke(1.dp, AtikBorder),
                modifier = Modifier.fillMaxSize().testTag("container_terminal_output")
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .verticalScroll(rememberScrollState())
                        .padding(14.dp)
                ) {
                    if (executionResult == null) {
                        Text(
                            text = "No execution data. Tap 'Run' or 'Render' in the top bar to execute your ${selectedLanguage.displayName} script.",
                            color = AtikTextMuted,
                            fontFamily = FontFamily.Monospace,
                            fontSize = 11.5.sp
                        )
                    } else if (executionResult.error != null) {
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = AtikError.copy(alpha = 0.12f),
                            border = BorderStroke(1.dp, AtikError.copy(alpha = 0.4f)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(10.dp)) {
                                Text(
                                    text = "Runtime Error Detected",
                                    color = AtikError,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = executionResult.error,
                                    color = AtikTextPrimary,
                                    fontFamily = FontFamily.Monospace,
                                    fontSize = 11.5.sp
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                Button(
                                    onClick = onDebugWithAi,
                                    colors = ButtonDefaults.buttonColors(containerColor = AtikError),
                                    shape = RoundedCornerShape(6.dp),
                                    modifier = Modifier.height(30.dp)
                                ) {
                                    Icon(Icons.Default.BugReport, null, modifier = Modifier.size(12.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Ask Atik AI to Fix", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    } else {
                        Text(
                            text = executionResult.output.ifBlank { "Program exited successfully with no standard console output." },
                            color = Color(0xFFE2E8F0),
                            fontFamily = FontFamily.Monospace,
                            fontSize = 12.sp,
                            lineHeight = 18.sp
                        )
                    }
                }
            }
        }
    }
}

/**
 * Diagnostics & Analysis Tab.
 */
@Composable
fun DiagnosticsTabContent(
    logs: List<DiagnosticLog>,
    onApplyAiFix: () -> Unit,
    onRefactor: () -> Unit
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF070B12))
            .padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "AI Diagnostic Center",
                    color = AtikTextPrimary,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold
                )

                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Button(
                        onClick = onApplyAiFix,
                        colors = ButtonDefaults.buttonColors(containerColor = AtikSurfaceVariant),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.height(32.dp)
                    ) {
                        Icon(Icons.Default.BugReport, null, tint = AtikNeonCyan, modifier = Modifier.size(13.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Debug & Fix", color = AtikNeonCyan, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }

                    Button(
                        onClick = onRefactor,
                        colors = ButtonDefaults.buttonColors(containerColor = AtikSurfaceVariant),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.height(32.dp)
                    ) {
                        Icon(Icons.Default.AutoAwesome, null, tint = AtikNeonAzure, modifier = Modifier.size(13.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Refactor", color = AtikNeonAzure, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        if (logs.isEmpty()) {
            item {
                Card(
                    shape = RoundedCornerShape(10.dp),
                    colors = CardDefaults.cardColors(containerColor = AtikSurface),
                    border = BorderStroke(1.dp, AtikBorder),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "No diagnostic events yet. Run your code or ask the AI Assistant for code reviews.",
                        color = AtikTextMuted,
                        fontSize = 12.sp,
                        modifier = Modifier.padding(16.dp)
                    )
                }
            }
        } else {
            items(logs) { log ->
                val (color, badge) = when (log.severity) {
                    DiagnosticSeverity.SUCCESS -> AtikSuccess to "SUCCESS"
                    DiagnosticSeverity.INFO -> AtikNeonCyan to "INFO"
                    DiagnosticSeverity.WARNING -> Color(0xFFFFB74D) to "WARNING"
                    DiagnosticSeverity.ERROR -> AtikError to "ERROR"
                }

                Card(
                    shape = RoundedCornerShape(10.dp),
                    colors = CardDefaults.cardColors(containerColor = AtikSurface),
                    border = BorderStroke(1.dp, color.copy(alpha = 0.4f)),
                    modifier = Modifier.fillMaxWidth().testTag("diagnostic_card_${log.timestamp}")
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Surface(
                                shape = RoundedCornerShape(4.dp),
                                color = color.copy(alpha = 0.15f)
                            ) {
                                Text(
                                    text = badge,
                                    color = color,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                            if (log.line != null) {
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Line ${log.line}", color = AtikTextMuted, fontSize = 10.5.sp)
                            }
                        }

                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = log.message,
                            color = AtikTextPrimary,
                            fontSize = 12.sp,
                            lineHeight = 16.sp
                        )

                        if (log.suggestion != null) {
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "💡 Suggestion: ${log.suggestion}",
                                color = AtikNeonAzure,
                                fontSize = 11.sp
                            )
                        }
                    }
                }
            }
        }
    }
}
