package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.AccentColorOption
import com.example.ui.theme.AppButtonStyle
import com.example.ui.theme.BackgroundWidgetType
import com.example.ui.theme.DynamicThemeState
import com.example.ui.theme.PRESET_ACCENT_COLORS
import com.example.ui.theme.ThemePreset

/**
 * Dynamic Home-Screen Theme Changer & Customization Studio (Step 25 Requirements 1, 2, 3).
 * Live interactive bottom sheet for selecting presets, accents, button contours, font scaling, and widgets.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DynamicThemeStudioSheet(
    isVisible: Boolean,
    themeState: DynamicThemeState,
    onSelectPreset: (ThemePreset) -> Unit,
    onSelectAccent: (AccentColorOption) -> Unit,
    onSelectButtonStyle: (AppButtonStyle) -> Unit,
    onSelectFontScale: (Float) -> Unit,
    onSelectBackgroundWidget: (BackgroundWidgetType) -> Unit,
    onDismiss: () -> Unit,
    modifier: Modifier = Modifier
) {
    if (!isVisible) return

    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = themeState.preset.defaultSurface,
        dragHandle = null,
        modifier = modifier
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 18.dp, vertical = 20.dp)
                .navigationBarsPadding()
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Surface(
                        shape = CircleShape,
                        color = themeState.accentColor.copy(alpha = 0.2f),
                        modifier = Modifier.size(36.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Text(text = "🎨", fontSize = 18.sp)
                        }
                    }
                    Column {
                        Text(
                            text = "Dynamic Theme Studio",
                            color = themeState.preset.defaultTextPrimary,
                            fontSize = 17.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Instant styling, accents & typography",
                            color = themeState.preset.defaultTextSecondary,
                            fontSize = 12.sp
                        )
                    }
                }

                Button(
                    onClick = onDismiss,
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = themeState.accentColor.copy(alpha = 0.2f),
                        contentColor = themeState.accentColor
                    )
                ) {
                    Text(text = "Done", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Voice Command Hint Card
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                color = themeState.preset.defaultSurfaceVariant,
                border = BorderStroke(1.dp, themeState.preset.defaultBorder)
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text(text = "🎙️", fontSize = 20.sp)
                    Column {
                        Text(
                            text = "Voice Command Supported",
                            color = themeState.preset.defaultTextPrimary,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Say: 'Change theme to 80s Synthwave' or 'Switch to AMOLED Dark'",
                            color = themeState.preset.defaultTextSecondary,
                            fontSize = 11.sp
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // 1. Predefined Themes
            Text(
                text = "PREDEFINED THEMES",
                color = themeState.accentColor,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp
            )
            Spacer(modifier = Modifier.height(8.dp))

            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                ThemePreset.values().forEach { preset ->
                    val isSelected = themeState.preset == preset

                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onSelectPreset(preset) },
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = if (isSelected) preset.defaultSurfaceHighlight else preset.defaultSurfaceVariant
                        ),
                        border = BorderStroke(
                            if (isSelected) 2.dp else 1.dp,
                            if (isSelected) themeState.accentColor else preset.defaultBorder
                        )
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(10.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                // Color Gradient Palette Preview Pill
                                Box(
                                    modifier = Modifier
                                        .size(36.dp)
                                        .clip(CircleShape)
                                        .background(Brush.sweepGradient(preset.previewGradient))
                                        .border(1.dp, Color.White.copy(alpha = 0.3f), CircleShape)
                                )
                                Column {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        Text(text = preset.iconEmoji, fontSize = 14.sp)
                                        Text(
                                            text = preset.displayName,
                                            color = preset.defaultTextPrimary,
                                            fontSize = 14.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                    Text(
                                        text = preset.description,
                                        color = preset.defaultTextSecondary,
                                        fontSize = 11.sp,
                                        maxLines = 1
                                    )
                                }
                            }

                            if (isSelected) {
                                Surface(
                                    shape = CircleShape,
                                    color = themeState.accentColor,
                                    modifier = Modifier.size(22.dp)
                                ) {
                                    Box(contentAlignment = Alignment.Center) {
                                        Text(text = "✓", color = Color.Black, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                    }
                }
            }

            HorizontalDivider(modifier = Modifier.padding(vertical = 16.dp), color = themeState.preset.defaultBorder)

            // 2. Custom Accent Colors
            Text(
                text = "ACCENT COLOR RADIANCE",
                color = themeState.accentColor,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp
            )
            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                PRESET_ACCENT_COLORS.forEach { opt ->
                    val isSelected = themeState.accentColorHex.equals(opt.hex, ignoreCase = true)
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.clickable { onSelectAccent(opt) }
                    ) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .clip(CircleShape)
                                .background(opt.color)
                                .border(
                                    if (isSelected) 3.dp else 1.dp,
                                    if (isSelected) Color.White else Color.Transparent,
                                    CircleShape
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            if (isSelected) {
                                Text(text = "✓", color = if (opt.color == Color.White) Color.Black else Color.White, fontWeight = FontWeight.Bold)
                            }
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = opt.name.split(" ").last(),
                            fontSize = 10.sp,
                            color = if (isSelected) themeState.accentColor else themeState.preset.defaultTextSecondary,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                        )
                    }
                }
            }

            HorizontalDivider(modifier = Modifier.padding(vertical = 16.dp), color = themeState.preset.defaultBorder)

            // 3. Button Styles
            Text(
                text = "BUTTON CONTOURS & SHAPES",
                color = themeState.accentColor,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp
            )
            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                AppButtonStyle.values().forEach { style ->
                    val isSelected = themeState.buttonStyle == style
                    Button(
                        onClick = { onSelectButtonStyle(style) },
                        modifier = Modifier.weight(1f),
                        shape = style.getShape(),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (isSelected) themeState.accentColor else themeState.preset.defaultSurfaceVariant,
                            contentColor = if (isSelected) (if (themeState.preset == ThemePreset.MINIMAL_LIGHT) Color.White else Color.Black) else themeState.preset.defaultTextPrimary
                        ),
                        border = BorderStroke(
                            1.dp,
                            if (isSelected) themeState.accentColor else themeState.preset.defaultBorder
                        )
                    ) {
                        Text(
                            text = style.icon,
                            fontSize = 13.sp
                        )
                    }
                }
            }

            HorizontalDivider(modifier = Modifier.padding(vertical = 16.dp), color = themeState.preset.defaultBorder)

            // 4. Font Scale Customization
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "FONT SCALING",
                    color = themeState.accentColor,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp
                )
                Text(
                    text = "${String.format("%.2f", themeState.fontScale)}x",
                    color = themeState.accentColor,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold
                )
            }
            Spacer(modifier = Modifier.height(4.dp))

            Slider(
                value = themeState.fontScale,
                onValueChange = onSelectFontScale,
                valueRange = 0.85f..1.30f,
                steps = 3,
                colors = SliderDefaults.colors(
                    thumbColor = themeState.accentColor,
                    activeTrackColor = themeState.accentColor,
                    inactiveTrackColor = themeState.preset.defaultBorder
                )
            )

            // Live Text Scale Preview
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(10.dp),
                color = themeState.preset.defaultSurfaceVariant,
                border = BorderStroke(1.dp, themeState.preset.defaultBorder)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text(
                        text = "Aa The quick brown fox jumps over the lazy dog",
                        fontSize = (13 * themeState.fontScale).sp,
                        color = themeState.preset.defaultTextPrimary,
                        fontWeight = FontWeight.Medium
                    )
                    Text(
                        text = "আসসালামু আলাইকুম আতিক ভাই 👋",
                        fontSize = (12 * themeState.fontScale).sp,
                        color = themeState.accentColor,
                        fontWeight = FontWeight.Normal
                    )
                }
            }

            HorizontalDivider(modifier = Modifier.padding(vertical = 16.dp), color = themeState.preset.defaultBorder)

            // 5. Dynamic Background Widget
            Text(
                text = "HOME-SCREEN DYNAMIC WIDGET",
                color = themeState.accentColor,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp
            )
            Spacer(modifier = Modifier.height(8.dp))

            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                BackgroundWidgetType.values().forEach { widget ->
                    val isSelected = themeState.backgroundWidget == widget

                    FilterChip(
                        selected = isSelected,
                        onClick = { onSelectBackgroundWidget(widget) },
                        label = {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)
                            ) {
                                Text(text = widget.iconEmoji, fontSize = 16.sp)
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = widget.displayName,
                                        fontSize = 13.sp,
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                        color = if (isSelected) themeState.accentColor else themeState.preset.defaultTextPrimary
                                    )
                                    Text(
                                        text = widget.description,
                                        fontSize = 11.sp,
                                        color = themeState.preset.defaultTextSecondary
                                    )
                                }
                            }
                        },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = themeState.preset.defaultSurfaceHighlight,
                            containerColor = themeState.preset.defaultSurfaceVariant
                        ),
                        border = FilterChipDefaults.filterChipBorder(
                            enabled = true,
                            selected = isSelected,
                            borderColor = themeState.preset.defaultBorder,
                            selectedBorderColor = themeState.accentColor
                        ),
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        }
    }
}
