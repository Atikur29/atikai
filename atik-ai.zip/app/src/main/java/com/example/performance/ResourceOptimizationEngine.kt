package com.example.performance

import android.app.ActivityManager
import android.content.Context
import android.content.SharedPreferences
import android.os.Environment
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

enum class PowerProfileMode(val title: String, val description: String, val iconEmoji: String) {
    BALANCED("Balanced Mode", "Dynamic balance between battery longevity and responsive performance", "⚖️"),
    BATTERY_SAVER("Battery Saver", "Minimizes CPU cycles, simplifies animations, and halts background telemetry", "🔋"),
    PERFORMANCE_TURBO("Ultra Turbo", "Maximum animation smoothness, eager AI model caching, and lowest latency", "🚀")
}

data class MemoryDiagnostics(
    val usedHeapMb: Float = 0f,
    val totalHeapMb: Float = 0f,
    val maxHeapMb: Float = 0f,
    val availableSystemRamMb: Long = 0L,
    val totalSystemRamMb: Long = 0L,
    val heapUsagePercent: Int = 0,
    val statusText: String = "Optimal"
)

data class StorageDiagnostics(
    val cacheSizeBytes: Long = 0L,
    val cacheSizeFormatted: String = "0 KB",
    val tempMediaSizeBytes: Long = 0L,
    val tempMediaFormatted: String = "0 KB",
    val totalCleanableFormatted: String = "0 KB",
    val lastCleanedFormatted: String = "Never",
    val autoCleanEnabled: Boolean = true,
    val autoCleanThresholdMb: Int = 30
)

data class OptimizationResult(
    val freedMemoryMb: Float,
    val clearedStorageBytes: Long,
    val clearedStorageFormatted: String,
    val executionTimeMs: Long,
    val timestamp: Long = System.currentTimeMillis()
)

/**
 * App Performance & Resource Optimization Engine (Step 15).
 * Optimizes battery consumption, RAM allocations, background workloads,
 * and maintains an automated cache and temporary resource cleaner.
 */
class ResourceOptimizationEngine(private val context: Context) {

    private val prefs: SharedPreferences =
        context.getSharedPreferences("atik_performance_prefs", Context.MODE_PRIVATE)

    private val _powerProfile = MutableStateFlow(
        try {
            PowerProfileMode.valueOf(prefs.getString("power_profile", PowerProfileMode.BALANCED.name) ?: PowerProfileMode.BALANCED.name)
        } catch (_: Exception) {
            PowerProfileMode.BALANCED
        }
    )
    val powerProfile: StateFlow<PowerProfileMode> = _powerProfile.asStateFlow()

    private val _memoryDiagnostics = MutableStateFlow(MemoryDiagnostics())
    val memoryDiagnostics: StateFlow<MemoryDiagnostics> = _memoryDiagnostics.asStateFlow()

    private val _storageDiagnostics = MutableStateFlow(StorageDiagnostics())
    val storageDiagnostics: StateFlow<StorageDiagnostics> = _storageDiagnostics.asStateFlow()

    private val _isOptimizing = MutableStateFlow(false)
    val isOptimizing: StateFlow<Boolean> = _isOptimizing.asStateFlow()

    private val _lastOptimizationResult = MutableStateFlow<OptimizationResult?>(null)
    val lastOptimizationResult: StateFlow<OptimizationResult?> = _lastOptimizationResult.asStateFlow()

    init {
        refreshDiagnostics()
        checkAndRunAutoCleanup()
    }

    /**
     * Refreshes RAM, Java Heap, and Cache size metrics.
     */
    fun refreshDiagnostics() {
        // Memory Diagnostics
        val runtime = Runtime.getRuntime()
        val totalMemory = runtime.totalMemory()
        val freeMemory = runtime.freeMemory()
        val maxMemory = runtime.maxMemory()
        val usedMemory = totalMemory - freeMemory

        val usedMb = usedMemory / (1024f * 1024f)
        val totalMb = totalMemory / (1024f * 1024f)
        val maxMb = maxMemory / (1024f * 1024f)
        val heapPercent = if (maxMb > 0) ((usedMb / maxMb) * 100).toInt().coerceIn(0, 100) else 0

        val actManager = context.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager
        val memInfo = ActivityManager.MemoryInfo()
        actManager?.getMemoryInfo(memInfo)

        val availSysMb = memInfo.availMem / (1024L * 1024L)
        val totalSysMb = memInfo.totalMem / (1024L * 1024L)

        val status = when {
            heapPercent < 50 -> "Optimal"
            heapPercent < 80 -> "Moderate"
            else -> "High Load"
        }

        _memoryDiagnostics.value = MemoryDiagnostics(
            usedHeapMb = usedMb,
            totalHeapMb = totalMb,
            maxHeapMb = maxMb,
            availableSystemRamMb = availSysMb,
            totalSystemRamMb = totalSysMb,
            heapUsagePercent = heapPercent,
            statusText = status
        )

        // Storage Diagnostics
        val cacheDirSize = getDirectorySize(context.cacheDir)
        val codeCacheDirSize = getDirectorySize(context.codeCacheDir)
        val extCacheSize = context.externalCacheDir?.let { getDirectorySize(it) } ?: 0L
        val totalCache = cacheDirSize + codeCacheDirSize + extCacheSize

        val lastCleanedTime = prefs.getLong("last_cleaned_time", 0L)
        val lastCleanedStr = if (lastCleanedTime > 0) {
            SimpleDateFormat("MMM d, h:mm a", Locale.getDefault()).format(Date(lastCleanedTime))
        } else {
            "Never"
        }

        val autoClean = prefs.getBoolean("auto_clean_enabled", true)
        val autoThreshold = prefs.getInt("auto_clean_threshold_mb", 30)

        _storageDiagnostics.value = StorageDiagnostics(
            cacheSizeBytes = totalCache,
            cacheSizeFormatted = formatBytes(totalCache),
            tempMediaSizeBytes = cacheDirSize,
            tempMediaFormatted = formatBytes(cacheDirSize),
            totalCleanableFormatted = formatBytes(totalCache),
            lastCleanedFormatted = lastCleanedStr,
            autoCleanEnabled = autoClean,
            autoCleanThresholdMb = autoThreshold
        )
    }

    /**
     * Executes a full system optimization sweep:
     * 1. Purges disk cache files and temporary vision/audio buffers.
     * 2. Clears dead references and requests Garbage Collection.
     * 3. Calculates memory and storage recovery metrics.
     */
    suspend fun runOptimizationSweep(): OptimizationResult = withContext(Dispatchers.IO) {
        _isOptimizing.value = true
        val startTime = System.currentTimeMillis()

        val initialUsedMemory = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory()
        val initialCacheSize = _storageDiagnostics.value.cacheSizeBytes

        // 1. Purge internal cache dir
        deleteDirectoryContents(context.cacheDir)
        // 2. Purge external cache if available
        context.externalCacheDir?.let { deleteDirectoryContents(it) }

        // 3. Suggest JVM Garbage Collection
        System.gc()

        val postUsedMemory = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory()
        val freedMemoryBytes = (initialUsedMemory - postUsedMemory).coerceAtLeast(0L)
        val freedMemoryMb = freedMemoryBytes / (1024f * 1024f)

        val clearedStorage = initialCacheSize.coerceAtLeast(0L)
        val duration = System.currentTimeMillis() - startTime

        // Update preferences
        val now = System.currentTimeMillis()
        prefs.edit().putLong("last_cleaned_time", now).apply()

        val result = OptimizationResult(
            freedMemoryMb = String.format(Locale.US, "%.1f", freedMemoryMb).toFloat(),
            clearedStorageBytes = clearedStorage,
            clearedStorageFormatted = formatBytes(clearedStorage),
            executionTimeMs = duration,
            timestamp = now
        )

        _lastOptimizationResult.value = result
        _isOptimizing.value = false

        refreshDiagnostics()
        result
    }

    /**
     * Checks if automated cleanup threshold has been met.
     */
    private fun checkAndRunAutoCleanup() {
        val autoClean = prefs.getBoolean("auto_clean_enabled", true)
        val thresholdMb = prefs.getInt("auto_clean_threshold_mb", 30)

        if (autoClean) {
            val totalBytes = _storageDiagnostics.value.cacheSizeBytes
            val totalMb = totalBytes / (1024 * 1024)
            if (totalMb >= thresholdMb) {
                // Background purge
                deleteDirectoryContents(context.cacheDir)
                prefs.edit().putLong("last_cleaned_time", System.currentTimeMillis()).apply()
            }
        }
    }

    fun setPowerProfile(mode: PowerProfileMode) {
        _powerProfile.value = mode
        prefs.edit().putString("power_profile", mode.name).apply()
    }

    fun setAutoCleanConfig(enabled: Boolean, thresholdMb: Int) {
        prefs.edit()
            .putBoolean("auto_clean_enabled", enabled)
            .putInt("auto_clean_threshold_mb", thresholdMb)
            .apply()
        refreshDiagnostics()
    }

    private fun getDirectorySize(dir: File?): Long {
        if (dir == null || !dir.exists()) return 0L
        var size = 0L
        val files = dir.listFiles() ?: return 0L
        for (file in files) {
            size += if (file.isDirectory) getDirectorySize(file) else file.length()
        }
        return size
    }

    private fun deleteDirectoryContents(dir: File?): Boolean {
        if (dir == null || !dir.exists() || !dir.isDirectory) return false
        var success = true
        val files = dir.listFiles() ?: return true
        for (file in files) {
            if (file.isDirectory) {
                success = deleteDirectoryContents(file) && success
                file.delete()
            } else {
                success = file.delete() && success
            }
        }
        return success
    }

    private fun formatBytes(bytes: Long): String {
        return when {
            bytes >= 1024 * 1024 * 1024 -> String.format(Locale.US, "%.1f GB", bytes / (1024f * 1024f * 1024f))
            bytes >= 1024 * 1024 -> String.format(Locale.US, "%.1f MB", bytes / (1024f * 1024f))
            bytes >= 1024 -> String.format(Locale.US, "%.1f KB", bytes / 1024f)
            else -> "$bytes B"
        }
    }
}
