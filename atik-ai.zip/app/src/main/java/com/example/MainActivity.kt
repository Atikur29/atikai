package com.example

import android.os.Bundle
import android.content.Intent
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.AtikViewModel
import com.example.ui.MainScreen
import com.example.ui.theme.AtikAiTheme
import com.example.widget.FloatingBubbleService

class MainActivity : ComponentActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()
    setContent {
      val viewModel: AtikViewModel = viewModel()
      val themeMode by viewModel.themeMode.collectAsStateWithLifecycle()
      val dynamicThemeState by viewModel.dynamicThemeState.collectAsStateWithLifecycle()

      LaunchedEffect(intent) {
        if (intent?.getBooleanExtra(FloatingBubbleService.EXTRA_OPEN_VOICE_OVERLAY, false) == true) {
          viewModel.setQuickOverlayVisible(true)
        }
      }

      AtikAiTheme(
        dynamicThemeState = dynamicThemeState,
        themeMode = themeMode
      ) {
        Surface(
          modifier = Modifier.fillMaxSize(),
          color = MaterialTheme.colorScheme.background
        ) {
          MainScreen(viewModel = viewModel)
        }
      }
    }
  }

  override fun onNewIntent(intent: Intent) {
    super.onNewIntent(intent)
    setIntent(intent)
  }
}
