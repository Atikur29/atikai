package com.example.accessibility

import java.util.UUID

/**
 * Supported messaging and telecommunication target platforms (Step 24 Requirement 2).
 */
enum class TargetMessagingApp(
    val id: String,
    val displayName: String,
    val primaryPackage: String,
    val iconEmoji: String,
    val secondaryPackages: List<String> = emptyList()
) {
    WHATSAPP(
        id = "WHATSAPP",
        displayName = "WhatsApp",
        primaryPackage = "com.whatsapp",
        iconEmoji = "💬",
        secondaryPackages = listOf("com.whatsapp.w4b")
    ),
    IMO(
        id = "IMO",
        displayName = "Imo Messenger",
        primaryPackage = "com.imo.android.imoim",
        iconEmoji = "📞",
        secondaryPackages = listOf("com.imo.android.imolite", "com.imo.android.imoimbeta")
    ),
    MESSAGES(
        id = "MESSAGES",
        displayName = "SMS / Messages",
        primaryPackage = "com.google.android.apps.messaging",
        iconEmoji = "✉️",
        secondaryPackages = listOf("com.samsung.android.messaging")
    ),
    PHONE(
        id = "PHONE",
        displayName = "Phone Dialer",
        primaryPackage = "com.google.android.dialer",
        iconEmoji = "📱",
        secondaryPackages = listOf("com.samsung.android.dialer", "com.android.dialer")
    ),
    TELEGRAM(
        id = "TELEGRAM",
        displayName = "Telegram",
        primaryPackage = "org.telegram.messenger",
        iconEmoji = "✈️",
        secondaryPackages = listOf("org.telegram.messenger.web")
    );

    fun matchesPackage(pkgName: String?): Boolean {
        if (pkgName == null) return false
        return pkgName == primaryPackage || secondaryPackages.contains(pkgName)
    }

    companion object {
        fun fromPackage(pkgName: String?): TargetMessagingApp? {
            if (pkgName == null) return null
            return values().firstOrNull { it.matchesPackage(pkgName) }
        }
    }
}

/**
 * Types of smart actions executable through Accessibility and Intents.
 */
enum class SmartActionType(val displayName: String, val icon: String) {
    SEND_MESSAGE("Send Message", "💬"),
    VOICE_CALL("Voice Call", "📞"),
    VIDEO_CALL("Video Call", "📹"),
    DIAL_NUMBER("Direct Dial", "📱")
}

/**
 * Request specification for a smart action.
 */
data class SmartActionRequest(
    val id: String = UUID.randomUUID().toString(),
    val targetApp: TargetMessagingApp,
    val actionType: SmartActionType,
    val recipient: String,
    val messageText: String? = null,
    val requireConfirmation: Boolean = true,
    val createdAt: Long = System.currentTimeMillis()
)

/**
 * Real-time execution phases emitted during action lifecycle (Step 24 Requirement 4).
 */
sealed class SmartActionPhase {
    object Idle : SmartActionPhase()

    data class AwaitingConsent(
        val request: SmartActionRequest,
        val secondsRemaining: Int
    ) : SmartActionPhase()

    data class LaunchingApp(
        val app: TargetMessagingApp,
        val recipient: String
    ) : SmartActionPhase()

    data class LocatingContact(
        val app: TargetMessagingApp,
        val recipient: String
    ) : SmartActionPhase()

    data class ComposingMessage(
        val app: TargetMessagingApp,
        val recipient: String,
        val snippet: String
    ) : SmartActionPhase()

    data class InitiatingCall(
        val app: TargetMessagingApp,
        val recipient: String,
        val callType: String
    ) : SmartActionPhase()

    data class ExecutingTouch(
        val app: TargetMessagingApp,
        val actionDescription: String
    ) : SmartActionPhase()

    data class Completed(
        val request: SmartActionRequest,
        val feedbackSummary: String
    ) : SmartActionPhase()

    data class Cancelled(
        val request: SmartActionRequest,
        val reason: String
    ) : SmartActionPhase()

    data class Failed(
        val request: SmartActionRequest,
        val error: String
    ) : SmartActionPhase()
}
