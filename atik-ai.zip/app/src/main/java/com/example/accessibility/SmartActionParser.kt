package com.example.accessibility

import java.util.regex.Pattern

/**
 * Natural Language Parser for Voice and Text Smart Messaging & Calling Commands (Step 24 Requirement 2).
 * Supports English, Bengali (বাংলা), and Banglish formats.
 */
object SmartActionParser {

    /**
     * Attempts to parse a user command into a SmartActionRequest.
     * Returns null if the text does not contain a messaging or calling intent.
     */
    fun parseCommand(input: String): SmartActionRequest? {
        val raw = input.trim()
        if (raw.isBlank()) return null
        val lower = raw.lowercase()

        // 1. Check for Target App keywords
        val targetApp = detectTargetApp(lower)

        // 2. Determine Action Type (Video Call, Voice Call, Dial, Send Message)
        val actionType = detectActionType(lower)

        // 3. Extract Recipient & Message
        val (recipient, message) = extractRecipientAndMessage(raw, targetApp, actionType)

        if (recipient.isBlank()) {
            return null
        }

        return SmartActionRequest(
            targetApp = targetApp,
            actionType = actionType,
            recipient = recipient.trim(),
            messageText = message?.trim()?.takeIf { it.isNotBlank() },
            requireConfirmation = true
        )
    }

    private fun detectTargetApp(lower: String): TargetMessagingApp {
        return when {
            lower.contains("whatsapp") || lower.contains("হোয়াটসঅ্যাপ") || lower.contains("হোয়াটসঅ্যাপ") -> TargetMessagingApp.WHATSAPP
            lower.contains("imo") || lower.contains("ইমো") -> TargetMessagingApp.IMO
            lower.contains("telegram") || lower.contains("টেলিগ্রাম") -> TargetMessagingApp.TELEGRAM
            lower.contains("sms") || lower.contains("এসএমএস") || lower.contains("text message") -> TargetMessagingApp.MESSAGES
            lower.contains("call") || lower.contains("dial") || lower.contains("কল") || lower.contains("ফোন") -> TargetMessagingApp.PHONE
            else -> TargetMessagingApp.WHATSAPP // Default to WhatsApp for general messaging
        }
    }

    private fun detectActionType(lower: String): SmartActionType {
        return when {
            lower.contains("video call") || lower.contains("ভিডিও কল") -> SmartActionType.VIDEO_CALL
            lower.contains("voice call") || lower.contains("অডিও কল") || lower.contains("ভয়েস কল") -> SmartActionType.VOICE_CALL
            lower.contains("dial") || (lower.contains("কল") && !lower.contains("মেসেজ") && !lower.contains("message")) ||
                    (lower.contains("call") && !lower.contains("message") && !lower.contains("text")) -> {
                if (lower.contains("whatsapp") || lower.contains("imo")) SmartActionType.VOICE_CALL else SmartActionType.DIAL_NUMBER
            }
            else -> SmartActionType.SEND_MESSAGE
        }
    }

    private fun extractRecipientAndMessage(
        raw: String,
        targetApp: TargetMessagingApp,
        actionType: SmartActionType
    ): Pair<String, String?> {
        val lower = raw.lowercase()

        // Pattern 1: Colon separator (e.g. "Send WhatsApp to Mom: I'm on the way", "হোয়াটসঅ্যাপে মাকে: আসছি")
        if (raw.contains(":")) {
            val parts = raw.split(":", limit = 2)
            val header = parts[0]
            val message = parts[1].trim()
            val recipient = cleanRecipient(header, targetApp)
            return Pair(recipient, message)
        }

        // Pattern 2: "saying" or "বলে" (e.g. "Send message to Karim on WhatsApp saying I will be late")
        val sayingPattern = Pattern.compile("(?i)(?:saying|that|বলে|বলুন|লিখে)\\s+(.+)$")
        val sayingMatcher = sayingPattern.matcher(raw)
        if (sayingMatcher.find()) {
            val message = sayingMatcher.group(1)?.trim()
            val prefix = raw.substring(0, sayingMatcher.start()).trim()
            val recipient = cleanRecipient(prefix, targetApp)
            return Pair(recipient, message)
        }

        // Pattern 3: "to <Recipient>" (e.g. "Call to Tariq on Imo", "Send WhatsApp to 01711223344")
        val toPattern = Pattern.compile("(?i)(?:to|কে)\\s+([a-zA-Z0-9+\\s]+)(?:on|in|using|দ্বারা|দিয়ে)?")
        val toMatcher = toPattern.matcher(raw)
        if (toMatcher.find()) {
            val recipient = cleanRecipient(toMatcher.group(1) ?: "", targetApp)
            return Pair(recipient, null)
        }

        // Pattern 4: Fallback cleanup
        val cleaned = cleanRecipient(raw, targetApp)
        return Pair(cleaned, null)
    }

    private fun cleanRecipient(raw: String, targetApp: TargetMessagingApp): String {
        var res = raw
        val wordsToRemove = listOf(
            "send", "message", "whatsapp", "imo", "telegram", "sms", "text", "call", "dial", "voice", "video",
            "to", "on", "in", "via", "please", "using", "with",
            "পাঠাও", "মেসেজ", "বার্তা", "হোয়াটসঅ্যাপে", "হোয়াটসঅ্যাপ", "হোয়াটসঅ্যাপ", "ইমোতে", "ইমো",
            "টেলিগ্রাম", "এসএমএস", "কল", "ফোন", "করো", "দাও", "দিয়ে", "দ্বারা", "কে"
        )

        for (w in wordsToRemove) {
            res = res.replace("(?i)\\b$w\\b".toRegex(), "")
        }
        res = res.replace("[:,!?-]".toRegex(), " ")
        return res.trim().replace("\\s+".toRegex(), " ")
    }
}
