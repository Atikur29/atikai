package com.example.accessibility

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.util.Log
import android.widget.Toast
import com.example.data.AtikDataStorePreferences
import com.example.data.ChatRepository
import com.example.data.SmartActionAuditEntity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Smart Action Automation Engine (Step 24 Requirements 1, 2, 3, 4).
 * Coordinates User Consent, Safety Guardrails, Intent Dispatch,
 * Accessibility Automation, Audit Logging, and Real-Time Screen Feedback.
 */
class SmartActionAutomationEngine(
    private val context: Context,
    private val repository: ChatRepository,
    private val dataStorePreferences: AtikDataStorePreferences
) {
    private val engineScope = CoroutineScope(Dispatchers.Main + Job())
    private var countdownJob: Job? = null

    private val _livePhase = MutableStateFlow<SmartActionPhase>(SmartActionPhase.Idle)
    val livePhase: StateFlow<SmartActionPhase> = _livePhase.asStateFlow()

    // Active pending request waiting for user confirmation
    private val _pendingConsentRequest = MutableStateFlow<SmartActionRequest?>(null)
    val pendingConsentRequest: StateFlow<SmartActionRequest?> = _pendingConsentRequest.asStateFlow()

    companion object {
        private const val TAG = "SmartActionEngine"
    }

    init {
        // Synchronize phase with AtikAccessibilityActionService
        engineScope.launch {
            AtikAccessibilityActionService.currentPhase.collect { servicePhase ->
                if (servicePhase !is SmartActionPhase.Idle) {
                    _livePhase.value = servicePhase
                    if (servicePhase is SmartActionPhase.Completed) {
                        recordAudit(servicePhase.request, "SUCCESS", servicePhase.feedbackSummary, null)
                    } else if (servicePhase is SmartActionPhase.Failed) {
                        recordAudit(servicePhase.request, "FAILED", null, servicePhase.error)
                    }
                }
            }
        }
    }

    /**
     * Entry point when voice or text triggers a smart action command.
     * Enforces strict safety guardrails and consent (Step 24 Requirement 3).
     */
    fun submitAction(request: SmartActionRequest) {
        engineScope.launch {
            // 1. Guardrail: Check master enable toggle
            val isMasterEnabled = dataStorePreferences.smartActionEnabled.first()
            if (!isMasterEnabled) {
                val msg = "⚠️ Smart Actions are currently disabled in Settings."
                _livePhase.value = SmartActionPhase.Cancelled(request, msg)
                Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
                return@launch
            }

            // 2. Guardrail: Check if target app is permitted
            val isAppAllowed = when (request.targetApp) {
                TargetMessagingApp.WHATSAPP -> dataStorePreferences.whatsappActionEnabled.first()
                TargetMessagingApp.IMO -> dataStorePreferences.imoActionEnabled.first()
                TargetMessagingApp.MESSAGES -> dataStorePreferences.smsActionEnabled.first()
                TargetMessagingApp.PHONE -> dataStorePreferences.phoneActionEnabled.first()
                TargetMessagingApp.TELEGRAM -> true
            }

            if (!isAppAllowed) {
                val msg = "⚠️ Automation for ${request.targetApp.displayName} is toggled off in Safety Guardrails."
                _livePhase.value = SmartActionPhase.Cancelled(request, msg)
                Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
                recordAudit(request, "CANCELLED", null, "App blocked by safety toggle")
                return@launch
            }

            // 3. User Consent & Countdown (Requirement 3)
            val requireConfirmation = dataStorePreferences.requireConfirmation.first()
            val countdownSecs = dataStorePreferences.countdownSeconds.first().toInt().coerceIn(3, 15)

            _pendingConsentRequest.value = request

            if (requireConfirmation) {
                startConsentCountdown(request, countdownSecs)
            } else {
                executeActionDirectly(request)
            }
        }
    }

    /**
     * Starts interactive safety countdown allowing the user to review or abort (Step 24 Requirement 3 & 4).
     */
    private fun startConsentCountdown(request: SmartActionRequest, totalSeconds: Int) {
        countdownJob?.cancel()
        countdownJob = engineScope.launch {
            for (sec in totalSeconds downTo 1) {
                _livePhase.value = SmartActionPhase.AwaitingConsent(request, sec)
                delay(1000)
            }
            // Once countdown finishes without cancellation, proceed to execute
            _pendingConsentRequest.value = null
            executeActionDirectly(request)
        }
    }

    /**
     * Explicit user approval via UI confirmation button ("Confirm & Send Now").
     */
    fun confirmAndExecuteNow() {
        countdownJob?.cancel()
        val request = _pendingConsentRequest.value ?: return
        _pendingConsentRequest.value = null
        executeActionDirectly(request)
    }

    /**
     * Explicit user abort via UI abort button ("Cancel / Stop Action").
     */
    fun abortAction(reason: String = "Cancelled by user") {
        countdownJob?.cancel()
        countdownJob = null
        val request = _pendingConsentRequest.value
        _pendingConsentRequest.value = null

        AtikAccessibilityActionService.abortCurrentAction(reason)

        if (request != null) {
            _livePhase.value = SmartActionPhase.Cancelled(request, reason)
            recordAudit(request, "CANCELLED", null, reason)
        } else {
            _livePhase.value = SmartActionPhase.Idle
        }
    }

    fun dismissFeedback() {
        _livePhase.value = SmartActionPhase.Idle
        _pendingConsentRequest.value = null
    }

    /**
     * Executes the requested smart action via Accessibility Service or Intent fallback.
     */
    private fun executeActionDirectly(request: SmartActionRequest) {
        engineScope.launch {
            _livePhase.value = SmartActionPhase.LaunchingApp(request.targetApp, request.recipient)
            delay(400)

            val isAccessibilityOn = AtikAccessibilityActionService.isAccessibilityEnabled(context)

            if (isAccessibilityOn && AtikAccessibilityActionService.isServiceConnected.value) {
                // Execute via Accessibility Service
                AtikAccessibilityActionService.setActiveRequest(request)
                launchTargetAppIntent(request)
            } else {
                // Execute via Direct Intent fallback
                executeViaIntentFallback(request)
            }
        }
    }

    /**
     * Launches target app so Accessibility Service can detect the window and automate touch/typing.
     */
    private fun launchTargetAppIntent(request: SmartActionRequest) {
        try {
            when (request.targetApp) {
                TargetMessagingApp.WHATSAPP -> {
                    // Try direct phone link first if number, else package launch
                    val isNumber = request.recipient.replace("[+\\s-]".toRegex(), "").all { it.isDigit() }
                    val intent = if (isNumber && request.recipient.length >= 7) {
                        val cleanNum = request.recipient.replace("[^0-9+]".toRegex(), "")
                        val uri = "https://api.whatsapp.com/send?phone=$cleanNum&text=${Uri.encode(request.messageText ?: "")}"
                        Intent(Intent.ACTION_VIEW, Uri.parse(uri)).apply {
                            setPackage("com.whatsapp")
                            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        }
                    } else {
                        context.packageManager.getLaunchIntentForPackage("com.whatsapp")?.apply {
                            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        }
                    }

                    if (intent != null) {
                        context.startActivity(intent)
                    } else {
                        executeViaIntentFallback(request)
                    }
                }
                TargetMessagingApp.IMO -> {
                    val intent = context.packageManager.getLaunchIntentForPackage(request.targetApp.primaryPackage)?.apply {
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                    if (intent != null) {
                        context.startActivity(intent)
                    } else {
                        executeViaIntentFallback(request)
                    }
                }
                TargetMessagingApp.MESSAGES -> {
                    val uri = Uri.parse("smsto:${Uri.encode(request.recipient)}")
                    val intent = Intent(Intent.ACTION_SENDTO, uri).apply {
                        putExtra("sms_body", request.messageText ?: "")
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                    context.startActivity(intent)
                }
                TargetMessagingApp.PHONE -> {
                    val uri = Uri.parse("tel:${Uri.encode(request.recipient)}")
                    val intent = Intent(Intent.ACTION_DIAL, uri).apply {
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                    context.startActivity(intent)
                }
                TargetMessagingApp.TELEGRAM -> {
                    val intent = context.packageManager.getLaunchIntentForPackage("org.telegram.messenger")?.apply {
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                    if (intent != null) {
                        context.startActivity(intent)
                    } else {
                        executeViaIntentFallback(request)
                    }
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error launching target intent", e)
            executeViaIntentFallback(request)
        }
    }

    /**
     * Fallback mechanism when Accessibility Service is not yet active or app is opened directly.
     */
    private fun executeViaIntentFallback(request: SmartActionRequest) {
        try {
            when (request.actionType) {
                SmartActionType.SEND_MESSAGE -> {
                    if (request.targetApp == TargetMessagingApp.WHATSAPP) {
                        val cleanNum = request.recipient.replace("[^0-9+]".toRegex(), "")
                        val uri = if (cleanNum.length >= 7) {
                            "https://api.whatsapp.com/send?phone=$cleanNum&text=${Uri.encode(request.messageText ?: "")}"
                        } else {
                            "https://api.whatsapp.com/send?text=${Uri.encode(request.messageText ?: "")}"
                        }
                        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(uri)).apply {
                            setPackage("com.whatsapp")
                            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        }
                        context.startActivity(intent)
                    } else if (request.targetApp == TargetMessagingApp.IMO) {
                        val intent = context.packageManager.getLaunchIntentForPackage(request.targetApp.primaryPackage)?.apply {
                            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        }
                        if (intent != null) {
                            context.startActivity(intent)
                        } else {
                            // Try browser or market
                            val marketIntent = Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=${request.targetApp.primaryPackage}")).apply {
                                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            }
                            context.startActivity(marketIntent)
                        }
                    } else {
                        val smsIntent = Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:${Uri.encode(request.recipient)}")).apply {
                            putExtra("sms_body", request.messageText ?: "")
                            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        }
                        context.startActivity(smsIntent)
                    }
                }
                SmartActionType.VOICE_CALL, SmartActionType.DIAL_NUMBER -> {
                    val dialIntent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:${Uri.encode(request.recipient)}")).apply {
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                    context.startActivity(dialIntent)
                }
                SmartActionType.VIDEO_CALL -> {
                    val intent = context.packageManager.getLaunchIntentForPackage(request.targetApp.primaryPackage)?.apply {
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                    if (intent != null) context.startActivity(intent)
                }
            }

            val summary = "${request.actionType.displayName} initiated for ${request.recipient} on ${request.targetApp.displayName}"
            _livePhase.value = SmartActionPhase.Completed(request, summary)
            recordAudit(request, "SUCCESS", summary, null)
        } catch (e: Exception) {
            Log.e(TAG, "Intent fallback failed", e)
            _livePhase.value = SmartActionPhase.Failed(request, e.localizedMessage ?: "Failed to open target app")
            recordAudit(request, "FAILED", null, e.localizedMessage)
        }
    }

    private fun recordAudit(
        request: SmartActionRequest,
        status: String,
        messageSnippet: String?,
        errorMessage: String?
    ) {
        engineScope.launch(Dispatchers.IO) {
            try {
                repository.recordSmartActionAudit(
                    SmartActionAuditEntity(
                        targetApp = request.targetApp.name,
                        recipient = request.recipient,
                        actionType = request.actionType.name,
                        messageSnippet = request.messageText ?: messageSnippet,
                        status = status,
                        errorMessage = errorMessage,
                        executionMode = if (AtikAccessibilityActionService.isServiceConnected.value) "ACCESSIBILITY" else "INTENT_FALLBACK"
                    )
                )
            } catch (e: Exception) {
                Log.e(TAG, "Failed to record audit", e)
            }
        }
    }
}
