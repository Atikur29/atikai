package com.example.accessibility

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Context
import android.content.Intent
import android.graphics.Path
import android.graphics.Rect
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.util.Log
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityManager
import android.view.accessibility.AccessibilityNodeInfo
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

/**
 * Android Accessibility Service for automated messaging, touch/type actions,
 * and hands-free calling on Imo, WhatsApp, and Social Messaging apps (Step 24 Requirement 1 & 2).
 */
class AtikAccessibilityActionService : AccessibilityService() {

    private val serviceScope = CoroutineScope(Dispatchers.Main + Job())
    private var activeActionJob: Job? = null

    companion object {
        private const val TAG = "AtikAccessibilityService"

        @Volatile
        private var instance: AtikAccessibilityActionService? = null

        private val _isServiceConnected = MutableStateFlow(false)
        val isServiceConnected: StateFlow<Boolean> = _isServiceConnected.asStateFlow()

        private val _currentPhase = MutableStateFlow<SmartActionPhase>(SmartActionPhase.Idle)
        val currentPhase: StateFlow<SmartActionPhase> = _currentPhase.asStateFlow()

        private var activeRequest: SmartActionRequest? = null

        fun getInstance(): AtikAccessibilityActionService? = instance

        /**
         * Checks whether the user has enabled Atik AI Accessibility Service in Android Settings.
         */
        fun isAccessibilityEnabled(context: Context): Boolean {
            val am = context.getSystemService(Context.ACCESSIBILITY_SERVICE) as? AccessibilityManager ?: return false
            val enabledServices = Settings.Secure.getString(
                context.contentResolver,
                Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
            ) ?: return false

            val expectedComponentName = "${context.packageName}/${AtikAccessibilityActionService::class.java.name}"
            return enabledServices.contains(expectedComponentName) ||
                    enabledServices.contains("${context.packageName}/.accessibility.AtikAccessibilityActionService")
        }

        /**
         * Deep links to Android Accessibility Settings screen to guide the user.
         */
        fun openAccessibilitySettings(context: Context) {
            try {
                val intent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                }
                context.startActivity(intent)
            } catch (e: Exception) {
                Log.e(TAG, "Failed to open accessibility settings", e)
            }
        }

        /**
         * Aborts any currently executing automation action immediately.
         */
        fun abortCurrentAction(reason: String = "User requested immediate stop") {
            val req = activeRequest
            activeRequest = null
            instance?.activeActionJob?.cancel()
            instance?.activeActionJob = null
            if (req != null) {
                _currentPhase.value = SmartActionPhase.Cancelled(req, reason)
            } else {
                _currentPhase.value = SmartActionPhase.Idle
            }
        }

        fun updatePhase(phase: SmartActionPhase) {
            _currentPhase.value = phase
        }

        fun setActiveRequest(request: SmartActionRequest?) {
            activeRequest = request
        }

        fun getActiveRequest(): SmartActionRequest? = activeRequest
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        _isServiceConnected.value = true
        Log.i(TAG, "AtikAccessibilityActionService connected and active.")
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        val currentReq = activeRequest ?: return

        val pkgName = event.packageName?.toString() ?: ""
        if (!currentReq.targetApp.matchesPackage(pkgName)) return

        when (event.eventType) {
            AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED,
            AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED -> {
                handleTargetAppWindow(currentReq)
            }
        }
    }

    override fun onInterrupt() {
        Log.w(TAG, "AtikAccessibilityActionService interrupted")
        abortCurrentAction("Service interrupted by system")
    }

    override fun onDestroy() {
        super.onDestroy()
        if (instance == this) {
            instance = null
        }
        _isServiceConnected.value = false
        Log.i(TAG, "AtikAccessibilityActionService destroyed")
    }

    /**
     * Inspects target app window content to type, click send, or initiate voice/video call.
     */
    private fun handleTargetAppWindow(request: SmartActionRequest) {
        val rootNode = rootInActiveWindow ?: return

        when (request.targetApp) {
            TargetMessagingApp.WHATSAPP -> handleWhatsAppAutomation(rootNode, request)
            TargetMessagingApp.IMO -> handleImoAutomation(rootNode, request)
            TargetMessagingApp.MESSAGES -> handleMessagesAutomation(rootNode, request)
            TargetMessagingApp.PHONE -> handlePhoneAutomation(rootNode, request)
            TargetMessagingApp.TELEGRAM -> handleTelegramAutomation(rootNode, request)
        }
    }

    /**
     * WhatsApp smart automation: Locate input/send or call buttons.
     */
    private fun handleWhatsAppAutomation(root: AccessibilityNodeInfo, request: SmartActionRequest) {
        if (activeActionJob?.isActive == true) return

        activeActionJob = serviceScope.launch {
            try {
                when (request.actionType) {
                    SmartActionType.SEND_MESSAGE -> {
                        _currentPhase.value = SmartActionPhase.ComposingMessage(
                            request.targetApp,
                            request.recipient,
                            request.messageText ?: ""
                        )
                        delay(600)

                        // 1. Locate message input field
                        val inputNode = findNodeByViewId(root, "com.whatsapp:id/entry")
                            ?: findFirstEditText(root)

                        if (inputNode != null && !request.messageText.isNullOrBlank()) {
                            setTextToNode(inputNode, request.messageText)
                            delay(500)
                        }

                        // 2. Locate Send button
                        _currentPhase.value = SmartActionPhase.ExecutingTouch(
                            request.targetApp,
                            "Tapping Send button in WhatsApp"
                        )
                        delay(400)

                        val sendButton = findNodeByViewId(root, "com.whatsapp:id/send")
                            ?: findNodeByContentDescription(root, "Send", "পাঠান")

                        if (sendButton != null) {
                            val clicked = clickNodeOrGesture(sendButton)
                            if (clicked) {
                                delay(600)
                                finishSuccess(request, "Message successfully sent to ${request.recipient} on WhatsApp")
                                return@launch
                            }
                        }
                    }
                    SmartActionType.VOICE_CALL, SmartActionType.VIDEO_CALL -> {
                        val isVideo = request.actionType == SmartActionType.VIDEO_CALL
                        val callId = if (isVideo) "com.whatsapp:id/video_call" else "com.whatsapp:id/voice_call"
                        val descKeyword = if (isVideo) "Video call" else "Voice call"

                        _currentPhase.value = SmartActionPhase.InitiatingCall(
                            request.targetApp,
                            request.recipient,
                            if (isVideo) "Video Call" else "Voice Call"
                        )
                        delay(500)

                        val callBtn = findNodeByViewId(root, callId)
                            ?: findNodeByContentDescription(root, descKeyword, "কল")

                        if (callBtn != null) {
                            val clicked = clickNodeOrGesture(callBtn)
                            if (clicked) {
                                delay(500)
                                finishSuccess(request, "${if (isVideo) "Video" else "Voice"} call initiated with ${request.recipient} on WhatsApp")
                                return@launch
                            }
                        }
                    }
                    else -> {}
                }
            } catch (e: Exception) {
                Log.e(TAG, "WhatsApp automation failed", e)
                _currentPhase.value = SmartActionPhase.Failed(request, e.localizedMessage ?: "Unknown error in WhatsApp")
            } finally {
                activeActionJob = null
            }
        }
    }

    /**
     * Imo messenger smart automation: Locate message input, send, or call icons.
     */
    private fun handleImoAutomation(root: AccessibilityNodeInfo, request: SmartActionRequest) {
        if (activeActionJob?.isActive == true) return

        activeActionJob = serviceScope.launch {
            try {
                when (request.actionType) {
                    SmartActionType.SEND_MESSAGE -> {
                        _currentPhase.value = SmartActionPhase.ComposingMessage(
                            request.targetApp,
                            request.recipient,
                            request.messageText ?: ""
                        )
                        delay(600)

                        // 1. Locate message input field
                        val inputNode = findFirstEditText(root)

                        if (inputNode != null && !request.messageText.isNullOrBlank()) {
                            setTextToNode(inputNode, request.messageText)
                            delay(500)
                        }

                        // 2. Locate Send button
                        _currentPhase.value = SmartActionPhase.ExecutingTouch(
                            request.targetApp,
                            "Tapping Send button in Imo"
                        )
                        delay(400)

                        val sendBtn = findNodeByContentDescription(root, "Send", "পাঠান")
                            ?: findNodeByText(root, "Send", "পাঠান")

                        if (sendBtn != null) {
                            val clicked = clickNodeOrGesture(sendBtn)
                            if (clicked) {
                                delay(600)
                                finishSuccess(request, "Message successfully sent to ${request.recipient} on Imo")
                                return@launch
                            }
                        }
                    }
                    SmartActionType.VOICE_CALL, SmartActionType.VIDEO_CALL -> {
                        val isVideo = request.actionType == SmartActionType.VIDEO_CALL
                        val callKeyword = if (isVideo) "Video call" else "Call"

                        _currentPhase.value = SmartActionPhase.InitiatingCall(
                            request.targetApp,
                            request.recipient,
                            if (isVideo) "Video Call" else "Audio Call"
                        )
                        delay(500)

                        val callBtn = findNodeByContentDescription(root, callKeyword, "Audio call", "কল")

                        if (callBtn != null) {
                            val clicked = clickNodeOrGesture(callBtn)
                            if (clicked) {
                                delay(500)
                                finishSuccess(request, "${if (isVideo) "Video" else "Audio"} call initiated with ${request.recipient} on Imo")
                                return@launch
                            }
                        }
                    }
                    else -> {}
                }
            } catch (e: Exception) {
                Log.e(TAG, "Imo automation error", e)
                _currentPhase.value = SmartActionPhase.Failed(request, e.localizedMessage ?: "Unknown error in Imo")
            } finally {
                activeActionJob = null
            }
        }
    }

    /**
     * SMS/Messages smart automation.
     */
    private fun handleMessagesAutomation(root: AccessibilityNodeInfo, request: SmartActionRequest) {
        if (activeActionJob?.isActive == true) return

        activeActionJob = serviceScope.launch {
            try {
                if (request.actionType == SmartActionType.SEND_MESSAGE) {
                    val inputNode = findFirstEditText(root)
                    if (inputNode != null && !request.messageText.isNullOrBlank()) {
                        setTextToNode(inputNode, request.messageText)
                        delay(400)
                    }

                    val sendBtn = findNodeByContentDescription(root, "Send SMS", "Send", "SMS")
                    if (sendBtn != null) {
                        clickNodeOrGesture(sendBtn)
                        delay(500)
                        finishSuccess(request, "SMS sent to ${request.recipient}")
                    }
                }
            } catch (e: Exception) {
                Log.e(TAG, "Messages automation error", e)
            } finally {
                activeActionJob = null
            }
        }
    }

    /**
     * Phone dialer automation.
     */
    private fun handlePhoneAutomation(root: AccessibilityNodeInfo, request: SmartActionRequest) {
        if (activeActionJob?.isActive == true) return

        activeActionJob = serviceScope.launch {
            try {
                val callBtn = findNodeByContentDescription(root, "dial", "call", "Call", "Dial")
                if (callBtn != null) {
                    clickNodeOrGesture(callBtn)
                    delay(500)
                    finishSuccess(request, "Dialing ${request.recipient}...")
                }
            } catch (e: Exception) {
                Log.e(TAG, "Phone automation error", e)
            } finally {
                activeActionJob = null
            }
        }
    }

    /**
     * Telegram automation.
     */
    private fun handleTelegramAutomation(root: AccessibilityNodeInfo, request: SmartActionRequest) {
        if (activeActionJob?.isActive == true) return

        activeActionJob = serviceScope.launch {
            try {
                val inputNode = findFirstEditText(root)
                if (inputNode != null && !request.messageText.isNullOrBlank()) {
                    setTextToNode(inputNode, request.messageText)
                    delay(400)
                }

                val sendBtn = findNodeByContentDescription(root, "Send")
                if (sendBtn != null) {
                    clickNodeOrGesture(sendBtn)
                    delay(500)
                    finishSuccess(request, "Message sent to ${request.recipient} on Telegram")
                }
            } catch (e: Exception) {
                Log.e(TAG, "Telegram automation error", e)
            } finally {
                activeActionJob = null
            }
        }
    }

    private fun finishSuccess(request: SmartActionRequest, summary: String) {
        activeRequest = null
        _currentPhase.value = SmartActionPhase.Completed(request, summary)
    }

    // ====== Node Traversal & Gesture Utilities ======

    private fun findFirstEditText(root: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        val queue = ArrayDeque<AccessibilityNodeInfo>()
        queue.add(root)

        while (queue.isNotEmpty()) {
            val node = queue.removeFirst()
            if (node.className?.contains("EditText", ignoreCase = true) == true) {
                return node
            }
            for (i in 0 until node.childCount) {
                node.getChild(i)?.let { queue.add(it) }
            }
        }
        return null
    }

    private fun findNodeByViewId(root: AccessibilityNodeInfo, viewId: String): AccessibilityNodeInfo? {
        val matches = root.findAccessibilityNodeInfosByViewId(viewId)
        return matches.firstOrNull()
    }

    private fun findNodeByContentDescription(root: AccessibilityNodeInfo, vararg keywords: String): AccessibilityNodeInfo? {
        val queue = ArrayDeque<AccessibilityNodeInfo>()
        queue.add(root)

        while (queue.isNotEmpty()) {
            val node = queue.removeFirst()
            val desc = node.contentDescription?.toString()
            if (desc != null) {
                for (kw in keywords) {
                    if (desc.contains(kw, ignoreCase = true)) {
                        return node
                    }
                }
            }
            for (i in 0 until node.childCount) {
                node.getChild(i)?.let { queue.add(it) }
            }
        }
        return null
    }

    private fun findNodeByText(root: AccessibilityNodeInfo, vararg keywords: String): AccessibilityNodeInfo? {
        for (kw in keywords) {
            val matches = root.findAccessibilityNodeInfosByText(kw)
            if (matches.isNotEmpty()) return matches.first()
        }
        return null
    }

    private fun setTextToNode(node: AccessibilityNodeInfo, text: String): Boolean {
        val arguments = Bundle().apply {
            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
        }
        return node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, arguments)
    }

    private fun clickNodeOrGesture(node: AccessibilityNodeInfo): Boolean {
        if (node.isClickable && node.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
            return true
        }

        // Try clicking clickable parent
        var parent = node.parent
        while (parent != null) {
            if (parent.isClickable && parent.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
                return true
            }
            parent = parent.parent
        }

        // Fallback: Perform gesture click at screen coordinates
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            val rect = Rect()
            node.getBoundsInScreen(rect)
            if (!rect.isEmpty) {
                val clickPath = Path().apply {
                    moveTo(rect.centerX().toFloat(), rect.centerY().toFloat())
                }
                val gesture = GestureDescription.Builder()
                    .addStroke(GestureDescription.StrokeDescription(clickPath, 0, 100))
                    .build()
                return dispatchGesture(gesture, null, null)
            }
        }
        return false
    }
}
