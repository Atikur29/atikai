package com.example.voice

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Build
import android.os.Bundle
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.util.Locale

enum class WakeWordSensitivity(val displayName: String, val weight: Float, val description: String) {
    LOW("Low Sensitivity", 0.35f, "Strict phrase match, minimum false triggers"),
    MEDIUM("Medium (Recommended)", 0.65f, "Balanced natural voice detection"),
    HIGH("High Sensitivity", 0.90f, "Eager detection, triggers easily in noisy environments")
}

enum class VoiceDuplexState {
    STANDBY,
    WAKE_DETECTED,
    LISTENING,
    PROCESSING,
    SPEAKING,
    CONTINUOUS_PROMPT
}

enum class AudioCueType {
    WAKE,
    PROCESSING,
    SUCCESS,
    ERROR
}

/**
 * Interactive Live Voice Assistant & Wake-Word Engine (Step 21).
 * Provides hands-free "Hey Atik" wake-word detection, continuous duplex loop,
 * discrete audio chimes, and haptic feedback.
 */
class WakeWordEngine(private val context: Context) {

    private val prefs: SharedPreferences = context.getSharedPreferences("atik_wake_word_prefs", Context.MODE_PRIVATE)
    private val scope = CoroutineScope(Dispatchers.Main)

    private val vibrator: Vibrator? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
        val vm = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
        vm?.defaultVibrator
    } else {
        @Suppress("DEPRECATION")
        context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
    }

    private var toneGenerator: ToneGenerator? = try {
        ToneGenerator(AudioManager.STREAM_NOTIFICATION, 85)
    } catch (_: Exception) {
        null
    }

    // State flows
    private val _isWakeWordEnabled = MutableStateFlow(prefs.getBoolean("wake_word_enabled", true))
    val isWakeWordEnabled: StateFlow<Boolean> = _isWakeWordEnabled.asStateFlow()

    private val _sensitivity = MutableStateFlow(
        try {
            WakeWordSensitivity.valueOf(prefs.getString("sensitivity", WakeWordSensitivity.MEDIUM.name) ?: WakeWordSensitivity.MEDIUM.name)
        } catch (_: Exception) {
            WakeWordSensitivity.MEDIUM
        }
    )
    val sensitivity: StateFlow<WakeWordSensitivity> = _sensitivity.asStateFlow()

    private val _isHandsFreeDuplexEnabled = MutableStateFlow(prefs.getBoolean("duplex_enabled", true))
    val isHandsFreeDuplexEnabled: StateFlow<Boolean> = _isHandsFreeDuplexEnabled.asStateFlow()

    private val _isAudioChimeEnabled = MutableStateFlow(prefs.getBoolean("audio_chime_enabled", true))
    val isAudioChimeEnabled: StateFlow<Boolean> = _isAudioChimeEnabled.asStateFlow()

    private val _isHapticFeedbackEnabled = MutableStateFlow(prefs.getBoolean("haptic_enabled", true))
    val isHapticFeedbackEnabled: StateFlow<Boolean> = _isHapticFeedbackEnabled.asStateFlow()

    private val _duplexState = MutableStateFlow(VoiceDuplexState.STANDBY)
    val duplexState: StateFlow<VoiceDuplexState> = _duplexState.asStateFlow()

    private val _lastDetectedPhrase = MutableStateFlow("")
    val lastDetectedPhrase: StateFlow<String> = _lastDetectedPhrase.asStateFlow()

    private val _rmsAmplitude = MutableStateFlow(0f)
    val rmsAmplitude: StateFlow<Float> = _rmsAmplitude.asStateFlow()

    private var wakeRecognizer: SpeechRecognizer? = null
    private var isListeningForWake = false
    var onWakeWordTriggered: ((phrase: String) -> Unit)? = null

    fun setWakeWordEnabled(enabled: Boolean) {
        _isWakeWordEnabled.value = enabled
        prefs.edit().putBoolean("wake_word_enabled", enabled).apply()
        if (enabled) {
            startWakeWordListening()
        } else {
            stopWakeWordListening()
        }
    }

    fun setSensitivity(sens: WakeWordSensitivity) {
        _sensitivity.value = sens
        prefs.edit().putString("sensitivity", sens.name).apply()
    }

    fun setSensitivityByWeight(weight: Float) {
        val sens = when {
            weight < 0.50f -> WakeWordSensitivity.LOW
            weight < 0.78f -> WakeWordSensitivity.MEDIUM
            else -> WakeWordSensitivity.HIGH
        }
        setSensitivity(sens)
    }

    fun setHandsFreeDuplexEnabled(enabled: Boolean) {
        _isHandsFreeDuplexEnabled.value = enabled
        prefs.edit().putBoolean("duplex_enabled", enabled).apply()
    }

    fun setAudioChimeEnabled(enabled: Boolean) {
        _isAudioChimeEnabled.value = enabled
        prefs.edit().putBoolean("audio_chime_enabled", enabled).apply()
    }

    fun setHapticFeedbackEnabled(enabled: Boolean) {
        _isHapticFeedbackEnabled.value = enabled
        prefs.edit().putBoolean("haptic_enabled", enabled).apply()
    }

    fun setDuplexState(state: VoiceDuplexState) {
        _duplexState.value = state
    }

    // =========================================================================
    // AUDIO CHIMES & HAPTIC FEEDBACK
    // =========================================================================

    fun playAudioCue(type: AudioCueType) {
        if (!_isAudioChimeEnabled.value) return
        try {
            when (type) {
                AudioCueType.WAKE -> {
                    // Ascending crisp tone cue
                    toneGenerator?.startTone(ToneGenerator.TONE_PROP_ACK, 120)
                }
                AudioCueType.PROCESSING -> {
                    // Discrete subtle beep
                    toneGenerator?.startTone(ToneGenerator.TONE_PROP_BEEP, 70)
                }
                AudioCueType.SUCCESS -> {
                    // Cheerful confirm chime
                    toneGenerator?.startTone(ToneGenerator.TONE_PROP_ACK, 150)
                }
                AudioCueType.ERROR -> {
                    // Low warning buzz
                    toneGenerator?.startTone(ToneGenerator.TONE_PROP_NACK, 120)
                }
            }
        } catch (e: Exception) {
            Log.e("WakeWordEngine", "Tone generator error: ${e.message}")
        }
    }

    fun triggerHaptic(type: AudioCueType) {
        if (!_isHapticFeedbackEnabled.value || vibrator == null || !vibrator.hasVibrator()) return
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                when (type) {
                    AudioCueType.WAKE -> {
                        // Quick energetic pulse
                        vibrator.vibrate(VibrationEffect.createOneShot(45, VibrationEffect.DEFAULT_AMPLITUDE))
                    }
                    AudioCueType.PROCESSING -> {
                        // Double subtle micro-tick
                        val timings = longArrayOf(0, 25, 40, 25)
                        val amplitudes = intArrayOf(0, 140, 0, 170)
                        vibrator.vibrate(VibrationEffect.createWaveform(timings, amplitudes, -1))
                    }
                    AudioCueType.SUCCESS -> {
                        // Smooth confirmation pulse
                        vibrator.vibrate(VibrationEffect.createOneShot(60, 180))
                    }
                    AudioCueType.ERROR -> {
                        // Double buzz warning
                        val timings = longArrayOf(0, 60, 50, 60)
                        val amplitudes = intArrayOf(0, 220, 0, 220)
                        vibrator.vibrate(VibrationEffect.createWaveform(timings, amplitudes, -1))
                    }
                }
            } else {
                @Suppress("DEPRECATION")
                when (type) {
                    AudioCueType.WAKE -> vibrator.vibrate(45)
                    AudioCueType.PROCESSING -> vibrator.vibrate(longArrayOf(0, 25, 30, 25), -1)
                    AudioCueType.SUCCESS -> vibrator.vibrate(60)
                    AudioCueType.ERROR -> vibrator.vibrate(100)
                }
            }
        } catch (_: Exception) {}
    }

    // =========================================================================
    // WAKE-WORD DETECTION ENGINE
    // =========================================================================

    /**
     * Checks if a transcript matches "Hey Atik", "Atik AI", or flexible phonetic variations.
     */
    fun matchesWakeWord(text: String): Boolean {
        val lower = text.trim().lowercase(Locale.ROOT)
        if (lower.isEmpty()) return false

        // Exact & standard wake-words
        val primaryPhrases = listOf(
            "hey atik", "hey atique", "hey ateek", "atik ai", "atique ai",
            "hello atik", "hi atik", "ok atik", "okay atik", "hey atikur",
            "আতিক", "এই আতিক", "হে আতিক", "আতিক এআই"
        )

        for (phrase in primaryPhrases) {
            if (lower.contains(phrase)) return true
        }

        // Sensitivity-adjusted matching
        when (_sensitivity.value) {
            WakeWordSensitivity.HIGH -> {
                // High sensitivity accepts single-word "atik", "atique", "ateek"
                if (lower.contains("atik") || lower.contains("atique") || lower.contains("ateek") || lower.contains("আতিক")) {
                    return true
                }
            }
            WakeWordSensitivity.MEDIUM -> {
                // Medium sensitivity accepts "atik" if preceded or followed by greetings or AI keywords
                if ((lower.contains("atik") || lower.contains("atique")) &&
                    (lower.contains("hey") || lower.contains("hi") || lower.contains("ai") || lower.contains("hello") || lower.contains("assistant") || lower.contains("boss"))
                ) {
                    return true
                }
            }
            WakeWordSensitivity.LOW -> {
                // Low sensitivity strictly requires "hey atik" or "atik ai"
                return lower.contains("hey atik") || lower.contains("atik ai")
            }
        }

        return false
    }

    /**
     * Starts continuous low-latency wake-word monitoring.
     */
    fun startWakeWordListening() {
        if (!_isWakeWordEnabled.value || isListeningForWake) return
        if (!SpeechRecognizer.isRecognitionAvailable(context)) {
            Log.w("WakeWordEngine", "SpeechRecognizer is unavailable on this device")
            return
        }

        stopWakeWordListening()
        isListeningForWake = true
        _duplexState.value = VoiceDuplexState.STANDBY

        scope.launch {
            try {
                wakeRecognizer = SpeechRecognizer.createSpeechRecognizer(context).apply {
                    setRecognitionListener(object : RecognitionListener {
                        override fun onReadyForSpeech(params: Bundle?) {}

                        override fun onBeginningOfSpeech() {}

                        override fun onRmsChanged(rmsdB: Float) {
                            _rmsAmplitude.value = rmsdB
                        }

                        override fun onBufferReceived(buffer: ByteArray?) {}

                        override fun onEndOfSpeech() {}

                        override fun onError(error: Int) {
                            // Automatically restart listening if still enabled
                            if (isListeningForWake && _isWakeWordEnabled.value) {
                                scope.launch {
                                    delay(400)
                                    restartWakeWordListener()
                                }
                            }
                        }

                        override fun onResults(results: Bundle?) {
                            val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                            val transcript = matches?.firstOrNull().orEmpty()
                            checkAndHandleTranscript(transcript)

                            if (isListeningForWake && _isWakeWordEnabled.value) {
                                restartWakeWordListener()
                            }
                        }

                        override fun onPartialResults(partialResults: Bundle?) {
                            val matches = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                            val partial = matches?.firstOrNull().orEmpty()
                            if (checkAndHandleTranscript(partial)) {
                                // Cancel further speech listening as wake-word is confirmed
                                wakeRecognizer?.stopListening()
                            }
                        }

                        override fun onEvent(eventType: Int, params: Bundle?) {}
                    })
                }

                val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                    putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
                    putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, context.packageName)
                }

                wakeRecognizer?.startListening(intent)
            } catch (e: Exception) {
                Log.e("WakeWordEngine", "Error launching wake word listener: ${e.message}")
            }
        }
    }

    private fun checkAndHandleTranscript(transcript: String): Boolean {
        if (matchesWakeWord(transcript)) {
            _lastDetectedPhrase.value = transcript
            _duplexState.value = VoiceDuplexState.WAKE_DETECTED

            // Audio chime & haptic trigger
            playAudioCue(AudioCueType.WAKE)
            triggerHaptic(AudioCueType.WAKE)

            onWakeWordTriggered?.invoke(transcript)
            return true
        }
        return false
    }

    private fun restartWakeWordListener() {
        try {
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
                putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, context.packageName)
            }
            wakeRecognizer?.startListening(intent)
        } catch (_: Exception) {}
    }

    fun stopWakeWordListening() {
        isListeningForWake = false
        try {
            wakeRecognizer?.stopListening()
            wakeRecognizer?.cancel()
            wakeRecognizer?.destroy()
        } catch (_: Exception) {}
        wakeRecognizer = null
        _duplexState.value = VoiceDuplexState.STANDBY
    }

    fun destroy() {
        stopWakeWordListening()
        try {
            toneGenerator?.release()
        } catch (_: Exception) {}
        toneGenerator = null
    }
}
