package com.example.voice

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.util.Log
import com.example.ai.LanguageMode
import com.example.translation.VoiceAccent
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.Locale

enum class VoiceGender(val displayName: String, val description: String) {
    DYNAMIC("Adaptive AI Voice", "Natural smart assistant tone"),
    MALE("Confident Male Timbre", "Deeper warrior timbre with crisp authority"),
    FEMALE("Expressive Female Voice", "Smooth melodic pacing with warm clarity")
}

class VoiceManager(private val context: Context) : TextToSpeech.OnInitListener {

    private var tts: TextToSpeech? = null
    private var isTtsReady = false

    var userPitch: Float = 1.0f
    var userSpeed: Float = 1.0f
    var userGender: VoiceGender = VoiceGender.DYNAMIC
    var userAccent: VoiceAccent = VoiceAccent.US_ENGLISH

    fun configureVoice(speed: Float, pitch: Float, gender: VoiceGender, accent: VoiceAccent = VoiceAccent.US_ENGLISH) {
        this.userSpeed = speed.coerceIn(0.6f, 2.0f)
        this.userPitch = pitch.coerceIn(0.6f, 1.5f)
        this.userGender = gender
        this.userAccent = accent
    }

    private var speechRecognizer: SpeechRecognizer? = null

    private val _isListening = MutableStateFlow(false)
    val isListening: StateFlow<Boolean> = _isListening.asStateFlow()

    private val _isSpeaking = MutableStateFlow(false)
    val isSpeaking: StateFlow<Boolean> = _isSpeaking.asStateFlow()

    private val _spokenText = MutableStateFlow("")
    val spokenText: StateFlow<String> = _spokenText.asStateFlow()

    private val _rmsDb = MutableStateFlow(0f)
    val rmsDb: StateFlow<Float> = _rmsDb.asStateFlow()

    init {
        try {
            tts = TextToSpeech(context.applicationContext, this)
        } catch (e: Exception) {
            Log.e("VoiceManager", "Failed to init TTS: ${e.message}")
        }
    }

    var onSpeakingDone: (() -> Unit)? = null
    var onBossSignatureDone: (() -> Unit)? = null

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            isTtsReady = true
            tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {
                    _isSpeaking.value = true
                }

                override fun onDone(utteranceId: String?) {
                    _isSpeaking.value = false
                    if (utteranceId?.startsWith("BossSignature") == true) {
                        val cb = onBossSignatureDone
                        onBossSignatureDone = null
                        cb?.invoke()
                    } else {
                        onSpeakingDone?.invoke()
                    }
                }

                @Deprecated("Deprecated in Java")
                override fun onError(utteranceId: String?) {
                    _isSpeaking.value = false
                    if (utteranceId?.startsWith("BossSignature") == true) {
                        val cb = onBossSignatureDone
                        onBossSignatureDone = null
                        cb?.invoke()
                    } else {
                        onSpeakingDone?.invoke()
                    }
                }
            })
        }
    }

    /**
     * Speaks the signature warrior response in a confident, energetic voice:
     * "Okay boss, I am doing it right now!"
     */
    fun speakBossSignature(onComplete: (() -> Unit)? = null) {
        if (!isTtsReady || tts == null) {
            onComplete?.invoke()
            return
        }

        stopSpeaking()

        this.onBossSignatureDone = onComplete

        // Confident, crisp voice profile
        tts?.setPitch(1.08f)
        tts?.setSpeechRate(1.06f)
        tts?.setLanguage(Locale.US)

        val phrase = "Okay boss, I am doing it right now!"
        val utteranceId = "BossSignature_${System.currentTimeMillis()}"

        val params = Bundle()
        params.putString(TextToSpeech.Engine.KEY_PARAM_UTTERANCE_ID, utteranceId)
        tts?.speak(phrase, TextToSpeech.QUEUE_FLUSH, params, utteranceId)
    }

    fun speak(text: String, mode: LanguageMode, pitch: Float? = null, speed: Float? = null) {
        if (!isTtsReady || tts == null) return

        stopSpeaking()

        val basePitch = pitch ?: userPitch
        val effectivePitch = (basePitch * when (userGender) {
            VoiceGender.MALE -> 0.90f
            VoiceGender.FEMALE -> 1.18f
            VoiceGender.DYNAMIC -> 1.0f
        }).coerceIn(0.5f, 2.0f)

        val effectiveSpeed = (speed ?: userSpeed).coerceIn(0.5f, 2.0f)

        tts?.setPitch(effectivePitch)
        tts?.setSpeechRate(effectiveSpeed)

        val isBengali = mode == LanguageMode.BANGLA || mode == LanguageMode.BANGLISH || text.any { it in '\u0980'..'\u09FF' }
        val primaryLocale = if (isBengali) Locale("bn", "BD") else userAccent.locale

        var result = tts?.setLanguage(primaryLocale)
        if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
            if (isBengali) {
                result = tts?.setLanguage(Locale("bn", "IN"))
                if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                    result = tts?.setLanguage(Locale("bn"))
                }
            }
            if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                tts?.setLanguage(Locale.getDefault())
            }
        }

        // Clean markdown symbols for cleaner TTS speech
        val cleanedText = text
            .replace(Regex("```[\\s\\S]*?```"), " [কোড ব্লক বাদ দেওয়া হয়েছে] ")
            .replace(Regex("[*#`_~>]"), "")
            .trim()

        val params = Bundle()
        params.putString(TextToSpeech.Engine.KEY_PARAM_UTTERANCE_ID, "AtikTtsUtterance")
        tts?.speak(cleanedText, TextToSpeech.QUEUE_FLUSH, params, "AtikTtsUtterance")
    }

    /**
     * Speaks text in a specific global language locale (e.g. for translation playback).
     */
    fun speakInLocale(text: String, targetLocale: Locale, speed: Float? = null, pitch: Float? = null) {
        if (!isTtsReady) return
        stopSpeaking()

        val basePitch = pitch ?: userPitch
        val effectivePitch = (basePitch * when (userGender) {
            VoiceGender.MALE -> 0.90f
            VoiceGender.FEMALE -> 1.18f
            VoiceGender.DYNAMIC -> 1.0f
        }).coerceIn(0.5f, 2.0f)

        val effectiveSpeed = (speed ?: userSpeed).coerceIn(0.5f, 2.0f)
        tts?.setPitch(effectivePitch)
        tts?.setSpeechRate(effectiveSpeed)

        var result = tts?.setLanguage(targetLocale)
        if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
            tts?.setLanguage(Locale(targetLocale.language))
        }

        val cleanedText = text
            .replace(Regex("```[\\s\\S]*?```"), " ")
            .replace(Regex("[*#`_~>]"), "")
            .trim()

        val params = Bundle()
        params.putString(TextToSpeech.Engine.KEY_PARAM_UTTERANCE_ID, "AtikTtsTranslation")
        tts?.speak(cleanedText, TextToSpeech.QUEUE_FLUSH, params, "AtikTtsTranslation")
    }

    fun stopSpeaking() {
        if (isTtsReady) {
            tts?.stop()
            _isSpeaking.value = false
        }
    }

    fun testAuditionVoice(mode: LanguageMode) {
        val phrase = if (mode == LanguageMode.ENGLISH) {
            "Hello Atik! This is your customized voice configuration for Atik AI. How does my speech rate and pitch sound to you?"
        } else {
            "হ্যালো আতিক ভাই! এটি আপনার নির্বাচিত আতিক এআই ভয়েস প্রোফাইল।"
        }
        speak(phrase, mode)
    }

    fun startListening(mode: LanguageMode, onResult: (String) -> Unit, onError: (String) -> Unit) {
        if (!SpeechRecognizer.isRecognitionAvailable(context)) {
            onError("এই ডিভাইসে স্পিচ রিকগনিশন উপলব্ধ নেই।")
            return
        }

        stopSpeaking()
        stopListening()

        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(context).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) {
                    _isListening.value = true
                }

                override fun onBeginningOfSpeech() {}

                override fun onRmsChanged(rmsdB: Float) {
                    _rmsDb.value = rmsdB
                }

                override fun onBufferReceived(buffer: ByteArray?) {}

                override fun onEndOfSpeech() {
                    _isListening.value = false
                }

                override fun onError(error: Int) {
                    _isListening.value = false
                    val errorMsg = when (error) {
                        SpeechRecognizer.ERROR_NO_MATCH -> "কথা স্পষ্ট শোনা যায়নি।"
                        SpeechRecognizer.ERROR_NETWORK -> "নেটওয়ার্ক সমস্যা।"
                        SpeechRecognizer.ERROR_AUDIO -> "মাইক্রোফোন সমস্যা।"
                        else -> "ভয়েস ইনপুট ত্রুটি ($error)"
                    }
                    onError(errorMsg)
                }

                override fun onResults(results: Bundle?) {
                    _isListening.value = false
                    val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    val spoken = matches?.firstOrNull() ?: ""
                    if (spoken.isNotBlank()) {
                        _spokenText.value = spoken
                        onResult(spoken)
                    }
                }

                override fun onPartialResults(partialResults: Bundle?) {
                    val matches = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    val partial = matches?.firstOrNull() ?: ""
                    if (partial.isNotBlank()) {
                        _spokenText.value = partial
                    }
                }

                override fun onEvent(eventType: Int, params: Bundle?) {}
            })
        }

        val langTag = when (mode) {
            LanguageMode.BANGLA -> "bn-BD"
            LanguageMode.ENGLISH -> "en-US"
            LanguageMode.BANGLISH -> "bn-BD"
        }

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, langTag)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, langTag)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, context.packageName)
        }

        speechRecognizer?.startListening(intent)
    }

    fun stopListening() {
        try {
            speechRecognizer?.stopListening()
            speechRecognizer?.cancel()
            speechRecognizer?.destroy()
        } catch (e: Exception) {
            Log.e("VoiceManager", "Error stopping recognizer: ${e.message}")
        } finally {
            speechRecognizer = null
            _isListening.value = false
        }
    }

    fun destroy() {
        stopSpeaking()
        stopListening()
        tts?.shutdown()
        tts = null
    }
}
