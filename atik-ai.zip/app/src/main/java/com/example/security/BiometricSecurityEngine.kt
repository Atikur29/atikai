package com.example.security

import android.app.Activity
import android.app.KeyguardManager
import android.content.Context
import android.content.SharedPreferences
import android.os.Build
import android.os.CancellationSignal
import androidx.core.content.ContextCompat
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.security.MessageDigest

/**
 * Biometric & Master PIN Security Engine (Step 16 Requirement 1).
 * Manages Fingerprint / Face Unlock authentication and master PIN verification
 * to protect application access, chat history, and sensitive actions.
 */
class BiometricSecurityEngine(private val context: Context) {

    private val prefs: SharedPreferences =
        context.getSharedPreferences("atik_biometric_security_prefs", Context.MODE_PRIVATE)

    private val _isBiometricEnabled = MutableStateFlow(
        prefs.getBoolean("biometric_enabled", false)
    )
    val isBiometricEnabled: StateFlow<Boolean> = _isBiometricEnabled.asStateFlow()

    private val _hasMasterPin = MutableStateFlow(
        !prefs.getString("master_pin_hash", "").isNullOrBlank()
    )
    val hasMasterPin: StateFlow<Boolean> = _hasMasterPin.asStateFlow()

    // App lock state: if biometric is enabled, start locked
    private val _isAppLocked = MutableStateFlow(
        prefs.getBoolean("biometric_enabled", false) &&
                !prefs.getString("master_pin_hash", "").isNullOrBlank()
    )
    val isAppLocked: StateFlow<Boolean> = _isAppLocked.asStateFlow()

    private val _failedAttempts = MutableStateFlow(0)
    val failedAttempts: StateFlow<Int> = _failedAttempts.asStateFlow()

    private val _lockTimeoutMinutes = MutableStateFlow(
        prefs.getInt("lock_timeout_minutes", 0) // 0 = Immediately on background/start
    )
    val lockTimeoutMinutes: StateFlow<Int> = _lockTimeoutMinutes.asStateFlow()

    /**
     * Checks if the device has hardware biometrics (Fingerprint/Face) or secure Keyguard setup.
     */
    fun canDeviceUseBiometrics(): Boolean {
        val keyguardManager = context.getSystemService(Context.KEYGUARD_SERVICE) as? KeyguardManager
        return keyguardManager?.isKeyguardSecure == true
    }

    fun setBiometricEnabled(enabled: Boolean) {
        _isBiometricEnabled.value = enabled
        prefs.edit().putBoolean("biometric_enabled", enabled).apply()
        if (enabled && _hasMasterPin.value) {
            _isAppLocked.value = false
        }
    }

    fun setLockTimeout(minutes: Int) {
        _lockTimeoutMinutes.value = minutes
        prefs.edit().putInt("lock_timeout_minutes", minutes).apply()
    }

    fun setMasterPin(pin: String) {
        val hash = hashPin(pin)
        prefs.edit().putString("master_pin_hash", hash).apply()
        _hasMasterPin.value = true
        _isBiometricEnabled.value = true
        prefs.edit().putBoolean("biometric_enabled", true).apply()
    }

    fun verifyMasterPin(pin: String): Boolean {
        val storedHash = prefs.getString("master_pin_hash", "") ?: ""
        if (storedHash.isBlank()) return false

        val inputHash = hashPin(pin)
        val success = inputHash == storedHash
        if (success) {
            _isAppLocked.value = false
            _failedAttempts.value = 0
        } else {
            _failedAttempts.value += 1
        }
        return success
    }

    /**
     * Triggers Android Native Biometric Prompt via Keyguard/Biometrics.
     */
    fun triggerNativeBiometricAuth(
        activity: Activity,
        onSuccess: () -> Unit,
        onError: (String) -> Unit
    ) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            try {
                val prompt = android.hardware.biometrics.BiometricPrompt.Builder(activity)
                    .setTitle("Unlock Atik AI")
                    .setSubtitle("Confirm your fingerprint or biometric profile")
                    .setDescription("Authenticate to access your executive workspace")
                    .setNegativeButton("Use PIN", activity.mainExecutor) { _, _ ->
                        onError("PIN required")
                    }
                    .build()

                val cancellationSignal = CancellationSignal()
                prompt.authenticate(
                    cancellationSignal,
                    activity.mainExecutor,
                    object : android.hardware.biometrics.BiometricPrompt.AuthenticationCallback() {
                        override fun onAuthenticationSucceeded(result: android.hardware.biometrics.BiometricPrompt.AuthenticationResult?) {
                            super.onAuthenticationSucceeded(result)
                            _isAppLocked.value = false
                            _failedAttempts.value = 0
                            onSuccess()
                        }

                        override fun onAuthenticationError(errorCode: Int, errString: CharSequence?) {
                            super.onAuthenticationError(errorCode, errString)
                            onError(errString?.toString() ?: "Biometric error")
                        }

                        override fun onAuthenticationFailed() {
                            super.onAuthenticationFailed()
                            _failedAttempts.value += 1
                            onError("Biometric unrecognized. Please try again.")
                        }
                    }
                )
            } catch (e: Exception) {
                onError(e.message ?: "Biometric unavailable")
            }
        } else {
            onError("Biometrics not supported on this OS version")
        }
    }

    fun lockApp() {
        if (_isBiometricEnabled.value && _hasMasterPin.value) {
            _isAppLocked.value = true
        }
    }

    fun unlockAppDirectly() {
        _isAppLocked.value = false
        _failedAttempts.value = 0
    }

    private fun hashPin(pin: String): String {
        val digest = MessageDigest.getInstance("SHA-256")
        val hash = digest.digest(("atik_salt_v1_$pin").toByteArray())
        return hash.joinToString("") { "%02x".format(it) }
    }
}
