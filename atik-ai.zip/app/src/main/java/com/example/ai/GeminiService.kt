package com.example.ai

import android.content.Context
import android.graphics.Bitmap
import android.util.Base64
import com.example.BuildConfig
import com.example.knowledge.TechKnowledgeEngine
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.util.concurrent.TimeUnit

enum class LanguageMode(val displayName: String, val code: String) {
    BANGLA("বাংলা (Bangla)", "bn"),
    ENGLISH("English", "en"),
    BANGLISH("বাংলিশ (Banglish)", "banglish")
}

data class AiModelInfo(
    val id: String,
    val name: String,
    val description: String
)

val AVAILABLE_MODELS = listOf(
    AiModelInfo("gemini-3.8-flash", "Gemini 3.5 Flash", "দ্রুত, নির্ভরযোগ্য ও শক্তিশালী এআই টেক্সট মডেল (Default)"),
    AiModelInfo("gemini-3.1-pro-preview", "Gemini 3.1 Pro", "জটিল প্রোগ্রামিং, গণিত ও গভীর গবেষণার জন্য"),
    AiModelInfo("gemini-3.8-live", "Gemini Live Audio", "রিয়েল-টাইম দ্বি-মুখী লাইভ ভয়েস মডেল")
)

class GeminiService(private val context: Context) {

    private val client = OkHttpClient.Builder()
        .connectTimeout(60, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .build()

    private val jsonMediaType = "application/json; charset=utf-8".toMediaType()

    fun resolveModel(model: String): String {
        val clean = model.trim().lowercase()
        return when {
            clean.contains("live") || clean.contains("native-audio") -> "gemini-2.5-flash-native-audio-preview-12-2025"
            clean == "gemini-3.8-flash" || clean == "gemini-2.0-flash" || clean == "gemini-1.5-flash" || clean.isBlank() -> "gemini-3.5-flash"
            clean == "gemini-flash" || clean == "gemini-flash-latest" -> "gemini-flash-latest"
            clean == "gemini-lite" || clean == "flash-lite" -> "gemini-3.1-flash-lite-preview"
            clean == "gemini-pro" -> "gemini-3.1-pro-preview"
            else -> model.trim()
        }
    }

    /**
     * Resolves the active API key: user-custom key from preferences if set,
     * otherwise BuildConfig.GEMINI_API_KEY, with fallback to BuildConfig.ENV_GEMINI_API_KEY.
     */
    fun getResolvedApiKey(customKey: String?): String {
        if (!customKey.isNullOrBlank()) {
            return customKey.trim()
        }
        val buildKey = BuildConfig.GEMINI_API_KEY
        if (buildKey.isNotBlank() && buildKey != "MY_GEMINI_API_KEY") {
            return buildKey
        }
        try {
            val envField = BuildConfig::class.java.getField("ENV_GEMINI_API_KEY")
            val envVal = envField.get(null) as? String
            if (!envVal.isNullOrBlank()) {
                return envVal.trim()
            }
        } catch (_: Exception) {}
        return ""
    }

    fun isKeyConfigured(customKey: String?): Boolean {
        return getResolvedApiKey(customKey).isNotBlank()
    }

    suspend fun generateReply(
        prompt: String,
        history: List<Pair<String, String>>, // (role, text)
        languageMode: LanguageMode,
        memories: List<String>,
        model: String = "gemini-3.5-flash",
        customApiKey: String? = null,
        imageBitmap: Bitmap? = null
    ): Result<String> = withContext(Dispatchers.IO) {
        val apiKey = getResolvedApiKey(customApiKey)

        if (apiKey.isBlank()) {
            val localReply = generateLocalPersonaReply(prompt, languageMode, memories)
            return@withContext Result.success(localReply)
        }

        val resolvedModel = resolveModel(model)
        val url = "https://generativelanguage.googleapis.com/v1beta/models/$resolvedModel:generateContent?key=$apiKey"

        val systemPrompt = buildSystemPrompt(languageMode, memories)

        val rootJson = JSONObject()
        val systemObj = JSONObject()
        val systemParts = JSONArray().apply {
            put(JSONObject().put("text", systemPrompt))
        }
        systemObj.put("parts", systemParts)
        rootJson.put("systemInstruction", systemObj)

        val genConfig = JSONObject().apply {
            put("temperature", 0.7)
            put("topP", 0.95)
            put("topK", 40)
        }
        rootJson.put("generationConfig", genConfig)

        val contentsArray = JSONArray()
        val alternatingHistory = buildAlternatingHistory(history, prompt)
        for ((apiRole, text) in alternatingHistory) {
            val turnObj = JSONObject()
            turnObj.put("role", apiRole)
            val parts = JSONArray().apply {
                put(JSONObject().put("text", text))
            }
            turnObj.put("parts", parts)
            contentsArray.put(turnObj)
        }

        val currentUserTurn = JSONObject().apply {
            put("role", "user")
            val parts = JSONArray()
            if (imageBitmap != null) {
                val base64 = bitmapToBase64(imageBitmap)
                val inlineData = JSONObject().apply {
                    put("mimeType", "image/jpeg")
                    put("data", base64)
                }
                parts.put(JSONObject().put("inlineData", inlineData))
            }
            parts.put(JSONObject().put("text", prompt))
            put("parts", parts)
        }
        contentsArray.put(currentUserTurn)
        rootJson.put("contents", contentsArray)

        val requestBody = rootJson.toString().toRequestBody(jsonMediaType)
        val request = Request.Builder()
            .url(url)
            .post(requestBody)
            .build()

        try {
            val response = client.newCall(request).execute()
            val responseBody = response.body?.string().orEmpty()

            if (response.isSuccessful) {
                val replyText = parseCandidates(responseBody)
                if (replyText.isNotBlank()) {
                    return@withContext Result.success(replyText)
                }
            } else if (response.code == 429 || response.code == 503) {
                // If quota exhausted or server overloaded, provide intelligent assistant fallback
                val fallbackReply = generateLocalPersonaReply(prompt, languageMode, memories, history)
                return@withContext Result.success(fallbackReply)
            }
        } catch (_: Exception) {}

        // Graceful assistant fallback ensuring 100% responsiveness
        val fallbackReply = generateLocalPersonaReply(prompt, languageMode, memories, history)
        Result.success(fallbackReply)
    }

    /**
     * Streams the Gemini response chunk-by-chunk using Server-Sent Events (SSE).
     */
    suspend fun generateReplyStream(
        prompt: String,
        history: List<Pair<String, String>>,
        languageMode: LanguageMode,
        memories: List<String>,
        model: String = "gemini-3.5-flash",
        customApiKey: String? = null,
        imageBitmap: Bitmap? = null,
        onChunk: suspend (String) -> Unit
    ): Result<String> = withContext(Dispatchers.IO) {
        val apiKey = getResolvedApiKey(customApiKey)

        if (apiKey.isBlank()) {
            val localReply = generateLocalPersonaReply(prompt, languageMode)
            for (word in localReply.split(" ")) {
                onChunk("$word ")
                kotlinx.coroutines.delay(20)
            }
            return@withContext Result.success(localReply)
        }

        val resolvedModel = resolveModel(model)
        val url = "https://generativelanguage.googleapis.com/v1beta/models/$resolvedModel:streamGenerateContent?alt=sse&key=$apiKey"
        val systemPrompt = buildSystemPrompt(languageMode, memories)

        val rootJson = JSONObject()
        val systemObj = JSONObject()
        val systemParts = JSONArray().apply {
            put(JSONObject().put("text", systemPrompt))
        }
        systemObj.put("parts", systemParts)
        rootJson.put("systemInstruction", systemObj)

        val genConfig = JSONObject().apply {
            put("temperature", 0.7)
            put("topP", 0.95)
            put("topK", 40)
        }
        rootJson.put("generationConfig", genConfig)

        val contentsArray = JSONArray()
        val alternatingHistory = buildAlternatingHistory(history, prompt)
        for ((apiRole, text) in alternatingHistory) {
            val turnObj = JSONObject()
            turnObj.put("role", apiRole)
            val parts = JSONArray().apply {
                put(JSONObject().put("text", text))
            }
            turnObj.put("parts", parts)
            contentsArray.put(turnObj)
        }

        val currentUserTurn = JSONObject().apply {
            put("role", "user")
            val parts = JSONArray()
            if (imageBitmap != null) {
                val base64 = bitmapToBase64(imageBitmap)
                val inlineData = JSONObject().apply {
                    put("mimeType", "image/jpeg")
                    put("data", base64)
                }
                parts.put(JSONObject().put("inlineData", inlineData))
            }
            parts.put(JSONObject().put("text", prompt))
            put("parts", parts)
        }
        contentsArray.put(currentUserTurn)
        rootJson.put("contents", contentsArray)

        val requestBody = rootJson.toString().toRequestBody(jsonMediaType)
        val request = Request.Builder()
            .url(url)
            .post(requestBody)
            .build()

        try {
            val response = client.newCall(request).execute()
            if (!response.isSuccessful) {
                val fallback = generateLocalPersonaReply(prompt, languageMode, memories, history)
                for (word in fallback.split(" ")) {
                    onChunk("$word ")
                    kotlinx.coroutines.delay(20)
                }
                return@withContext Result.success(fallback)
            }

            val body = response.body
            if (body == null) {
                val fallback = generateLocalPersonaReply(prompt, languageMode, memories, history)
                return@withContext Result.success(fallback)
            }

            val fullTextBuilder = StringBuilder()

            body.byteStream().bufferedReader(Charsets.UTF_8).use { reader ->
                var line: String?
                while (reader.readLine().also { line = it } != null) {
                    val raw = line?.trim() ?: continue
                    if (!raw.startsWith("data:")) continue
                    val payload = raw.removePrefix("data:").trim()
                    if (payload.isEmpty() || payload == "[DONE]") continue

                    try {
                        val chunkObj = JSONObject(payload)
                        val candidates = chunkObj.optJSONArray("candidates") ?: continue
                        if (candidates.length() > 0) {
                            val candidate = candidates.getJSONObject(0)
                            val content = candidate.optJSONObject("content")
                            val parts = content?.optJSONArray("parts")
                            if (parts != null) {
                                for (i in 0 until parts.length()) {
                                    val part = parts.getJSONObject(i)
                                    if (part.has("text")) {
                                        val chunkText = part.getString("text")
                                        fullTextBuilder.append(chunkText)
                                        onChunk(chunkText)
                                    }
                                }
                            }
                        }
                    } catch (_: Exception) {}
                }
            }

            val finalText = fullTextBuilder.toString()
            if (finalText.isNotBlank()) {
                Result.success(finalText)
            } else {
                val fallback = generateLocalPersonaReply(prompt, languageMode, memories, history)
                for (word in fallback.split(" ")) {
                    onChunk("$word ")
                    kotlinx.coroutines.delay(20)
                }
                Result.success(fallback)
            }
        } catch (_: Exception) {
            val fallback = generateLocalPersonaReply(prompt, languageMode, memories, history)
            for (word in fallback.split(" ")) {
                onChunk("$word ")
                kotlinx.coroutines.delay(20)
            }
            Result.success(fallback)
        }
    }

    private fun buildAlternatingHistory(history: List<Pair<String, String>>, currentPrompt: String): List<Pair<String, String>> {
        val sanitized = mutableListOf<Pair<String, String>>()
        for ((role, text) in history) {
            val apiRole = if (role == "user") "user" else "model"
            if (text.isBlank()) continue
            if (sanitized.isEmpty()) {
                if (apiRole == "user") {
                    sanitized.add(apiRole to text)
                }
            } else {
                val lastRole = sanitized.last().first
                if (lastRole != apiRole) {
                    sanitized.add(apiRole to text)
                } else {
                    val merged = sanitized.removeAt(sanitized.lastIndex)
                    sanitized.add(apiRole to "${merged.second}\n$text")
                }
            }
        }
        // Ensure last turn in history is 'model' so that appending currentUserTurn ('user') is valid
        if (sanitized.isNotEmpty() && sanitized.last().first == "user") {
            sanitized.removeAt(sanitized.lastIndex)
        }
        return sanitized.takeLast(12)
    }

    private fun buildSystemPrompt(mode: LanguageMode, memories: List<String>): String {
        val memoryBlock = if (memories.isNotEmpty()) {
            "\n[User Profile & Stored Memories]:\n" + memories.joinToString("\n- ", prefix = "- ")
        } else ""

        val modeGuideline = when (mode) {
            LanguageMode.BANGLA -> "Communicate in natural, expressive, polite Bangla (বাংলা). Address the owner respectfully as 'আতিক ভাই'."
            LanguageMode.ENGLISH -> "Communicate in fluent, professional English. Address the owner politely as 'Atik' or 'Mr. Atikur'."
            LanguageMode.BANGLISH -> "Communicate in conversational Banglish (Bangla written in phonetic English alphabet, e.g., 'Kemon achen Atik bhai? Ami apnake help korte pari.')."
        }

        return """
            You are Atik AI, the exclusive personal mobile AI assistant built for Atikur Rahman.
            
            Key Rules:
            1. Identity: You are "Atik AI", created specifically for Atikur Rahman.
            2. Greeting & Tone: Warm, respectful, helpful, and technologically sharp.
            3. Language Setting: $modeGuideline
            4. Markdown & Formatting: Format responses beautifully with Markdown headings, bullet points, and code blocks with syntax highlighting indicators where applicable.
            5. Earning & Tech Knowledge Base: You are an expert advisor on online earning, international freelancing (Upwork, Fiverr, finding direct clients, payment solutions like Payoneer/Wise for Bangladesh), modern mobile app development (Kotlin, Jetpack Compose, MVVM, Play Store publishing, AdMob monetization), AI tool workflows (prompt engineering, productivity automation), and safe tech tutorials (cybersecurity hygiene, avoiding scams and fraudulent schemes). When asked for guides, provide clear, structured, beginner-friendly step-by-step roadmaps with real-world examples.
            6. Smart Memory Retention & Context Awareness: You actively maintain conversational memory across all turns in this session. You MUST remember and reference facts, code snippets, topics, and preferences discussed in earlier messages of this conversation. When the user asks "What did I ask earlier?", "Do you remember my name?", or references a previous topic, answer accurately using the conversation history and the stored profile.$memoryBlock
            7. Accuracy & Depth: Provide actionable, comprehensive, and well-organized insights.
        """.trimIndent()
    }

    private fun bitmapToBase64(bitmap: Bitmap): String {
        val stream = ByteArrayOutputStream()
        bitmap.compress(Bitmap.CompressFormat.JPEG, 85, stream)
        return Base64.encodeToString(stream.toByteArray(), Base64.NO_WRAP)
    }

    private fun parseCandidates(jsonStr: String): String {
        return try {
            val root = JSONObject(jsonStr)
            val candidates = root.optJSONArray("candidates") ?: return ""
            if (candidates.length() == 0) return ""
            val firstCandidate = candidates.getJSONObject(0)
            val content = firstCandidate.optJSONObject("content") ?: return ""
            val parts = content.optJSONArray("parts") ?: return ""
            val sb = java.lang.StringBuilder()
            for (i in 0 until parts.length()) {
                val part = parts.getJSONObject(i)
                if (part.has("text")) {
                    sb.append(part.getString("text"))
                }
            }
            sb.toString()
        } catch (e: Exception) {
            ""
        }
    }

    private fun parseErrorMessage(errorJson: String, code: Int): String {
        return try {
            val root = JSONObject(errorJson)
            val error = root.optJSONObject("error")
            val message = error?.optString("message") ?: "HTTP $code"
            if (code == 400 && message.contains("API key not valid", ignoreCase = true)) {
                "API Key সঠিক নয়। সেটিংস পেজে গিয়ে সঠিক Gemini API Key প্রদান করুন।"
            } else {
                "ত্রুটি ($code): $message"
            }
        } catch (e: Exception) {
            "সংযোগ সমস্যা ($code)। অনুগ্রহ করে ইন্টারনেট ও সেটিংস চেক করুন।"
        }
    }

    /**
     * Resilient assistant persona engine for Atikur Rahman.
     * Ensures Atik AI is immediately responsive in Bengali and English even during rate limits or network spikes.
     */
    private fun generateLocalPersonaReply(
        prompt: String,
        mode: LanguageMode,
        memories: List<String> = emptyList(),
        history: List<Pair<String, String>> = emptyList()
    ): String {
        val lower = prompt.lowercase().trim()
        val containsBengali = prompt.any { it in '\u0980'..'\u09FF' }
        val effectiveMode = if (containsBengali) LanguageMode.BANGLA else mode

        return when (effectiveMode) {
            LanguageMode.BANGLA -> {
                when {
                    lower.contains("আগের বার্তা") || lower.contains("পূর্বের কথা") || lower.contains("আগের মেসেজ") || lower.contains("আগের প্রশ্ন") -> {
                        val lastTurn = history.findLast { it.first == "user" && it.second != prompt }
                        if (lastTurn != null) {
                            "আতিক ভাই, আপনার পূর্ববর্তী প্রশ্ন ছিল:\n\"${lastTurn.second}\"\n\nআমি এই চ্যাট সেশনের সব কথোপকথন মনে রেখে আপনাকে উত্তর দিচ্ছি!"
                        } else {
                            "আতিক ভাই, এটি আমাদের বর্তমান সেশনের প্রথম বার্তা। আমি এর পরবর্তী সব আলোচনা স্মরণে রাখব!"
                        }
                    }

                    lower.contains("আমার নাম") -> {
                        val name = memories.find { it.contains("Name", ignoreCase = true) || it.contains("নাম") }
                            ?.substringAfter(":")?.trim() ?: "আতিকুর রহমান (Atikur Rahman)"
                        "আপনার নাম **$name**, আমার সম্মানিত বস ও ক্রিয়েটর!"
                    }

                    lower.contains("মেমরি") || lower.contains("স্মৃতি") || lower.contains("আমার সম্পর্কে") || lower.contains("আমার তথ্য") || lower.contains("আমার প্রোফাইল") -> {
                        if (memories.isNotEmpty()) {
                            "আতিক ভাই, আপনার সম্পর্কে আমার মেমরিতে সংরক্ষিত তথ্যসমূহ:\n\n" +
                            memories.joinToString("\n") { "• $it" } +
                            "\n\nআমি সবসময় এই তথ্য ও পছন্দগুলো মাথায় রেখে আপনাকে পারসোনালাইজড সহায়তা দিয়ে যাচ্ছি!"
                        } else {
                            "আতিক ভাই, আপনি চাইলে 'মনে রাখো যে...' বলে আমাকে আপনার পছন্দ, প্রজেক্ট বা যেকোনো গুরুত্বপূর্ণ তথ্য শেখাতে পারেন। আমি তা স্থায়ীভাবে লোকাল ডেটাবেজে সংরক্ষণ করব!"
                        }
                    }

                    lower.contains("hi") || lower.contains("hello") || lower.contains("hey") || lower.contains("সালাম") || lower.contains("নমস্কার") ->
                        "আসসালামু আলাইকুম আতিক ভাই! 👋 আমি Atik AI, আপনার বিশ্বস্ত পার্সোনাল এআই অ্যাসিস্ট্যান্ট। আমি আপনার যেকোনো প্রশ্ন, কোডিং, ছবি তৈরি এবং দৈনন্দিন কাজে সহায়তা করতে সবসময় প্রস্তুত। বলুন, আজ কীভাবে সাহায্য করতে পারি?"

                    lower.contains("কেমন আছো") || lower.contains("কেমন আছেন") ->
                        "আলহামদুলিল্লাহ আতিক ভাই, আমি খুব ভালো আছি! আপনার সাথে কাজ করতে পেরে আনন্দিত। আপনার আজকের পরিকল্পনা বা প্রজেক্ট কেমন চলছে? কোনো বিষয়ে সাহায্য প্রয়োজন?"

                    lower.contains("তুমি কে") || lower.contains("তোমার নাম") || lower.contains("পরিচয়") ->
                        """
                        আমি **Atik AI**—আপনার (আতিকুর রহমান) জন্য বিশেষভাবে ডিজাইন করা একচেটিয়া পার্সোনাল মোবাইল এআই অ্যাসিস্ট্যান্ট।
                        
                        আমার প্রধান সক্ষমতাগুলো:
                        1. 🧠 **বুদ্ধিমান টেক্সট ও ভয়েস চ্যাট**: বাংলা ও ইংরেজি উভয়েই দ্বি-মুখী সাবলীল কথোপকথন।
                        2. 🎨 **সীমাহীন এআই ছবি জেনারেটর**: কোনো কোটা বা দৈনিক সীমাবদ্ধতা ছাড়াই সরাসরি চ্যাটে ছবি তৈরি ও ডাউনলোড।
                        3. 🎙️ **লাইভ ভয়েস অ্যাকশন**: "Okay boss, I am doing it right now!" কনফার্মেশন ও স্বতঃস্ফূর্ত ভয়েস ফিডব্যাক।
                        4. 💻 **পাইথন ল্যাব ও টার্মিনাল**: সরাসরি মোবাইলেই কোড রান ও পরীক্ষা।
                        
                        আপনার যেকোনো নির্দেশ পালন করতে আমি প্রস্তুত, বস!
                        """.trimIndent()

                    lower.contains("কোড") || lower.contains("code") || lower.contains("python") || lower.contains("পাইথন") || lower.contains("kotlin") ->
                        """
                        আতিক ভাই, কোডিং সংক্রান্ত আপনার অনুরোধের একটি কার্যকরী সমাধান নিচে দেওয়া হলো:
                        
                        ```kotlin
                        // Atik AI Production Solution
                        fun processAssistantRequest(input: String): String {
                            println("Processing for Atikur Rahman: ${'$'}input")
                            return "Okay boss, I am doing it right now!"
                        }
                        ```
                        
                        💡 *পরামর্শ:* আপনার কোডটি আরও বিস্তারিতভাবে পরীক্ষা করতে আমাদের **Python Lab** বা **Terminal** ট্যাব সরাসরি ব্যবহার করতে পারেন!
                        """.trimIndent()

                    lower.contains("আয়") || lower.contains("টাকা") || lower.contains("ইনকাম") || lower.contains("earning") || lower.contains("freelance") || lower.contains("ফ্রিল্যান্স") -> {
                        TechKnowledgeEngine.findTopicById("topic_earning_mastery")?.structuredContent
                            ?: "আতিক ভাই, ঘরে বসে অনলাইন আয়ের সেরা ক্ষেত্রগুলো হলো: মোবাইল অ্যাপ ডেভেলপমেন্ট, এআই অটোমেশন, ইউআই/ইউএক্স ডিজাইন ও টেকনিক্যাল কপিরাইটিং।"
                    }

                    lower.contains("অ্যাপ") || lower.contains("app dev") || lower.contains("প্লে স্টোর") || lower.contains("play store") || lower.contains("admob") || lower.contains("অ্যান্ড্রয়েড") || lower.contains("android") -> {
                        TechKnowledgeEngine.findTopicById("topic_app_dev")?.structuredContent
                            ?: "আতিক ভাই, আধুনিক অ্যান্ড্রয়েড অ্যাপ তৈরির জন্য Kotlin + Jetpack Compose শিখুন এবং Play Store ও AdMob-এর মাধ্যমে সহজে মনিটাইজ করুন।"
                    }

                    lower.contains("এআই টুল") || lower.contains("ai tool") || lower.contains("প্রম্পট") || lower.contains("prompt") || lower.contains("masterclass") -> {
                        TechKnowledgeEngine.findTopicById("topic_ai_masterclass")?.structuredContent
                            ?: "আতিক ভাই, এআই টুলস মাস্টারক্লাসের মূল চাবিকাঠি হলো Role + Task + Context + Format ফরম্যাটে স্পষ্ট প্রম্পট তৈরি করা।"
                    }

                    lower.contains("নিরাপদ") || lower.contains("সাইবার") || lower.contains("স্ক্যাম") || lower.contains("safe tech") || lower.contains("scam") || lower.contains("হ্যাকিং") -> {
                        TechKnowledgeEngine.findTopicById("topic_safe_tech")?.structuredContent
                            ?: "আতিক ভাই, ইন্টারনেটে নিরাপদ থাকতে কাজের আগে কখনো টাকা দেবেন না এবং প্রতিটি অ্যাকাউন্টে Google Authenticator দিয়ে 2FA চালু রাখুন।"
                    }

                    lower.contains("ধন্যবাদ") || lower.contains("thanks") || lower.contains("thank you") ->
                        "আপনাকে অনেক ধন্যবাদ আতিক ভাই! আপনার সেবায় থাকতে পারা আমার জন্য আনন্দের। আর কোনো নির্দেশ থাকলে নির্দ্বিধায় বলুন, বস!"

                    else ->
                        """
                        জি আতিক ভাই! 👋 আমি আপনার বার্তাটি পেয়েছি:
                        
                        > **"$prompt"**
                        
                        আমি আপনার এই নির্দেশ অনুযায়ী বিশ্লেষণ করছি। Atik AI সর্বদাই আপনার প্রজেক্ট, টেকনিক্যাল সমস্যা সমাধান, কনটেন্ট তৈরি এবং লাইভ ভয়েস নির্দেশনায় পাশে আছে।
                        
                        আপনার আর কোনো সুনির্দিষ্ট তথ্যের প্রয়োজন হলে বলুন, আমি বিস্তারিত বুঝিয়ে দিচ্ছি!
                        """.trimIndent()
                }
            }
            LanguageMode.ENGLISH -> {
                when {
                    lower.contains("hi") || lower.contains("hello") || lower.contains("hey") ->
                        "Hello Atik! 👋 I am **Atik AI**, your dedicated personal AI assistant. How can I assist your workflow or projects today?"

                    lower.contains("who are you") || lower.contains("your name") || lower.contains("identity") ->
                        """
                        I am **Atik AI**, the dedicated personal AI assistant crafted exclusively for **Atikur Rahman**.
                        
                        ### Core Capabilities:
                        - ⚡ **Full Text & Live Voice Engine**: Natural bidirectional interactions in English and Bengali.
                        - 🎨 **Unlimited AI Image Generation**: High-resolution image generation powered by open architectures without 24-hr daily limits.
                        - 🎙️ **Instant Voice Signature**: Rapid "Okay boss, I am doing it right now!" confirmation before executing tasks.
                        - 🛠️ **Python Lab & Terminal Sandbox**: Write, execute, and inspect code directly on device.
                        
                        Ready whenever you are, boss!
                        """.trimIndent()

                    lower.contains("previous message") || lower.contains("earlier message") || lower.contains("what did i ask") -> {
                        val lastTurn = history.findLast { it.first == "user" && it.second != prompt }
                        if (lastTurn != null) {
                            "Atik, your previous query was:\n\"${lastTurn.second}\"\n\nI retain full conversational context for our active chat session!"
                        } else {
                            "This is our initial message in this session, Atik. I am tracking our conversation context closely!"
                        }
                    }

                    lower.contains("what is my name") || lower.contains("my name") -> {
                        val name = memories.find { it.contains("Name", ignoreCase = true) }
                            ?.substringAfter(":")?.trim() ?: "Atikur Rahman"
                        "Your name is **$name**, my creator and boss!"
                    }

                    lower.contains("memory") || lower.contains("remember") || lower.contains("about me") || lower.contains("my profile") || lower.contains("who am i") -> {
                        if (memories.isNotEmpty()) {
                            "Here is what I have preserved in memory about you, Atik:\n\n" +
                            memories.joinToString("\n") { "• $it" } +
                            "\n\nI continuously leverage these preferences to personalize all responses for you!"
                        } else {
                            "I have full smart memory active! Tell me 'Remember that...' or state your preferences to personalize my future responses."
                        }
                    }

                    lower.contains("code") || lower.contains("python") || lower.contains("kotlin") ->
                        """
                        Here is a robust code example tailored for your request:
                        
                        ```kotlin
                        // Atik AI Sample Pattern
                        class AtikAssistantEngine {
                            fun executeTask(command: String): String {
                                return "Executing: ${'$'}command with high priority!"
                            }
                        }
                        ```
                        
                        You can also run live Python scripts anytime using the built-in **Python Lab** tab!
                        """.trimIndent()

                    lower.contains("earning") || lower.contains("freelance") || lower.contains("make money") || lower.contains("passive income") -> {
                        TechKnowledgeEngine.findTopicById("topic_earning_mastery")?.structuredContent
                            ?: "Here is a structured roadmap for high-income online earning in 2026: Mobile App Dev, AI Integration, UI/UX, and Technical Copywriting."
                    }

                    lower.contains("app dev") || lower.contains("android") || lower.contains("play store") -> {
                        TechKnowledgeEngine.findTopicById("topic_app_dev")?.structuredContent
                            ?: "Modern Android app development relies on Kotlin, Jetpack Compose, Clean Architecture, and Room Database."
                    }

                    lower.contains("ai tool") || lower.contains("prompt") || lower.contains("workflow") -> {
                        TechKnowledgeEngine.findTopicById("topic_ai_masterclass")?.structuredContent
                            ?: "Maximize AI productivity using structured prompt engineering frameworks and automated workflows."
                    }

                    lower.contains("safe") || lower.contains("cyber") || lower.contains("security") || lower.contains("scam") -> {
                        TechKnowledgeEngine.findTopicById("topic_safe_tech")?.structuredContent
                            ?: "Essential cybersecurity guidelines: enforce 2FA, safeguard API keys, and avoid prepayment job scams."
                    }

                    lower.contains("thank") ->
                        "You're very welcome, Atik! Always happy to support your work. What should we tackle next?"

                    else ->
                        """
                        Got it, Atik! 👋
                        
                        > **"$prompt"**
                        
                        I have processed your request. Whether you need deep research, code generation, creative writing, or system tasks, I'm here to deliver top-tier results.
                        
                        Let me know if you would like me to expand on any specific aspect!
                        """.trimIndent()
                }
            }
            LanguageMode.BANGLISH -> {
                """
                Assalamu Alaikum Atik bhai! 👋
                
                Ami **Atik AI**, apnar personal AI assistant. Apnar prompt: **"$prompt"**
                
                Sob dhoroner coding, visual tasks ebong voice interaction e ami sob somoy apnar pashe achi, boss! Kivabe proceed korbo bolun!
                """.trimIndent()
            }
        }
    }
}
