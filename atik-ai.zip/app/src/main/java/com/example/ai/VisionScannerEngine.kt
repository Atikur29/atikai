package com.example.ai

import android.content.Context
import android.graphics.Bitmap
import androidx.annotation.OptIn
import androidx.camera.core.ExperimentalGetImage
import androidx.camera.core.ImageProxy
import com.example.BuildConfig
import com.google.mlkit.vision.barcode.BarcodeScannerOptions
import com.google.mlkit.vision.barcode.BarcodeScanning
import com.google.mlkit.vision.barcode.common.Barcode
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.util.concurrent.TimeUnit
import android.util.Base64

enum class VisionScanMode(val title: String, val description: String) {
    OBJECT_AI("AI Vision & Object", "Instant AI analysis, plant/product identification & explanation"),
    QR_BARCODE("QR & Barcode Scanner", "High-speed automatic link, code & product reader"),
    OCR_TEXT("OCR Text Scanner", "Instant character recognition with single-tap copy")
}

enum class VisionAiPreset(val label: String, val prompt: String) {
    IDENTIFY_OBJECT("General Object", "Identify and analyze the main object in this image in detail. State what it is, its category, materials, features, practical uses, and interesting facts. Format with clear headings and bullet points in professional English."),
    PLANT_FLORA("Plant & Flower", "Identify this plant, flower, tree, or crop. Give its common name, botanical scientific name, family, natural habitat, sunlight & watering care tips, and whether it is safe or toxic for pets/humans."),
    PRODUCT_BARCODE("Product & Food", "Analyze this product, package, or food item. Identify the brand, product type, key ingredients or technical specs, expected use, and quality or nutrition insights."),
    DOCUMENT_SOLVER("Document & Problem", "Read the document, formula, or problem in this image. Explain the key points or provide step-by-step problem-solving solution in clear English."),
    SCENE_EXPLAIN("Scene & Environment", "Provide a comprehensive description of this scene, environment, activities, and lighting context.")
}

data class QrBarcodeResult(
    val rawValue: String,
    val format: String,
    val valueType: String,
    val displayTitle: String,
    val isUrl: Boolean,
    val timestamp: Long = System.currentTimeMillis()
)

data class OcrResult(
    val fullText: String,
    val lineCount: Int,
    val blockCount: Int,
    val timestamp: Long = System.currentTimeMillis()
)

data class VisionAiAnalysisResult(
    val title: String,
    val category: String,
    val summary: String,
    val explanation: String,
    val rawMarkdown: String,
    val timestamp: Long = System.currentTimeMillis()
)

class VisionScannerEngine(private val context: Context) {

    private val barcodeScanner by lazy {
        val options = BarcodeScannerOptions.Builder()
            .setBarcodeFormats(
                Barcode.FORMAT_ALL_FORMATS
            )
            .build()
        BarcodeScanning.getClient(options)
    }

    private val textRecognizer by lazy {
        TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    }

    private val httpClient = OkHttpClient.Builder()
        .connectTimeout(60, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .build()

    private val jsonMediaType = "application/json; charset=utf-8".toMediaType()

    /**
     * Process ImageProxy from CameraX Analyzer for Barcode/QR
     */
    @OptIn(ExperimentalGetImage::class)
    fun scanBarcodeFromProxy(
        imageProxy: ImageProxy,
        onSuccess: (QrBarcodeResult) -> Unit,
        onFailure: (Exception) -> Unit = {},
        onComplete: () -> Unit = {}
    ) {
        val mediaImage = imageProxy.image
        if (mediaImage == null) {
            imageProxy.close()
            onComplete()
            return
        }

        val image = InputImage.fromMediaImage(mediaImage, imageProxy.imageInfo.rotationDegrees)
        barcodeScanner.process(image)
            .addOnSuccessListener { barcodes ->
                val first = barcodes.firstOrNull()
                if (first != null && !first.rawValue.isNullOrBlank()) {
                    val result = parseBarcode(first)
                    onSuccess(result)
                }
            }
            .addOnFailureListener { e ->
                onFailure(e)
            }
            .addOnCompleteListener {
                imageProxy.close()
                onComplete()
            }
    }

    /**
     * Process Bitmap for Barcode/QR (e.g. from gallery or snapshot)
     */
    fun scanBarcodeFromBitmap(
        bitmap: Bitmap,
        onSuccess: (QrBarcodeResult?) -> Unit,
        onFailure: (Exception) -> Unit
    ) {
        val image = InputImage.fromBitmap(bitmap, 0)
        barcodeScanner.process(image)
            .addOnSuccessListener { barcodes ->
                val first = barcodes.firstOrNull()
                if (first != null && !first.rawValue.isNullOrBlank()) {
                    onSuccess(parseBarcode(first))
                } else {
                    onSuccess(null)
                }
            }
            .addOnFailureListener { e ->
                onFailure(e)
            }
    }

    /**
     * Process ImageProxy from CameraX Analyzer for OCR
     */
    @OptIn(ExperimentalGetImage::class)
    fun recognizeTextFromProxy(
        imageProxy: ImageProxy,
        onSuccess: (OcrResult) -> Unit,
        onFailure: (Exception) -> Unit = {},
        onComplete: () -> Unit = {}
    ) {
        val mediaImage = imageProxy.image
        if (mediaImage == null) {
            imageProxy.close()
            onComplete()
            return
        }

        val image = InputImage.fromMediaImage(mediaImage, imageProxy.imageInfo.rotationDegrees)
        textRecognizer.process(image)
            .addOnSuccessListener { visionText ->
                if (visionText.text.isNotBlank()) {
                    val lines = visionText.textBlocks.flatMap { it.lines }.size
                    val blocks = visionText.textBlocks.size
                    onSuccess(
                        OcrResult(
                            fullText = visionText.text.trim(),
                            lineCount = lines,
                            blockCount = blocks
                        )
                    )
                }
            }
            .addOnFailureListener { e ->
                onFailure(e)
            }
            .addOnCompleteListener {
                imageProxy.close()
                onComplete()
            }
    }

    /**
     * Process Bitmap for OCR
     */
    fun recognizeTextFromBitmap(
        bitmap: Bitmap,
        onSuccess: (OcrResult) -> Unit,
        onFailure: (Exception) -> Unit
    ) {
        val image = InputImage.fromBitmap(bitmap, 0)
        textRecognizer.process(image)
            .addOnSuccessListener { visionText ->
                val lines = visionText.textBlocks.flatMap { it.lines }.size
                val blocks = visionText.textBlocks.size
                onSuccess(
                    OcrResult(
                        fullText = visionText.text.trim(),
                        lineCount = lines,
                        blockCount = blocks
                    )
                )
            }
            .addOnFailureListener { e ->
                onFailure(e)
            }
    }

    private fun parseBarcode(barcode: Barcode): QrBarcodeResult {
        val raw = barcode.rawValue.orEmpty()
        val formatStr = when (barcode.format) {
            Barcode.FORMAT_QR_CODE -> "QR Code"
            Barcode.FORMAT_EAN_13 -> "EAN-13"
            Barcode.FORMAT_EAN_8 -> "EAN-8"
            Barcode.FORMAT_UPC_A -> "UPC-A"
            Barcode.FORMAT_UPC_E -> "UPC-E"
            Barcode.FORMAT_CODE_128 -> "Code 128"
            Barcode.FORMAT_CODE_39 -> "Code 39"
            Barcode.FORMAT_CODE_93 -> "Code 93"
            Barcode.FORMAT_DATA_MATRIX -> "Data Matrix"
            Barcode.FORMAT_AZTEC -> "Aztec"
            Barcode.FORMAT_PDF417 -> "PDF417"
            else -> "Barcode"
        }

        val typeStr: String
        val isUrl: Boolean
        val title: String

        when (barcode.valueType) {
            Barcode.TYPE_URL -> {
                typeStr = "Web Link"
                isUrl = true
                title = barcode.url?.url ?: raw
            }
            Barcode.TYPE_WIFI -> {
                typeStr = "Wi-Fi Network"
                isUrl = false
                val ssid = barcode.wifi?.ssid ?: "Wi-Fi"
                title = "Wi-Fi: $ssid"
            }
            Barcode.TYPE_CONTACT_INFO -> {
                typeStr = "Contact Card"
                isUrl = false
                val name = barcode.contactInfo?.name?.formattedName ?: "Contact"
                title = "Contact: $name"
            }
            Barcode.TYPE_PRODUCT -> {
                typeStr = "Product Barcode"
                isUrl = false
                title = "Product Code: $raw"
            }
            Barcode.TYPE_TEXT -> {
                val lower = raw.lowercase()
                if (lower.startsWith("http://") || lower.startsWith("https://")) {
                    typeStr = "Web Link"
                    isUrl = true
                    title = raw
                } else {
                    typeStr = "Text Data"
                    isUrl = false
                    title = if (raw.length > 40) raw.take(40) + "..." else raw
                }
            }
            else -> {
                val lower = raw.lowercase()
                if (lower.startsWith("http://") || lower.startsWith("https://")) {
                    typeStr = "Web Link"
                    isUrl = true
                    title = raw
                } else {
                    typeStr = "Standard Code"
                    isUrl = false
                    title = if (raw.length > 40) raw.take(40) + "..." else raw
                }
            }
        }

        return QrBarcodeResult(
            rawValue = raw,
            format = formatStr,
            valueType = typeStr,
            displayTitle = title,
            isUrl = isUrl
        )
    }

    /**
     * Gemini Vision AI Object / Scene / Plant / Product Analyzer
     */
    suspend fun analyzeImageWithAi(
        bitmap: Bitmap,
        preset: VisionAiPreset,
        customPrompt: String?,
        apiKey: String?
    ): Result<VisionAiAnalysisResult> = withContext(Dispatchers.IO) {
        val key = getResolvedApiKey(apiKey)
        val prompt = if (!customPrompt.isNullOrBlank()) {
            "${preset.prompt}\n\nAdditional user instruction: $customPrompt"
        } else {
            preset.prompt
        }

        if (key.isBlank()) {
            // Local fallback explanation
            val localResult = generateLocalVisionAnalysis(preset)
            return@withContext Result.success(localResult)
        }

        val model = "gemini-3.5-flash"
        val url = "https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent?key=$key"

        val systemInstruction = "You are Atik AI Vision Intelligence Engine, an expert multimodal computer vision and real-time object analyzer. Provide accurate, clear, professional English analysis with structured markdown headers and bullet points."

        val rootJson = JSONObject()
        val sysObj = JSONObject().put("parts", JSONArray().put(JSONObject().put("text", systemInstruction)))
        rootJson.put("systemInstruction", sysObj)

        val genConfig = JSONObject().apply {
            put("temperature", 0.4)
            put("topP", 0.95)
            put("topK", 40)
        }
        rootJson.put("generationConfig", genConfig)

        val base64Image = bitmapToBase64(bitmap)
        val parts = JSONArray().apply {
            put(
                JSONObject().put(
                    "inlineData",
                    JSONObject().put("mimeType", "image/jpeg").put("data", base64Image)
                )
            )
            put(JSONObject().put("text", prompt))
        }

        val contents = JSONArray().apply {
            put(JSONObject().put("role", "user").put("parts", parts))
        }
        rootJson.put("contents", contents)

        val requestBody = rootJson.toString().toRequestBody(jsonMediaType)
        val request = Request.Builder().url(url).post(requestBody).build()

        try {
            val response = httpClient.newCall(request).execute()
            val responseBody = response.body?.string().orEmpty()

            if (response.isSuccessful) {
                val json = JSONObject(responseBody)
                val candidates = json.optJSONArray("candidates")
                val firstCandidate = candidates?.optJSONObject(0)
                val content = firstCandidate?.optJSONObject("content")
                val responseParts = content?.optJSONArray("parts")
                val text = responseParts?.optJSONObject(0)?.optString("text").orEmpty()

                if (text.isNotBlank()) {
                    val parsed = parseAiVisionResponse(text, preset)
                    return@withContext Result.success(parsed)
                }
            }
            Result.failure(Exception("AI Vision returned empty response (${response.code})"))
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    private fun parseAiVisionResponse(text: String, preset: VisionAiPreset): VisionAiAnalysisResult {
        val lines = text.lines().map { it.trim() }.filter { it.isNotEmpty() }
        val firstHeader = lines.firstOrNull { it.startsWith("#") }?.replace("#", "")?.trim()
            ?: lines.firstOrNull()?.take(60)
            ?: preset.label

        val category = when (preset) {
            VisionAiPreset.PLANT_FLORA -> "Botanical & Plant Species"
            VisionAiPreset.PRODUCT_BARCODE -> "Product & Package Analytics"
            VisionAiPreset.DOCUMENT_SOLVER -> "Document / Academic Problem"
            VisionAiPreset.SCENE_EXPLAIN -> "Scene & Spatial Context"
            VisionAiPreset.IDENTIFY_OBJECT -> "Object & Entity Identification"
        }

        val summary = lines.drop(1).firstOrNull { !it.startsWith("#") && it.length > 20 }
            ?: "Analysis complete. Detailed specifications and breakdown below."

        return VisionAiAnalysisResult(
            title = firstHeader,
            category = category,
            summary = summary,
            explanation = text,
            rawMarkdown = text
        )
    }

    private fun generateLocalVisionAnalysis(preset: VisionAiPreset): VisionAiAnalysisResult {
        return VisionAiAnalysisResult(
            title = "${preset.label} Inspection",
            category = "On-Device Offline Vision",
            summary = "Image captured successfully. Connect an active Gemini API key in Settings to receive full generative neural vision analysis.",
            explanation = "### Offline Vision Mode\n- **Target Category:** ${preset.label}\n- **Image Status:** Processed locally\n- **Recommendation:** Add a free Google AI Studio Gemini API Key in Settings to unlock deep multi-spectral reasoning, plant disease diagnosis, and product lookups.",
            rawMarkdown = "Offline Vision Mode active."
        )
    }

    private fun bitmapToBase64(bitmap: Bitmap): String {
        // Compress and scale down to max 1280px for swift upload & low latency
        val maxDim = 1280
        val width = bitmap.width
        val height = bitmap.height
        val scaled = if (width > maxDim || height > maxDim) {
            val ratio = width.toFloat() / height.toFloat()
            if (ratio > 1f) {
                Bitmap.createScaledBitmap(bitmap, maxDim, (maxDim / ratio).toInt(), true)
            } else {
                Bitmap.createScaledBitmap(bitmap, (maxDim * ratio).toInt(), maxDim, true)
            }
        } else {
            bitmap
        }

        val stream = ByteArrayOutputStream()
        scaled.compress(Bitmap.CompressFormat.JPEG, 85, stream)
        return Base64.encodeToString(stream.toByteArray(), Base64.NO_WRAP)
    }

    private fun getResolvedApiKey(customKey: String?): String {
        if (!customKey.isNullOrBlank()) return customKey.trim()
        val buildKey = BuildConfig.GEMINI_API_KEY
        if (buildKey.isNotBlank() && buildKey != "MY_GEMINI_API_KEY") return buildKey
        try {
            val envField = BuildConfig::class.java.getField("ENV_GEMINI_API_KEY")
            val envVal = envField.get(null) as? String
            if (!envVal.isNullOrBlank()) return envVal.trim()
        } catch (_: Exception) {}
        return ""
    }
}
