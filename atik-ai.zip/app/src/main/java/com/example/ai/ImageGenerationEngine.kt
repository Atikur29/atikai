package com.example.ai

import android.content.ContentValues
import android.content.Context
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.net.URLEncoder
import java.nio.charset.StandardCharsets
import java.util.concurrent.TimeUnit
import kotlin.random.Random

/**
 * Unlimited AI Image Generation Engine powered by open and unrestricted models
 * (Pollinations AI with FLUX and Turbo architectures). No daily limits or 24-hr quotas.
 */
class ImageGenerationEngine {

    private val httpClient = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .build()

    /**
     * Builds a high-resolution, unrestricted image generation URL using Pollinations AI.
     */
    fun buildImageUrl(
        prompt: String,
        width: Int = 1024,
        height: Int = 1024,
        model: String = "flux",
        seed: Long = Random.nextLong(100000, 99999999)
    ): String {
        val cleanPrompt = prompt.trim()
            .replace(Regex("[\\r\\n]+"), " ")
            .take(600)

        val encoded = try {
            URLEncoder.encode(cleanPrompt, StandardCharsets.UTF_8.toString())
                .replace("+", "%20")
        } catch (e: Exception) {
            cleanPrompt.replace(" ", "%20")
        }

        return "https://image.pollinations.ai/prompt/$encoded?width=$width&height=$height&model=$model&nologo=true&seed=$seed"
    }

    /**
     * Downloads the generated image bytes and saves it to the device Gallery/Photos storage
     * using MediaStore (scoped storage compliant, zero extra storage permissions required).
     */
    suspend fun downloadAndSaveImage(
        context: Context,
        imageUrl: String,
        promptDescription: String
    ): Result<Uri?> = withContext(Dispatchers.IO) {
        try {
            val request = Request.Builder()
                .url(imageUrl)
                .header("User-Agent", "AtikAI-Android/1.0")
                .build()

            val response = httpClient.newCall(request).execute()
            if (!response.isSuccessful) {
                return@withContext Result.failure(Exception("HTTP error ${response.code} downloading image"))
            }

            val imageBytes = response.body?.bytes()
                ?: return@withContext Result.failure(Exception("Empty image body received"))

            val fileName = "AtikAI_${System.currentTimeMillis()}.jpg"

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val contentValues = ContentValues().apply {
                    put(MediaStore.MediaColumns.DISPLAY_NAME, fileName)
                    put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg")
                    put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/AtikAI")
                    put(MediaStore.MediaColumns.IS_PENDING, 1)
                }

                val resolver = context.contentResolver
                val imageUri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, contentValues)
                    ?: return@withContext Result.failure(Exception("Failed to create MediaStore entry"))

                resolver.openOutputStream(imageUri)?.use { out ->
                    out.write(imageBytes)
                    out.flush()
                }

                contentValues.clear()
                contentValues.put(MediaStore.MediaColumns.IS_PENDING, 0)
                resolver.update(imageUri, contentValues, null, null)

                Result.success(imageUri)
            } else {
                val picturesDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES)
                val atikDir = File(picturesDir, "AtikAI").apply { if (!exists()) mkdirs() }
                val targetFile = File(atikDir, fileName)
                targetFile.writeBytes(imageBytes)

                MediaScannerConnection.scanFile(
                    context,
                    arrayOf(targetFile.absolutePath),
                    arrayOf("image/jpeg"),
                    null
                )

                Result.success(Uri.fromFile(targetFile))
            }
        } catch (e: Exception) {
            Log.e("ImageGenerationEngine", "Failed to save generated image: ${e.message}", e)
            Result.failure(e)
        }
    }
}
