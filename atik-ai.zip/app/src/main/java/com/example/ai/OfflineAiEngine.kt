package com.example.ai

import android.content.Context
import com.example.data.ChatRepository
import com.example.device.DeviceHardwareManager
import com.example.knowledge.TechKnowledgeEngine
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.pow
import kotlin.math.roundToInt
import kotlin.math.sqrt

/**
 * Result structure returned by OfflineAiEngine.
 */
data class OfflineAiResult(
    val responseText: String,
    val category: OfflineAiCategory,
    val executedAction: String? = null,
    val isActionExecuted: Boolean = false
)

enum class OfflineAiCategory(val label: String) {
    CALCULATOR("Offline Calculator"),
    NOTE_MEMORY("Local Notes & Memory"),
    DEVICE_CONTROL("Device Hardware Control"),
    KNOWLEDGE_BASE("Offline Tech Guides"),
    TIME_DATE("Local Clock & Calendar"),
    CONVERSATIONAL_FALLBACK("Kung-Fu Offline Persona")
}

/**
 * Lightweight Local Rule & Intent Engine for Atik AI (Step 12 Requirement 1).
 * Executes essential queries, notes, calculations, device commands, and knowledge lookups
 * without requiring any network connectivity or external API calls.
 */
class OfflineAiEngine(
    private val context: Context,
    private val repository: ChatRepository,
    private val deviceManager: DeviceHardwareManager
) {

    /**
     * Process user query locally and return structured offline result.
     */
    suspend fun processQuery(
        prompt: String,
        userName: String = "Atikur Rahman",
        preferredTitle: String = "Atik Bhai"
    ): OfflineAiResult {
        val trimmed = prompt.trim()
        val lower = trimmed.lowercase(Locale.ROOT)

        // 1. Math & Calculator Expressions
        val mathResult = tryEvaluateMath(lower, trimmed)
        if (mathResult != null) {
            return OfflineAiResult(
                responseText = "🧮 **[Offline Calculator]**\n\n$mathResult\n\n*(Calculated instantly on local engine)*",
                category = OfflineAiCategory.CALCULATOR,
                executedAction = "Calculated expression",
                isActionExecuted = true
            )
        }

        // 2. Device Hardware & Sensor Commands
        val deviceResult = handleDeviceCommand(lower)
        if (deviceResult != null) {
            return deviceResult
        }

        // 3. Notes & Local Memory Commands
        val noteResult = handleNoteOrMemory(lower, trimmed)
        if (noteResult != null) {
            return noteResult
        }

        // 4. Local Time, Date & Calendar Queries
        val timeDateResult = handleTimeDate(lower)
        if (timeDateResult != null) {
            return timeDateResult
        }

        // 5. Offline Knowledge & Tech Academy Guides
        val knowledgeResult = handleOfflineKnowledge(lower)
        if (knowledgeResult != null) {
            return knowledgeResult
        }

        // 6. Kung-Fu Warrior Persona Greetings & General Fallback
        return handleConversationalFallback(lower, userName, preferredTitle)
    }

    /**
     * Mathematical evaluator supporting basic arithmetic, percentages, and conversions.
     */
    private fun tryEvaluateMath(lower: String, original: String): String? {
        // Currency conversion: USD to BDT (~122.50)
        val usdRegex = """(\d+(\.\d+)?)\s*(usd|dollar|\$)\s*(to|into|in)?\s*(bdt|taka|টাকা)""".toRegex()
        val usdMatch = usdRegex.find(lower)
        if (usdMatch != null) {
            val amount = usdMatch.groupValues[1].toDoubleOrNull() ?: 0.0
            val bdt = amount * 122.50
            return "$amount USD ≈ **${String.format(Locale.US, "%,.2f", bdt)} BDT** (Exchange Rate: ~122.50 BDT/USD)"
        }

        // Unit conversion: KM to Miles
        val kmRegex = """(\d+(\.\d+)?)\s*(km|kilometer|কিলোমিটার)\s*(to|in)?\s*(mile|miles|মাইল)""".toRegex()
        val kmMatch = kmRegex.find(lower)
        if (kmMatch != null) {
            val km = kmMatch.groupValues[1].toDoubleOrNull() ?: 0.0
            val miles = km * 0.621371
            return "$km km = **${String.format(Locale.US, "%.3f", miles)} miles**"
        }

        // Percentage: e.g. "25% of 800" or "800 এর 25%"
        val pctRegex = """(\d+(\.\d+)?)\s*%\s*(of|এর)\s*(\d+(\.\d+)?)""".toRegex()
        val pctMatch = pctRegex.find(lower)
        if (pctMatch != null) {
            val pct = pctMatch.groupValues[1].toDoubleOrNull() ?: 0.0
            val total = pctMatch.groupValues[4].toDoubleOrNull() ?: 0.0
            val ans = (pct / 100.0) * total
            return "$pct% of $total = **${String.format(Locale.US, "%,.2f", ans)}**"
        }

        // Direct arithmetic calculation
        val cleanExpr = original
            .replace("calculate", "", ignoreCase = true)
            .replace("হিসাব করো", "", ignoreCase = true)
            .replace("solve", "", ignoreCase = true)
            .replace("what is", "", ignoreCase = true)
            .replace("=", "")
            .trim()

        // Match math operators
        if (cleanExpr.matches(Regex("""^[\d\s\+\-\*\/\^\.\(\)\%]+$""")) && cleanExpr.any { it in "+-*/^" }) {
            try {
                val evaluated = evaluateSimpleExpression(cleanExpr)
                if (evaluated != null) {
                    val formatted = if (evaluated == evaluated.toLong().toDouble()) {
                        "${evaluated.toLong()}"
                    } else {
                        String.format(Locale.US, "%.4f", evaluated).trimEnd('0').trimEnd('.')
                    }
                    return "$cleanExpr = **$formatted**"
                }
            } catch (_: Exception) {
            }
        }

        return null
    }

    private fun evaluateSimpleExpression(expr: String): Double? {
        val sanitized = expr.replace(" ", "")
        // Handle basic binary operations: a + b, a - b, a * b, a / b, a ^ b
        for (op in listOf('+', '-', '*', '/', '^')) {
            val idx = sanitized.lastIndexOf(op)
            if (idx > 0 && idx < sanitized.length - 1) {
                val left = sanitized.substring(0, idx).toDoubleOrNull()
                val right = sanitized.substring(idx + 1).toDoubleOrNull()
                if (left != null && right != null) {
                    return when (op) {
                        '+' -> left + right
                        '-' -> left - right
                        '*' -> left * right
                        '/' -> if (right != 0.0) left / right else Double.NaN
                        '^' -> left.pow(right)
                        else -> null
                    }
                }
            }
        }
        return null
    }

    /**
     * Hardware and device commands.
     */
    private fun handleDeviceCommand(lower: String): OfflineAiResult? {
        // Flashlight ON
        if (lower.contains("flashlight on") || lower.contains("torch on") || lower.contains("ফ্ল্যাশলাইট জ্বালাও") || lower.contains("লাইট অন")) {
            val success = deviceManager.toggleFlashlight(true).getOrDefault(false)
            return OfflineAiResult(
                responseText = if (success) {
                    "🔦 **[Hardware Control]**\n\nFlashlight turned **ON** successfully, Boss!"
                } else {
                    "⚠️ Could not enable flashlight (Camera flash unavailable or restricted)."
                },
                category = OfflineAiCategory.DEVICE_CONTROL,
                executedAction = "Flashlight ON",
                isActionExecuted = success
            )
        }

        // Flashlight OFF
        if (lower.contains("flashlight off") || lower.contains("torch off") || lower.contains("ফ্ল্যাশলাইট বন্ধ") || lower.contains("লাইট অফ")) {
            val offSuccess = deviceManager.toggleFlashlight(false).getOrDefault(false)
            return OfflineAiResult(
                responseText = "🔦 **[Hardware Control]**\n\nFlashlight turned **OFF**.",
                category = OfflineAiCategory.DEVICE_CONTROL,
                executedAction = "Flashlight OFF",
                isActionExecuted = offSuccess
            )
        }

        // Battery Status
        if (lower.contains("battery") || lower.contains("ব্যাটারি") || lower.contains("charge") || lower.contains("চার্জ")) {
            val info = deviceManager.getBatteryInfo()
            val chargingIcon = if (info.isCharging) "⚡ Charging" else "🔋 Discharging"
            val text = """
                🔋 **[Device Battery Telemetry]**
                
                • **Charge Level:** ${info.levelPct}%
                • **Status:** $chargingIcon (${info.statusStr})
                • **Temperature:** ${String.format(Locale.US, "%.1f", info.temperatureC)}°C
                • **Health:** ${info.healthStr}
            """.trimIndent()
            return OfflineAiResult(
                responseText = text,
                category = OfflineAiCategory.DEVICE_CONTROL,
                executedAction = "Checked Battery",
                isActionExecuted = true
            )
        }

        // RAM / Memory Usage
        if (lower.contains("ram") || lower.contains("র‍্যাম") || lower.contains("memory usage")) {
            val ram = deviceManager.getRamInfo()
            val text = """
                🧠 **[System RAM Diagnostics]**
                
                • **Total RAM:** ${String.format(Locale.US, "%.2f", ram.totalGb)} GB
                • **Available RAM:** ${String.format(Locale.US, "%.2f", ram.freeGb)} GB
                • **Used RAM:** ${String.format(Locale.US, "%.2f", ram.usedGb)} GB (${ram.usedPct}%)
            """.trimIndent()
            return OfflineAiResult(
                responseText = text,
                category = OfflineAiCategory.DEVICE_CONTROL,
                executedAction = "Checked RAM",
                isActionExecuted = true
            )
        }

        // Storage Space
        if (lower.contains("storage") || lower.contains("disk") || lower.contains("স্টোরেজ") || lower.contains("মেমরি কত খালি")) {
            val storage = deviceManager.getStorageInfo()
            val text = """
                💾 **[Device Internal Storage]**
                
                • **Total Space:** ${String.format(Locale.US, "%.2f", storage.totalGb)} GB
                • **Free Space:** ${String.format(Locale.US, "%.2f", storage.freeGb)} GB
                • **Used Space:** ${String.format(Locale.US, "%.2f", storage.usedGb)} GB (${storage.usedPct}%)
            """.trimIndent()
            return OfflineAiResult(
                responseText = text,
                category = OfflineAiCategory.DEVICE_CONTROL,
                executedAction = "Checked Storage",
                isActionExecuted = true
            )
        }

        // System Specs
        if (lower.contains("device specs") || lower.contains("system info") || lower.contains("ডিভাইস ইনফো")) {
            val specs = deviceManager.getSystemSpecs()
            val text = """
                📱 **[System Specifications]**
                
                • **Device Model:** ${specs.manufacturer} ${specs.deviceModel}
                • **OS Version:** Android ${specs.osVersion}
                • **CPU Architecture:** ${specs.abi} (${specs.cpuCores} Cores)
                • **System Uptime:** ${specs.uptimeFormatted}
            """.trimIndent()
            return OfflineAiResult(
                responseText = text,
                category = OfflineAiCategory.DEVICE_CONTROL,
                executedAction = "Checked System Specs",
                isActionExecuted = true
            )
        }

        return null
    }

    /**
     * Notes and local database memory handling.
     */
    private suspend fun handleNoteOrMemory(lower: String, original: String): OfflineAiResult? {
        // Save note or remember instruction
        val isSaveNote = lower.startsWith("note:") ||
                lower.startsWith("note that") ||
                lower.startsWith("remember that") ||
                lower.startsWith("save note") ||
                lower.startsWith("মনে রাখো") ||
                lower.startsWith("নোট করো")

        if (isSaveNote) {
            val cleanContent = original
                .replace("note:", "", ignoreCase = true)
                .replace("note that", "", ignoreCase = true)
                .replace("remember that", "", ignoreCase = true)
                .replace("save note", "", ignoreCase = true)
                .replace("মনে রাখো", "", ignoreCase = true)
                .replace("নোট করো", "", ignoreCase = true)
                .trim()

            if (cleanContent.isNotBlank()) {
                val key = "Note-${SimpleDateFormat("MMM d, HH:mm", Locale.US).format(Date())}"
                repository.addMemory(key = key, value = cleanContent, category = "Offline Note")
                return OfflineAiResult(
                    responseText = "📝 **[Offline Note Saved]**\n\nI have securely saved this to your local database memory:\n\n> \"$cleanContent\"\n\n*(Accessible offline anytime in the Memory tab)*",
                    category = OfflineAiCategory.NOTE_MEMORY,
                    executedAction = "Saved Note",
                    isActionExecuted = true
                )
            }
        }

        // List notes or view memories
        val isListNotes = lower.contains("list notes") ||
                lower.contains("show notes") ||
                lower.contains("my notes") ||
                lower.contains("আমার নোট") ||
                lower.contains("নোটগুলো দেখাও")

        if (isListNotes) {
            val memories = repository.getAllMemoriesSync()
            return if (memories.isEmpty()) {
                OfflineAiResult(
                    responseText = "📋 **[Local Notes & Memory]**\n\nYou have no saved notes yet. You can say **\"Note that [your text]\"** to record one offline!",
                    category = OfflineAiCategory.NOTE_MEMORY
                )
            } else {
                val sb = StringBuilder("📋 **[Local Notes & Memory Vault]**\n\n")
                memories.take(8).forEachIndexed { i, m ->
                    sb.append("${i + 1}. **${m.key}** (${m.category}): ${m.value}\n")
                }
                if (memories.size > 8) {
                    sb.append("\n*...plus ${memories.size - 8} more in the Memory tab.*")
                }
                OfflineAiResult(
                    responseText = sb.toString(),
                    category = OfflineAiCategory.NOTE_MEMORY,
                    executedAction = "Listed Notes",
                    isActionExecuted = true
                )
            }
        }

        return null
    }

    /**
     * Time and date queries.
     */
    private fun handleTimeDate(lower: String): OfflineAiResult? {
        if (lower.contains("what time") || lower.contains("current time") || lower.contains("কয়টা বাজে") || lower.contains("সময় কত")) {
            val time = SimpleDateFormat("hh:mm:ss a (zzzz)", Locale.getDefault()).format(Date())
            return OfflineAiResult(
                responseText = "🕒 **[Local Clock]**\n\nCurrent time is **$time**.",
                category = OfflineAiCategory.TIME_DATE,
                executedAction = "Checked Time",
                isActionExecuted = true
            )
        }

        if (lower.contains("what date") || lower.contains("today's date") || lower.contains("আজকে কি বার") || lower.contains("তারিখ কত")) {
            val date = SimpleDateFormat("EEEE, MMMM d, yyyy", Locale.getDefault()).format(Date())
            return OfflineAiResult(
                responseText = "📅 **[Local Calendar]**\n\nToday is **$date**.",
                category = OfflineAiCategory.TIME_DATE,
                executedAction = "Checked Date",
                isActionExecuted = true
            )
        }

        return null
    }

    /**
     * Offline Knowledge Base queries from TechKnowledgeEngine.
     */
    private fun handleOfflineKnowledge(lower: String): OfflineAiResult? {
        if (lower.contains("freelancing") || lower.contains("fiverr") || lower.contains("upwork") ||
            lower.contains("python") || lower.contains("termux") || lower.contains("earning") ||
            lower.contains("আর্নিং") || lower.contains("ফ্রিল্যান্সিং")
        ) {
            val guide = TechKnowledgeEngine.getInstantGuide(lower)
            if (guide != null) {
                return OfflineAiResult(
                    responseText = "📚 **[Offline Tech & Earning Guide]**\n\n$guide\n\n*(Retrieved directly from local offline knowledge cache)*",
                    category = OfflineAiCategory.KNOWLEDGE_BASE,
                    executedAction = "Retrieved Tech Guide",
                    isActionExecuted = true
                )
            }
        }
        return null
    }

    /**
     * Kung-Fu warrior persona conversational fallback when offline.
     */
    private fun handleConversationalFallback(
        lower: String,
        userName: String,
        preferredTitle: String
    ): OfflineAiResult {
        // Greetings
        val isGreeting = lower.contains("hello") || lower.contains("hi") || lower.contains("salam") ||
                lower.contains("সালাম") || lower.contains("কেমন আছো") || lower.contains("hey")

        val response = if (isGreeting) {
            """
                🥋 **Assalamu Alaikum $preferredTitle!**
                
                I am **Atik AI**, operating on **Local Offline Neural Fallback**.
                
                Even without an internet connection, my offline engine can execute:
                • 🧮 **Instant Math & Calculator:** (e.g. `25 * 400`, `100 USD to BDT`, `20% of 1500`)
                • 📝 **Local Notes & Memory:** (e.g. `Note that my client meeting is at 4 PM`)
                • 🔦 **Hardware Controls:** Flashlight on/off, Battery %, RAM & Storage telemetry
                • 📚 **Offline Academy Guides:** Python shortcuts, Freelancing steps & Termux tips
                • 🕒 **System Clock & Calendar:** Instant local time & date
                
                How can I assist you right now, Boss?
            """.trimIndent()
        } else {
            """
                🥋 **[Atik AI Offline Mode Active]**
                
                Boss $preferredTitle, we are currently disconnected from the cloud network.
                
                **Supported Offline Tools:**
                1. **Calculator & Currency:** `calculate 500 * 12`, `100 USD to BDT`
                2. **Save Local Notes:** `Note that [text]`, `List my notes`
                3. **Device Control:** `Flashlight on/off`, `Battery status`, `Check RAM`
                4. **Offline Guides:** `freelancing guide`, `python tips`
                
                *Note: Complex creative coding or open web inquiries will automatically synchronize once the network reconnects.*
            """.trimIndent()
        }

        return OfflineAiResult(
            responseText = response,
            category = OfflineAiCategory.CONVERSATIONAL_FALLBACK
        )
    }
}
