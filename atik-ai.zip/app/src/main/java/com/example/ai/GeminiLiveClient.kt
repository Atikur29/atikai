package com.example.ai

import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import org.json.JSONObject
import java.util.concurrent.TimeUnit

enum class GeminiLiveStatus {
    DISCONNECTED,
    CONNECTING,
    CONNECTED,
    FALLBACK_MODE,
    ERROR
}

/**
 * Gemini Live Client implementing bidirectional streaming over WebSockets.
 * Supports model 'gemini-3.8-live' / 'gemini-2.5-flash-native-audio-preview-12-2025'
 * with graceful fallback to STT -> Gemini Flash -> TTS.
 */
class GeminiLiveClient(
    private val scope: CoroutineScope,
    private val getApiKey: () -> String
) {
    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(0, TimeUnit.MILLISECONDS)
        .pingInterval(15, TimeUnit.SECONDS)
        .build()

    private var webSocket: WebSocket? = null

    private val _status = MutableStateFlow(GeminiLiveStatus.DISCONNECTED)
    val status: StateFlow<GeminiLiveStatus> = _status.asStateFlow()

    private val _lastAiText = MutableStateFlow("")
    val lastAiText: StateFlow<String> = _lastAiText.asStateFlow()

    private val _errorMessage = MutableStateFlow<String?>(null)
    val errorMessage: StateFlow<String?> = _errorMessage.asStateFlow()

    var onFallbackNeeded: (() -> Unit)? = null
    var onLiveTextReceived: ((String) -> Unit)? = null

    fun connectLiveSession(modelName: String = "gemini-3.8-live") {
        val apiKey = getApiKey()
        if (apiKey.isBlank()) {
            _status.value = GeminiLiveStatus.FALLBACK_MODE
            onFallbackNeeded?.invoke()
            return
        }

        _status.value = GeminiLiveStatus.CONNECTING
        _errorMessage.value = null

        val liveModelParam = if (modelName.contains("live", ignoreCase = true)) {
            "models/gemini-2.5-flash-native-audio-preview-12-2025"
        } else {
            "models/$modelName"
        }

        val url = "wss://generativelanguage.googleapis.com/ws/google.ai.generativelanguage.v1alpha.GenerativeService.BidiGenerateContent?key=$apiKey"
        val request = Request.Builder().url(url).build()

        webSocket = client.newWebSocket(request, object : WebSocketListener() {
            override fun onOpen(webSocket: WebSocket, response: Response) {
                Log.d("GeminiLiveClient", "WebSocket connected successfully.")
                _status.value = GeminiLiveStatus.CONNECTED

                // Send setup message
                val setupPayload = JSONObject().apply {
                    val setup = JSONObject().apply {
                        put("model", liveModelParam)
                        val genConfig = JSONObject().apply {
                            put("responseModalities", org.json.JSONArray().apply {
                                put("AUDIO")
                                put("TEXT")
                            })
                            val speechConfig = JSONObject().apply {
                                val voiceConfig = JSONObject().apply {
                                    val prebuilt = JSONObject().apply {
                                        put("voiceName", "Kore")
                                    }
                                    put("prebuiltVoiceConfig", prebuilt)
                                }
                                put("voiceConfig", voiceConfig)
                            }
                            put("speechConfig", speechConfig)
                        }
                        put("generationConfig", genConfig)
                    }
                    put("setup", setup)
                }

                webSocket.send(setupPayload.toString())
            }

            override fun onMessage(webSocket: WebSocket, text: String) {
                try {
                    val root = JSONObject(text)
                    val serverContent = root.optJSONObject("serverContent")
                    val modelTurn = serverContent?.optJSONObject("modelTurn")
                    val parts = modelTurn?.optJSONArray("parts")
                    if (parts != null && parts.length() > 0) {
                        for (i in 0 until parts.length()) {
                            val part = parts.getJSONObject(i)
                            if (part.has("text")) {
                                val chunk = part.getString("text")
                                _lastAiText.value = chunk
                                onLiveTextReceived?.invoke(chunk)
                            }
                        }
                    }
                } catch (e: Exception) {
                    Log.e("GeminiLiveClient", "Error parsing live message: ${e.message}")
                }
            }

            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                Log.w("GeminiLiveClient", "Live WebSocket connection fallback triggered: ${t.message}")
                _status.value = GeminiLiveStatus.FALLBACK_MODE
                _errorMessage.value = t.message
                scope.launch(Dispatchers.Main) {
                    onFallbackNeeded?.invoke()
                }
            }

            override fun onClosing(webSocket: WebSocket, code: Int, reason: String) {
                webSocket.close(1000, null)
                _status.value = GeminiLiveStatus.DISCONNECTED
            }

            override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
                _status.value = GeminiLiveStatus.DISCONNECTED
            }
        })
    }

    fun sendText(text: String) {
        val ws = webSocket
        if (ws != null && _status.value == GeminiLiveStatus.CONNECTED) {
            val clientContent = JSONObject().apply {
                val turn = JSONObject().apply {
                    put("role", "user")
                    val parts = org.json.JSONArray().apply {
                        put(JSONObject().put("text", text))
                    }
                    put("parts", parts)
                }
                put("clientContent", JSONObject().apply {
                    put("turns", org.json.JSONArray().apply { put(turn) })
                    put("turnComplete", true)
                })
            }
            ws.send(clientContent.toString())
        }
    }

    fun disconnect() {
        try {
            webSocket?.close(1000, "User stopped live session")
            webSocket = null
        } catch (e: Exception) {
            Log.e("GeminiLiveClient", "Error closing WebSocket: ${e.message}")
        } finally {
            _status.value = GeminiLiveStatus.DISCONNECTED
        }
    }
}
