package com.example.widget

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

enum class ShortcutActionType {
    MORNING_BRIEFING,
    EVENING_SUMMARY,
    FLASHLIGHT_TOGGLE,
    BATTERY_CHECK,
    DEEP_WORK_FOCUS,
    QUICK_NOTE,
    TRANSLATE_BANGLA,
    CUSTOM_PROMPT
}

data class VoiceShortcut(
    val id: String = UUID.randomUUID().toString(),
    val title: String,
    val triggerPhrase: String,
    val actionType: ShortcutActionType,
    val iconEmoji: String,
    val customPrompt: String = "",
    val isCustom: Boolean = false
)

/**
 * Quick Voice Shortcuts Engine (Step 14 Requirement 2).
 * Manages system-wide trigger phrases, pre-configured rapid actions, and customizable shortcut mappings.
 */
class VoiceShortcutsEngine(private val context: Context) {

    private val prefs: SharedPreferences =
        context.getSharedPreferences("atik_voice_shortcuts_prefs", Context.MODE_PRIVATE)

    private val _shortcuts = MutableStateFlow<List<VoiceShortcut>>(emptyList())
    val shortcuts: StateFlow<List<VoiceShortcut>> = _shortcuts.asStateFlow()

    companion object {
        val DEFAULT_SHORTCUTS = listOf(
            VoiceShortcut(
                id = "sc_morning",
                title = "Morning Briefing",
                triggerPhrase = "Morning briefing",
                actionType = ShortcutActionType.MORNING_BRIEFING,
                iconEmoji = "🌅"
            ),
            VoiceShortcut(
                id = "sc_flashlight",
                title = "Toggle Flashlight",
                triggerPhrase = "Turn on flashlight",
                actionType = ShortcutActionType.FLASHLIGHT_TOGGLE,
                iconEmoji = "🔦"
            ),
            VoiceShortcut(
                id = "sc_battery",
                title = "Battery Telemetry",
                triggerPhrase = "Check battery status",
                actionType = ShortcutActionType.BATTERY_CHECK,
                iconEmoji = "🔋"
            ),
            VoiceShortcut(
                id = "sc_focus",
                title = "Deep Work Sprint",
                triggerPhrase = "Start focus session",
                actionType = ShortcutActionType.DEEP_WORK_FOCUS,
                iconEmoji = "⚡"
            ),
            VoiceShortcut(
                id = "sc_evening",
                title = "Evening Summary",
                triggerPhrase = "Evening recap",
                actionType = ShortcutActionType.EVENING_SUMMARY,
                iconEmoji = "🌇"
            ),
            VoiceShortcut(
                id = "sc_translate",
                title = "Translate to Bangla",
                triggerPhrase = "Translate to Bangla",
                actionType = ShortcutActionType.TRANSLATE_BANGLA,
                iconEmoji = "🌐"
            )
        )
    }

    init {
        loadShortcuts()
    }

    private fun loadShortcuts() {
        val savedJson = prefs.getString("custom_shortcuts", null)
        val list = mutableListOf<VoiceShortcut>()
        list.addAll(DEFAULT_SHORTCUTS)

        if (!savedJson.isNullOrBlank()) {
            try {
                val array = JSONArray(savedJson)
                for (i in 0 until array.length()) {
                    val obj = array.getJSONObject(i)
                    val actionName = obj.optString("actionType", ShortcutActionType.CUSTOM_PROMPT.name)
                    val actionType = try {
                        ShortcutActionType.valueOf(actionName)
                    } catch (_: Exception) {
                        ShortcutActionType.CUSTOM_PROMPT
                    }
                    list.add(
                        VoiceShortcut(
                            id = obj.optString("id", UUID.randomUUID().toString()),
                            title = obj.optString("title", "Custom Shortcut"),
                            triggerPhrase = obj.optString("triggerPhrase", ""),
                            actionType = actionType,
                            iconEmoji = obj.optString("iconEmoji", "⚡"),
                            customPrompt = obj.optString("customPrompt", ""),
                            isCustom = true
                        )
                    )
                }
            } catch (_: Exception) {
            }
        }
        _shortcuts.value = list
    }

    fun addCustomShortcut(title: String, triggerPhrase: String, customPrompt: String, iconEmoji: String = "⚡") {
        val shortcut = VoiceShortcut(
            title = title.trim(),
            triggerPhrase = triggerPhrase.trim(),
            actionType = ShortcutActionType.CUSTOM_PROMPT,
            iconEmoji = iconEmoji,
            customPrompt = customPrompt.trim(),
            isCustom = true
        )
        val current = _shortcuts.value.toMutableList()
        current.add(shortcut)
        _shortcuts.value = current
        saveCustomShortcuts(current.filter { it.isCustom })
    }

    fun deleteShortcut(id: String) {
        val current = _shortcuts.value.filter { it.id != id }
        _shortcuts.value = current
        saveCustomShortcuts(current.filter { it.isCustom })
    }

    private fun saveCustomShortcuts(customList: List<VoiceShortcut>) {
        val array = JSONArray()
        customList.forEach { sc ->
            val obj = JSONObject().apply {
                put("id", sc.id)
                put("title", sc.title)
                put("triggerPhrase", sc.triggerPhrase)
                put("actionType", sc.actionType.name)
                put("iconEmoji", sc.iconEmoji)
                put("customPrompt", sc.customPrompt)
            }
            array.put(obj)
        }
        prefs.edit().putString("custom_shortcuts", array.toString()).apply()
    }

    /**
     * Matches a spoken transcript against registered trigger phrases.
     */
    fun findMatchingShortcut(speechTranscript: String): VoiceShortcut? {
        val clean = speechTranscript.trim().lowercase()
        return _shortcuts.value.firstOrNull { sc ->
            clean.contains(sc.triggerPhrase.lowercase()) ||
            sc.triggerPhrase.lowercase().contains(clean)
        }
    }
}
