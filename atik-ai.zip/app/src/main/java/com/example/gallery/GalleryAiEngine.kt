package com.example.gallery

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import com.example.ai.GeminiService
import com.example.ai.LanguageMode
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.InputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

enum class PhotoCategory(val displayName: String, val emoji: String) {
    ALL("All Photos", "🖼️"),
    PEOPLE("People & Selfies", "👤"),
    DOCUMENTS("Documents & Receipts", "📄"),
    NATURE("Nature & Scenery", "🌲"),
    TECH("Tech & Gadgets", "💻"),
    FOOD("Food & Dining", "☕"),
    TRAVEL("Travel & Cities", "✈️"),
    VEHICLES("Vehicles & Cars", "🚗")
}

data class GalleryPhotoItem(
    val id: String,
    val title: String,
    val uriString: String? = null,
    val description: String,
    val category: PhotoCategory,
    val semanticTags: List<String>,
    val timestampFormatted: String,
    val isUserImported: Boolean = false,
    val visualIconEmoji: String = "🖼️",
    val confidencePct: Int = 95
)

data class SemanticSearchResult(
    val query: String,
    val matches: List<GalleryPhotoItem>,
    val matchCount: Int,
    val executionTimeMs: Long
)

/**
 * AI Gallery & Semantic Photo Finder Engine (Step 20).
 * Deep Vision AI indexing of photos allowing natural-language semantic queries
 * like "sunglasses picture", "documents", "nature", "receipts", etc.
 */
class GalleryAiEngine(
    private val context: Context,
    private val geminiService: GeminiService
) {

    private val _photos = MutableStateFlow<List<GalleryPhotoItem>>(getInitialPhotoCatalog())
    val photos: StateFlow<List<GalleryPhotoItem>> = _photos.asStateFlow()

    private val _selectedCategory = MutableStateFlow(PhotoCategory.ALL)
    val selectedCategory: StateFlow<PhotoCategory> = _selectedCategory.asStateFlow()

    private val _isAnalyzing = MutableStateFlow(false)
    val isAnalyzing: StateFlow<Boolean> = _isAnalyzing.asStateFlow()

    private val _lastSearchResult = MutableStateFlow<SemanticSearchResult?>(null)
    val lastSearchResult: StateFlow<SemanticSearchResult?> = _lastSearchResult.asStateFlow()

    fun selectCategory(category: PhotoCategory) {
        _selectedCategory.value = category
    }

    /**
     * Semantic search engine for photos.
     * Evaluates natural language queries against semantic tags, category names,
     * visual descriptions, and synonym networks.
     */
    fun searchPhotos(query: String): SemanticSearchResult {
        val startTime = System.currentTimeMillis()
        val trimmedQuery = query.trim().lowercase()

        if (trimmedQuery.isEmpty()) {
            val all = _photos.value
            val res = SemanticSearchResult(query, all, all.size, 0)
            _lastSearchResult.value = res
            return res
        }

        // Expanded semantic tokens / synonyms mapping
        val queryTokens = trimmedQuery.split(Regex("\\s+")).filter { it.isNotBlank() }

        val synonymMap = mapOf(
            "sunglasses" to listOf("sunglasses", "glasses", "shades", "eyewear", "goggles", "spectacles", "portrait", "face"),
            "document" to listOf("documents", "document", "invoice", "receipt", "passport", "paperwork", "tax", "text", "bill", "contract"),
            "documents" to listOf("documents", "document", "invoice", "receipt", "passport", "paperwork", "tax", "text", "bill", "contract"),
            "nature" to listOf("nature", "mountain", "trees", "lake", "forest", "sunset", "landscape", "river", "beach", "green"),
            "tech" to listOf("tech", "laptop", "code", "computer", "gadget", "keyboard", "coding", "screen", "workstation"),
            "food" to listOf("food", "coffee", "croissant", "breakfast", "latte", "dining", "meal", "snack", "cafe"),
            "travel" to listOf("travel", "city", "skyline", "architecture", "urban", "night", "hotel", "street"),
            "car" to listOf("vehicles", "car", "supercar", "automotive", "speed", "drive", "road")
        )

        val targetKeywords = mutableSetOf<String>()
        for (token in queryTokens) {
            targetKeywords.add(token)
            synonymMap[token]?.let { targetKeywords.addAll(it) }
        }

        val rankedPhotos = _photos.value.mapNotNull { photo ->
            var matchScore = 0
            val lowerDesc = photo.description.lowercase()
            val lowerTitle = photo.title.lowercase()
            val lowerCategory = photo.category.displayName.lowercase()

            // 1. Direct query substring match
            if (lowerDesc.contains(trimmedQuery) || lowerTitle.contains(trimmedQuery)) {
                matchScore += 10
            }

            // 2. Token match against tags
            for (tag in photo.semanticTags) {
                val lowerTag = tag.lowercase()
                for (kw in targetKeywords) {
                    if (lowerTag == kw) {
                        matchScore += 8
                    } else if (lowerTag.contains(kw) || kw.contains(lowerTag)) {
                        matchScore += 4
                    }
                }
            }

            // 3. Token match against title & description
            for (kw in targetKeywords) {
                if (lowerTitle.contains(kw)) matchScore += 5
                if (lowerDesc.contains(kw)) matchScore += 3
                if (lowerCategory.contains(kw)) matchScore += 4
            }

            if (matchScore > 0) {
                photo to matchScore
            } else {
                null
            }
        }.sortedByDescending { it.second }.map { it.first }

        val duration = System.currentTimeMillis() - startTime
        val result = SemanticSearchResult(
            query = query,
            matches = rankedPhotos,
            matchCount = rankedPhotos.size,
            executionTimeMs = duration
        )

        _lastSearchResult.value = result
        return result
    }

    /**
     * Analyzes and imports a user selected device photo using Vision AI.
     */
    suspend fun indexImportedPhoto(uri: Uri): GalleryPhotoItem = withContext(Dispatchers.IO) {
        _isAnalyzing.value = true
        val photoId = "user_photo_${System.currentTimeMillis()}"
        val dateFormatted = SimpleDateFormat("MMM d, yyyy", Locale.getDefault()).format(Date())

        var detectedCategory = PhotoCategory.PEOPLE
        var visualTitle = "Imported Photo"
        var visualDescription = "User photo indexed with Atik AI Vision Engine."
        var tags = listOf("photo", "gallery", "device")
        var icon = "🖼️"

        try {
            val bitmap = loadBitmapFromUri(uri)
            if (bitmap != null) {
                // Call Gemini to analyze the image
                val prompt = """
                    Analyze this photo for smart gallery indexing.
                    Output a JSON object with:
                    {
                      "title": "Short descriptive title (3-5 words)",
                      "category": "PEOPLE / DOCUMENTS / NATURE / TECH / FOOD / TRAVEL / VEHICLES",
                      "description": "Clear 1-2 sentence description of subjects, clothing, objects, and setting.",
                      "tags": ["tag1", "tag2", "tag3", "tag4", "tag5"],
                      "iconEmoji": "Representative emoji (e.g. 🕶️, 📄, 🌲, 💻, ☕, 🚗)"
                    }
                    Output JSON ONLY.
                """.trimIndent()

                val reply = geminiService.generateReply(
                    prompt = prompt,
                    history = emptyList(),
                    languageMode = LanguageMode.ENGLISH,
                    memories = emptyList(),
                    model = "gemini-3.5-flash",
                    customApiKey = null,
                    imageBitmap = bitmap
                )

                val raw = reply.getOrNull()?.trim()
                if (raw != null) {
                    val jsonStr = extractJsonFromResponse(raw)
                    val json = JSONObject(jsonStr)
                    visualTitle = json.optString("title", "Imported Photo")
                    visualDescription = json.optString("description", visualDescription)
                    icon = json.optString("iconEmoji", "🖼️")

                    val catStr = json.optString("category", "PEOPLE").uppercase()
                    detectedCategory = when {
                        catStr.contains("DOC") -> PhotoCategory.DOCUMENTS
                        catStr.contains("NAT") -> PhotoCategory.NATURE
                        catStr.contains("TEC") -> PhotoCategory.TECH
                        catStr.contains("FOO") -> PhotoCategory.FOOD
                        catStr.contains("TRA") -> PhotoCategory.TRAVEL
                        catStr.contains("VEH") -> PhotoCategory.VEHICLES
                        else -> PhotoCategory.PEOPLE
                    }

                    val tagsArray = json.optJSONArray("tags")
                    if (tagsArray != null) {
                        val parsedTags = mutableListOf<String>()
                        for (i in 0 until tagsArray.length()) {
                            parsedTags.add(tagsArray.getString(i))
                        }
                        if (parsedTags.isNotEmpty()) tags = parsedTags
                    }
                }
            }
        } catch (_: Exception) {
            visualTitle = "Device Photo"
            visualDescription = "Photo indexed into local device gallery catalog."
        }

        val newItem = GalleryPhotoItem(
            id = photoId,
            title = visualTitle,
            uriString = uri.toString(),
            description = visualDescription,
            category = detectedCategory,
            semanticTags = tags,
            timestampFormatted = dateFormatted,
            isUserImported = true,
            visualIconEmoji = icon,
            confidencePct = 98
        )

        _photos.value = listOf(newItem) + _photos.value
        _isAnalyzing.value = false
        newItem
    }

    private fun loadBitmapFromUri(uri: Uri): Bitmap? {
        return try {
            val input: InputStream? = context.contentResolver.openInputStream(uri)
            BitmapFactory.decodeStream(input)
        } catch (_: Exception) {
            null
        }
    }

    private fun extractJsonFromResponse(response: String): String {
        val start = response.indexOf('{')
        val end = response.lastIndexOf('}')
        return if (start != -1 && end != -1 && end > start) {
            response.substring(start, end + 1)
        } else {
            response
        }
    }

    private fun getInitialPhotoCatalog(): List<GalleryPhotoItem> {
        return listOf(
            GalleryPhotoItem(
                id = "photo_sunglasses_01",
                title = "Summer Portrait with Sunglasses",
                description = "Portrait of a person wearing black designer sunglasses outdoors under sunny golden hour lighting.",
                category = PhotoCategory.PEOPLE,
                semanticTags = listOf("sunglasses", "glasses", "shades", "portrait", "eyewear", "summer", "outdoor", "fashion"),
                timestampFormatted = "Yesterday, 4:15 PM",
                visualIconEmoji = "🕶️",
                confidencePct = 99
            ),
            GalleryPhotoItem(
                id = "photo_document_02",
                title = "Verified Tax Invoice Document",
                description = "High-contrast scanned official invoice and transaction receipt with itemized line entries.",
                category = PhotoCategory.DOCUMENTS,
                semanticTags = listOf("documents", "document", "invoice", "receipt", "passport", "tax", "paperwork", "contract", "billing"),
                timestampFormatted = "Sep 28, 2026",
                visualIconEmoji = "📄",
                confidencePct = 98
            ),
            GalleryPhotoItem(
                id = "photo_nature_03",
                title = "Alpine Mountain Forest & Lake",
                description = "Panoramic mountain landscape with evergreen pine trees and serene turquoise lake reflection at sunset.",
                category = PhotoCategory.NATURE,
                semanticTags = listOf("nature", "mountain", "trees", "forest", "lake", "sunset", "landscape", "hiking", "greenery"),
                timestampFormatted = "Sep 25, 2026",
                visualIconEmoji = "🌲",
                confidencePct = 97
            ),
            GalleryPhotoItem(
                id = "photo_tech_04",
                title = "AI Engineering Coding Station",
                description = "Dual-monitor developer workstation featuring an RGB mechanical keyboard, code editor, and high-performance laptop.",
                category = PhotoCategory.TECH,
                semanticTags = listOf("tech", "laptop", "code", "workstation", "monitor", "developer", "hardware", "keyboard", "programming"),
                timestampFormatted = "Sep 20, 2026",
                visualIconEmoji = "💻",
                confidencePct = 96
            ),
            GalleryPhotoItem(
                id = "photo_food_05",
                title = "Artisan Espresso & Bakery Croissant",
                description = "Warm espresso cup decorated with delicate latte foam art accompanied by a fresh butter croissant.",
                category = PhotoCategory.FOOD,
                semanticTags = listOf("food", "coffee", "croissant", "espresso", "latte", "breakfast", "cafe", "pastry", "dining"),
                timestampFormatted = "Sep 18, 2026",
                visualIconEmoji = "☕",
                confidencePct = 97
            ),
            GalleryPhotoItem(
                id = "photo_travel_06",
                title = "Tokyo Metropolis Neon Skyline",
                description = "Vibrant night cityscape illuminated by towering skyscrapers, neon billboards, and urban traffic reflections.",
                category = PhotoCategory.TRAVEL,
                semanticTags = listOf("travel", "city", "skyline", "night", "urban", "architecture", "skyscrapers", "neon", "tokyo"),
                timestampFormatted = "Sep 15, 2026",
                visualIconEmoji = "🌆",
                confidencePct = 95
            ),
            GalleryPhotoItem(
                id = "photo_car_07",
                title = "Matte Blue Electric Supercar",
                description = "Aerodynamic electric sports car with carbon fiber accents parked along a coastal highway.",
                category = PhotoCategory.VEHICLES,
                semanticTags = listOf("vehicles", "car", "supercar", "automotive", "sports car", "coastal", "speed", "ev"),
                timestampFormatted = "Sep 10, 2026",
                visualIconEmoji = "🏎️",
                confidencePct = 96
            )
        )
    }
}
