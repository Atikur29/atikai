package com.example.translation

import android.content.Context
import com.example.ai.GeminiService
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext

data class TranslationResult(
    val sourceText: String,
    val translatedText: String,
    val detectedSourceLanguage: LanguageInfo,
    val targetLanguage: LanguageInfo,
    val latencyMs: Long,
    val isOfflineFallback: Boolean = false,
    val timestamp: Long = System.currentTimeMillis()
)

/**
 * Global Multi-Language Translation Engine (Step 17 Requirement 1 & 3).
 * Supports translation across 100+ global languages with automated language detection
 * and contextual preservation.
 */
class GlobalTranslationEngine(
    private val context: Context,
    private val geminiService: GeminiService
) {

    private val _isTranslating = MutableStateFlow(false)
    val isTranslating: StateFlow<Boolean> = _isTranslating.asStateFlow()

    private val _lastResult = MutableStateFlow<TranslationResult?>(null)
    val lastResult: StateFlow<TranslationResult?> = _lastResult.asStateFlow()

    private val _translationHistory = MutableStateFlow<List<TranslationResult>>(emptyList())
    val translationHistory: StateFlow<List<TranslationResult>> = _translationHistory.asStateFlow()

    /**
     * Translates input text into target language.
     * If sourceCode is "auto", performs auto-detection first.
     */
    suspend fun translate(
        text: String,
        sourceCode: String = "auto",
        targetCode: String = "en"
    ): TranslationResult = withContext(Dispatchers.IO) {
        val startTime = System.currentTimeMillis()
        _isTranslating.value = true

        val detected = if (sourceCode == "auto" || sourceCode.isBlank()) {
            LanguageDetector.detectLanguage(text)
        } else {
            val info = GlobalLanguageCatalog.findByCode(sourceCode)
            DetectedLanguage(info.code, info.name, 1.0f, info.flagEmoji)
        }

        val sourceLang = GlobalLanguageCatalog.findByCode(detected.languageCode)
        val targetLang = GlobalLanguageCatalog.findByCode(targetCode)

        // If source and target are identical
        if (sourceLang.code.equals(targetLang.code, ignoreCase = true)) {
            val result = TranslationResult(
                sourceText = text,
                translatedText = text,
                detectedSourceLanguage = sourceLang,
                targetLanguage = targetLang,
                latencyMs = System.currentTimeMillis() - startTime
            )
            _lastResult.value = result
            _isTranslating.value = false
            return@withContext result
        }

        val prompt = buildTranslationPrompt(text, sourceLang.name, targetLang.name)

        var translatedOutput: String
        var isOffline = false

        try {
            val response = geminiService.generateReply(
                prompt = prompt,
                history = emptyList(),
                languageMode = com.example.ai.LanguageMode.ENGLISH,
                memories = emptyList(),
                model = "gemini-3.5-flash"
            )
            translatedOutput = cleanTranslationResponse(response.getOrThrow())
        } catch (_: Exception) {
            // Offline fallback
            isOffline = true
            translatedOutput = fallbackOfflineTranslate(text, sourceLang.code, targetLang.code)
        }

        val latency = System.currentTimeMillis() - startTime
        val result = TranslationResult(
            sourceText = text,
            translatedText = translatedOutput,
            detectedSourceLanguage = sourceLang,
            targetLanguage = targetLang,
            latencyMs = latency,
            isOfflineFallback = isOffline
        )

        _lastResult.value = result
        _translationHistory.value = listOf(result) + _translationHistory.value.take(19)
        _isTranslating.value = false

        result
    }

    private fun buildTranslationPrompt(text: String, sourceName: String, targetName: String): String {
        return """
            You are the professional Global Translation Engine for Atik AI.
            Translate the following text accurately from $sourceName to $targetName.
            Rules:
            1. Provide ONLY the direct translation without preamble, conversational remarks, or quotation marks.
            2. Preserve tone, formatting, line breaks, and cultural nuances.
            3. If technical terms or code blocks are included, translate comments or natural text while preserving technical integrity.
            
            Text to translate:
            $text
        """.trimIndent()
    }

    private fun cleanTranslationResponse(raw: String): String {
        var clean = raw.trim()
        if (clean.startsWith("\"") && clean.endsWith("\"") && clean.length > 1) {
            clean = clean.substring(1, clean.length - 1).trim()
        }
        return clean
    }

    private fun fallbackOfflineTranslate(text: String, from: String, to: String): String {
        // Basic dictionary / heuristic fallback for common phrases
        val common = mapOf(
            "hello" to mapOf("bn" to "হ্যালো", "es" to "Hola", "fr" to "Bonjour", "de" to "Hallo", "ar" to "مرحبا", "hi" to "नमस्ते"),
            "thank you" to mapOf("bn" to "ধন্যবাদ", "es" to "Gracias", "fr" to "Merci", "de" to "Danke", "ar" to "شكرا", "hi" to "धन्यवाद"),
            "how are you" to mapOf("bn" to "আপনি কেমন আছেন?", "es" to "¿Cómo estás?", "fr" to "Comment allez-vous?", "de" to "Wie geht es Ihnen?", "ar" to "كيف حالك؟"),
            "good morning" to mapOf("bn" to "শুভ সকাল", "es" to "Buenos días", "fr" to "Bonjour", "de" to "Guten Morgen", "ar" to "صباح الخير"),
            "good night" to mapOf("bn" to "শুভ রাত্রি", "es" to "Buenas noches", "fr" to "Bonne nuit", "de" to "Gute Nacht", "ar" to "تصبح على خير")
        )

        val lower = text.trim().lowercase()
        val entry = common[lower]
        if (entry != null && entry.containsKey(to)) {
            return entry[to] ?: text
        }

        return "[Offline Translation] $text"
    }

    fun clearHistory() {
        _translationHistory.value = emptyList()
    }
}
