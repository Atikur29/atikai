package com.example.translation

data class DetectedLanguage(
    val languageCode: String,
    val languageName: String,
    val confidence: Float,
    val flagEmoji: String
)

/**
 * Real-Time Auto Language Detection Engine (Step 17 Requirement 3).
 * Identifies input text language using Unicode block heuristics,
 * character frequency distributions, and grammatical marker analysis.
 */
object LanguageDetector {

    fun detectLanguage(text: String): DetectedLanguage {
        val trimmed = text.trim()
        if (trimmed.isEmpty()) {
            return DetectedLanguage("en", "English", 1.0f, "🇺🇸")
        }

        var bengaliCount = 0
        var arabicCount = 0
        var devanagariCount = 0
        var cjkCount = 0
        var hangulCount = 0
        var kanaCount = 0
        var cyrillicCount = 0
        var greekCount = 0
        var hebrewCount = 0
        var thaiCount = 0
        var latinCount = 0

        for (ch in trimmed) {
            when (ch) {
                in '\u0980'..'\u09FF' -> bengaliCount++
                in '\u0600'..'\u06FF', in '\u0750'..'\u077F' -> arabicCount++
                in '\u0900'..'\u097F' -> devanagariCount++
                in '\u4E00'..'\u9FFF' -> cjkCount++
                in '\uAC00'..'\uD7AF' -> hangulCount++
                in '\u3040'..'\u30FF' -> kanaCount++
                in '\u0400'..'\u04FF' -> cyrillicCount++
                in '\u0370'..'\u03FF' -> greekCount++
                in '\u0590'..'\u05FF' -> hebrewCount++
                in '\u0E00'..'\u0E7F' -> thaiCount++
                in 'a'..'z', in 'A'..'Z' -> latinCount++
            }
        }

        val totalChars = trimmed.length.toFloat()

        if (bengaliCount > 0 && bengaliCount.toFloat() / totalChars > 0.2f) {
            return DetectedLanguage("bn", "Bengali", (bengaliCount / totalChars).coerceIn(0.5f, 1.0f), "🇧🇩")
        }

        if (arabicCount > 0 && arabicCount.toFloat() / totalChars > 0.2f) {
            // Check for Persian/Urdu specifics
            val isUrdu = trimmed.contains("ہیں") || trimmed.contains("تھا") || trimmed.contains("کیا")
            return if (isUrdu) {
                DetectedLanguage("ur", "Urdu", 0.95f, "🇵🇰")
            } else {
                DetectedLanguage("ar", "Arabic", 0.95f, "🇸🇦")
            }
        }

        if (devanagariCount > 0 && devanagariCount.toFloat() / totalChars > 0.2f) {
            return DetectedLanguage("hi", "Hindi", 0.95f, "🇮🇳")
        }

        if (cjkCount > 0 && cjkCount.toFloat() / totalChars > 0.2f) {
            return DetectedLanguage("zh", "Chinese", 0.95f, "🇨🇳")
        }

        if (hangulCount > 0 && hangulCount.toFloat() / totalChars > 0.2f) {
            return DetectedLanguage("ko", "Korean", 0.95f, "🇰🇷")
        }

        if (kanaCount > 0 && kanaCount.toFloat() / totalChars > 0.2f) {
            return DetectedLanguage("ja", "Japanese", 0.95f, "🇯🇵")
        }

        if (cyrillicCount > 0 && cyrillicCount.toFloat() / totalChars > 0.2f) {
            return DetectedLanguage("ru", "Russian", 0.95f, "🇷🇺")
        }

        if (thaiCount > 0 && thaiCount.toFloat() / totalChars > 0.2f) {
            return DetectedLanguage("th", "Thai", 0.95f, "🇹🇭")
        }

        if (greekCount > 0 && greekCount.toFloat() / totalChars > 0.2f) {
            return DetectedLanguage("el", "Greek", 0.95f, "🇬🇷")
        }

        if (hebrewCount > 0 && hebrewCount.toFloat() / totalChars > 0.2f) {
            return DetectedLanguage("he", "Hebrew", 0.95f, "🇮🇱")
        }

        // Latin Sub-Classification
        val lower = trimmed.lowercase()

        // Banglish check
        val banglishTokens = listOf("kemon", "acho", "valo", "tumi", "ki", "korcho", "bhai", "amio", "hobe", "dada", "apni", "dhonnobad")
        val banglishMatches = banglishTokens.count { lower.contains(Regex("\\b$it\\b")) }
        if (banglishMatches >= 1) {
            return DetectedLanguage("bn", "Bengali (Banglish)", 0.92f, "🇧🇩")
        }

        // Spanish check
        val spanishTokens = listOf("el", "la", "de", "que", "y", "en", "un", "por", "para", "como", "hola", "gracias", "buenos")
        val spanishMatches = spanishTokens.count { lower.contains(Regex("\\b$it\\b")) }
        if (spanishMatches >= 2) {
            return DetectedLanguage("es", "Spanish", 0.90f, "🇪🇸")
        }

        // French check
        val frenchTokens = listOf("le", "la", "les", "des", "est", "un", "une", "pour", "dans", "avec", "bonjour", "merci")
        val frenchMatches = frenchTokens.count { lower.contains(Regex("\\b$it\\b")) }
        if (frenchMatches >= 2) {
            return DetectedLanguage("fr", "French", 0.90f, "🇫🇷")
        }

        // German check
        val germanTokens = listOf("der", "die", "das", "und", "ist", "in", "ein", "eine", "nicht", "hallo", "danke", "bitte")
        val germanMatches = germanTokens.count { lower.contains(Regex("\\b$it\\b")) }
        if (germanMatches >= 2) {
            return DetectedLanguage("de", "German", 0.90f, "🇩🇪")
        }

        // Default to English
        val target = GlobalLanguageCatalog.findByCode("en")
        return DetectedLanguage(target.code, target.name, 0.85f, target.flagEmoji)
    }
}
