package com.example.translation

import java.util.Locale

data class LanguageInfo(
    val code: String,
    val name: String,
    val nativeName: String,
    val flagEmoji: String,
    val region: String,
    val locale: Locale = Locale(code)
)

enum class VoiceAccent(
    val id: String,
    val displayName: String,
    val region: String,
    val flagEmoji: String,
    val locale: Locale
) {
    US_ENGLISH("en_US", "American English", "United States", "🇺🇸", Locale.US),
    UK_ENGLISH("en_GB", "British English", "United Kingdom", "🇬🇧", Locale.UK),
    INDIAN_ENGLISH("en_IN", "Indian English", "India", "🇮🇳", Locale("en", "IN")),
    AUSTRALIAN_ENGLISH("en_AU", "Australian English", "Australia", "🇦🇺", Locale("en", "AU")),
    CANADIAN_ENGLISH("en_CA", "Canadian English", "Canada", "🇨🇦", Locale.CANADA),
    BANGLADESH("bn_BD", "Bangladeshi Bengali", "Bangladesh", "🇧🇩", Locale("bn", "BD")),
    SPANISH_ES("es_ES", "Castilian Spanish", "Spain", "🇪🇸", Locale("es", "ES")),
    FRENCH_FR("fr_FR", "Metropolitan French", "France", "🇫🇷", Locale.FRANCE),
    GERMAN_DE("de_DE", "Standard German", "Germany", "🇩🇪", Locale.GERMANY),
    JAPANESE_JP("ja_JP", "Tokyo Japanese", "Japan", "🇯🇵", Locale.JAPAN),
    ARABIC_SA("ar_SA", "Modern Standard Arabic", "Middle East", "🇸🇦", Locale("ar", "SA"))
}

object GlobalLanguageCatalog {

    val ALL_LANGUAGES: List<LanguageInfo> = listOf(
        // Primary & South Asian
        LanguageInfo("en", "English", "English", "🇺🇸", "Global", Locale.US),
        LanguageInfo("bn", "Bengali", "বাংলা", "🇧🇩", "South Asia", Locale("bn", "BD")),
        LanguageInfo("hi", "Hindi", "हिन्दी", "🇮🇳", "South Asia", Locale("hi", "IN")),
        LanguageInfo("ur", "Urdu", "اردو", "🇵🇰", "South Asia", Locale("ur", "PK")),
        LanguageInfo("ta", "Tamil", "தமிழ்", "🇮🇳", "South Asia", Locale("ta", "IN")),
        LanguageInfo("te", "Telugu", "తెలుగు", "🇮🇳", "South Asia", Locale("te", "IN")),
        LanguageInfo("mr", "Marathi", "मराठी", "🇮🇳", "South Asia", Locale("mr", "IN")),
        LanguageInfo("gu", "Gujarati", "ગુજરાતી", "🇮🇳", "South Asia", Locale("gu", "IN")),
        LanguageInfo("kn", "Kannada", "ಕನ್ನಡ", "🇮🇳", "South Asia", Locale("kn", "IN")),
        LanguageInfo("ml", "Malayalam", "മലയാളം", "🇮🇳", "South Asia", Locale("ml", "IN")),
        LanguageInfo("pa", "Punjabi", "ਪੰਜਾਬੀ", "🇮🇳", "South Asia", Locale("pa", "IN")),
        LanguageInfo("ne", "Nepali", "नेपाली", "🇳🇵", "South Asia", Locale("ne", "NP")),
        LanguageInfo("si", "Sinhala", "සිංහල", "🇱🇰", "South Asia", Locale("si", "LK")),

        // East & Southeast Asia
        LanguageInfo("zh", "Chinese (Simplified)", "简体中文", "🇨🇳", "East Asia", Locale.SIMPLIFIED_CHINESE),
        LanguageInfo("zh-TW", "Chinese (Traditional)", "繁體中文", "🇹🇼", "East Asia", Locale.TRADITIONAL_CHINESE),
        LanguageInfo("ja", "Japanese", "日本語", "🇯🇵", "East Asia", Locale.JAPANESE),
        LanguageInfo("ko", "Korean", "한국어", "🇰🇷", "East Asia", Locale.KOREAN),
        LanguageInfo("vi", "Vietnamese", "Tiếng Việt", "🇻🇳", "Southeast Asia", Locale("vi", "VN")),
        LanguageInfo("th", "Thai", "ไทย", "🇹🇭", "Southeast Asia", Locale("th", "TH")),
        LanguageInfo("id", "Indonesian", "Bahasa Indonesia", "🇮🇩", "Southeast Asia", Locale("id", "ID")),
        LanguageInfo("ms", "Malay", "Bahasa Melayu", "🇲🇾", "Southeast Asia", Locale("ms", "MY")),
        LanguageInfo("fil", "Filipino", "Tagalog", "🇵🇭", "Southeast Asia", Locale("fil", "PH")),
        LanguageInfo("my", "Burmese", "မြန်မာဘာသာ", "🇲🇲", "Southeast Asia", Locale("my", "MM")),
        LanguageInfo("km", "Khmer", "ភាសាខ្មែរ", "🇰🇭", "Southeast Asia", Locale("km", "KH")),
        LanguageInfo("lo", "Lao", "ພາສາລາວ", "🇱🇦", "Southeast Asia", Locale("lo", "LA")),

        // Middle East & Central Asia
        LanguageInfo("ar", "Arabic", "العربية", "🇸🇦", "Middle East", Locale("ar", "SA")),
        LanguageInfo("fa", "Persian (Farsi)", "فارسی", "🇮🇷", "Middle East", Locale("fa", "IR")),
        LanguageInfo("tr", "Turkish", "Türkçe", "🇹🇷", "Middle East", Locale("tr", "TR")),
        LanguageInfo("he", "Hebrew", "עברית", "🇮🇱", "Middle East", Locale("he", "IL")),
        LanguageInfo("ku", "Kurdish", "Kurdî", "🇮🇶", "Middle East", Locale("ku")),
        LanguageInfo("ps", "Pashto", "پښتو", "🇦🇫", "Central Asia", Locale("ps")),
        LanguageInfo("uz", "Uzbek", "Oʻzbekcha", "🇺🇿", "Central Asia", Locale("uz")),
        LanguageInfo("kk", "Kazakh", "Қазақ тілі", "🇰🇿", "Central Asia", Locale("kk")),
        LanguageInfo("az", "Azerbaijani", "Azərbaycan", "🇦🇿", "Central Asia", Locale("az")),

        // Western & Southern Europe
        LanguageInfo("es", "Spanish", "Español", "🇪🇸", "Europe", Locale("es", "ES")),
        LanguageInfo("fr", "French", "Français", "🇫🇷", "Europe", Locale.FRANCE),
        LanguageInfo("de", "German", "Deutsch", "🇩🇪", "Europe", Locale.GERMANY),
        LanguageInfo("it", "Italian", "Italiano", "🇮🇹", "Europe", Locale.ITALIAN),
        LanguageInfo("pt", "Portuguese", "Português", "🇵🇹", "Europe", Locale("pt", "PT")),
        LanguageInfo("nl", "Dutch", "Nederlands", "🇳🇱", "Europe", Locale("nl", "NL")),
        LanguageInfo("el", "Greek", "Ελληνικά", "🇬🇷", "Europe", Locale("el", "GR")),

        // Northern & Eastern Europe
        LanguageInfo("ru", "Russian", "Русский", "🇷🇺", "Eastern Europe", Locale("ru", "RU")),
        LanguageInfo("uk", "Ukrainian", "Українська", "🇺🇦", "Eastern Europe", Locale("uk", "UA")),
        LanguageInfo("pl", "Polish", "Polski", "🇵🇱", "Eastern Europe", Locale("pl", "PL")),
        LanguageInfo("cs", "Czech", "Čeština", "🇨🇿", "Eastern Europe", Locale("cs", "CZ")),
        LanguageInfo("sk", "Slovak", "Slovenčina", "🇸🇰", "Eastern Europe", Locale("sk", "SK")),
        LanguageInfo("hu", "Hungarian", "Magyar", "🇭🇺", "Eastern Europe", Locale("hu", "HU")),
        LanguageInfo("ro", "Romanian", "Română", "🇷🇴", "Eastern Europe", Locale("ro", "RO")),
        LanguageInfo("bg", "Bulgarian", "Български", "🇧🇬", "Eastern Europe", Locale("bg", "BG")),
        LanguageInfo("hr", "Croatian", "Hrvatski", "🇭🇷", "Eastern Europe", Locale("hr", "HR")),
        LanguageInfo("sr", "Serbian", "Српски", "🇷🇸", "Eastern Europe", Locale("sr", "RS")),
        LanguageInfo("sv", "Swedish", "Svenska", "🇸🇪", "Northern Europe", Locale("sv", "SE")),
        LanguageInfo("da", "Danish", "Dansk", "🇩🇰", "Northern Europe", Locale("da", "DK")),
        LanguageInfo("no", "Norwegian", "Norsk", "🇳🇴", "Northern Europe", Locale("no", "NO")),
        LanguageInfo("fi", "Finnish", "Suomi", "🇫🇮", "Northern Europe", Locale("fi", "FI")),
        LanguageInfo("et", "Estonian", "Eesti", "🇪🇪", "Northern Europe", Locale("et", "EE")),
        LanguageInfo("lv", "Latvian", "Latviešu", "🇱🇻", "Northern Europe", Locale("lv", "LV")),
        LanguageInfo("lt", "Lithuanian", "Lietuvių", "🇱🇹", "Northern Europe", Locale("lt", "LT")),

        // Africa
        LanguageInfo("sw", "Swahili", "Kiswahili", "🇰🇪", "Africa", Locale("sw")),
        LanguageInfo("am", "Amharic", "አማርኛ", "🇪🇹", "Africa", Locale("am")),
        LanguageInfo("ha", "Hausa", "Hausa", "🇳🇬", "Africa", Locale("ha")),
        LanguageInfo("yo", "Yoruba", "Èdè Yorùbá", "🇳🇬", "Africa", Locale("yo")),
        LanguageInfo("ig", "Igbo", "Asụsụ Igbo", "🇳🇬", "Africa", Locale("ig")),
        LanguageInfo("zu", "Zulu", "isiZulu", "🇿🇦", "Africa", Locale("zu")),
        LanguageInfo("xh", "Xhosa", "isiXhosa", "🇿🇦", "Africa", Locale("xh")),
        LanguageInfo("af", "Afrikaans", "Afrikaans", "🇿🇦", "Africa", Locale("af")),
        LanguageInfo("so", "Somali", "Soomaali", "🇸🇴", "Africa", Locale("so")),
        LanguageInfo("mg", "Malagasy", "Malagasy", "🇲🇬", "Africa", Locale("mg")),

        // Americas & Oceanic
        LanguageInfo("pt-BR", "Portuguese (Brazil)", "Português do Brasil", "🇧🇷", "Americas", Locale("pt", "BR")),
        LanguageInfo("es-MX", "Spanish (Mexico)", "Español Mexicano", "🇲🇽", "Americas", Locale("es", "MX")),
        LanguageInfo("es-AR", "Spanish (Argentina)", "Español Argentino", "🇦🇷", "Americas", Locale("es", "AR")),
        LanguageInfo("haw", "Hawaiian", "ʻŌlelo Hawaiʻi", "🌺", "Oceania", Locale("haw")),
        LanguageInfo("sm", "Samoan", "Gagana Sāmoa", "🇼🇸", "Oceania", Locale("sm")),
        LanguageInfo("mi", "Maori", "Te Reo Māori", "🇳🇿", "Oceania", Locale("mi")),

        // Classical & International
        LanguageInfo("la", "Latin", "Latīna", "🏛️", "Classical", Locale("la")),
        LanguageInfo("eo", "Esperanto", "Esperanto", "🌐", "Constructed", Locale("eo")),
        LanguageInfo("cy", "Welsh", "Cymraeg", "🏴󠁧󠁢󠁷󠁬󠁳󠁿", "Europe", Locale("cy")),
        LanguageInfo("ga", "Irish", "Gaeilge", "🇮🇪", "Europe", Locale("ga", "IE")),
        LanguageInfo("gd", "Scottish Gaelic", "Gàidhlig", "🏴󠁧󠁢󠁳󠁣󠁴󠁿", "Europe", Locale("gd")),
        LanguageInfo("eu", "Basque", "Euskara", "🇪🇸", "Europe", Locale("eu")),
        LanguageInfo("ca", "Catalan", "Català", "🇪🇸", "Europe", Locale("ca")),
        LanguageInfo("gl", "Galician", "Galego", "🇪🇸", "Europe", Locale("gl")),
        LanguageInfo("is", "Icelandic", "Íslenska", "🇮🇸", "Europe", Locale("is", "IS")),
        LanguageInfo("sq", "Albanian", "Shqip", "🇦🇱", "Europe", Locale("sq", "AL")),
        LanguageInfo("mk", "Macedonian", "Македонски", "🇲🇰", "Europe", Locale("mk", "MK")),
        LanguageInfo("bs", "Bosnian", "Bosanski", "🇧🇦", "Europe", Locale("bs")),
        LanguageInfo("sl", "Slovenian", "Slovenščina", "🇸🇮", "Europe", Locale("sl", "SI")),
        LanguageInfo("hy", "Armenian", "Հայերեն", "🇦🇲", "Caucasus", Locale("hy", "AM")),
        LanguageInfo("ka", "Georgian", "ქართული", "🇬🇪", "Caucasus", Locale("ka", "GE")),
        LanguageInfo("mn", "Mongolian", "Монгол хэл", "🇲🇳", "Central Asia", Locale("mn", "MN")),
        LanguageInfo("bo", "Tibetan", "བོད་སྐད་", "🏔️", "Central Asia", Locale("bo")),
        LanguageInfo("ky", "Kyrgyz", "Кыргызча", "🇰🇬", "Central Asia", Locale("ky")),
        LanguageInfo("tg", "Tajik", "Тоҷикӣ", "🇹🇯", "Central Asia", Locale("tg")),
        LanguageInfo("tt", "Tatar", "Татарча", "🇷🇺", "Central Asia", Locale("tt")),
        LanguageInfo("ug", "Uyghur", "ئۇيغۇرچە", "🌐", "Central Asia", Locale("ug")),
        LanguageInfo("sd", "Sindhi", "سنڌي", "🇵🇰", "South Asia", Locale("sd")),
        LanguageInfo("or", "Odia", "ଓଡ଼ିଆ", "🇮🇳", "South Asia", Locale("or", "IN")),
        LanguageInfo("as", "Assamese", "অসমীয়া", "🇮🇳", "South Asia", Locale("as", "IN")),
        LanguageInfo("dv", "Dhivehi", "ދިވެހި", "🇲🇻", "South Asia", Locale("dv")),
        LanguageInfo("sn", "Shona", "chiShona", "🇿🇼", "Africa", Locale("sn")),
        LanguageInfo("st", "Sesotho", "Sesotho", "🇱🇸", "Africa", Locale("st")),
        LanguageInfo("rw", "Kinyarwanda", "Ikinyarwanda", "🇷🇼", "Africa", Locale("rw")),
        LanguageInfo("lg", "Ganda (Luganda)", "Oluganda", "🇺🇬", "Africa", Locale("lg")),
        LanguageInfo("ny", "Nyanja (Chichewa)", "Chichewa", "🇲🇼", "Africa", Locale("ny")),
        LanguageInfo("ceb", "Cebuano", "Bisaya", "🇵🇭", "Southeast Asia", Locale("ceb")),
        LanguageInfo("jv", "Javanese", "Basa Jawa", "🇮🇩", "Southeast Asia", Locale("jv")),
        LanguageInfo("su", "Sundanese", "Basa Sunda", "🇮🇩", "Southeast Asia", Locale("su")),
        LanguageInfo("mt", "Maltese", "Malti", "🇲🇹", "Europe", Locale("mt", "MT")),
        LanguageInfo("lb", "Luxembourgish", "Lëtzebuergesch", "🇱🇺", "Europe", Locale("lb", "LU"))
    )

    fun findByCode(code: String): LanguageInfo {
        return ALL_LANGUAGES.firstOrNull { it.code.equals(code, ignoreCase = true) }
            ?: ALL_LANGUAGES.first { it.code == "en" }
    }
}
