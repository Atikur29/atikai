package com.example

import com.example.python.PythonSandboxEngine
import com.example.terminal.TerminalSandboxEngine
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class SandboxEnginesTest {

    private val pythonEngine = PythonSandboxEngine()
    private val terminalEngine = TerminalSandboxEngine(pythonEngine)

    @Test
    fun testPythonBasicExecution() = runBlocking {
        val code = """
            x = 10
            y = 20
            print("SUM:", x + y)
        """.trimIndent()

        val result = pythonEngine.execute(code)
        assertTrue(result.success)
        assertTrue(result.output.contains("SUM: 30"))
        assertTrue(result.isSandboxed)
    }

    @Test
    fun testPythonLoopCalculation() = runBlocking {
        val code = """
            total = 0
            for i in range(1, 5):
                total = total + i
            print("TOTAL:", total)
        """.trimIndent()

        val result = pythonEngine.execute(code)
        assertTrue(result.success)
        assertTrue(result.output.contains("TOTAL: 10"))
    }

    @Test
    fun testPythonDangerousKeywordsBlocked() = runBlocking {
        val dangerousCode = """
            import os
            os.system("rm -rf /")
        """.trimIndent()

        val result = pythonEngine.execute(dangerousCode)
        assertFalse(result.success)
        assertTrue(result.error?.contains("Security Policy Error") == true)
    }

    @Test
    fun testTerminalBasicCommands() = runBlocking {
        val pwdLines = terminalEngine.executeCommand("pwd")
        assertTrue(pwdLines.any { it.text.contains("/home/atik") })

        val whoamiLines = terminalEngine.executeCommand("whoami")
        assertTrue(whoamiLines.any { it.text.contains("atik") })

        val helpLines = terminalEngine.executeCommand("help")
        assertTrue(helpLines.any { it.text.contains("Sandbox Help") })
    }

    @Test
    fun testTerminalDirectoryNavigation() = runBlocking {
        terminalEngine.executeCommand("mkdir projects")
        terminalEngine.executeCommand("cd projects")
        assertEquals("/home/atik/projects", terminalEngine.getCurrentDir())

        terminalEngine.executeCommand("cd ..")
        assertEquals("/home/atik", terminalEngine.getCurrentDir())
    }

    @Test
    fun testAvailableModelsConfig() {
        val models = com.example.ai.AVAILABLE_MODELS
        assertTrue(models.any { it.id == "gemini-3.8-flash" })
        assertTrue(models.any { it.id == "gemini-3.1-pro-preview" })
        assertTrue(models.any { it.id == "gemini-3.8-live" })
    }

    @Test
    fun testTechKnowledgeEngineSuggestions() {
        val chips = com.example.knowledge.TechKnowledgeEngine.QUICK_SUGGESTION_CHIPS
        assertTrue(chips.any { it.label.contains("Earning Ideas") })
        assertTrue(chips.any { it.label.contains("App Dev") || it.label.contains("App Development") })
        assertTrue(chips.any { it.label.contains("AI Tools Masterclass") })
        assertTrue(chips.any { it.label.contains("Freelancing Roadmap") })
        assertTrue(chips.any { it.label.contains("Safe Tech") })
    }

    @Test
    fun testGeneratedImagesAndSettingsEntity() {
        val image = com.example.data.GeneratedImageEntity(
            id = "test-img-1",
            prompt = "Cyberpunk warrior",
            imageUrl = "https://image.pollinations.ai/prompt/cyberpunk",
            sessionId = "session-1"
        )
        assertEquals("test-img-1", image.id)
        assertEquals("Cyberpunk warrior", image.prompt)

        val setting = com.example.data.UserSettingEntity(
            key = "pref_language_mode",
            value = "ENGLISH"
        )
        assertEquals("pref_language_mode", setting.key)
        assertEquals("ENGLISH", setting.value)
    }

    @Test
    fun testTechKnowledgeEngineSearch() {
        val searchEarning = com.example.knowledge.TechKnowledgeEngine.searchTopics("Earning")
        assertTrue(searchEarning.isNotEmpty())
        val searchKotlin = com.example.knowledge.TechKnowledgeEngine.searchTopics("Kotlin")
        assertTrue(searchKotlin.isNotEmpty())
        val searchSafe = com.example.knowledge.TechKnowledgeEngine.searchTopics("Cyber")
        assertTrue(searchSafe.isNotEmpty())
    }

    @Test
    fun testSmartMemoryEntities() {
        val memory = com.example.data.MemoryEntity(
            id = 1,
            key = "Owner",
            value = "Atikur Rahman",
            category = "Profile"
        )
        assertEquals("Owner", memory.key)
        assertEquals("Atikur Rahman", memory.value)
        assertEquals("Profile", memory.category)

        val session = com.example.data.ChatSessionEntity(
            id = "test-session-123",
            title = "Earning Roadmap Discussion"
        )
        assertEquals("test-session-123", session.id)
        assertEquals("Earning Roadmap Discussion", session.title)
    }
}
