package com.example

import com.example.ai.ImageGenerationEngine
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ExampleUnitTest {

    @Test
    fun addition_isCorrect() {
        assertEquals(4, 2 + 2)
    }

    @Test
    fun imageGenerationEngine_buildsValidUrl() {
        val engine = ImageGenerationEngine()
        val prompt = "a cybernetic warrior in neon armor"
        val url = engine.buildImageUrl(prompt, width = 1024, height = 1024, model = "flux", seed = 12345L)

        assertTrue(url.startsWith("https://image.pollinations.ai/prompt/"))
        assertTrue(url.contains("cybernetic"))
        assertTrue(url.contains("width=1024"))
        assertTrue(url.contains("height=1024"))
        assertTrue(url.contains("model=flux"))
        assertTrue(url.contains("seed=12345"))
    }

    @Test
    fun promptExtraction_handlesVariousPrefixes() {
        val testCases = listOf(
            "Create an image of a cybernetic warrior" to "a cybernetic warrior",
            "Generate an image of sunset over mountains" to "sunset over mountains",
            "Draw a majestic dragon" to "majestic dragon",
            "Create an image: cyberpunk city" to "cyberpunk city"
        )

        val prefixes = listOf(
            "create an image of", "create an image", "create image of", "create image",
            "generate an image of", "generate an image", "generate image of", "generate image",
            "draw a picture of", "draw an image of", "draw an image", "draw a", "draw ",
            "paint an image of", "paint a picture of", "paint ",
            "make an image of", "make an image",
            "picture of", "image of"
        )

        for ((input, expected) in testCases) {
            var clean = input.trim()
            for (p in prefixes) {
                if (clean.lowercase().startsWith(p)) {
                    clean = clean.substring(p.length).trim()
                    break
                }
            }
            clean = clean.removePrefix(":").removePrefix("-").removePrefix("for").removePrefix("about").trim()
            assertEquals(expected, clean)
        }
    }

    @Test
    fun dynamicThemeVoiceParser_recognizesPredefinedThemes() {
        val vintage = com.example.ui.theme.DynamicThemeVoiceParser.parseThemeCommand("Switch to vintage 80s theme please")
        assertTrue(vintage is com.example.ui.theme.ThemeCommandResult.PresetChange)
        assertEquals(com.example.ui.theme.ThemePreset.VINTAGE_80S, (vintage as com.example.ui.theme.ThemeCommandResult.PresetChange).preset)

        val cyberpunk = com.example.ui.theme.DynamicThemeVoiceParser.parseThemeCommand("আতিক, সাইবারপাঙ্ক থিম চালু করো")
        assertTrue(cyberpunk is com.example.ui.theme.ThemeCommandResult.PresetChange)
        assertEquals(com.example.ui.theme.ThemePreset.CYBERPUNK, (cyberpunk as com.example.ui.theme.ThemeCommandResult.PresetChange).preset)

        val amoled = com.example.ui.theme.DynamicThemeVoiceParser.parseThemeCommand("Turn on amoled pitch black mode")
        assertTrue(amoled is com.example.ui.theme.ThemeCommandResult.PresetChange)
        assertEquals(com.example.ui.theme.ThemePreset.AMOLED_DARK, (amoled as com.example.ui.theme.ThemeCommandResult.PresetChange).preset)

        val minimal = com.example.ui.theme.DynamicThemeVoiceParser.parseThemeCommand("Set minimal light mode")
        assertTrue(minimal is com.example.ui.theme.ThemeCommandResult.PresetChange)
        assertEquals(com.example.ui.theme.ThemePreset.MINIMAL_LIGHT, (minimal as com.example.ui.theme.ThemeCommandResult.PresetChange).preset)

        val futuristic = com.example.ui.theme.DynamicThemeVoiceParser.parseThemeCommand("নিয়ন থিম সেট করো")
        assertTrue(futuristic is com.example.ui.theme.ThemeCommandResult.PresetChange)
        assertEquals(com.example.ui.theme.ThemePreset.FUTURISTIC_NEON, (futuristic as com.example.ui.theme.ThemeCommandResult.PresetChange).preset)
    }

    @Test
    fun dynamicThemeVoiceParser_recognizesButtonAndFontStyles() {
        val buttonPill = com.example.ui.theme.DynamicThemeVoiceParser.parseThemeCommand("Change button style to pill")
        assertTrue(buttonPill is com.example.ui.theme.ThemeCommandResult.ButtonStyleChange)
        assertEquals(com.example.ui.theme.AppButtonStyle.PILL_MODERN, (buttonPill as com.example.ui.theme.ThemeCommandResult.ButtonStyleChange).style)

        val fontLarge = com.example.ui.theme.DynamicThemeVoiceParser.parseThemeCommand("Make font size large")
        assertTrue(fontLarge is com.example.ui.theme.ThemeCommandResult.FontScaleChange)
        assertEquals(1.15f, (fontLarge as com.example.ui.theme.ThemeCommandResult.FontScaleChange).scale, 0.01f)
    }

    @Test
    fun dynamicThemeState_roomEntityConversion_roundtripsCorrectly() {
        val state = com.example.ui.theme.DynamicThemeState(
            preset = com.example.ui.theme.ThemePreset.CYBERPUNK,
            accentColorHex = "#FFE600",
            buttonStyle = com.example.ui.theme.AppButtonStyle.ANGULAR_TECH,
            fontScale = 1.15f,
            backgroundWidget = com.example.ui.theme.BackgroundWidgetType.SYNTHWAVE_SUNSET
        )
        val entity = state.toEntity()
        val restored = com.example.ui.theme.DynamicThemeState.fromEntity(entity)

        assertEquals(com.example.ui.theme.ThemePreset.CYBERPUNK, restored.preset)
        assertEquals("#FFE600", restored.accentColorHex)
        assertEquals(com.example.ui.theme.AppButtonStyle.ANGULAR_TECH, restored.buttonStyle)
        assertEquals(1.15f, restored.fontScale, 0.01f)
        assertEquals(com.example.ui.theme.BackgroundWidgetType.SYNTHWAVE_SUNSET, restored.backgroundWidget)
    }

    @Test
    fun gameTemplate_resolvesKeywordsInMultipleLanguages() {
        val ludo = com.example.game.GameTemplateType.fromPrompt("আতিক, একটি লুডু গেম বানাও")
        assertEquals(com.example.game.GameTemplateType.LUDO_MINI, ludo)

        val racing = com.example.game.GameTemplateType.fromPrompt("Generate high speed car racing game")
        assertEquals(com.example.game.GameTemplateType.TURBO_RACER, racing)

        val flappy = com.example.game.GameTemplateType.fromPrompt("Make a flappy bird game with neon graphics")
        assertEquals(com.example.game.GameTemplateType.CYBER_FLAP, flappy)

        val space = com.example.game.GameTemplateType.fromPrompt("মহাকাশ স্পেস শুটার গেম খেলবো")
        assertEquals(com.example.game.GameTemplateType.COSMIC_INVADERS, space)

        val brick = com.example.game.GameTemplateType.fromPrompt("Create arkanoid brick breaker paddle game")
        assertEquals(com.example.game.GameTemplateType.NEON_ARKANOID, brick)

        val snake = com.example.game.GameTemplateType.fromPrompt("Play cyber matrix snake arcade")
        assertEquals(com.example.game.GameTemplateType.MATRIX_SNAKE, snake)
    }

    @Test
    fun gameTemplates_generateValidHtml5AndCanvas() {
        com.example.game.GameTemplateType.values().forEach { template ->
            val html = com.example.game.GameTemplates.getTemplateHtml(template)
            assertTrue(html.contains("<!DOCTYPE html>"))
            assertTrue(html.contains("<canvas id=\"gameCanvas\"></canvas>"))
            assertTrue(html.contains("AndroidBridge"))
            assertTrue(html.contains("requestAnimationFrame"))
        }
    }

    @Test
    fun gameProjectEntity_storesGameStateAndScore() {
        val entity = com.example.data.GameProjectEntity(
            id = "test_game_1",
            title = "Test Racer",
            genre = "Racing",
            prompt = "make racing game",
            htmlContent = "<html></html>",
            highScore = 450,
            playCount = 3,
            gameStateJson = "{\"level\": 2, \"nitro\": 80}"
        )
        assertEquals(450, entity.highScore)
        assertEquals(3, entity.playCount)
        assertEquals("{\"level\": 2, \"nitro\": 80}", entity.gameStateJson)
    }
}
